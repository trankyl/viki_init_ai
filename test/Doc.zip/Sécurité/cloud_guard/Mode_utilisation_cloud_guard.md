
## Sommaire   

* [Présentation de Cloud Guard](#présentation-de-cloud-guard)
* [Quelques tableaux de bord dans Cloud Guard](#quelques-tableaux-de-bord-dans-cloud-guard)
* [Lexique Cloud Guard](https://docs.oracle.com/fr-ca/iaas/cloud-guard/using/cg-concepts.htm#cg-concepts)
* [Préalables pour activation de Cloud Guard](#préalables-pour-activation-de-cloud-guard)
* [Tarification de Cloud Guard](#tarification-de-cloud-guard)   
* [Bonnes pratiques pour optimiser l'utilisation de Cloud Guard](#bonnes-pratiques-pour-optimiser-utilisation-de-cloud-guard)
* [Scénario 1 : Comment intégrer les problèmes et résolutions Cloud Guard à votre outil SIEM](#scénario-1--comment-intégrer-les-problèmes-et-résolutions-cloud-guard-à-votre-outil-siem)   
  * [Étape 1 : Déploiement de la zone Accueil OCI et activation de Cloud Guard](#étape-1--déploiement-de-la-zone-accueil-oci-et-activation-de-cloud-guard)
  * [Étape 2 : Accès au service Cloud Guard](#étape-2--accès-au-service-cloud-guard)
  * [Étape 3 : Configuration des cibles dans Cloud Guard](#étape-3--configuration-des-cibles-dans-cloud-guard)
  * [Étape 4 : Activation règle d’événement cloud dans la recette du répondeur Cloud Guard](#étape-4--activation-règle-événement-cloud-dans-la-recette-du-répondeur-cloud-guard)
  * [Étape 5  : Déploiement API Python pour envoyer des journaux Cloud Guard à un SIEM](#étape-5--déploiement-api-python-pour-envoyer-les-journaux-cloud-guard-à-un-siem)
* [Scénario 2 : Posture de sécurité et remédiation dans votre zone d'accueil OCI](#scénario-2--posture-de-sécurité-et-remédiation-dans-votre-zone-accueil-oci)  
  * [Déploiement zone accueil OCI et activation de la surveillance Cloud Guard](#déploiement-zone-accueil-oci-et-activation-de-la-surveillance-cloud-guard) 
  * [Apercu des indicateurs relatifs à la surveillance Cloud GUard sur votre zone accueil OCI](#apercu-des-indicateurs-relatifs-à-la-surveillance-cloud-guard-sur-votre-zone-accueil-oci)
  * [Simulation menace dans la zone accueil OCI](#simulation-menace-dans-la-zone-accueil-oci)
  * [Remédiation du problème](#remédiation-bucket-anormalement-public)
* [Limites de Cloud Guard](https://docs.oracle.com/fr-fr/iaas/Content/General/Concepts/servicelimits.htm#Cloud_Guard_Limits)
* [Foire aux questions sur Cloud Guard](https://www.oracle.com/ca-fr/security/cloud-security/cloud-guard/faq/)
* [Retour à la Page d'Accueil](../../README.md)  

## Présentation de Cloud Guard   

Cloud Guard est un service Oracle Cloud Infrastructure qui fournit un tableau de bord central permettant de surveiller des ressources cloud (```cible/target```) afin de détecter (```détecteur/detector```) les failles de sécurité dans la configuration, les mesures et les journaux. Lorsqu'il détecte un ```problème/problem```, il peut faire des suggestions, proposer une assistance ou effectuer des actions correctives (```répondant/responder```), en fonction de votre configuration (```recette/recipe```) Cloud Guard.   

Le schéma ci-dessous illustre un scénario de fonctionnement de Cloud Guard.   

![exemple_fonctionnement_cloud_guard](../../images/cloud_guard_oci/exemple_fonctionnement_cloud_guard.JPG)   

Source :   https://www.youtube.com/watch?v=WrEBDKJxSjo   
   

## Quelques tableaux de bord dans Cloud Guard

Vue d'ensemble de quelques tableaux de board dans Cloud Guard   


![vue_ensemble_dashboard_cloud_guard](../../images/cloud_guard_oci/vue_ensemble_dashboard_cloud_guard.JPG)   


## Préalables pour activation de Cloud Guard  

### Avoir une location payante   

Le service de Cloud Guard n'est pas disponible pour les locations Oracle Cloud Infrastructure gratuites. Avant d'essayer d'activer le service Protection Cloud Guard, assurez-vous que :   

* Vous avez une location payante.   
* Votre type de compte de location est l'un des suivants :   
  * default_dbaas   
  * enterprise_dbaas   
  * entreprise   

### Créer un groupe utilisateurs du service de protection Cloud Guard   

Pour permettre aux utilisateurs de travailler avec le service Cloud Guard, créez un groupe d'utilisateurs avec des privilèges d'administrateur.   

Le service Cloud Guard traite les informations de sécurité globalement et devrait être accessible à un public restreint.   

Suivre les étapes suivantes pour créer manuellement ce groupe d'utilisateurs : https://docs.oracle.com/fr-ca/iaas/cloud-guard/using/prerequisites.htm#prereq-user-group   

Puis ajouter dans le groupe créé , les utilisateurs autorisées a utiliser le service Cloud Guard   

### Avoir un privilege IAM cloud-guard-family   

Le groupe utilisateurs créé ci-dessus doit avoir les privilèges IAM suivant :    

    allow group <group> to manage cloud-guard-family in tenancy     

Avec cette politique en place, les personnes que vous ajoutez au groupe d'utilisateurs du service Cloud Guard sont maintenant prêtes à poursuivre l'activation et les options de survaillance Cloud Guard.

## Tarification de Cloud Guard   

Le service Cloud Guard est **gratuit**.  

La mise en place de la configuration et les options de surveillance Cloud Guard pour votre zone d'accueil est gratuite.  

L'activité OCI de surveillance sur toutes les ressources OCI dans votre zone d'accueil est aussi gratuite.  

Référence : https://www.oracle.com/ca-fr/security/cloud-security/pricing/  

## Bonnes pratiques pour optimiser utilisation de Cloud Guard   


En tant que propriétaire du locataire, vous êtes responsable de la gestion des configurations de sécurité, de la surveillance des modifications et de la correction des problèmes de sécurité. Cloud Guard vous aide en examinant les ressources de votre location OCI, en détectant les failles de sécurité liées à la configuration et à l’activité administrative, et en activant la remédiation automatisée.

Veuillez consulter le document suivant pour plus de recommandations : https://docs.oracle.com/fr-ca/iaas/cloud-guard/using/part-start.htm#cg-start-planning

### Scénario 1 : Comment intégrer les problèmes et résolutions Cloud Guard à votre outil SIEM

La plupart des clients souhaitent que la surveillance de la sécurité du cloud s'intègre aux processus, procédures et personnes existants. De nombreuses équipes InfoSec intégreront les problèmes Cloud Guard à leurs outils SIEM internes pour relier les problèmes Cloud Guard à leurs processus internes.    

Cloud Guard ne fournit pas d'intégration SIEM directe. Les clients peuvent utiliser des fonctions et des événements OCI tels que le service de notification, le service de fonction et d'autres pour intégrer Cloud Guard à un SIEM tiers.   

Ces intégrations peuvent utiliser les API Cloud Guard et/ou les services d'infrastructure OCI existants tels qu'OCI Events, OCI Notifications, et OCI Functions. Les clients peuvent utiliser Events to OCI Functions pour créer des réponses ou une intégration personnalisées en fonction de leurs besoins d'affaire.   


Les étapes suivantes illustrent le cas d'utilisation que nous allons présenter :


Problème identifié par Cloud Guard ==> Événement ==> Fonction sans serveur ==> Application SIEM     

Résolution de Cloud Guard ==> Événement ==> Fonction sans serveur ==> Application SIEM   

Lorsque Cloud Guard émet des événements qui correspondent aux conditions de règle définies, le service Événements OCI déclenche la fonction spécifiée. Lorsqu’il est appelé, le code de la fonction lit les données des journaux à partir d’événements et les envoie au point de terminaison de l’API de chargement du SIEM. Nous pouvons ensuite afficher les journaux à partir du tableau de bord de l’Explorateur de journaux et les traiter pour d’autres visualisations et informations.

#### Recette pour la mise en place du scénario

1. Déploiement de la zone Accueil OCI et activation de Cloud Guard   
2. Accès au service Cloud Guard   
3. Configuration  des cibles dans Cloud Guard   
4. Activation règle d’événement cloud dans la recette du répondeur Cloud Guard   
5. Déploiement API Python pour envoyer des journaux Cloud Guard à un SIEM   


#### Étape 1 : Déploiement de la zone Accueil OCI et activation de Cloud Guard    

Suivre la [recette suivante](../../Déploiement/Deploi_Script.md) pour déployer une Zone d'Accueil OCI.

À l'[étape 14](../../Déploiement/Deploi_Script.md#notification-et-posture-de-sécurité), lors de la configuration de la pile de déploiement , assurez vous que le service Cloud Guard est activé en choisissant le statut **ENABLE** dans le champ **État de la configuration de Cloud Guard**.   

![Connecter_réseaux](../../images/DP_Ecran14.png)   

Une fois la zone d'accueil OCI déployée, Le service Cloud Guard est activé et commence à fonctionner.   


**Nota Bene 1** : Afin de respecter les [préalables](#préalables-pour-activation-de-cloud-guard) pour l'activation du service Cloud Guard , le script Terraform déploie automatiquement des groupes utilisateurs , des stratégies Cloud Guard et des stratégies IAM pour le service Cloud Guard.    

**Nota Bene 2** : Dans le script [config\locals.tf](/config/locals.tf) , la variable  **cloud_guard_statements** contient la liste des stratégies Cloud Guard déployées dans une zone d'accueil OCI :

     cloud_guard_statements = ["Allow service cloudguard to read keys in tenancy",
                            "Allow service cloudguard to read compartments in tenancy",
                            "Allow service cloudguard to read tenancies in tenancy",
                            "Allow service cloudguard to read audit-events in tenancy",
                            "Allow service cloudguard to read compute-management-family in tenancy",
                            "Allow service cloudguard to read instance-family in tenancy",
                            "Allow service cloudguard to read virtual-network-family in tenancy",
                            "Allow service cloudguard to read volume-family in tenancy",
                            "Allow service cloudguard to read database-family in tenancy",
                            "Allow service cloudguard to read object-family in tenancy",
                            "Allow service cloudguard to read load-balancers in tenancy",
                            "Allow service cloudguard to read users in tenancy",
                            "Allow service cloudguard to read groups in tenancy",
                            "Allow service cloudguard to read policies in tenancy",
                            "Allow service cloudguard to read dynamic-groups in tenancy",
                            "Allow service cloudguard to read authentication-policies in tenancy",
                            "Allow service cloudguard to use network-security-groups in tenancy"]   

**Nota Bene 2** : Le script [modules\monitoring\cloud-guard\main.tf](../../../modules/monitoring/cloud-guard/main.tf) lance le déploiement de votre configuration Cloud Guard ( espace de surveillance , règles de surveillance / détecteurs géré par OCI , répondants / actions à faire par défaut par OCI ).   

Afin de mieux répondre aux besoins spécifiques de votre environnement , vous devez poursuivre la configuration de votre zone d'accueil , en prcisant la configuration des détecteurs et des répondants .

* [Retour au Sommaire](#sommaire)   

#### Étape 2 : Accès au service Cloud Guard

Dans la console Oracle Cloud , sous le menu, sélectionnez **Identité et sécurité**, **Cloud Guard**, puis **Cibles**.   

Une nouvelle page web **Cibles** s'affiche   

![lancement_cloud_guard](../../images/cloud_guard_oci/scenario1/lancement_cloud_guard.JPG)   

* [Retour au Sommaire](#sommaire)   

#### Étape 3 : Configuration des cibles dans Cloud Guard

Les cibles définissent la portée des ressources qui doivent être surveillées par Cloud Guard   

Nous allons lancer la surveillance sur notre zone d'accueil précédemment [déployée](#étape-1--déploiement-de-la-zone-accueil-oci-et-activation-de-cloud-guard).

* Dans le panneau à gauche , dans la section Portée, sélectionner le compartiment qui doit être surveillé par Cloud Guard   

* Cocher la case **Inclure les compartiments enfants** , afin de surveiller les sous-compartiments.   

* Cliquer sur le bouton **Créer une cible**   

Une fenêtre modale s'affiche   

![creation_cible_cloudguard](../../images/cloud_guard_oci/scenario1/creation_cible_cloudguard.JPG)   

* Saisir le nom de la cible   
* Saisir éventuellement une description de la surveillance

Pour les règles de surveillance , nous n'allons pas ajouter des règles personnalisées , mais réutiliser les règles proposées par défaut par Oracle  

* Définir la recette des détecteurs dans Cloud Guard   

Les détecteurs définissent les règles qui déterminent les activités et les configurations que le service Cloud Guard identifie comme des problèmes.   

Nous avons sélectionné les recettes par défaut de Oracle. Ces règles ont la mention **Géré par Oracle** 

* Définir la recette du répondant dans Cloud Guard   

Les [répondants](https://docs.oracle.com/fr-ca/iaas/cloud-guard/using/respond-recipes-about.htm#respond-recipes-about) précisent les actions que le service Cloud Guard peut effectuer lorsqu'un détecteur a identifié un problème.      

Nous avons sélectionné le répondant géré par Oracle. Ce répondant a la mention **Géré par Oracle** 


* Puis cliquer sur le bouton **Créer**

Le système affiche la page web **Détails de la cible**   

![cible_cloudguard_creee](../../images/cloud_guard_oci/scenario1/cible_cloudguard_creee.JPG)   

Suite à la configuration ci-dessus , voici la liste des actions que le répondant géré par Oracle fera en cas problèmes dans la zone d'accueil cmp-ceiza-cloudguard :   

![regles_de_repondeur](../../images/cloud_guard_oci/scenario1/regles_de_repondeur.JPG)   


#### Étape 4 : Activation règle événement cloud dans la recette du répondeur Cloud Guard

À partir de la page web **Détails de la cible** 

Dans le panneau **Ressources** à gauche de l'écran,

* Cliquer sur **Recette de répondeur**.

La partie central de la fenêtre s'actualise avec la liste des recettes. Vous y trouverez uniquement la recette **OCI Responder Recipe (Géré par Oracle)**.

* Cliquer sur la recette **OCI Responder Recipe (Géré par Oracle)** 

Le système affiche une nouvelle page web **Recette de répondeur**, avec la liste des actions que le répondant géré par Oracle fera en cas problèmes dans la zone d'accueil cmp-ceiza-cloudguard

À gauche de l'écran

* Cliquer sur **Règles de répondeur**

Et dans la liste des règles. 

* Aller sur la ligne **Cloud Event** et cliquer sur les trois points , vers la fin de la ligne

* Cliquer sur **Modifier** dans le menu contextuel.  

Une fenêtre modale **Configurer une règle de répondeur** s'affiche

![activer_execution_automatique_cloud_event_dans_regle_repondeur](../../images/cloud_guard_oci/scenario1/activer_execution_automatique_cloud_event_dans_regle_repondeur.JPG)   

* Cocher **Exécuter automatiquement**

* Cocher **Confirmer l'exécution automatique**

* Et cliquer sur le bouton **Enregistrer**   

A chaque détection d'un problème , OCI va pousser les détails de ce problème dans un bus d'événemets Oracle Cloud Infrastructure Events Service.

#### Étape 5  : Déploiement API Python pour envoyer les journaux Cloud Guard à un SIEM   

Nous allons à présent créer une API qui va écouter le bus d'événemts ; elle sera déclenché chaque fois qu'une information est poussée par le répondeur de notre zone d'accueil. 

Cette API va pousser les activités du répondeur dans un outil SIEM tiers.

Pour créer l'API avec Python, appliquer les  étapes suivantes :  

* Dans le menu de la console  Oracle Cloud Console, naviguer vers **Services de développeur** et sélectionner **Applications** dans la section **Fonctions**  


![naviguer_vers_page_creation_fonction_oci](../../images/cloud_guard_oci/scenario1/naviguer_vers_page_creation_fonction_oci.JPG)   

Le système affiche la page web **Fonction**

* À gauche de l'écran , sélectionner le compartiment ayant notre zone d'accueil

* Sélectionner une application existante ou cliquer sur le bouton  **Créer une application**.

Une fenêtre modale **Créer une application** s'affiche.
 
![creation_fonction_oci_cloud_to_siem](../../images/cloud_guard_oci/scenario1/creation_fonction_oci_cloud_to_siem.JPG)   

* Saisir le nom de l'application. Nous l'avons appelé **fncloudguard2siem**

* Sélectionner le nom du réseau virtuel (VCN) dans lequel l'application va s'exécuter.   

* Sélectionner le nom du sous-réseau dans lequel l'application va s'exécuter.   

* Sélectionner la forme de l'application (GENERIC_X86, ...)  

* Cliquer sur le bouton Créer...

Nous allons utiliser la console Cloud Shell de Oracle pour coder le corps de l'API Python.  

Lancer la console Cloud Shell et tapez la commande suivante :  

  fn init --runtime python fncloudguard2siem   

![creation_code_python_fonction_fncloudguard2siem_avec_cloud_shell_oci](../../images/cloud_guard_oci/scenario1/creation_code_python_fonction_fncloudguard2siem_avec_cloud_shell_oci.JPG)   

Cette commande génère un dossier **fncloudguard2siem** avec 3 fichiers 

- func.py,    
- func.yaml,    
- et requirements.txt   

![ls_fncloudguard2siem](../../images/cloud_guard_oci/scenario1/ls_fncloudguard2siem.JPG)   

* Saisir le code suivant dans le fichier func.py

  import io
      import json
      import logging 
      import oci 
      from fdk import response 

       #The below method will receive the list of log entries from OCI as input in the form of bytestream and is defined in func.yaml 
       def handler(ctx, data: io.BytesIO = None): 
           funDataStr = data.read().decode('utf-8') 
           funData =  json.loads(funDataStr) 
           logging.getLogger().info(funData) 
      
          #send the log data to a temporary json file. /tmp is the supported writable directory for OCI functions 
           with open('/tmp/test.json', 'w', encoding='utf-8') as f: 
               json.dump(funData, f, ensure_ascii=False, indent=4) 
           file_details=io.open("/tmp/test.json") 
           signer = oci.auth.signers.get_resource_principals_signer() 
           log_analytics_client = oci.log_analytics.LogAnalyticsClient({},signer = signer)

       # Send the request to service, some parameters are not required, see API doc for more info 

           log_group_id="ocid1.loganalyticsloggroup.oc1.iad.amaaaaaas4n35viawkqpxtefipgoqemkc2n55b7hylaucb2vck6z4xxxxxxx" 
           upload_log_file_response=log_analytics_client.upload_log_file(namespace_name="orasenatdpltsecitom04", upload_name="CG_logs", log_source_name="Cloud Guard_functions_source", filename="test.json", opc_meta_loggrpid=log_group_id, upload_log_file_body=file_details)   

* Saisir le code suivant dans le fichier func.yaml

  schema_version: 20180708    
       name: fncloudguard2siem       
       version: 0.0.31    
       runtime: python    
       build_image: fnproject/python:3.9-dev    
       run_image: fnproject/python:3.9    
       entrypoint: /python/bin/fdk /function/func.py handler    
       memory: 256   

* Saisir les instructions suivantes dans le fichier requirements.txt

  fdk>=0.1.48    
      oci  

Déployez la fonction OCI à l’aide de la commande suivante :   

  fn -v deploy --app fncloudguard2siem   

Lorsqu’il est appelé par le service Events, le code de la fonction récupère les données de journal à partir du service Events et les charge dans le SIEM via son API de chargement.   


#### Conclusion   

Dans ce scénario, nous avons expliqué comment un OP peut ingérer des événements Cloud Guard dans son SIEM  à l’aide d'une API dans OCI.
 
* [Retour au Sommaire](#sommaire)

### Scénario 2 : Posture de sécurité et remédiation dans votre zone accueil OCI

Dans ce second scénario, vous allons déployer une zone d'accueil OCI , y activer le service de surveillance Cloud Guard , et voir comment la surveillance Cloud Guard améliore la posture de sécurité de notre zone d'accueil.   

#### Déploiement zone accueil OCI et activation de la surveillance Cloud Guard

1. Suivre le [guide suivant](#étape-1--déploiement-de-la-zone-accueil-oci-et-activation-de-cloud-guard) pour déployer une zone d'accueil OCI dans un compartiment englobant.

Assurer vous que le service Cloud Guard est activé (ENABLE) dans la pile de configuration.   

2. Puis accéder au service Cloud Guard et accéder à la liste des cibles dans le compartiment englobant   


Le script Terraform  déploie automatiquement les ressources suivantes :  

* une cible dans le compartiment racine. La portée de cette cible est le compartiment racine et les sous-compartiments enfants. 
Le nom de cette cible est ceicg02-cloud-guard-root-target , où ceicg02 est l'étiquette ( service label ) utilisé dans la pile déploiement   

* 4 recettes gérées par OCI.
  * **1 recette de détecteur** (de problèmes de type Menace) avec **1 règle**. Ce type de règle est conçue spécifiquement pour détecter dans votre zone d'accueil des modèles d'activité subtils dont l'accumulation est susceptible de poser un problème de sécurité.   
  * **1 recette de détecteur** (de problèmes de type Configuration) avec **50 règles**. Ces règles sont conçues spécifiquement pour détecter les paramètres de configuration de ressource susceptibles de poser un problème de sécurité dans votre zone d'accueil.   
  * **1 recette de détecteur** (de problèmes de type Activité) avec **28 règles**. Ces règles sont conçues spécifiquement pour détecter les actions sur les ressources susceptibles de poser un problème de sécurité de votre zone d'accueil.    
  * **1 recette de répondeur** avec **10 résolutions** qui vont corriger les problèmes de sécurité en fonction d'un problème identifié

![cible_pour_zone_accueil_oci_deployee](../../images/cloud_guard_oci/scenario2/cible_pour_zone_accueil_oci_deployee.JPG)   


3. Cliquer sur le nom de la cible.  

Le système affiche la page web **Détails de cible**   

Cliquer sur la section **Configuration** pour avoir la configuration de la cible Cloud Guard.  

![detail_cible_configuration_za_oci](../../images/cloud_guard_oci/scenario2/detail_cible_configuration_za_oci.JPG)   

4. Cliquer sur la section **Recettes de détecteur** pour avoir les 3 recettes du détecteur Cloud Guard.  

![detail_cible_recette_detecteur_za_oci](../../images/cloud_guard_oci/scenario2/detail_cible_recette_detecteur_za_oci.JPG)   

Ces 3 recettes sont créées et gérées par Oracle. 

**N.B** : Vous pouvez ajouter votre propre recette en utilisant un recette gérée par Oracle comme modèle.   

Chacune de ces recettes contient un ensemble de régles.  

5. Cliquer sur une recette pour voir ses règles.  

Cliquons par exemple sur la recette de configuration **OCI Configuration Detector Recipe (Géré par Oracle)**  .   

Le système affiche la page web **Recette de détecteur**   .

Cliquer ensuite sur le lien **Règles de détecteur**

Dans la partie centrale de la page web , s'actualise la liste des règles du détecteur de problèmes liés à la configuration dans notre zone d'accueil et dans le compartiment racine.   

![regles_recette_detecteur_za_oci](../../images/cloud_guard_oci/scenario2/regles_recette_detecteur_za_oci.JPG)   

En cas de déection de problème , quelle action Cloud Guard doit-il appliquer ?

La réponse est dans les règles du répondant Cloud Guard

Revenir sur la page web **Détails de cible**

* Cliquer sur la recette de répondeur  

* Puis cliquer sur la recette **OCI Responder Recipe (Géré par Oracle)**  

Le systéme affiche la page web **Recette de répondeur**


Cliquer ensuite sur le lien **Règles de répondeur**

Dans la partie centrale de la page web , s'actualise la liste des actions de rémédiation que Cloud Guard appliquera en cas deproblèmes dans  notre zone d'accueil et dans le compartiment racine.   

![regles_recette_repondeur_za_oci](../../images/cloud_guard_oci/scenario2/regles_recette_repondeur_za_oci.JPG)   


Vous pouvez commencer avec la configuration et les recettes par défaut prédéfinies par OCI, mais vous constaterez peut-être que les stratégies de détection prêtes à l’emploi génèrent des résultats que vous déterminez comme étant des faux positifs.   

Par exemple, le service Cloud Guard dispose de règles de détection intégrées pour détecter si une instance est accessible au public ou si elle possède une adresse IP publique. Dans de nombreux cas, ces résultats en matière de sécurité sont importants.    

Toutefois, si vous disposez d’un environnement avec une instance de calcul destinée à être accessible au public, vous considérez probablement ces résultats comme des faux positifs pour cette instance. Ainsi, la possibilité de personnaliser les règles du détecteur pour répondre à vos propres besoins est très précieuse.  

Dans les cas où vous souhaitez qu’une règle de détecteur s’applique à certaines ressources mais pas à d’autres, un moyen efficace de répondre à ces exigences consiste à configurer des [**conditions de règle de détecteur**](https://docs.oracle.com/fr/learn/oci-cloud-guard-rules/#task-2-create-a-condition-group-in-the-detector-rule). 


Cette fonctionnalité offre une plus grande flexibilité dans la gestion de votre posture de sécurité du cloud.

### Apercu des indicateurs relatifs à la surveillance Cloud GUard sur votre zone accueil OCI   

Cloud Guard offre des tableaux de bord , qui affichent des indicateurs et des risques rencontrés dans votre zone d'accueil OCI.

À partir de la capture précédente , cliquer sur **Cloud Guard** dans le fil d'ariane

![indicateurs_cloud_guard](../../images/cloud_guard_oci/scenario2/indicateurs_cloud_guard.JPG)   

Dans la page **Présentation** , Cloud Guard fournit des mesures clés :    

- le score de risques;
- Le score de sécurité et sa notation
- Un cliché des problèmes par compartiment ou par ressource dans votre zone d'accueil
- Des recommandations de sécurité
- Une liste des actions de remédiation en attente de validation   

* [Retour au Sommaire](#sommaire)   

### Simulation menace dans la zone accueil OCI

Le bucket privé **ceicg02-appdev-bucket** est déployé dans le compartiment cmp-prod-001 de la zone d'accueil OCI.   

Afin de créer une faille de sécurité , nous allons rendre public ce bucket , puis nous allons observer la réaction de la surveillance Cloud Guard.   

![rendre_public_un_bucket](../../images/cloud_guard_oci/scenario2/rendre_public_un_bucket.JPG)   

Suite à cette faille , les indicateurs Cloud Guard ont changé :

![suite_au_risque_bucket_public_le_score_a_change](../../images/cloud_guard_oci/scenario2/suite_au_risque_bucket_public_le_score_a_change.JPG)   

- La notation du score e sécurité a baissé de 75 à 72.   
- Le score de risque a augmenté de 1985 à 2199.   
- Une recommandation de sécurité s'est ajouté : **Resolve Bucket is public problems in target ceicg02-cloud-guard-root-target**  
- Bucket a été ajouté dans la vue des problémes par type de ressources.   
- Le nombre de problèmes est incrémenté : de 42 à 43.   
- Le nombre d'actions de rémédiation a augmenté : de 22 à 23.    



* [Retour au Sommaire](#sommaire)

### Remédiation bucket anormalement public

Cloud Guard détecte un risque de sécurité élevée dans la configuration de la ressource **ceicg02-appdev-bucket** , dans le compartiment cmp-prod-001, car son contenu est publiquement accessible sur Internet.    

![cloud_guard_detecte_une_menace_sur_un_bucket](../../images/cloud_guard_oci/scenario2/cloud_guard_detecte_une_menace_sur_un_bucket.JPG)   

Cliquer sur la ligne **Bucket is public**  

Une page web **Détails du problème** s'affiche.    

![detail_probleme_bucket_is_public](../../images/cloud_guard_oci/scenario2/detail_probleme_bucket_is_public.JPG)   

Cliquer sur le bouton **Résoudre** et appliquer la résolution **Make Bucket Private**.   

![appliquer_resolution_make_bucket_private](../../images/cloud_guard_oci/scenario2/appliquer_resolution_make_bucket_private.JPG)   

Et le problème est résolu !

![probleme_resolu](../../images/cloud_guard_oci/scenario2/probleme_resolu.JPG)   





* [Retour au Sommaire](#sommaire)   
* [Retour à la Page d'Accueil](../../README.md)  




