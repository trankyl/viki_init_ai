# Rencontre Initiale | CEI | 2023-07-10

Lors de la rencontre, nous avons tenté d'établir un plan dans le but de récolter l'information nécessaire pour faire une étude des scénarios courants dans les zones d'accueil. Les tâches qui en découlent sont :

- Rencontrer l'équipe tactique afin d'avoir leur feeback (s'ils en ont)
- Créer un sondage destiné aux OPs afin de récolter de l'information sur leurs pratiques et infrastructures présentement. Le sondage sera probablement de 3 questions qui porteront sur
  - Le fournisseur de la zone d'accueil
  - Les ressources utilisées / non utilisées
  - Les améliorations et l'appréciation de la zone d'accueil

Le sondage sera donc envoyé aux OPs et sera sur base volontaire. L'idée serait aussi d'être capable de récolter de manière récurrente ces informations dans l'optique d'une amélioration continue des zones d'accueil.