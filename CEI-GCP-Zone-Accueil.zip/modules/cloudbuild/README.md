## Aperçu

Ce module contient du code pour créer une machine virtuelle avec cloud builder et le reste du code nécessaire pour commencer à construire un pipeline CI/CD .

## Usage

```hcl
module "bootstrap" {
  source  = "terraform-google-modules/bootstrap/google//modules/cloudbuild"
  version = "~> 2.1"

  org_id         = "<ORGANIZATION_ID>"
  billing_account         = "<BILLING_ACCOUNT_ID>"
  group_org_admins        = "gcp-organization-admins@example.com"
  default_region          = "australia-southeast1"
  sa_enable_impersonation = true
  terraform_sa_email      = "<SERVICE_ACCOUNT_EMAIL>"
  terraform_sa_name       = "<SERVICE_ACCOUNT_NAME>"
  terraform_state_bucket  = "<GCS_STATE_BUCKET_NAME>"
}
```

Des exemples fonctionnels et des définitions de Cloud Build se trouvent dans [examples](../../examples/)

## Fonctionnalités
- Créer un nouveau projet de cloud build en utilisant `project_prefix`
- Activer les APIs dans le projet de cloud build en utilisant `activate_apis`
- Construire une image docker de Terraform pour Cloud Building, y compris [terraform-validator](https://github.com/GoogleCloudPlatform/terraform-validator)
- Créer un bucket GCS pour les artifacts de Cloud Build en utilisant `project_prefix`
- Créer des repos de Cloud Sources pour les pipelines
  - Créer un déclencheur de Cloud Build pour `terraform apply` dans la branche principale
  - Créer un déclencheur de Cloud Build pour `terraform plan` pour toutes les autres branches.
- Créer un trousseau de clé de KMS et clés pour le cryptage
  - Accorder l'accès pour déchiffrer le compte service de Cloud Build et `terraform_sa_email`
  - Accorder l'accès pour chiffrer à `group_org_admins`
- OPTION: Accorder les permissions au compte service de Cloud Build de se faire passer pour un compte service de Terraform en utilisant `sa_enable_impersonation` et la valeur fournie pour `terraform_sa_name`

## Ressources Créées

- Trousseaux de clés KMS et des clés pour secrets, y compris IAM pour Cloud Build, Admins d'organisation et compte service de Terraform
- (Optionnel) Permissions d'usurption d'identité de Cloud Build pour un compte service
- (Optionnel) Repos de Cloud Source, avec déclencheurs pour `terraform plan` Pour toutes les autres branches & `terraform apply` (principal)
- (optional) Cloudbuild impersonation permissions for a service account
- (optional) Cloud Source Repos, with triggers for terraform plan (all other branches) & terraform apply (master)


<!-- BEGINNING OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
## Entrées

| Name | Description                                                                                                                                             | Type | Défaut                                                                                                                                                                                                                                                                                                                                                                                                  | Requis |
|------|---------------------------------------------------------------------------------------------------------------------------------------------------------|------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|:------:|
| activate\_apis | Liste d'APIs à activer dans le projet de Cloudbuild                                                                                                     | `list(string)` | <pre>[<br>  "serviceusage.googleapis.com",<br>  "servicenetworking.googleapis.com",<br>  "compute.googleapis.com",<br>  "logging.googleapis.com",<br>  "bigquery.googleapis.com",<br>  "cloudresourcemanager.googleapis.com",<br>  "cloudbilling.googleapis.com",<br>  "iam.googleapis.com",<br>  "admin.googleapis.com",<br>  "appengine.googleapis.com",<br>  "storage-api.googleapis.com"<br>]</pre> |  non   |
| billing\_account | ID du compte de factiratopm à associer avec le projet                                                                                                   | `string` | n/a                                                                                                                                                                                                                                                                                                                                                                                                     |  oui   |
| cloud\_source\_repos | Liste de repor de Cloud Source à créer avec des déclencheurs de Cloudbuild                                                                              | `list(string)` | <pre>[<br>  "gcp-org",<br>  "gcp-networks",<br>  "gcp-projects"<br>]</pre>                                                                                                                                                                                                                                                                                                                              |  non   |
| cloudbuild\_apply\_filename | Chemin et nom de définition YAML de Cloud Build utilisé pour terraform apply                                                                            | `string` | `"cloudbuild-tf-apply.yaml"`                                                                                                                                                                                                                                                                                                                                                                            |  non   |
| cloudbuild\_plan\_filename | Chemin et nom de définition YAML de Cloud Build utilisé pour terraform plan                                                                             | `string` | `"cloudbuild-tf-plan.yaml"`                                                                                                                                                                                                                                                                                                                                                                             |  non   |
| create\_cloud\_source\_repos | Si des repos partagés de Cloud Source devraient être créer                                                                                              | `bool` | `true`                                                                                                                                                                                                                                                                                                                                                                                                  |  non   |
| default\_region | Région par défaut dans laquelle sont créées les ressources, si applicable                                                                               | `string` | `"us-central1"`                                                                                                                                                                                                                                                                                                                                                                                         |  non   |
| folder\_id | ID d'un dossier pour héberger ce projet                                                                                                                 | `string` | `""`                                                                                                                                                                                                                                                                                                                                                                                                    |  non   |
| gar\_repo\_name | Nom personnalisé à utiliser pour le repo GAR                                                                                                            | `string` | `""`                                                                                                                                                                                                                                                                                                                                                                                                    |  non   |
| group\_org\_admins | Google Group pour les administrateurs d'organisation de GCP                                                                                             | `string` | n/a                                                                                                                                                                                                                                                                                                                                                                                                     |  oui   |
| org\_id | ID d'organisation de GCP                                                                                                                                | `string` | n/a                                                                                                                                                                                                                                                                                                                                                                                                     |  oui   |
| project\_id | ID de projet personnalisé à utiliser pour le projet créé                                                                                                | `string` | `""`                                                                                                                                                                                                                                                                                                                                                                                                    |  non   |
| project\_labels | Étiquettes à appliquer à ce projet                                                                                                                      | `map(string)` | `{}`                                                                                                                                                                                                                                                                                                                                                                                                    |  non   |
| project\_prefix | Préfixe de nom à utiliser pour les projets créés                                                                                                        | `string` | `"cft"`                                                                                                                                                                                                                                                                                                                                                                                                 |  non   |
| random\_suffix | Concatener un suffixe de 4 caractères aléatoires à l'ID de projet et le nom de bucket                                                                   | `bool` | `true`                                                                                                                                                                                                                                                                                                                                                                                                  |  non   |
| sa\_enable\_impersonation | Permettre org\_admins group à se faire passer d'un compte service & activer les APIs requis                                                             | `bool` | `false`                                                                                                                                                                                                                                                                                                                                                                                                 |  non   |
| storage\_bucket\_labels | Étiquettes à appliquer au bucket de stockage                                                                                                            | `map(string)` | `{}`                                                                                                                                                                                                                                                                                                                                                                                                    |  non   |
| terraform\_apply\_branches | Liste de branches git configurées pour exécuter le déclencheur Cloud Build de terraform apply. Toutes les autres branches s'exécuteront plan par défaut | `list(string)` | <pre>[<br>  "master"<br>]</pre>                                                                                                                                                                                                                                                                                                                                                                         |   no   |
| terraform\_sa\_email | Courriel de compte service de Terraform                                                                                                                 | `string` | n/a                                                                                                                                                                                                                                                                                                                                                                                                     |  oui   |
| terraform\_sa\_name | Nom qualifié de compte service de Terraform                                                                                                             | `string` | n/a                                                                                                                                                                                                                                                                                                                                                                                                     |  oui   |
| terraform\_state\_bucket | Bucket d'état par défaut, utilisé dans les subsitutions de Cloud Build                                                                                  | `string` | n/a                                                                                                                                                                                                                                                                                                                                                                                                     |  oui   |
| terraform\_validator\_release | Version par défaut de terraform-validator                                                                                                               | `string` | `"2021-03-22"`                                                                                                                                                                                                                                                                                                                                                                                          |  non   |
| terraform\_version | Version par défaut de Terraform.                                                                                                                        | `string` | `"0.13.6"`                                                                                                                                                                                                                                                                                                                                                                                              |  non   |
| terraform\_version\_sha256sum | sha256sum pour la version par défaut de terraform                                                                             | `string` | `"55f2db00b05675026be9c898bdd3e8230ff0c5c78dd12d743ca38032092abfc9"`                                                                                                                                                                                                                                                                                                                                    |  non   |

## Sorties

| Nom                                | Description                                                                                |
|------------------------------------|--------------------------------------------------------------------------------------------|
| cloudbuild\_project\_id            | Projet où se trouvent la configuration de Cloud Build et l'image de conteneur de terraform |
| csr\_repos                         | List de repos de Cloud Source créés par le module, lié aux déclencheurs de Cloud Build     |
| gcs\_bucket\_cloudbuild\_artifacts | Bucket utilisé pour stocker les artefacts de Cloud Build dans le projet de Cloud Build     |
| kms\_crypto\_key                   | Clé KMS créée par le module                                                                |
| kms\_keyring                       | Trousseau de clé KMS créé par le module                                                    |
| tf\_runner\_artifact\_repo         | Repo GAR créé pour stocker les images               |

<!-- END OF PRE-COMMIT-TERRAFORM DOCS HOOK -->

## Exigence

### Logiciels

-   [gcloud sdk](https://cloud.google.com/sdk/install) >= 206.0.0
-   [Terraform](https://www.terraform.io/downloads.html) >= 0.13.0
-   [terraform-provider-google] plugin 3.50.x

### Permissions

- `roles/billing.user` dans le compte de facturation fourni 
- `roles/resourcemanager.organizationAdmin` dans l'organisation GCP 
- `roles/resourcemanager.projectCreator` dans l'organisation GCP Organization ou dossier

### APIs

Un projet avec les APIs activés suivant doit être utilisé pour héberger les ressources de ce module:

- Google Cloud Resource Manager API: `cloudresourcemanager.googleapis.com`
- Google Cloud Billing API: `cloudbilling.googleapis.com`
- Google Cloud IAM API: `iam.googleapis.com`
- Google Cloud Storage API `storage-api.googleapis.com`
- Google Cloud Service Usage API: `serviceusage.googleapis.com`
- Google Cloud Build API: `cloudbuild.googleapis.com`
- Google Cloud Source Repo API: `sourcerepo.googleapis.com`
- Google Cloud KMS API: `cloudkms.googleapis.com`

Cet API peut être activé dans le projet par défaut créé pendant l'établissement d'uen organisation

