# Notes sommaires des changements relatifs au paramétrage du script de la zone d'accueil Azure par rapport à la version 2.0

version 2.2

---

* Paramétrage de l'ID du groupe d'administration racine basé sur l'ID de l'organisation : par défaut \'\$(var-prefixe-env-org)-\$(var-organisation-name)\'
* Par défaut, var-prefixe-env-org est 'EnvironnementOrganisationnel' ; il est nécessaire de conserver tel quel lorsqu'on fait une mise à jour de la version 2.0 à la version 2.2, mais autrement paramétrable.
* Pour des nouveaux déploiements, on recommande de raccourcir var-prefixe-env-org (par exemple) à EnvOrg pour éviter de dépasser la limite de 68 caractères des noms des déploiements, surtout dans le cas des déploiements des stratégies et des initiatives.
* Domaine ("scope") d'assignation des stratégies et des initiatives, en remplaçant le *hardcodage* ("definitionScope": "EnvironnementOrganisationnel") par "definitionScope": "$(var-organisation-id)".
* Nomenclature des pipelines et des templates, en éliminant le dédoublement des noms :

  * assign-subscriptions.yml => assign-subscriptions.yml
  * landingzones.yml => landingzones.yml
  * platform.yml => platform.yml
  * deploy-landingzone.yml => deploy-landingzone.yml
  * deploy-platform.yml => deploy-platform.yml
  * Nomenclature des configurations par scénario et communes entre les scénarios

  * cei-perimetre.yml => cei-perimetre.yml
  * cei-platform.yml => cei-platform.yml
  * cei-base-routage.yml => cei-base-routage.yml
  * cei-complexe-routage.yml => cei-complexe-routage.yml

## Avertissements importants

* Le script ne déploie pas des routes et/ou des NSG et/ou des règles dedans pour permettre la communication entre l'environnement infonuagique et l'environnement réseau local ou autres services infonuagiques spécifiques au client. Par exemple :
  * Communication entre les instances AD-DC dans le nuage (abonnement identité) et les instances AD-DC sur site
  * Communication avec les environnements PaaS comme Azure VDP ou Citrix (par exemple FluidApps)
* Le script ne déploie pas des routes et/ou des NSG et/ou des règles dedans pour permettre la communication interne dans l'environnement infonuagique selon des besoins spécifiques au client. Par exemple :
  * Communication avec les services KMS ou Update de Microsoft pour les machines virtuelles déployées dans les zones de charges
  * Communication entre les instances AD-DC dans le nuage (abonnement identité) et les machines virtuelles dans les zones de charges

---

## Rajout d'un soutien *jumpbox* dans zones de charges, gestion et identité

* Aucun paramétrage n'est requis (même si c'est possible en mode de personnalisation avancé). Les "jumpbox" sont déployés par défaut dans les sous-réseaux *jumpbox* dans les VNet des zones Gestion, Identité et zones de charges, dans les scénarios "de base" et "complexe".
* Les "jumpbox" sont des petites VM Windows Server 2019 dont le nom d'usager et le mot de passe initiaux sont *hardcodés* dans la configuration. Ils sont à changer une fois provisionnées par le script.
* Éléments importants de configuration à prendre en note pour cette fonctionnalité :
  * Rajout dans template deploy-platform.yml de la création VM *jumpbox* dans zones identité et gestion
  * Pour le scénario de base, rajout et/ou changements des fichiers de configuration suivants :

    * cei-base-vm-param.yml : contient le paramétrage commun de la VM jumpbox
    * cei-base-jb-vm.yml : contient les définitions pour les VM *jumpbox* dans les zones de charges, gestion et identité y compris le nom d'usager et MDP initiaux pour les VM. Le *hardcodage* va être changé dans la version suivante par des "secrets" protégés dans la chambre forte (*keyvault*).
    * cei-base-lz.yml : rajout du paramètre createVmParam dans sous-réseaux *jumpbox* dans chaque abonnement et dans chaque sous-réseaux Web, données et applications pour la création optionnelle automatique de machines virtuelles dans ces sous-réseaux. Le but est surtout pour le dépannage et les tests, pour sauver du temps dans la création manuelle de ces machines virtuelles, au besoin. Par défaut, les variables sont vides et aucune machine virtuelle ne sera créée dans ces sous-réseaux (les variables sont définies dans le nouveau fichier cei-base-vm-param.yml). Si jamais vous avez le besoin de créer de telles VM "de test", il faut enlever le commentaire devant " template: cei-base-test-vm.yml" dans cei-base-main.yml. Le fichier contient des exemples de configurations de VM de test Linux et Windows. Cette fonctionnalité avancée existe, mais elle n'est pas prise en charge.
  * Pour le scénario complexe, rajout et/ou changements des fichiers de configuration suivants :

    * cei-complexe-vm-param.yml : contient le paramétrage commun de la VM *jumpbox*
    * cei-complexe-jb-vm.yml : contient les définitions pour les VM *jumpbox* dans les zones de charges, gestion et identité y compris le nom d'usager et MDP initiaux pour les VM. Le *hardcodage* va être changé dans la version suivante par des "secrets" protégés dans la chambre forte (*keyvault*).
    * cei-complexe-lz.yml : rajout du paramètre createVmParam dans sous-réseaux *jumpbox* dans chaque abonnement et dans chaque sous-réseaux Web, données et applications pour la création optionnelle automatique de machines virtuelles dans ces sous-réseaux. Le but est surtout pour le dépannage et les tests, pour sauver du temps dans la création manuelle de ces machines virtuelles, au besoin. Par défaut, les variables sont vides et aucune machine virtuelle ne sera créée dans ces sous-réseaux (les variables sont définies dans le nouveau fichier cei-base-vm-param.yml). Si jamais vous avez besoin de créer de telles VM "de test", il faut enlever le commentaire devant " template: cei-base-test-vm.yml" dans cei-base-main.yml. Le fichier contient des exemples de configurations de VM de test Linux et Windows. Cette fonctionnalité avancée existe, mais elle n'est pas prise en charge.

## Soutien NetworkWatcher dans les abonnements plateforme et zones de charges

* Aucun paramétrage requis, fonctionnalité disponible par défaut
* Configuré dans chaque abonnement, car pour utiliser NetworkWatcher dans un abonnement, il doit y avoir une instance.
* Très utile pour le dépannage (routage, connectivité, règles NSG), la capture de paquets sur des interfaces VM
* Essentiel pour permettre l'inspection des journaux NSG ("NSG Flow") et l'analyse du trafic dans un espace Log Analytics ("Traffic Analytics)
* Permet de visualiser et d'analyser les événements "Accept / Deny" causés par les règles NSG, soit en temps réel pour des fins de dépannage, soit ultérieurement pour des fins d'investigation de sécurité.

## Amélioration du routage

* Amélioration du mécanisme de routage interne ("inter-spoke") via la passerelle VPN, alternative beaucoup moins coûteuse que d'utiliser un C/F FortiGate ou Azure Firewall dans le même but
  * Il faut évidemment provisionner la passerelle VPN (var-platform-hub-deploy-VPNGW: true).
  * On n'a plus besoin d'une adresse IP privée fixe sur l'interface de la passerelle VPN, le routage se fait grâce aux paramètres d'apparairage ("use remote gateway", "forward traffic" et "transit gateway") en spécifiant dans les routes "NextHopType: VpnGateway".
  * La variable var-platform-hub-privIp-VPNGW (par défaut "false") est quand même présente dans cei-base-param.yml et cei-complexe-param.yml pour des cas d'usage très spécifiques, dont l'utilisation est peu probable.
  * Aucune raison de mettre cette variable à "true" à moins que l'on veuille router via la passerelle VPN de l'ancienne façon. Dans ce cas, le mode 'nva' pour les routes internes ("inter-spoke") pourra utiliser la passerelle VPN avec un "next-hop" égal à $(var-platform-hub-virtualNetwork-ip-prefix).0.6. Pour le mode de routage 'vpn', cette variable n'a pas d'effet.
  * Il faut souligner que le routage en mode 'nva' via la passerelle VPN, même si cela est possible, n'est plus pris en charge.
* Routage flexible paramétrable pour les trois catégories de route : vers Internet, vers réseau du client et interne interpériphérique (*inter-spoke*)
  * Permet de prendre en charge une panoplie de scénarios de déploiement en fonction des besoins, par exemple le routage interne via la passerelle VPN, routage vers l'Internet via le tunnel VPN et le pare-feu sur site, ou n'importe quelle autre combinaison.
  * Il y a maintenant dans cei-base-param.yml et cei-complexe-param.yml trois variables qui contrôlent le routage, dont les valeurs possibles sont soit 'nva', soit 'vpn'.

    * var-mode-route-internet : contrôle le mode de routage vers Internet (destination 0.0.0.0/0).
    * var-mode-route-client : contrôle le mode de routage vers le réseau local du client (préfixes dans var-client-local-network-prefix).
    * var-mode-route-spoke : contrôle le routage *inter-spoke* (c'est-à-dire entre Gestion et les autres *spokes*).
  * Le mode 'nva' implique le routage via une adresse IP "next-hop" d'une application virtuelle (comme FortiGate, Azure Firewall) ou même de la passerelle VPN si l'adresse IP privée y est provisionnée (var-platform-hub-privIp-VPNGW: true).
  * Dans le cas où var-mode-route-client: 'nva', il faut configurer le tunnel VPN sur l'application virtuelle (par exemple FortiGate)
    entre Azure et l'environnement réseau local du client. Cela doit être fait manuellement, le script ne le fait pas.
  * Si on choisit le mode 'nva' pour une catégorie de routage, il faut fournir aussi une valeur "next-hop".
    Par défaut, il s'agit de l'adresse interne du C/F FortiGate; dans ce cas, il faut donc déployer FortiGate.
  * Pour contrôler le "next-hop", il y a trois variables dans cei-base-param.yml / cei-complexe-param.yml, une pour chaque mode et dont la valeur par défaut est l'adresse interne du C/F FortiGate (dans le FortiGate déployé) :

    * var-route-internet-nexthop : $(var-platform-hub-fg-lb-frontend-ip)
    * var-route-spoke-nexthop : $(var-platform-hub-fg-lb-frontend-ip)
    * var-route-client-nexthop : $(var-platform-hub-fg-lb-frontend-ip)
  * Le "next-hop" ci-haut est en effet l'adresse IP du front-end de balanceur de charge interne devant les deux FortiGate, par défaut 10.84.4.68/26.

    * Le balanceur de charge surveille les deux VM FortiGate qui fonctionnent en mode actif-passif.
    * En mode normal, c'est FortiGate A qui route le trafic, s'il est *down*, c'est FortiGate B qui prend la charge.
  * Si, par contre, on veut déployer Azure Firewall dans le *hub* et/ou dans le périmètre utilisé comme "next-hop", il faut utiliser les adresses plus bas à la place de var-platform-hub-fg-lb-frontend-ip.

    * var-platform-hub-subnet-nva-ip-prefix : adresse IP interne "next-hop" Azure Firewall dans le *hub*
    * var-platform-perimetre-subnet-nva-ip-prefix : adresse IP interne "next-hop" Azure Firewall dans le périmètre
  * Permettre de spécifier une liste de préfixes destination pour le routage vers le réseau local du client, à la place d'un seul préfixe en 2.0 (ce qui nécessitait des éditions manuelles des tables de routage). Il s'agit de la même variable que dans v2.0, qui prend à la place d'une seule chaîne de caractères (*string*) une liste de préfixes, par exemple :

    ```
    # Préfixes du réseau du client joignable via VPN (à définir par le client)
    var-client-local-network-prefix: >
        [
        "100.64.0.0/10",
        "10.0.0.0/8", 
        "192.168.0.0/24", 
        "172.16.0.0/12"
        ]
    ```

## Rajout soutien Azure Defender

* Rajout de nouveaux fichiers de paramétrage pour chaque scénario : cei-base-defender.yml et cei-complexe-defender.yml
* Rajout pour chaque scénario dans cei-base-lz.yml respectivement cei-complexe-lz.yml du paramétrage Azure Defender pour chaque zone de charges. Il s'agit du choix et du provisionnement d'un plan de protection P1 ou P2, pour des VM et des DNS.
* Pour clarifier Azure Defender for Servers, il y a deux [plans disponibles](https://learn.microsoft.com/en-us/azure/defender-for-cloud/plan-defender-for-servers-select-plan) pour sécuriser les VM et un plan de protection Azure Defender qui s'applique au niveau d'un abonnement complet :
  * P1 : plan de base, autour de 5 US$/mois par serveur de machine virtuelle
  * P2 : prend en charge toutes les fonctionnalités, mais coûte plus cher, autour de 15 US$/mois par serveur de machine virtuelle.
* Pour le scénario de base, les niveaux suivants sont provisionnés par le nouveau paramètre azDefenderParam dans cei-base-lz.yml :
  * Abonnements "Données Non Sensibles" et Non-prod : P1
  * Abonnement "Données Sensibles" : P2
* Pour le scénario complexe, le niveau P1 est provisionné pour tous les abonnements par le nouveau paramètre azDefenderParam dans cei-complexe-lz.yml.
* Un nouveau stage a été rajouté dans pipeline platform.yml pour déployer Azure Defender, qui roule après que les ressources sont provisionnés dans les abonnements.
* Un nouveau paramètre a été rajouté dans template deploy-landingzone.yml pour le déploiement d'Azure Defender :
  azDefenderParam='$(var-lz-az-defender-param)'
* Un nouveau module Bicep 'security' en charge du déploiement de Azure Defender a été rajouté.
* Les événements de sécurité générés par Azure Defender sont envoyés dans un espace Log Analystics dédié à la sécurité.
  Pour plus de détails, voir la section [Paramétrage Azure Defender](parametrage_azure_defender.md).

## Rajout soutien C/F FortiGate

* Dans le paramétrage (scénario de base et complexe), rajout de l'option de déploiement C/F Fortigate, par défault réglée :
  var-platform-hub-deploy-Fortigate (défaut true)
* Le paramétrage FortiGate est commun pour les deux scénarios : var-platform-hub-fortigate; il se trouve dans le fichier cei-platform.yml.
* Le nouveau module .bicep Fortigate va déployer les ressources suivantes:

  * 2 VM FortiGate (FG-A et FG-B) en mode HA, actif-passif, avec FG-A étant le noeud actif en conditions normales
  * 2 balanceurs de charge, l'un est externe, l'autre est interne.
  * 1 adresse IP publique associée au balanceur de charge externe. L'adresse source de la communication vers Internet est cette adresse IP.
  * L'adresse interne du "front-end" du balanceur de charge interne est le "next-hop" pour les routes 'nva' qui utilisent le FortiGate comme plateforme de routage interne ou de sortie vers l'Internet ou vers le réseau du client via VPN.
  * Optionnellement (mais pas recommandé en production), 2 adresses publiques pour les interfaces de gestion de chaque VM Fortigate. Il est recommandé d'utiliser l'adresse interne de l'interface de gestion à partir du *jumpbox* Gestion en utilisant l'URL https://\<adresse interne port de gestion\>.
  * Par défaut, il n'y a pas d'adresse publique assignée au port de gestion, mais pour en activer l'assignation lors du déploiement dans cei-platform.yml, rajouter une variable au-dessus de la variable var-platform-hub-fortigate :
    var-platform-hub-nva-mgmt-pip-allowed: 'yes'. Dans ce cas, dans l'assignation de l'initiative "Network", exclure l'abonnement Connectivité, autrement l'assignation d'adresse publique sera bloquée.
  * Pour chaque machine virtuelle, il y 4 ports réseau provisionnés pour chaque VM FortiGate :

    * Port1 : interface externe, étant dans le "back-end" du balanceur de charge externe
    * Port2 : interface interne, étant dans le "back-end" du balanceur de charge interne
    * Port3 : non routable, pour la synchronisation des configurations entre les deux FortiGate
    * Port4 : port assigné à l'interface de gestion
  * Par défaut, les adresses internes sont :

    * VM Fortigate A : 10.84.4.69/26
    * VM Fortigate B : 10.84.4.70/26
    * Balanceur de charge interne ("frontend") : 10.84.4.68/26
  * La présence des quatre ports fait en sorte qu'on a besoin d'une licence complète, car la licence d'essai (*trial*) ne prend pas en charge cette configuration.
  * En mode normal et sécuritaire, l'accès aux interfaces de gestion des VM FortiGate peut se faire de deux façons :

    * Dans le portail via l'option de menu gauche "Console Série" dans la page de configuration de chaque machine virtuelle
    * Via l'interface Web de chaque VM FortiGate, accessible à l'adresse du Port 2 de chaque VM, à partir de la VM *jumpbox* dans Gestion (par défaut : 10.84.4.69/26 pour FG-A et 10.84.4.70/26 pour FG-B).
  * Le pipeline platform.yml va demander le nom d'usager et MDP pour les FortiGate, peu importe si on les déploie ou non.
  * La configuration des FortiGate est manuelle et possible après avoir appliqué (manuellement) une licence BYOL valide sur chacune des VM via l'option de licence de téléchargement (*pload licence*) dans l'interface Web initiale après le déploiement.
  * Pour éviter d'entrer manuellement tous les paramètres dans l'interface Web de gestion de chaque VM FortiGate, on fournit un script PowerShell (Replace-Tokens-fg-cli.ps1) qui génère le fichier de commandes de configuration à partir d'un fichier de paramétrage (config.ini) qui contient les quatre paramètres d'adressage nécessaires et deux maquettes contenant des jetons de configuration remplaçables (fga_cfg.tpl et fgb_cfg.tpl). Le tout se trouve dans le répertoire (*repository*) de déploiement en dessous de Scripts/Fortigate. Voir la section de la documentation pour le [Paramétrage FortiGate](parametrage_fortigate.md).
