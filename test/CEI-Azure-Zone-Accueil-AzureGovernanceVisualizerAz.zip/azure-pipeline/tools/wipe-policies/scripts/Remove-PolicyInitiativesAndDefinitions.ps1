[CmdletBinding()]
param (
    [Parameter(Mandatory = $true, Position = 1)]
    [string] $subscriptions
)

$subscriptions = $subscriptions.replace(" ",'')
$subArray = $subscriptions.Split(",")

foreach($sub in $subArray)
{
  if (![string]::IsNullOrWhiteSpace($sub))
  {
    Write-Host "##[group]Wiping policies initiatives and definitions linked to subscription $sub"

    $customPolicySets = Get-AzPolicySetDefinition -SubscriptionId $sub -Custom
    Write-Host ("##[section]Found " + $customPolicySets.Count + " custom initiatives ...")

    foreach($customSet in $customPolicySets) {
      Write-Host ("Deleting " + $customSet.Name + " (" + $customSet.ResourceId + ")")
      Remove-AzPolicySetDefinition -Id $customSet.ResourceId -Force
    }

    $customPolicyDefs = Get-AzPolicyDefinition -SubscriptionId $sub -Custom
    Write-Host ("##[section]Found " + $customPolicyDefs.Count + " custom definitions ...")

    foreach($customDef in $customPolicyDefs) {
      Write-Host ("Deleting " + $customDef.Name + " (" + $customDef.ResourceId + ")")
      Remove-AzPolicyDefinition -Id $customDef.ResourceId -Force
    }

    Write-Host "##[endgroup]"
  }
}