# Générateur du plan d'adressage réseau

Au menu

* [Contexte](#contexte)
* [Stratégies de planification d'un plan d'adressage réseau](#stratégies-de-planification-plan-adressage-réseau)
  * [Décrémentation du préfixe réseau ou du masque de sous réseau](#décrémentation-du-préfixe-réseau-ou-du-masque-de-sous-réseau)
  * [Incrémentation du préfixe réseau ou du masque de sous réseau](#incrémentation-du-préfixe-réseau-ou-du-masque-de-sous-réseau)
  * [Nombre d'hôtes](#nombre-hôtes)
* [Conception de la boite noire](#conception-de-la-boite-noire)
  * [Intrant](#intrant)
  * [Extrant](#extrant)
* [Modification Conception Pipeline existant](#modification-conception-pipeline-existant)
* [Choix technologiques](#choix-technologiques)
* [Preuve de concept](#preuve-de-concept)
* [Flow exécution](#flow-exécution)
* [Liste des fichiers impliqués](#liste-des-fichiers-impliqués)
* [Code source](#code-source)
* [Conclusion](#conclusion)
* [Annexes](#annexes)

## Contexte

Dans les précédentes versions du modèle de déploiement de la zone d'accueil Azure , le [chiffrier suivant](../../../Doc/fichiers/Adressage_IP_ZoneAccueil_Azure_base.xlsx) présente le Plan d'adressage IP de la zone d'accueil Azure. Néanmoins il y a des optimisation à faire au niveau du plan d'adressage car certains subnet possèdent simplement trop d'IP pour rien. De plus, si le plan d'adressage est à modifier par un OP, c'est une bonne gymnastique de toute refaire selon leur besoin et de rentrer les différents préfixes et suffixes dans les nombreuses variables et c'est facile de se tromper. On veut faire un peu de recherche à savoir comment on peut améliorer l'automatisation de ceci et le rendre plus dynamique.

Dans ce document d'analyse, nous allons clarifier les options d'automatisation de plan d'adressage selon certains paramètres.

## Stratégies de planification plan adressage réseau

Nous allons considérer la génération du plan d'adressage comme une boite noire qui a des entrées et des sorties.  

Il existe plusieurs stratégies dans la planification d'un plan d'adressage  

Les paramètres à considérer pour schématiser un plan d'adressage réseau vont varier suivant la stratégie

Voici les différentes stratégies suite à notre analyse :  

- Décrémentation du préfixe réseau ou du masque de sous réseau
- Incrémentation du préfixe réseau ou du masque de sous réseau
- Génération du plan d'adressage à partir du nombre de hôtes souhaité par espace réseau ou par spoke

*Note* : Cette liste n'est pas exhaustive et nous sommes ouvert à toutes autres stratégies dans la planification du schéma d'adressage  

### Décrémentation du préfixe réseau ou du masque de sous réseau

Cette stratégie vise à utiliser un préfixe réseau de départ
Le préfixe peut être sous la forme CIDR ( Ex : /17) ou  sous forme d'un masque de sous-réseau  

Dans notre peuve de concept (POC) , nous avons utilisé la notation CIDR.  

Etant donné une adresse IP de départ et un préfixe réseau de départ
On parcours les spokes , les espaces réseau .
A chaque itération dans un spoke ou espace réseau
  On décrémente le préfixe réseau , suivant le pas défini a l'entrée de la boite noire
  On affecte au spoke ou à l'espace réseau de l'itération en cours le préfixe réseau et l'adresse IP de départ

Dans cette approche , on a pas le controle sur le nombre d'hotes disponibles par spoke ou espace réseau , car il varie suivant le préfixe

### Incrémentation du préfixe réseau ou du masque de sous réseau

Cette stratégie vise à utiliser un préfixe réseau de départ
Le préfixe peut être sous la forme CIDR ( Ex : /17) ou  sous forme d'un masque de sous-réseau  

Dans notre POC , nous avons utilisé la notation CIDR.  

Etant donné une adresse IP de départ et un préfixe réseau de départ
On parcours les spokes , les espaces réseau .
A chaque itération dans un spoke ou espace réseau
  On incrémente le préfixe réseau , suivant le pas défini a l'entrée de la boite noire
  On affecte au spoke ou à l'espace réseau de l'itération en cours le préfixe réseau et l'adresse IP de départ

Dans cette approche , on a pas le controle sur le nombre d'hotes disponible par spoke ou espace réseau ,car il varie suivant le préfixe réseau

### Nombre hôtes

Cette stratégie vise à générer un plan d'adressage à partir du nombre de hôtes souhaités ( NH ) dans un spoke ou un espace réseau

Ainsi ,  étant donné un nombre , et une adresse IP de départ par spoke ou espace réseau , on génére un préfixe réseau sous la forme CIDR ( Ex : /17) ou  sous forme d'un masque de sous-réseau  

Dans notre POC , nous avons utilisé la notation CIDR.  

Dans cette approche , on a le controle sur le nombre d'hotes disponible par spoke ou espace réseau , mais les plages d'adresses ne seront pas continues, mais discontinues.

## Conception de la boite noire

Sur la base des stratégies ci-desssus , la boite noire a 2 principaux parametres

- le type de stratégie ou d'algorithme
- et les informations requis pour implémenter un type de stratégie

### Intrant

| Nom paramètre entrée       | Rôle   | Type de données    |
| ------------------- | ------ | ------------------ |
| Algorithme          | Type de stratégie           | Chaine de caracteres                      |
| ParametreAlgorithme | Liste de paramètres pour un type de stratégie     | Objet structuré      |

### Extrant

En sortie la boite noire retourne un plan d'adressage correspodant au type de stratégie en entrée

| Nom paramètre sortie       | Rôle   | Type de données    |
| ------------------- | ------ | ------------------ |
| Plan d'adressage | plan d'adressage réseau    | Objet structuré      |

Structure JSON de l'objet en sortie


    {
        'connectivite': 
            {
                'adressage': '10.85.0.0/15', 
                'prefixe_reseau': '15', 
                'nombre_ip': '', 
                'erreur': True, 
                'message_erreur': '10.85.0.0/15 has host bits set'
            }, 
        'ASSIGNÉ': 
            {
                'adressage': '10.85.0.0/16', 
                'prefixe_reseau': '16', 
                'nombre_ip': 65536, 
                'erreur': False
            }, 
        'Gateway': 
            {
                'adressage': '10.85.0.0/17', 
                'prefixe_reseau': '17', 
                'nombre_ip': 32768, 
                'erreur': False
            },
            ETC...
    }



Pour faciliter l'intégration de cette sortie dans une variable YAML , nous allons formater cet objet structuré sous forme de chaine de caractères.


## Modification Conception Pipeline existant

L'intégration d'un générateur de plan d'adressage nécessite que l'administrateur définisse le type d'algorithme et ses paramètres lors du lancement d'un pipeline de déploiement.

Nous avons donc modifier l'IHM du pipeline platform.yml avec les nouveaux paramètres suivants : 


![parametre_pipeline_platform](images/parametre_pipeline_platform.PNG "Paramétres dans pipeline Platfrom")

On y trouve les champs suivants : 

| Champ       | Rôle   | Type de données    | Obligatoire | Commentaires |
| ------------------- | ------ | ------------------ | ------------------ | ------------------ |
| Stratégie génération du Plan Adressage           | Type de stratégie           |   Chaine de caractères   |   Oui  |  
| Énumération des spokes ou espaces réseau dans la zone d accueil | Liste des noms de spokes ou espaces réseau dans la zone d accueil cible     | Chaine de caractères |  Oui | Cette liste est obligatoire peu importe la stratégie choisie   |
| Liste de triplets (adresse IP de départ & préfixe réseau OU nombre d hotes attendus & Liste des spokes ou espace réseau associés ) | Ensemble de triplets (adresse IP de départ & préfixe réseau OU nombre d hotes attendus & Liste des spokes ou espace réseau associés )     | Chaine de caractères    |  Oui |  Chaque triplet est séparé par le symbole @. Chaque élément d'un triplet est séparé par le symbole & . Si on y trouve une seule configuration , alors cette unique configuration est appliquée a tous les spokes ou espaces réseau. |
| Pas pour incrémenter ou décrementer préfixe reseau  | Pas pour incrémenter ou décrementer préfixe reseau           | Chaine de caractères    | Non | Exemple : -2 , 3 . Ce paramétre n'est valable que pour les stratégies incrémenter ou décrémenter un préfixe réseau.  |


### Choix technologiques  

Afin de rendre cette boite noire réutilisable dans d'autres zones d'accueil AWS , Oracle , IBM , etc., nous avons choisi de l'implémenter dans le langage **Python**.  

### Preuve de concept


Le seul moyen concevable de dévoiler une boîte noire, c’est de jouer avec. Nous avons implémenter une POC pour faciliter la configuration du plan d'adressage

Nous avons fait notre preuve de concept avec un fonction Pyhton , qui génère un plan d'adressage , puis le plan généré est affecté dans un variable YAML structuré , avec le plan d'adressage par spoke ou espace réseau

Le flow YAML va par la suite accéder à un index de la variable pour récupérer son plan d'adressage (Ex : 10.80.0.7 / 26) , et va l'affecter comme propriété à la ressource à déployer dans l'environnement Azure

### Flow exécution

L'intégration de la sortie du générateur du plan d'adressage se fera par la modification au runtime des variables YAML qui contiennent les préfixes et suffixes réseau

Voici le flow d'exécution

1. platform.yml
2. /azure-pipeline/config/variables/scenario-base/cei-base-param.yml
3. templates/steps/deploy-platform.yml
4. scripts/generateur-plan-adressage/generer_plan_adressage.py
5. step affectation des variables préfixes et suffixes de l'étape 2 par les sorties de l'étape 4

### Liste des fichiers impliqués

| Fichier      | Rôle   | Emplacement    |
| ------------------- | ------ | ------------------ |
| [cei-base-param.yml](../../../azure-pipeline/config/variables/scenario-base/cei-base-param.yml) | Fichier qui contient les variables YAML avec les préfixes et suffixes réseau    |   /azure-pipeline/config/variables/scenario-XXX/cei-base-param.yml    |
| [platform.yml](../../../azure-pipeline/platform.yml) | Pipeline de déploiement des abonnements plafteformes , avec les nouveaux paramètres sur l'IHM. Nous y avons ajouté de nouveaaus types pour installer Python , installer les paquetages Python    |   azure-pipeline/platform.yml    |
| [deploy-plaform.yml](../../../azure-pipeline/templates/steps/deploy-platform.yml) | script YAML qui implémente les étapes (steps ) du pipeline de déploiement des abonnements plateformes. Nous y avons ajouté de nouveaux steps pour installer Python , installer les paquetages Python ipaddress , netaddr et argparse   |   azure-pipeline/templates/steps/deploy-platform.yml    |
| [generateur_plan_adressage.py](../generer_plan_adressage.py) | Fichier a appeler depuis pipeline YAML pour lancer la génération du plan d'adressage par spoke ou espace réseau    |    scripts/generateur-plan-adressage/generer_plan_adressage.py   |
| [plan_adressage.py](../plan_adressage.py) | Fichier qui contient la classe PlanAdressage qui implémente les stratégies de génération    |    scripts/generateur-plan-adressage/plan_adressage.py   |

### Code source

Voici le lien vers le dossier contenat la documentation markdown et les scripts Python et Yaml

[scripts/generateur-plan-adressage/](../../)

* Fichier cei-base-param.yml

Aucun changement dans ce fichier.  

* Fichier platform.yml 

Ajout des instructions suivantes :  

    
    - name: strategiePlanAdressage
    displayName: "Strategie génération du Plan Adressage : incrementation_prefixe_reseau OU nombre_hote"
    type: string
    default: incrementation_prefixe_reseau
    values:
        - incrementation_prefixe_reseau
        - nombre_hote
    - name : listeSousReseauZoneAccueil
    displayName: "Énumération des spokes ou espaces réseau dans la zone d accueil, séparés par &"
    type: string
    - name : porteeAdresseDepart
    displayName: "Liste de triplets (adresse IP de départ & préfixe réseau  OU nombre d hotes attendus & Liste des spokes ou espace réseau associés ) pour définir la portée d une adresse dans la génération . Ex : 10.84.0.0&17&EVOLUTION@10.82.0.0&18&connectivite,Gateway"
    type: string  
    - name : pasPrefixeReseau
    displayName: "Pas pour incrementer ou decrementer prefixe reseau"
    type: string
    default: 1


* Fichier deploy-plaform.yml 

Ajout des instructions suivantes :  


    parameters:
    - name: description
        type: string
    - name: workingDir
        type: string
    - name: deployOperation
        type: string
        default: create
        values:
        - create
        - what-if
    - name : strategiePlanAdressage
        type: string
        default: incrementation_prefixe_reseau
        values:
        - incrementation_prefixe_reseau
        - nombre_hote
    - name : listeSousReseauZoneAccueil
        type: string
    - name : porteeAdresseDepart
        type: string
    - name : pasPrefixeReseau
        type: string
        default: 1
    - name : valeurLicFortigateA
        type: string
    - name : valeurLicFortigateB
        type: string


    steps:


    # ----------------------------------------------------------------------------------
    #  Génération plan d'adressage
    # ----------------------------------------------------------------------------------

    - task: UsePythonVersion@0
    displayName: 'Installation Python version 3.8'
    inputs:
        versionSpec: '3.8'

    - script: |
        python -m pip install --upgrade pip
    displayName: 'Installation pip'

    - script: |
        pip install ipaddress netaddr argparse
    displayName: 'Installation paquetages ipaddress , netaddr et argparse'

    - task: PythonSCript@0
    displayName: 'Génération plan adressage'
    inputs:
        scriptSource: 'filePath'
        scriptPath: 'scripts/generateur-plan-adressage/generer_plan_adressage.py'
        arguments : -a '${{ parameters.strategiePlanAdressage }}' -p '10.84.0.0&17&EVOLUTION@10.82.0.0&18&connectivite,Gateway' -l 'connectivite&ASSIGNE&Gateway&AzureFirewall&EVOLUTION&NVASubnetExterne&NVASubnetInterne' -i ${{ parameters.pasPrefixeReseau }} 
        workingDirectory: '${{ parameters.workingDir }}'
    # now you can use the variable in the next step

    - task: AzureCLI@2
    displayName: 'Modifications des préfixes et suffixes YAML par la sortie du générateur du plan d adressage reseau'
    inputs:
        azureSubscription: $(serviceConnectionName)
        scriptType: 'bash'
        scriptLocation: 'inlineScript'
        inlineScript: |
        $(var-bashPreInjectScript)

        echo "my favorite color is: $(COLOR)"

        $(var-bashPostInjectScript)
        workingDirectory: '${{ parameters.workingDir }}'

* Classe PlanAdressage

    class PlanAdressage():

        #lancer la génération
        def generer(
                pliste_sous_reseau
                , palgorithme
                , pparametre_algorithme
                , pliste_portee_adresse_depart
                , ptype_adresse_ip = 'IPv4'
                )

        # générer plan adressage réseau suivant prefixe réseau
        def incrementation_prefixe_reseau(pliste_sous_reseau
                                        , pliste_portee_adresse_ip_depart 
                                        , ppas_prefixe_reseau_cidr):

        #calculer un prefixe réseau a aprtir d'une adresse IP de départ et un nombre de hotes
        def calculer_prefixe_reseau_from(padresse_ip_depart , pnombre_hote)

        # générer plan adressage réseau avec nombre de hotes attendus
        def a_partir_du_nombre_de_hotes(pliste_sous_reseau
                                      , pliste_portee_adresse_ip_depart ):
    

## Conclusion  

La génération du plan d'adressage réseau dans la zone d'accueil Azure peut être vue , comme un  module , comme une boite noire . On peut modifier ou améliorer la logique d'affaire de cette boite noire et cela ne va pas entrainer le refactoring du modèle de déploiement de la zone d'accueil.

Ce module peut être commun à tous les zones d'accueil infonuagique au CEI.


## Annexes  
  
* [Chiffrier Excel avec Plan d'adressage IP de la zone d'accueil Azure](../../../Doc/fichiers/Adressage_IP_ZoneAccueil_Azure_base.xlsx) 
* https://www.sebastienadam.be/ipcalculator/
* https://www.site24x7.com/fr/tools/ipv4-sous-reseau-calculatrice.html
