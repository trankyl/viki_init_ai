# Contrôles de sécurité pour l'exigence minimale 9

09 : Implémenter des services de sécurité réseau

Contrôles communs à l'exigence 09 : AC-3, AC-4, SC-5, SC-7, SC-7(5), SI-3, SI-3(7), SI-4

## < --- Contrôle EX9_AC-3--->

![EX9](../images/ex9_AC-3.PNG)

## Validation Contrôle EX9_AC-3

   1. Responsabilité fournisseur : Oui
   2. Commentaire : Le script de zone d'accueil crée plusieurs stratégies (*policies*) et groupes pour segmenter les accès aux ressources infonuagiques selon différents profils d'utilisateurs.
   Vérification:
   Identité & Sécurité-->Politiques
   Identité & Sécurité-->Groups
   3. [Lien Document](https://docs.public.oneportal.content.oci.oraclecloud.com/fr-ca/iaas/Content/devops/using/create-policy.htm)

## < --- Contrôle EX9_AC-4--->  

![EX9](../images/ex9_AC-4.PNG)

## Validation Contrôle EX9_AC-4

   1. Responsabilité fournisseur : Oui
   2. Commentaire : Il faut s'assurer que chaque VCN soit protégé par une ou plusieurs règles, d'entrée ou de sortie, définies par un pare-feu de type NGF, une liste de sécurité et/ou un NSG (*Network security group*).

   La présence de pare-feux peut être confirmée par la présence de VM de pare-feu au niveau du compartiment "cmp-conne-001 Compartment". Pour ce faire, naviguer dans : Compute-->Instances

  On devrait aussi vérifier les rapports :

- Protégé B : Section 'Networking'
- Cloud Guard : Label = CIS_OCI_V1.1_NETWORK et/ou label = CIS_OCI_V1.0_NETWORK
- Vulnerability Scanning : Scanning reports-->onglet 'Ports'

 3. [Lien Document](https://docs.oracle.com/fr-ca/iaas/Content/Network/Concepts/networksecuritygroups.htm)

## < --- Contrôle EX9_SC-5--->

![EX9](../images/ex9_SC-5.PNG)

## Validation Contrôle EX9_SC-5

   1. Responsabilité fournisseur : Oui
   2. Commentaire : Le script de zone d'accueil ne crée pas par défaut de WAF pour minimiser les coûts. Lors du déploiement d'application dans votre locataire (*tenant*), il est conseillé de configurer les équilibreurs de charge et des WAF.
   3. [Lien Document](https://docs.oracle.com/fr-ca/iaas/Content/WAF/Concepts/overview.htm)

## < --- Contrôle EX9_SC-7--->

![EX9](../images/ex9_SC-7.PNG)

## Validation Contrôle EX9_SC-7

   1. Responsabilité fournisseur : Oui
   2. Commentaire : Les VCN peuvent contenir des sous-réseaux publics ou privés. Le script de zone d'accueil ne crée pas par défaut de réseau public au niveau des périphériques (*spokes*). Les journaux des sous-réseaux doivent être régulièrement inspectés  - Logging-->Log Groups-->CEI01-flow-logs-group
   3. [Lien Document](https://docs.oracle.com/fr-ca/iaas/Content/Network/Concepts/overview.htm)

## < --- Contrôle EX9_SC-7(5)--->

![EX9](../images/ex9_SC-7(5).PNG)

## Validation Contrôle EX9_SC-7(5)

   1. Responsabilité fournisseur : Oui
   2. Commentaire : Avec le script de zone d'accueil, les FortiGate sont installés sans règle de pare-feu et les listes de sécurité sont vides par défaut pour tous les sous-réseaux.
   3. [Lien Document](https://docs.oracle.com/fr-ca/iaas/Content/Network/Concepts/networksecuritygroups.htm)

## < --- Contrôle EX9_SI-3--->

![EX9](../images/ex9_SI-3.PNG)

## Validation Contrôle EX9_SI-3

   1. Responsabilité fournisseur : Oui
   2. Commentaire : Comme bonne pratique, il faut activer des pare-feux d’applications Web (WAF), Vulnerability Scanning et utiliser autant que possible des VM de type instance de bouclier (*'Shield instance'*). Cependant, ces mécanismes ne protègent pas contre les virus; l'utilisation d'un anti-virus d'un tiers est donc conseillée. - Vulnerability scanning: Scanning reports-->onglet 'Ports'
   3. [Lien Document](https://docs.oracle.com/fr-ca/iaas/Content/WAF/Concepts/overview.htm)

## < --- Contrôle EX9_SI-3(7)--->

![EX9](../images/ex9_SI-3(7).PNG)

## Validation Contrôle EX9_SI-3(7)

   1. Responsabilité fournisseur : Oui
   2. Commentaire : Comme bonne pratique, il faut activer des pare-feux d’applications Web (WAF), Vulnerability Scanning et utiliser autant que possible des VM de type instance de bouclier (*'Shield instance'*). Cependant, ces mécanismes ne protègent pas contre les virus; l'utilisation d'un anti-virus d'un tiers est donc conseillée. - Vulnerability scanning : Scanning reports-->onglet 'Ports'
   3. [Lien Document](https://docs.oracle.com/fr-ca/iaas/Content/WAF/Concepts/overview.htm)

## < --- Contrôle EX9_SI-4--->

![EX9](../images/ex9_SI-4.PNG)

## Validation Contrôle EX9_SI-4Contrôle EX9_SI-4

   1. Responsabilité fournisseur : Oui
   2. Commentaire : Utiliser les fonctions de surveillance de menace de Cloud Guard. Vérifier également les journaux des réseaux dans OCI Logging. Optionnellement, il est possible d'utiliser Logging Analytics pour identifier plus rapidement des problèmes au niveau des journaux. Cette option engendre toutefois des coûts.
   Vérification:
   3. [Lien Document](https://docs.public.oneportal.content.oci.oraclecloud.com/fr-ca/iaas/releasenotes/changes/f6044420-4982-47ce-8674-fc39248c2cf8/)
  
 [Retour à la liste des exigences](OCI_12_exigences.md)
