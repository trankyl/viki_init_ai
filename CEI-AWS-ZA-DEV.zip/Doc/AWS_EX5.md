# Contrôles de sécurité  pour l'exigence 5

05 : Déterminer la localisation des données
  
![EX5](image/EX5.jfif)

[Lien document](https://aws.amazon.com/fr/about-aws/global-infrastructure/regions_az/)

[Retour à la Page d'accueil](/ReadMe.md)
