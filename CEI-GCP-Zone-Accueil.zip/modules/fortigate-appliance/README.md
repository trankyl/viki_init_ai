# Fortigate HA Cluster

## Conception

Il y a quelques limitations de conceptions qui entraînent cette conception actuelle.

- GCP reuiert l'utilisation de groupes d'instance pour utiliser répartition de charge dans les interfaces autre que nic0. Chaque appareil virtuel a des métadonnées uniques qui sont utilisées pour la configuration de mettre en place. Donc les instances statiques ont été utilisées pour accomplir cette tâche.

- L'image sur-demande requiert que l'appareil soit capable d'accéder à l'internet via le port défaut nic0. Dans l'exemple, l'appareil GCP Cloud NAT est créé pour fournir l'accès internet sans donner un IP public à l'instance.

- En ce moment, port1 (utilisé pour réseau de transit) est ouvert à gestion parce que `Identity Aware Proxy (IAP)` requiert une connexion à `nic0` dans l'instance. Cela peut et devrait être interdit dans l'appareil afin de permettre l'intervalle de l'IP IAP dans ce port.

- Les images multi-nic dans GCP ont besoin d'avoir activé la capacité de "Guest OS" pour multi-nic. Consulter [cette page](https://cloud.google.com/vpc/docs/create-use-multiple-interfaces#i_am_having_connectivity_issues_when_using_a_netmask_that_is_not_32)

    Il y a une ressource Terraform qui crée l'image. Suivant est l'équivalent en `gcloud` pour référence

  `gcloud compute images create fortinet-fgtondemand-646-20210531-001-w-license-multi-nic \
     --source-image-project fortigcp-project-001 \
     --source-image fortinet-fgtondemand-646-20210531-001-w-license \
     --guest-os-features MULTI_IP_SUBNET \
     --project my-image-project`

- Le réseau interne (port3) est utilisé comme l'adresse `next hop` dans une route créée par le module mais maintenue par le connecteur de Fortigate SDN qui est configuré dans le module `terraform-fortios-configuration` qui est à exécuter après que ce module aura été complété.


## Exigence de pare-feu GCP
- IPProtocol: TCP
  ports:
  - '22'
- IPProtocol: TCP
  ports:
  - '443'
- IPProtocol: TCP
  ports:
  - '80'
- IPProtocol: TCP
  ports:
  - '541'
- IPProtocol: TCP
  ports:
  - '3000'
- IPProtocol: TCP
  ports:
  - '8008'

<!-- BEGINNING OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
## Exigence

Pas d'exigence

## Fournisseurs

| Nom                                                              | Version |
|------------------------------------------------------------------|---------|
| <a name="provider_google"></a> [google](#provider\_google)       | 3.74.0 |
| <a name="provider_local"></a> [local](#provider\_local)          | n/a |
| <a name="provider_null"></a> [null](#provider\_null)             | 3.1.0 |
| <a name="provider_random"></a> [random](#provider\_random)       | 3.1.0 |
| <a name="provider_template"></a> [template](#provider\_template) | 2.2.0 |

## Modules

| Nom                                                                                                                                                      | Source | Version |
|----------------------------------------------------------------------------------------------------------------------------------------------------------|--------|---------|
| <a name="module_compute_address_internal_active_ip"></a> [compute\_address\_internal\_active\_ip](#module\_compute\_address\_internal\_active\_ip)       | ../terraform-gc-naming//modules/gcp/compute_address_internal_ip | 2.14.3 |
| <a name="module_compute_address_internal_mirror_port"></a> [compute\_address\_internal\_mirror\_port](#module\_compute\_address\_internal\_mirror\_port) | ../terraform-gc-naming//modules/gcp/compute_address_internal_ip | 2.14.3 |
| <a name="module_compute_address_internal_passive_ip"></a> [compute\_address\_internal\_passive\_ip](#module\_compute\_address\_internal\_passive\_ip)    | ../terraform-gc-naming//modules/gcp/compute_address_internal_ip | 2.14.3 |
| <a name="module_fortigate_service_account"></a> [fortigate\_service\_account](#module\_fortigate\_service\_account)                                      | ../terraform-gc-naming//modules/gcp/service_account | 2.14.3 |
| <a name="module_instances"></a> [instances](#module\_instances)                                                                                          | ../terraform-virtual-machine | 1.1.0 |
| <a name="module_mirror_backend_service"></a> [mirror\_backend\_service](#module\_mirror\_backend\_service)                                               | ../terraform-gc-naming//modules/gcp/region_backend_service | 2.14.3 |
| <a name="module_mirror_forwarding_rule"></a> [mirror\_forwarding\_rule](#module\_mirror\_forwarding\_rule)                                               | ../terraform-gc-naming//modules/gcp/forwarding_rule | 2.14.3 |
| <a name="module_probe_response_health_check"></a> [probe\_response\_health\_check](#module\_probe\_response\_health\_check)                              | ../terraform-gc-naming//modules/gcp/health_check | 2.14.3 |
| <a name="module_virtual_machine_instance_group"></a> [virtual\_machine\_instance\_group](#module\_virtual\_machine\_instance\_group)                     | ../terraform-gc-naming//modules/gcp/virtual_machine_instance_group | 2.14.3 |
| <a name="module_vm_name"></a> [vm\_name](#module\_vm\_name)                                                                                              | ../terraform-gc-naming//modules/gcp/virtual_machine | 2.6.2 |

## Resources

| Nom                                                                                                                                                                           | Type |
|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|------|
| [google_compute_address.active](https://registry.terraform.io/providers/hashicorp/google/latest/docs/resources/compute_address)                                               | resource |
| [google_compute_address.mirror_lb](https://registry.terraform.io/providers/hashicorp/google/latest/docs/resources/compute_address)                                            | resource |
| [google_compute_address.passive](https://registry.terraform.io/providers/hashicorp/google/latest/docs/resources/compute_address)                                              | resource |
| [google_compute_forwarding_rule.mirror_forwarding_rule](https://registry.terraform.io/providers/hashicorp/google/latest/docs/resources/compute_forwarding_rule)               | resource |
| [google_compute_image.fortios](https://registry.terraform.io/providers/hashicorp/google/latest/docs/resources/compute_image)                                                  | resource |
| [google_compute_instance_group.instance_group](https://registry.terraform.io/providers/hashicorp/google/latest/docs/resources/compute_instance_group)                         | resource |
| [google_compute_packet_mirroring.internal](https://registry.terraform.io/providers/hashicorp/google/latest/docs/resources/compute_packet_mirroring)                           | resource |
| [google_compute_region_backend_service.mirror_backend_service](https://registry.terraform.io/providers/hashicorp/google/latest/docs/resources/compute_region_backend_service) | resource |
| [google_compute_region_health_check.probe_response](https://registry.terraform.io/providers/hashicorp/google/latest/docs/resources/compute_region_health_check)               | resource |
| [google_compute_route.internal](https://registry.terraform.io/providers/hashicorp/google/latest/docs/resources/compute_route)                                                 | resource |
| [google_project_iam_member.fortigate_project](https://registry.terraform.io/providers/hashicorp/google/latest/docs/resources/project_iam_member)                              | resource |
| [google_project_iam_member.internal_network_project](https://registry.terraform.io/providers/hashicorp/google/latest/docs/resources/project_iam_member)                       | resource |
| [google_service_account.fortigate_service_account](https://registry.terraform.io/providers/hashicorp/google/latest/docs/resources/service_account)                            | resource |
| [null_resource.setup_api_key](https://registry.terraform.io/providers/hashicorp/null/latest/docs/resources/resource)                                                          | resource |
| [null_resource.setup_replication](https://registry.terraform.io/providers/hashicorp/null/latest/docs/resources/resource)                                                      | resource |
| [random_password.fgt_ha_password](https://registry.terraform.io/providers/hashicorp/random/latest/docs/resources/password)                                                    | resource |
| [google_compute_subnetwork.subnetworks](https://registry.terraform.io/providers/hashicorp/google/latest/docs/data-sources/compute_subnetwork)                                 | data source |
| [local_file.Terraform_RW_User_API_key](https://registry.terraform.io/providers/hashicorp/local/latest/docs/data-sources/file)                                                 | data source |
| [template_file.metadata](https://registry.terraform.io/providers/hashicorp/template/latest/docs/data-sources/file)                                                            | data source |
| [template_file.replication](https://registry.terraform.io/providers/hashicorp/template/latest/docs/data-sources/file)                                                         | data source |

## Entrées

| Nom                                                                                                                                                    | Description | Type | Défaut                                              | Requis |
|--------------------------------------------------------------------------------------------------------------------------------------------------------|-------------|------|-----------------------------------------------------|:--:|
| <a name="input_admin_ssh_private_key_location"></a> [admin\_ssh\_private\_key\_location](#input\_admin\_ssh\_private\_key\_location)                   | Endroit pour le clé privé à utiliser pour la connexion à Fortigate pour des réglages initiales | `any` | n/a                                                 | oui |
| <a name="input_admin_ssh_public_key"></a> [admin\_ssh\_public\_key](#input\_admin\_ssh\_public\_key)                                                   | Clé public SSH utilisé pour configurer les réglages initiales de Fortigate. Quand créer la variable soit localement soit dans le secret, ne pas inclure le nom d'usager à la fin du clé, cela sera ajouté pendant l'exécution du module.  | `any` | n/a                                                 | oui |
| <a name="input_compute_resource_policy"></a> [compute\_resource\_policy](#input\_compute\_resource\_policy)                                            | Police à joindre dans les disques des appareils  | `string` | `""`                                                | non |
| <a name="input_compute_resource_policy_non_bootdisk"></a> [compute\_resource\_policy\_non\_bootdisk](#input\_compute\_resource\_policy\_non\_bootdisk) | Police à joindre dans les disques des appareils | `string` | `""`                                                | non |
| <a name="input_department_code"></a> [department\_code](#input\_department\_code)                                                                      | Code pour département, partie du module de nommage | `string` | n/a                                                 | oui |
| <a name="input_environment"></a> [environment](#input\_environment)                                                                                    | S-Sandbox P-Production Q-Quality D-development | `string` | n/a                                                 | oui |
| <a name="input_ha_port"></a> [ha\_port](#input\_ha\_port)                                                                                              | Clé pour network\_ports utilisé pour HA  | `string` | `"port2"`                                           | non |
| <a name="input_image"></a> [image](#input\_image)                                                                                                      | Nom d'image à utiliser | `string` | `"fortinet-fgtondemand-646-20210531-001-w-license"` | non |
| <a name="input_image_location"></a> [image\_location](#input\_image\_location)                                                                         | Projet où se trouve l'image source | `string` | `"fortigcp-project-001"`                            | non |
| <a name="input_internal_port"></a> [internal\_port](#input\_internal\_port)                                                                            | Clé pour network\_ports utilisé pour le réseau interne | `string` | `"port3"`                                           | non |
| <a name="input_location"></a> [location](#input\_location)                                                                                             | Endroit où se trouve les ressources | `string` | `"northamerica-northeast1"`                         | non |
| <a name="input_machine_type"></a> [machine\_type](#input\_machine\_type)                                                                               | Taille d'instance | `string` | `"n1-standard-4"`                                   | non |
| <a name="input_mgmt_port"></a> [mgmt\_port](#input\_mgmt\_port)                                                                                        | Clé pour network\_ports utilisé pour gestion d'appareil | `string` | `"port2"`                                           | non |
| <a name="input_mirror_port"></a> [mirror\_port](#input\_mirror\_port)                                                                                  | Clé pour network\_ports utilisé pour le miroir réseau  | `string` | `"port4"`                                           | non |
| <a name="input_network_ports"></a> [network\_ports](#input\_network\_ports)                                                                            | Configuration pour les ports sur les appareils fortigate,  fonctions valides qui sont en transite, HA, gestion et internes | <pre>map(object({<br>    port_name  = string<br>    project    = string<br>    subnetwork = string<br>  }))</pre> | n/a                                                 | oui |
| <a name="input_network_tags"></a> [network\_tags](#input\_network\_tags)                                                                               | Étiquettes de réseau à ajouter dans l'instance | `list(any)` | `[]`                                                | non |
| <a name="input_owner"></a> [owner](#input\_owner)                                                                                                      | Division ou groupe responsable pour l'engagement sécuritaire et financier | `string` | n/a                                                 | oui |
| <a name="input_project"></a> [project](#input\_project)                                                                                                | Projet auquel se mettra Fortigate | `any` | n/a                                                 | oui |
| <a name="input_region"></a> [region](#input\_region)                                                                                                   | Région dans laquelle ajoutera le pare-feu | `string` | `"northamerica-northeast1"`                         | non |
| <a name="input_sleep_seconds"></a> [sleep\_seconds](#input\_sleep\_seconds)                                                                            | Nombre de seconds à `sleep` avant de tenter d'obtenir le clé API | `number` | `100`                                               | non |
| <a name="input_transit_port"></a> [transit\_port](#input\_transit\_port)                                                                               | Clé pour network\_ports utilisé pour le réseau de transit  | `string` | `"port1"`                                           | non |
| <a name="input_user_defined_string"></a> [user\_defined\_string](#input\_user\_defined\_string)                                                        | String défini par l'usager  | `string` | n/a                                                 | oui |
| <a name="input_zone_1"></a> [zone\_1](#input\_zone\_1)                                                                                                 | Zone dans lequel s'ajoutera le premier appareil Fortigate | `string` | `"northamerica-northeast1-a"`                       | non |
| <a name="input_zone_2"></a> [zone\_2](#input\_zone\_2)                                                                                                 | Zone dans lequel s'ajoutera le deuxième appareil Fortigate  | `string` | `"northamerica-northeast1-b"`                       | non |

## Sorties

| Nom                                                                                                                     | Description |
|-------------------------------------------------------------------------------------------------------------------------|-------------|
| <a name="output_Terraform_RW_User_API_key"></a> [Terraform\_RW\_User\_API\_key](#output\_Terraform\_RW\_User\_API\_key) | n/a |
| <a name="output_fgt_ha_password"></a> [fgt\_ha\_password](#output\_fgt\_ha\_password)                                   | n/a |
| <a name="output_internal_route"></a> [internal\_route](#output\_internal\_route)                                        | n/a |
| <a name="output_mirror_lb_address"></a> [mirror\_lb\_address](#output\_mirror\_lb\_address)                             | n/a |
| <a name="output_port_to_network_map"></a> [port\_to\_network\_map](#output\_port\_to\_network\_map)                     | n/a |
<!-- END OF PRE-COMMIT-TERRAFORM DOCS HOOK -->