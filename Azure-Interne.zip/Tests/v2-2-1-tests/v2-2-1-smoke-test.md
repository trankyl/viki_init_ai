# Plan de test haut niveau pour la release v.2.2.1

## Policies
- [ ] Validation de la conformité de la zone d'accueil selon des prédéfinies acceptable
- [ ] Remédiation des *resource tags*
  - [ ] Les tags par rapport à l'organisation sont bien mis et définis dans le code
  - [ ] Les tags par rapport aux abonnements sont bien mis et définis dans le code
  - [ ] L'héritage suite à la remédiation se fait bien des abonnements vers les groupes de ressources
  - [ ] Les tags sont bel et bien obligatoires lors de la création ou modification d'un *resource group*.
  - [ ] Remédiation de public endpoint sur storage account et keyvault
  - [ ] La remédiation de *public endpoint* est appliquée sur le *storage account* et le *keyvault*
  - [ ] Il n'y a pas de *builtin* qui sont obsolète dans les initiatives utilisées
- [ ] *Resource Lock*
    - [ ] La remédiation applique les verrouillages sur les groupes de ressources de production
## Wipe Tenant
- [ ] Le nettoyage se fait même avec le *Resource Lock*
## BGP Propagation
- [ ] On peut configurer le paramètre BGP visuellement à la valeur *true* ou *false*
## Register resource provider
- [ ] La liste des fournisseurs de ressources est bien installée **avant** la fin du pipeline d'assignation des abonnements
## Service en lignes
- [ ] Les conflits d'addressages sont gérés
- [ ] Le *peering* est fait avec le hub
- [ ] Le routage NSG est fonctionnel
- [ ] Les services en lignes sont fonctionnels avec le *jumpbox* aussi.
## AVD
- [ ] Les ressources sont déployées pour le pipeline Commun
- [ ] Les ressources sont déployées pour le pipeline Instance
- [ ] Éventuellement peut être, Domain Controller dans Identité. Valider que les regle permette que AVD s'enregistre dans DC
- [ ] Lorsqu'un Domain Controller est déployé dans l'abonnement Identité, AVD peut communiquer avec ce Domain Controller.
## NSG / ASG / DNS Resolver
- [ ] TODO
## Groupes de variable
- [ ] Les groupes de variables sont bien fonctionnels pour tous les pipelines
  - [ ] Pour le pipeline 1 - Azure - ManagementGroups
    - [X] Pour le scénario de base
      - [ ] Le management group ServicesEnLigneNonProd existe dans le cadre du scénario de base
      - [ ] Le management group ServicesEnLigneProd existe dans le cadre du scénario de base
    - [X] Pour le scénario complexe
    - [X] Avec "None" comme organisation
    - [X] Avec "what-if" comme paramètre
  - [ ] Pour le pipeline 2 - Azure - AssignSubscriptions
    - [ ] Avec "None" comme organisation
    - [X] Pour le scénario de base
    - [ ] Pour le scénario complexe
  - [ ] Pour le pipeline 3 - Azure - Platform
    - [X] Pour le scénario de base
    - [ ] Pour le scénario complexe
  - [ ] Pour le pipeline 4 - Azure - LandingZone
    - [X] Pour le scénario de base
    - [ ] Pour le scénario complexe
  - [ ] Pour le pipeline 5 - Azure - Policy
    - [X] Pour le scénario de base
    - [ ] Pour le scénario complexe
  - [ ] Pour le pipeline 6 - Azure - RBAC
    - [X] Pour le scénario de base
    - [ ] Pour le scénario complexe
  - [ ] Pour le pipeline Azure - Wipe Tenant
- [ ] Le mot de clé None fait que le groupe de variables n'est pas utilisé pour les pipelines visés
- [ ] Toutes les valeurs des variables présentes dans le code ont priorité sur les valeurs du groupe de variables


## Checkbox et pipeline adhoc pour Wipe Policies
- [ ] Les anciennes *policies* sont bien nettoyées avant de procéder à l'assignation des nouvelles *policies*
