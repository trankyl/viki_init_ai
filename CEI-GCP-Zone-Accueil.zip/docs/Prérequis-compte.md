# Prérequis d'un nouveau compte Google Cloud

Quand créer un nouveau compte Google cloud, les artifacts suivants seront exigés :
- Un ou pluisuers IDs de compte de facture ou l'accès à une carte de crédit qui sera associée avec le nouveau compte de facture
- Un courriel (nouveau ou existant) en tant que "Primary Admin" [ici](https://admin.google.com/ac/accountsettings) et en tant que "Super Admin" [ici](https://admin.google.com/ac/roles/53389702564151297)
- Un domain existant ou nouveau pour la validation de DNS de l'organisation

Un rôle spécial IAM devra être ajouté dans tous les nouveaux usagers de noveau "super admin" au-delà du compte racine SA original et tous les comptes service utilisant de déploiements automatisés dans les nouveaux projets qui nécessitent des permissions de facturation associés pour lier un compte de facture à des projets. En plus de "Gérant de facturation de projet", nous avons besoin de mettre en place un administrateur de compte de facture.

Dans la capture d'écran suivant, c'est un nouveau compte GCP où le compte racine a été automatiquement ajouté dans le côte de permission de facturation dans [la page de facturation](https://console.cloud.google.com/billing). Tous les usagers admins additionnels sont ajoutés automatiquement dans le côté de facturation s'ils sont ajoutés dans IAM. Remarquer que le compte racine n'est pas défini en IAM mais l'est en la facturation.

<img width="1882" alt="_billing_account_administrator_role_new_account_both_iam_and_billing" src="https://user-images.githubusercontent.com/94715080/174884634-7d32a255-014d-4252-95ad-ee5005d73127.png">

---

# Compte Google Cloud après déploiement de la zone d'accueil

Après avoir créé votre organisation, nous recommandons une des mesures de sécurité suivantes ou options de déploiements de la zone d'accueil dépendant le profil de sécurité de vos projets et/ou votre organisation.

## Mesure de sécurité de Google Cloud et options de la zone d'accueil

Déterminant quel ensemble de mesure de sécurité ou de zone d'accueil dépendra de votre cas d'utilisation du [profil de cloud](https://github.com/canada-ca/cloud-guardrails/blob/master/EN/00_Applicable-Scope.md#cloud-usage-profiles)

[//]: # (  &#40;Level 1 for private only sandboxes all the way to Level 6 for PBMM &#40;Protected B Medium Integrity / Medium Availability - with or without SCED/SC2G - see slide 18-19 of https://wiki.gccollab.ca/images/7/75/GC_Cloud_Connection_Patterns.pdf&#41;)

Nous recommandons soit les [mesures de sécurité de 30-jours](https://github.com/canada-ca/accelerators_accelerateurs-gcp) ou une zone d'accueil [PBMM complète](https://github.com/GoogleCloudPlatform/pbmm-on-gcp-onboarding) pour profil 1 ou 2 ou travail de prototypage.

Nous recommandons la zone d'accueil [PBMM complète](https://github.com/GoogleCloudPlatform/pbmm-on-gcp-onboarding) pour profil 2 à 6

[Validation de mesure de sécurité de 30-jour](https://github.com/canada-ca/cloud-guardrails-gcp/tree/main/guardrails-validation)

[Documentation des contrôles de mesures de sécurité](https://github.com/canada-ca/cloud-guardrails/tree/master/EN)

### Gabarits additionnels et SDKs

- [Config Controller Anthos based Landing Zone blueprint](https://cloud.google.com/anthos-config-management/docs/tutorials/landing-zone)

- [Terraform based SDK blueprints](https://cloud.google.com/docs/terraform/blueprints/terraform-blueprints#blueprints) off the [Cloud Foundation Toolkit](https://cloud.google.com/foundation-toolkit)

- [Example Log Sinks](https://github.com/terraform-google-modules/terraform-google-log-export)

- [Google infrastructure security design overview](https://cloud.google.com/docs/security/infrastructure/design)

- [Security Foundations Blueprint](https://cloud.google.com/architecture/security-foundations)

- [Secure data exchange with ingress and egress rules](https://cloud.google.com/vpc-service-controls/docs/secure-data-exchange)

- [Compliance offerings](https://cloud.google.com/security/compliance/offerings#/regions=Canada)

---

## Intégration Catégorie 1: Compte Workspace - Domaines hébergés sur Google Domains

Suivi les étapes suivantes si:
* Vous être un nouveau client et nécessitez un nouveau domaine.

Le scénario vous guidera dans le processus d'acheter un domaine disponible dans Google Domains et créer un nouveau compte Workspace.

**Effectue les étapes suivantes dans la mode privée de votre navigateur.**

Pour créer un nouveau compte de Google Workspace:
1. Aller à [cette page](https://workspace.google.com/business/signup/welcome)
2. Entrer le nom de votre entreprise.
3. Choisir "Just You" sous "Nombre d'employés". Vous pouvez l'ajuster plus tard.
4. Assurer que "Canada" est choisi pour la "Région".
5. Cliquer "Suivant"

<img width="1770" alt="Screen Shot 2022-06-05 at 08 29 35" src="https://user-images.githubusercontent.com/24765473/172050451-ac9d24e0-980f-49d1-ac0d-fab492618e44.png">

6. Entrer les informations pour l'administrateur du compte de Google Workspace et votre courriel actuel.
7. Cliquer "Suivant"

<img width="1766" alt="Screen Shot 2022-06-05 at 08 30 36" src="https://user-images.githubusercontent.com/24765473/172050528-75b8927b-8b55-4999-83fb-ce1da20e78b6.png">

8. Dans l'étape suivante, choisi "No, I need one" afin d'acheter un nouveau domaine.

<img width="1778" alt="Screen Shot 2022-06-05 at 08 31 21" src="https://user-images.githubusercontent.com/24765473/172050562-f5a3b75d-575a-417a-8528-6e9356eea83a.png">

9. Chercher un nom de domaine disponible et cliquer sur le nom de domaine ou la flèche ">"

<img width="1772" alt="Screen Shot 2022-06-05 at 10 16 36" src="https://user-images.githubusercontent.com/24765473/172055017-970f3972-1981-479e-9d87-542ad53ec276.png">

10. Cliquer "Suivant".

<img width="1775" alt="Screen Shot 2022-06-05 at 10 17 59" src="https://user-images.githubusercontent.com/24765473/172055035-f9262497-08a8-47b3-b00d-b705e52c47b2.png">

11. Entrer l'information de votre entreprise et cliquer "Suivant".
12. Choisir si vous voulez recevoir des annonces et des offres.
13. Choisir si vous voulez que vos usagers reçoivent les informations et les astuces de Google Worksapce.
14. Créer votre premier usager, qui deviendra "Workspace Super Admin". Cliquer "Accepter et Continuer".

<img width="1767" alt="Screen Shot 2022-06-05 at 10 19 16" src="https://user-images.githubusercontent.com/24765473/172055093-8f4a2b6c-fd20-4d71-a2f0-6a58e35efaef.png">

15. Réviser votre plan de paiement et cliquer "Suivant".

<img width="1777" alt="Screen Shot 2022-06-05 at 10 20 03" src="https://user-images.githubusercontent.com/24765473/172055124-676d384c-5ac9-40a9-ba1d-baded5d78d06.png">

16. Entrer les détails de paiement et choisir si vous voulez renouveler automatiquement votre enregistrement du domain chaque année. Cliquer "Suivant" pour finaliser la création de votre compte de Workspace.

<img width="1773" alt="Screen Shot 2022-06-05 at 10 21 18" src="https://user-images.githubusercontent.com/24765473/172055180-bed23bc6-ad6f-421d-ab1f-ef6ad16c2025.png">

17. Cliquer "Continuer ver le console admin"

<img width="1772" alt="Screen Shot 2022-06-05 at 10 22 06" src="https://user-images.githubusercontent.com/24765473/172055236-f34015e4-8567-42d9-96bf-3f62c0fdf3cd.png">

**Important**: Vérifie votre boîte de réception de courriel et répondre au courriel vous demandant de vérifier l'information de contact. Cela est exigé par ICANN (the governing body for domain registration) pour compléter l'enregistrement du domaine. Après avoir acheté le domaine, vous recevrez un courriel pour vérifier votre adresse de courriel. Vous devez vérifier l'adresse de courriel dans 15 jours. Sinon, votre domaine ne sera pas enregistré et vous ne pouvez pas l'utiliser pour courriel ou d'autres services.

<img width="773" alt="Screen Shot 2022-06-05 at 11 08 14" src="https://user-images.githubusercontent.com/24765473/172057273-09a32553-83e0-4d2f-8ddf-96d3cafba3f8.png">

### Étapes de validation du compte Workspace

1. Dans le console admin, vous verrez l'alerte "Enregistrement du domain est en cours" (Comme suivant) si vous n'avez pas encore répondu au courriel qui vous a été envoyé après avoir acheté le domaine. Si vous ne l'avez pas encore fait, veuillez vérifier l'adresse courriel en ouvrant le courriel envoyé par Google Domains et cliquer "Verifier le courriel maintenant"

<img width="1774" alt="Screen Shot 2022-06-05 at 10 22 32" src="https://user-images.githubusercontent.com/24765473/172055244-b3638c99-544e-4f4c-a145-d519976c7e49.png">

2. Pour vérifier les abonnements de service, aller à "Billing -> Subscriptions". Vérifier que vous avez: Enregistrement du domain et Google Workspace.

<img width="1775" alt="Screen Shot 2022-06-05 at 10 23 32" src="https://user-images.githubusercontent.com/24765473/172055284-ec163002-927e-4f93-bb97-1b23c62c0bb0.png">

3. Aller à "Account -> Admin Roles" pour valider que votre compte d'admin a été ajouté au rôle Super Admin.

<img width="1677" alt="Screen Shot 2022-06-05 at 10 29 08" src="https://user-images.githubusercontent.com/24765473/172055573-32d5995e-cf96-428d-858a-1b7a276454f5.png">

### Mettre en place l'organisation GCP

1. Aller à [cette page](http://console.cloud.google.com)
2. Choisir "Canada" pour le pays, lire les termes de service et cliquer "Accepter et Continuer"

<img width="1679" alt="Screen Shot 2022-06-05 at 10 30 19" src="https://user-images.githubusercontent.com/24765473/172056451-b54af622-7067-4318-bbfd-bc892993b8a8.png">

3. Activer votre essai gratuit en cliquant le bouton "Activer" se trouvant au coin supérieure droite de l'écran.

<img width="1671" alt="Screen Shot 2022-06-05 at 10 30 52" src="https://user-images.githubusercontent.com/24765473/172056460-9a9af020-a442-4f46-8872-e2731da04251.png">

4. Entrer les informations requises sur le compte et le paiement. Ces étapes vous aident à mettre en place un compte de facturation.

<img width="1677" alt="Screen Shot 2022-06-05 at 10 33 10" src="https://user-images.githubusercontent.com/24765473/172056504-fd3c7fdd-117a-4740-a008-c3d5df453f40.png">

<img width="1673" alt="Screen Shot 2022-06-05 at 10 33 39" src="https://user-images.githubusercontent.com/24765473/172056510-0a805854-16d1-45ae-a53e-a4a330f5216e.png">

<img width="1675" alt="Screen Shot 2022-06-05 at 10 34 12" src="https://user-images.githubusercontent.com/24765473/172056521-4dda0433-d8b2-4d9c-ac2a-8a8487e0f181.png">

<img width="612" alt="Screen Shot 2022-06-05 at 10 35 08" src="https://user-images.githubusercontent.com/24765473/172056531-870bf9d7-c027-44e0-bf5f-246c4a65a933.png">

5. Répondre au questionnaire et cliquer "Terminé"

<img width="1678" alt="Screen Shot 2022-06-05 at 10 35 40" src="https://user-images.githubusercontent.com/24765473/172056541-af79f786-d0dc-43ad-b258-ea0114b27785.png">

**Étapes de validation GCP**
1. Dans le console de GCP, aller à IAM & Admin -> Identity & Organization.
2. Cliquer le bouton "Aller à la liste de contrôle"

<img width="1674" alt="Screen Shot 2022-06-05 at 10 31 40" src="https://user-images.githubusercontent.com/24765473/172056470-e70236d6-3654-436f-aeba-688eb0925c92.png">

3. Assurez-vous que vous avez les permissions pour effectuer certaines actions d'admin dans le console comme suivant.

<img width="1676" alt="Screen Shot 2022-06-05 at 10 31 51" src="https://user-images.githubusercontent.com/24765473/172056476-9fd454a6-6234-4eb2-b56b-34615252c1a3.png">

4. Cliquer "Cloud Identity & Organization"(Dans le menu à gauche) et valider que cette étape a été complétée.
5. Aller à "IAM & Admin -> IAM" pour valider les permissions pour votre organisation. Assurez que le nom de votre organisation est sélectionné. Il se trouve normalement en haut de l'écran, à gauche du champ de recherche.

<img width="1668" alt="Screen Shot 2022-06-05 at 10 46 26" src="https://user-images.githubusercontent.com/24765473/172056383-0f11aa21-8352-4712-9376-edbed2043f53.png">

6. Réviser les rôles par défaut au niveau de l'organisation et accorder votre usager d'admin les rôles: Owner et Folder Admin.

<img width="1662" alt="Screen Shot 2022-06-05 at 10 57 09" src="https://user-images.githubusercontent.com/24765473/172056846-a796853f-b7e6-4edd-98c3-5b8fb45c3791.png">

7. Pour valider le rôle de "Folder Admin", créer un dossier de test dans votre organisation
8. Entrer "Gérer les ressources" dans le champ de recherche en haut de l'écran. Choisir "Gérer les ressources".
9. Cliquer "Créer un dossier"
10. Entrer les informations requises et assurez que votre organisation est sélectionnée sous "Organisation" et "Endroit". Cliquer "Créer".

<img width="1667" alt="Screen Shot 2022-06-05 at 10 57 57" src="https://user-images.githubusercontent.com/24765473/172056857-8f2f0460-7411-4f3c-888f-e9db02ebada0.png">

11. Actualiser la page pour voir le nouveau dossier.

<img width="1675" alt="Screen Shot 2022-06-05 at 10 58 27" src="https://user-images.githubusercontent.com/24765473/172056860-112e00f3-91ad-4b9a-bc82-fc3ff52a5261.png">

12. Dans le même écran, valider que vous pouvez créer des projets dans le dossier créé dans l'étape précédente.
13. Cliquer "Créer Projet"
14. Entrer les informations requises et assurez que votre organisation est sélectionné sous "Organisation", et le dossier créé est sélectionné sous "Endroit". Cliquer "Créer".

<img width="1671" alt="Screen Shot 2022-06-05 at 11 02 46" src="https://user-images.githubusercontent.com/24765473/172057009-3bed2530-d3c7-45fe-9f87-87b10fa3e369.png">

**Augmentation de Quota**

Par défaut, un compte de facturation peut seulement lier à un certain nombre de projets, basé sur des facteurs divers. Pour demander une augmentation de quota:
1. Créer (au moins) 5 projets, ou plus, dans le dossier créé dans la section de la validation de GCP
2. Dans le menu à gauche, aller à "Facturation" et choisir "Mes Projets". Remarquer que la facturation du dernier projet a été désactivé.
3. Dans la colonne "Actions", cliquer l'icône "Plus d'actions" (3 points) correspondant au projet. Choisir "Changer la facturation".

<img width="1670" alt="Screen Shot 2022-06-05 at 11 04 01" src="https://user-images.githubusercontent.com/24765473/172057176-2b2d3ba4-63e4-417c-80f8-ea04001920e3.png">

4. Choisir un compte de facturation et cliquer "Définir le compte"

<img width="513" alt="Screen Shot 2022-06-05 at 11 04 32" src="https://user-images.githubusercontent.com/24765473/172057181-132ecd4e-8cc7-42d9-a1cb-1c585c8a3472.png">

5. Le message suivant s'affichera. Choisir "Demande augmentation de quota"

<img width="555" alt="Screen Shot 2022-06-05 at 11 04 39" src="https://user-images.githubusercontent.com/24765473/172057185-ad218feb-6187-4846-b407-f0aeffc1782f.png">

6. Fournir les informations requises et soumettre la demande d'augmentation de quota.

<img width="1663" alt="Screen Shot 2022-06-05 at 11 05 45" src="https://user-images.githubusercontent.com/24765473/172057188-1260a4f6-82b3-4d9c-b156-654678f1ff9a.png">

<img width="1660" alt="Screen Shot 2022-06-05 at 11 05 55" src="https://user-images.githubusercontent.com/24765473/172057198-860fa182-e4b7-487d-9ba5-9f944dcf76be.png">

**Au lieu de soumettre une demande d'augmentation de quota, vous pouvez aussi créer un autre compte de facturation**
1. Aller à "Billing", choisiri "Mes comptes de facturation", vous pouvez créer un autre compte de facturation.
2. Fournir les informations de paiement requises

<img width="1665" alt="Screen Shot 2022-06-05 at 11 24 46" src="https://user-images.githubusercontent.com/24765473/172058013-9aa6fac3-58de-441a-8c76-2ba17f0cd95f.png">

<img width="1667" alt="Screen Shot 2022-06-05 at 11 25 16" src="https://user-images.githubusercontent.com/24765473/172058016-6d6e8cfd-37a6-48eb-87c1-1e6e820369a3.png">

## Intégration Catégorie 2: Courriel de tierce partie - Domaine GCP

Cette catégorie est où le client utilise son propre système de courriel mais le domaine de l'organisation est dans GCP.

## Intégration Catégorie 3: Compte Gmail - Domaines hébergés sur Google Domains

Suivre les étapes suivantes si:
* Vous êtes un nouveau client utilisant un compte Gmail avec enregistrement optionnel de redirection dans un domain existant hébergé sur Google Domains pour votre organisation

Ce scénario vous guidera dans le processus de créer un compte Cloud Identity (en utilisant un compte Gmail) et un sous-domaine pour un domaine existant géré par Google Domains

Vous pouvez aussi utiliser un compte de tierce partie.

**Effectuer les étapes suivants dans la mode privée de votre navigateur**

Pour créer un compte Cloud Identity, suivre les étapes suivantes:
1. Aller à [cette page](https://accounts.google.com/SignUpWithoutGmail)
2. Entrer les informations requises.
3. Sélectionner "Créer une nouvelle adresse Gmail à la place "

<img width="1500" alt="3-3" src="https://user-images.githubusercontent.com/94715080/169103623-f0628cf6-627b-4373-9cf5-186813aca0e6.png">

4. Entrer les détailles de compte.
5. Cliquer "Suivant"

<img width="1166" alt="3-5" src="https://user-images.githubusercontent.com/94715080/169103739-d0c14b66-a68a-48f1-841e-b2a81aa9620e.png">

6. Suivre les étapes pour vérifier votre numéro de téléphone.

<img width="1518" alt="3-6" src="https://user-images.githubusercontent.com/94715080/169103768-3a1db456-d4bb-4d7d-85d5-9b187a50dedc.png">

7. Confirmer que votre compte a été créé.

<img width="484" alt="3-7" src="https://user-images.githubusercontent.com/94715080/169103836-125c5eb5-b0c3-406c-bf20-3b243567d079.png">

**Ces étapes suivantes vous guideront dans le processus d'intégration de votre organisation GCP**
1. Aller à [cette page](https://console.cloud.google.com) avec le compte que vous avez créé dans les étapes précédentes.
2. Lire les "Termes de service" et cliquer "Accepter et Continuer"
3. Aller à "IAM & Admin -> Identity & Organization"
4. Cliquer "Aller à la liste de contrôle"
    1. *Vous verrez un message indiquant que votre compte actuel n'est pas associé avec une organisation dans Google Cloud.*

<img width="886" alt="3-17" src="https://user-images.githubusercontent.com/94715080/169104114-f3773a09-d800-4721-ac02-651429791332.png">

5. Choisir "Commencer la configuration"

<img width="1516" alt="3-18" src="https://user-images.githubusercontent.com/94715080/169104355-35c904c0-4080-4188-a85f-6ba6aee68ccc.png">

6. Dans l'écran "Cloud Identity & Organization", faire défiler la page et choisir "Je suis un nouveau client"

<img width="1526" alt="3-19" src="https://user-images.githubusercontent.com/94715080/169104384-965f7e9a-c824-4d87-8d34-9c35f820bfea.png">

7. Choisir "S'inscrire pour Cloud Identify"

<img width="585" alt="3-20" src="https://user-images.githubusercontent.com/94715080/169104428-0fb2fd1f-c1dd-4e48-a88c-413a6de0a63b.png">

8. Dans l'assistant de configuration de Cloud Identity, choisir "Suivant"

<img width="1520" alt="3-21" src="https://user-images.githubusercontent.com/94715080/169104574-ce544af5-d3ad-44c3-8471-1a85263987eb.png">

9. Entrer le nom de l'entreprise et choisir "Just You" sous le nombre d'employé
10. Choisir "Suivant".

<img width="1512" alt="3-22" src="https://user-images.githubusercontent.com/94715080/169104598-a2c16544-f9fe-4f8c-86d0-52aa84773e2c.png">

11. Choisir le pays où se trouve votre entreprise. Cliquer "Suivant"
12. Entrer l'adresse Gmail que vous avez créée. Choisir "Suivant"
    1. *Remarque: Vous pouvez aussi utiliser votre propre courriel*

<img width="1518" alt="3-23" src="https://user-images.githubusercontent.com/94715080/169104631-cc293b2a-e1fc-4c26-80f5-4ad90c8001e0.png">

13. Entrer le nom du domaine.
    1. *Remarque: Assurez que vous entrez un nom pour un (nouveau) sous-domaine (gcp.**). Par exemple: gcp.gcloud.network*

<img width="1516" alt="3-24" src="https://user-images.githubusercontent.com/94715080/169104653-f6395cb7-25e9-4b87-967d-7d91fa0ff772.png">

14. Cliquer "Suivant" pour confirmer le domaine que vous voulez utiliser pour le compte.
    1. Concernant l'avertissement de la redirection de courriel - Cela sera mis en place dans le compte du propriétaire de domaine.

<img width="1522" alt="3-25" src="https://user-images.githubusercontent.com/94715080/169104692-ed482a0c-df15-4d1e-822e-da2994732b3f.png">

15. Choisir "Suivant" pour aller à l'écran prochain
16. Vous reviendrez à cet écran après la section suivante.

Dans un autre onglet, suivre les étapes suivantes pour vérifier le domaine:
1. Aller à [cette page](https://domains.google) et se connecter avec le compte auquel appartient le domaine. Dans ce cas: *gcloud.network*
2. Choisir le domaine, cliquer "Gérer" et aller à "Courriel"
    1. *À noter qu'il n'y a pas encore d'enregistrement d'acheminement de courriel

<img width="1528" alt="3-26a" src="https://user-images.githubusercontent.com/94715080/169104721-59836309-d048-4f3e-9afd-830898abc20a.png">

3. Cliquer "Ajouter alias de courriel"
4. Entrer l'information d'acheminement de courriel
    1. *Utiliser un alias de "super admin" - un compte sera créé avec cet alias plus tard*
5. Cliquer "Ajouter"

<img width="1520" alt="3-27a" src="https://user-images.githubusercontent.com/94715080/169104792-b200b423-421c-40ac-925b-316ba0090b41.png">

6. Dans la boîte de réception de Gmail, vous recevrez le courriel suivant pour vérifier l'adresse de redirection de courriel.
7. Cliquer "Verifier mon adresse courriel maintenant".

<img width="1530" alt="3-29" src="https://user-images.githubusercontent.com/94715080/169104932-a648f8cd-cdee-405e-a16f-d2accb228921.png">

**Pour vérifier la redirection, suivre les étapes suivantes:**
1. Envoyer un courriel au compte du nouvel super admin.

<img width="597" alt="3-31" src="https://user-images.githubusercontent.com/94715080/169105169-40e6cb6d-6a21-45b1-b5e7-1e24f490009a.png">

2. Vérifier que le courriel a été acheminé au compte Gmail.

<img width="1530" alt="3-32" src="https://user-images.githubusercontent.com/94715080/169105205-b0b2f165-2d48-4b03-be27-531a71692f78.png">

**Revenir à l'assistant de configuration de Cloud Identity**
1. Dans l'écran de "Qui êtes-vous", entrer les informations pour l'administrateur du compte. Cliquer "Suivant".

<img width="1523" alt="3-33" src="https://user-images.githubusercontent.com/94715080/169105684-31f9cd8d-3acc-4a8c-a719-42f255020e60.png">

2. Entrer le nom d'utilisateur et le mot de passe pour le compte de super admin pour votre nouveau sous-domaine.

<img width="1522" alt="3-34" src="https://user-images.githubusercontent.com/94715080/169105720-ce76b314-b457-4adb-905e-f339483d62d0.png">

3. Choisir si vous voulez recevoir des astuces, des offres et des annoncements.

<img width="1516" alt="3-35" src="https://user-images.githubusercontent.com/94715080/169106023-7dc58527-f9b5-4697-ac68-b50cde6dd18e.png">

4. Choisir si vous voulez que vos usagers reçoivent l'information et des astuces par rapport à Google Workspace.
5. Passer reCAPTCHA et cliquer "Accepter et Créer le compte"

<img width="1523" alt="3-36" src="https://user-images.githubusercontent.com/94715080/169106716-2bb6b24e-9db4-41a6-a44c-30d37ea447b0.png">

6. Cliquer "Aller à la configuration".

<img width="1528" alt="3-37" src="https://user-images.githubusercontent.com/94715080/169106752-f66d6e2d-3356-4338-9e07-8d627ae1dad3.png">

7. Se connecter en utilisant le nouveau compte Super Admin dans votre sous-domaine.

<img width="1527" alt="3-38" src="https://user-images.githubusercontent.com/94715080/169106802-078b0541-2503-46cc-9d83-b8234e2baffa.png">

8. Suivre les étapes pour vérifier votre identité.

<img width="1526" alt="3-39" src="https://user-images.githubusercontent.com/94715080/169106856-5c00ff98-047d-4b10-a412-ecbda7682a04.png">

<img width="1518" alt="3-40" src="https://user-images.githubusercontent.com/94715080/169106882-abac7b23-b2ae-4383-ac9d-eb387008546c.png">

9. Cliquer "Accepter"

<img width="1524" alt="3-41" src="https://user-images.githubusercontent.com/94715080/169106910-053b28ae-014e-4e65-a6d2-5d93a7d3f281.png">

10. Cliquer "Suivant"

<img width="1522" alt="3-42" src="https://user-images.githubusercontent.com/94715080/169106937-df59e280-58bd-4a82-9008-dfe68f13da8d.png">

11. Cliquer "Vérifier" pour vérifier le nouveau sous-domaine.

<img width="1518" alt="3-43" src="https://user-images.githubusercontent.com/94715080/169106989-c31d1a78-e34e-4f98-a1a2-71719794f488.png">

12. Cliquer "Changer la méthode de vérification"

<img width="1524" alt="3-44" src="https://user-images.githubusercontent.com/94715080/169107030-34f7d874-04ad-4af1-af12-e3d663964c77.png">

13. Choisir "Créer un enregistrement TXT (Recommandé)"
14. Cliquer "Suivant"

<img width="1526" alt="3-45" src="https://user-images.githubusercontent.com/94715080/169107063-36ebe5e2-a056-48e2-a0bf-c105e63d86e2.png">

<img width="1520" alt="3-47" src="https://user-images.githubusercontent.com/94715080/169107129-e719024c-69fb-4551-b446-a0553b348315.png">

15. Aller à [cette page](https://domains.google) et se connecter avec le compte auquel appartient le domaine (gcloud.network)
16. Choisir le domaine que vous voulez vérifier, cliquer "Gérer" et choisir "DNS"
17. Dans la section "Enregistrements personnalisés", entrer le nom d'hôte, modifier le "Type" à "TXT", modifier "TTL" à 3600 (soit une heure) et coller le code de vérification TXT.
18. Cliquer "Sauvegarder".

<img width="1523" alt="3-49a" src="https://user-images.githubusercontent.com/94715080/169107211-e41f7b9a-0cab-498a-a9cc-affc8c9ad7ad.png">

<img width="1528" alt="3-50a" src="https://user-images.githubusercontent.com/94715080/169107234-259efa61-2f12-45ed-b5b8-c461363dedf2.png">

19. Reviens à l'écran "Vérifier votre domaine", cliquer "Vérifier mon domaine". Cela va prendre quelques minutes

<img width="1525" alt="3-51" src="https://user-images.githubusercontent.com/94715080/169107271-5fa60041-401a-4663-8bd1-76793aeb5ea1.png">

20. Exécuter un `dig` dans votre sous-domaine.

<img width="989" alt="3-53b" src="https://user-images.githubusercontent.com/94715080/169107335-bd1c494f-8a28-49e7-99e3-0e3bda996325.png">

21. L'assistant de configuration de Cloud Identity mettra à jour quand le domaine aura été vérifié.
22. Cliquer "Configurer le console de GCP Cloud maintenant". Assurer que vous vous êtes connecté avec vo

<img width="1522" alt="3-54" src="https://user-images.githubusercontent.com/94715080/169107353-ae578ac5-4141-47c1-833e-018b1f6b4806.png">

23. Lire les "Termes de service" et cliquer "Accepter et Continuer"

<img width="1524" alt="3-55" src="https://user-images.githubusercontent.com/94715080/169107401-ea5d8135-ecd8-4a98-bf07-f8b469cc22e3.png">

24. Aller à IAM&Admin -> IAM
    - *À noter que l'organisation GCP sera automatiquement créée.

<img width="609" alt="3-56" src="https://user-images.githubusercontent.com/94715080/169107437-65dce692-75b3-49e5-9ada-2f27c35da02d.png">

25. Cliquer "Choisir un projet" en haut de l'écran
26. Choisir la nouvelle organisation dans le menu déroulant "Select from"

<img width="1528" alt="3-63b" src="https://user-images.githubusercontent.com/94715080/169107680-f7b9af00-d1f5-4556-8653-91f465b10e99.png">

27. La nouvelle organisation devrait être visible dans l'onglet "Tout"

<img width="1531" alt="3-64b" src="https://user-images.githubusercontent.com/94715080/169107702-1ff52a02-a630-42f2-ba09-4feb7fb077c1.png">

28. Valider que l'usager Super Admin ont été accordé avec le rôle d'administrateur d'organisation

<img width="1529" alt="3-65b" src="https://user-images.githubusercontent.com/94715080/169107734-e6cdedd6-872e-4166-9689-3ceb3bbc6b68.png">

## Intégration Catégorie 5: Courriel tierce partie - Domaine tierce partie 3rd party Domain

This category is common for organizations new to GCP or multicloud where both the email system and DNS hosting zone are 3rd party

### Catégorie 5a: Premier courriel tierce partie - Domaine tierce partie qui requiert la vérification TXT

### Catégorie 5b: First 3rd party Email - Domaine tierce partie qui requiert la vérification indirecte
Copier/coller le courriel

### Catégorie 5c: Deuxième courriel tierce partie - Domaine tierce partie déjà vérifié
- Utiliser l'original super admin/propriétaire pour créer un autre compte Cloud Admin avec un courriel se trouvant dans le domaine de l'organisation - avec un acheminement optionnel de courriel à leur courriel de travail.
- Donner des droits comme "Propriétaire" ou "Admin de Dossier" à deuxième usager+, quand il se connecte à [console](console.cloud.google.com), ils auront déjà d'accès approprié à l'organisation (Pas de validation de domaine nécessaire)


1. Aller à la [page d'admin](admin.google.com)

<img width="784" alt="5c-1" src="https://user-images.githubusercontent.com/94715080/169107772-9eb92ccd-0c3e-41ee-8844-77fc01a4fdc9.png">

2. Ajouter le nouveau usager - utiliser un usager existant de Super Admin.

<img width="1202" alt="5c-2" src="https://user-images.githubusercontent.com/94715080/169107798-4a3ab66a-9f24-4ab6-9bd2-1f98044b9a49.png">

3. Envoyer les instructions de connexion - avec le mot de passe temporaire.

<img width="949" alt="5c-3" src="https://user-images.githubusercontent.com/94715080/169107829-3b2a1ada-628e-435b-b563-6b315d5f9f1f.png">

4. Démarre la mode privée de Chrome

<img width="1527" alt="5c-4" src="https://user-images.githubusercontent.com/94715080/169107861-f9076e19-5eff-4a6d-a29c-c725247fd522.png">

5. Aller à [gestion de compte](accounts.google.com)

<img width="665" alt="5c-5" src="https://user-images.githubusercontent.com/94715080/169107897-7c496cb1-1085-4f59-b6ec-6d78176ef424.png">

6. Se connecter en tant que nouvel usager.

<img width="1017" alt="5c-6" src="https://user-images.githubusercontent.com/94715080/169107928-16cedc7e-f76a-4c4a-a391-ebe781968afc.png">

7. Page de bienvenue de nouveau compte

<img width="1125" alt="5c-7" src="https://user-images.githubusercontent.com/94715080/169107958-ebe88b07-d840-4418-91cb-8d0512e8fe7b.png">

8. Changer le mot de passe

<img width="965" alt="5c-8" src="https://user-images.githubusercontent.com/94715080/169107973-6f02ab4c-f117-473f-81aa-f27a915a67a1.png">

<img width="1192" alt="5c-9" src="https://user-images.githubusercontent.com/94715080/169107999-66ccf18f-9906-433b-affa-afbba278fce4.png">

9. Choisir l'icône du profil au coin supérieur droit - ajouter (pour obtenir un nouveau profil de Chrome pour l'usager)

<img width="1021" alt="5c-10" src="https://user-images.githubusercontent.com/94715080/169108035-a0948886-bc09-4a05-8e9c-6b6046ea28c0.png">

10. Se connecter de nouveau

<img width="1019" alt="5c-11a" src="https://user-images.githubusercontent.com/94715080/169108055-305a9ca7-7bf1-451a-8514-152fee4a8c41.png">

11. Accepter le profil

<img width="1020" alt="5c-12a" src="https://user-images.githubusercontent.com/94715080/169108108-604b1725-2fe4-4cd9-900c-42e60c9423bd.png">

12. Aller au [console de cloud](console.cloud.google.com)

<img width="482" alt="5c-13a" src="https://user-images.githubusercontent.com/94715080/169108142-aaeeba2a-0711-4d13-ac25-1f85b08b6d4c.png">

13. Accepter la license.

<img width="1524" alt="5c-14a" src="https://user-images.githubusercontent.com/94715080/169108167-e98a0de6-83eb-43b4-a4d1-e5de3e87ca5c.png">

14. Vérifier que vous êtes déjà dans l'organisation existante (Pas de vérification DNS nécessaire)

<img width="1515" alt="5c-15a" src="https://user-images.githubusercontent.com/94715080/169108221-b134e86f-76cf-4162-86cf-5314693c447e.png">

15. Essayer de créer un projet - Basculer à l'organisation

<img width="1125" alt="5c-16a" src="https://user-images.githubusercontent.com/94715080/169108265-73b57e4a-ccea-4ae1-ba4b-f196a46c7532.png">

16. Choisir l'organisation - normal sans un rôle plus privilégié. Un usager Super Admin sera créé

<img width="1127" alt="5c-17a" src="https://user-images.githubusercontent.com/94715080/169108292-46170222-9dfe-4320-8900-7d9c16c7a3a6.png">

17. Vérifier que vous n'avez pas de droit à cette organisation

<img width="1525" alt="5c-18a" src="https://user-images.githubusercontent.com/94715080/169108322-2ee8977c-73d4-4b24-8b62-fabb8d16fa70.png">

18. Vérifier la liste de contrôle des mesures de sécurité

<img width="1010" alt="5c-20a" src="https://user-images.githubusercontent.com/94715080/169108347-50a0ae6a-7a49-413b-95b0-cd46a0c85acd.png">

<img width="1523" alt="5c-21a" src="https://user-images.githubusercontent.com/94715080/169108372-a99d6ac3-421a-4dfc-895c-f46575e4f9ff.png">

19. Basculer à l'autre usager Super Admin - Aller à IAM pour vérifier les rôles

<img width="1429" alt="5c-23b" src="https://user-images.githubusercontent.com/94715080/169108396-751a6040-ab1c-4131-b528-221dc6cf25c6.png">

20. Accorder un nouveau usager le droit de "Propriétaire" pour l'instant - normalement utiliser "Créateur de dossier" et "Administrateur d'organisation" par exemple.

<img width="1221" alt="5c-24b" src="https://user-images.githubusercontent.com/94715080/169108424-d0c17e1f-b5ba-4dac-b941-f3bb7b55fdce.png">

21. Vérifier le changement de rôle de l'usage #2.

<img width="1396" alt="5c-25b" src="https://user-images.githubusercontent.com/94715080/169108468-1884ddec-a359-4b4a-a896-225e44fbe13a.png">

22. Naviguer à IAM -> Cloud Identity -> Vérifier vos nouvelles droits

<img width="1113" alt="5c-26a" src="https://user-images.githubusercontent.com/94715080/169108486-fda6cce7-b395-4f7e-8915-7b1e9a61616c.png">

23. Remarquer que vous avez droits maintenant à l'organisation.

<img width="1125" alt="5c-27a" src="https://user-images.githubusercontent.com/94715080/169108503-a119bfb6-ec46-49c8-bd29-d1fdd873704c.png">






## Intégration Catégorie 6: Courriel Gmail - Domaine tierce partie

Cette catégorie est une variante de la catégorie 3 où il y a un compte gmail avec redirection optionnelle où les enregistrements de zone d'organisation sont dans un système DNS tierce-partie

## Intégration Catégorie 7: Courriel tierce partie - Pas de domaine

Cette catégorie est normale pour des clients individuels où ils n'ont pas de compte gmail ou de domaine. Cette option n'aura pas de noeud du haut d'organisation dans IAM.

## Intégration Catégorie 8 : Courriel Gmail - Pas de domaine

Cette catégorie est normale pour des clients individuels où ils n'ont pas de domaine mais un compte Gmail. Cette option n'aura pas de noeud du haut d'organisation dans IAM.

# Intégration à Google Cloud utilisant compte Cloud Identity
## Google Cloud Identity

Les comptes Google Cloud Identity sont idéals pour les organisations de compte Cloud où les identités d'usager sont gérés dehors de Google Cloud, par exemple, un Workmail d'AWS ou Active Directory d'Azure.

## Pour Commencer

- Créer ou obtenir l'accès au domaine que vous voulez associer aux usagers fédérés. Par exemple: packet.global.
- Vous aurez l'accès à la zone du domaine pour ajouter des enregistrements TXT pour validation de domaine sous un sous-domaine comme gcp.packet.global
-------------------------------------------------------------
1. Ouvrir une fenêtre de Chrome sans compte Google.
2. Démarrer ["Se connecter sans Gmail"](https://accounts.google.com/SignUpWithoutGmail) - choisir Gmail
3. S'inscrire et démarrer une nouvelle fenêtre de navigateur
4. Ajouter le nouveau compte et se connecter
5. Créer votre compte Gmail.

<img width="1197" alt="_eventstream_1" src="https://user-images.githubusercontent.com/94715080/169108568-45b3b0d4-d6a2-49fb-8a3f-3daf27cd14fa.png">

6. Démarrer [Google Cloud](https://console.cloud.google.com/). **NE PAS** choisir une organisation - parce que le domaine sous l'enregistrement de GCP n'a pas encore un courriel, et il n'est pas inscrit avec Workspace.
7. Ajouter gratuitement [Cloud Identity](https://cloud.google.com/identity/docs/set-up-cloud-identity-admin)
8. Suivre [cette page](https://workspace.google.com/signup/gcpidentity/welcome#0)
9. ajouter votre courriel Gmail et le domaine GCP
10. Ajouter la [capacité de courriel](https://support.google.com/cloudidentity/answer/7667994)
11. Choisir le courriel dans [l'onglet à gauche](https://domains.google.com/registrar/eventstream.dev/email?hl=en-US)
12. Ajouter l'acheminement de courriel à votre compte Gmail
13. Démarrer Gmail pour vérifier le courriel - Ne vous inquiétez pas, les domaines seront dans votre compte gmail actuel.
14. Vérifier votre compte gmail dans un autre compte à laquelle appartient l'inscription du domaine
15. Vérifier l'acheminement de courriel dans l'onglet de DNS
16. Attendre la propagation d'enregistrement de DNS pendant 30 seconds.
17. Suivre l'assistant de configuration de [Cloud Identity](https://workspace.google.com/signup/gcpidentity/tos) malgré l'avertissement - utiliser votre nouvelle adresse d'acheminement de courriel
18. Aller à la configuration après création
19. Démarrer l'admin, vérifier le compte de Cloud Identity.
20. Choisir ["À Commencer"](https://admin.google.com/u/1/ac/signup/setup/v2/gettingstarted)
21. Vérifier le domaine
22. Ajouter l'enregistrement de TXT
23. Cliquer "Vérifier" pour revenir à la page d'admin

L'organisation sera automatiquement créée (pas de sous-domaine parce que l'enregistrement TXT est le premier dans le domaine.) S'il y a déjà un enregistrement racine de TXT, vous aurez à utiliser un sous-domaine comme gcp.domain.com

# Intégration à Google Cloud en utilisant compte de Workspace

## Avec un compte Workspace et un domain géré par Google

## Avec un compte gmail

1. Remplir le [formulaire](https://accounts.google.com/SignUpWithoutGmail) avec un courriel existant qui n'est pas géré par Google
2. Commencer par [l'étape 2](https://console.cloud.google.com/cloud-setup/organization) -> IAM -> Cloud Identity & Organization -> Liste de Contrôle, jusqu'à [cette page](https://workspace.google.com/signup/gcpidentity/welcome)


# Intégration à Google Cloud avec un compte de tierce partie