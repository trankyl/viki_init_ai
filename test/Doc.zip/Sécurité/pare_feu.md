
Au menu :  

- [Scénarii de déploiement pare-feu](#scénarii-de-déploiement-pare-feu)
  - [Déploiement et configuration automatique cluster pare-feu FortiGate lors du déploiement zone accueil](#déploiement-et-configuration-automatique-cluster-pare-feu-fortigate-lors-du-déploiement-zone-accueil)  
  - [Ajout manuel du pare-feu FortiGate dans une zone d'accueil sans pare-feu](#ajout-manuel-du-pare-feu-fortigate-dans-une-zone-accueil-sans-pare-feu)  
  - [Ajout manuel du pare-feu natif OCI dans une zone d'accueil sans pare-feu](#ajout-manuel-du-pare-feu-natif-oci-dans-une-zone-accueil-sans-pare-feu)
  - [Ajout manuel du pare-feu CheckPoint CloudGuard dans une zone d'accueil sans pare-feu](#ajout-manuel-du-pare-feu-natif-oci-dans-une-zone-accueil-sans-pare-feu)

- [Accueil](../../README.md "Retour à la page d'accueil")


## Scénarii de déploiement pare-feu

### Déploiement et configuration automatique cluster pare-feu FortiGate lors du déploiement zone accueil

1. Lors de la configuration de la pile de déploiement de la zone d'accueil OCI , vous avez la possibilité de choisir si vous souhaitez déployer un pare-feu ou non. Si oui, un pare-feu **FortiGate** de Fortinet , sera déploy dans le compartiment de Connectivité.

La section [**Variables réseau concernant le VNC HUB - DMZ VCN**](../Déploiement/Deploi_Script.md#variables-réseau-concernant-le-vnc-hub---dmz-vcn) dans le [guide de déploiement de la zone d'accueil](../Déploiement/Deploi_Script.md) vous montre les étapes pour le déploiement et la configuration automatique d'un cluster de pare-feu Fortigate.

2. [Analyse script déploiement du pare-feu Fortigate](Analyse_Script_Fortinet.md)

Si vous souhaitez personnaliser le déploiement du pare-feu, vous pouvez suivre l'un des 3 scénarii suivants.   

### Ajout manuel du pare-feu FortiGate dans une zone accueil sans pare-feu

1. [Déploiement du pare-feu FortiGate](../Déploiement/deploy_manuel_fortigate.md)  
  
### Ajout manuel du pare-feu natif OCI dans une zone accueil sans pare-feu  

1. [Présentation du pare-feu réseau natif de Oracle Cloud Infrastructure](../Déploiement/description_parefeu_oci.md)
2. [Déploiement du pare-feu réseau natif de Oracle Cloud Infrastructure](../Déploiement/deploiement_parefeu_oci.md)  

### Ajout manuel du pare-feu CheckPoint CloudGuard dans une zone accueil sans pare-feu  

1. [Présentation du pare-feu réseau CheckPoint CloudGuard ](../Déploiement/description_parefeu_cloudguard.md)
2. [Déploiement du pare-feu réseau  CheckPoint CloudGuard](../Déploiement/deploy_manuel_cloudguard.md)
3. [Analyse script déploiement du pare-feu réseau  CheckPoint CloudGuard](Script_deploiement_cloudguard.md)    


[Retour à la Page d'Accueil](../../ReadMe.md)
