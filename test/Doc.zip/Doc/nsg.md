#### Retour en arrière

* [Aperçu du script](apercu_script.md)
* [Aperçu de l'abonnement Plateforme Connectivité](connectivite.md)
* [Paramétrage du script pour les Zones d'accueil](parametrage_za_charge.md)
* [Page d'accueil](../Readme.md)

# Les groupes de sécurité réseau (NSG)

Les groupes de sécurité réseau (NSG ou *Network Security Group* en anglais) sont appliqués au niveau des sous-réseaux dans les différents abonnements pour limiter les échanges de données selon au principe du moindre privilège, mettant en place des mécanismes de microsegmentation réseau.

# Principe du détenteur des règles NSG

Chaque sous-réseau virtuel sera responsable de contrôler les flux entrants. Les flux sortants ne seront pas contrôlés par défaut, sauf pour ceux qui se destinent aux sous-réseaux locaux **Private Endpoint**.

![principe_detenteur_regle_nsg](images/principe_detenteur_regle_nsg.png)

Les NSG suivants ont été ajoutés et intégrés à la zone d’accueil.

# Règles de trafic entrant

Les règles de trafic entrant, fournies ci-dessous à titre illustratif, autorisent explicitement, ou bloquent explicitement, le trafic qui tente d’accéder aux différents sous-réseaux virtuels. Le tableau suivant exemplifie certaines de ces règles, pour le scénario de base avec un plan d'adressage défaut. Pour des raisons d'espace, la liste n'est pas complète, la meilleure référence étant les fichiers de configuration paramétrables:

* cei-tpl-lzvars.yml pour les règles NSG dans les zones de charge pour le scénario de base et complexe
* cei-platform.yml pour les règles NSG dans le hub, identité et gestion


| Périphérique | Sous-réseau source | Priorité | Source (défaut) | Ports source | Destination (défaut) | Ports de destination   | Protocole | Accès | Sous-réseau destination |
| ---------------- | --------------------- | ----------- | ------------------ | -------------- | ----------------------- | ------------------------ | ----------- | -------- | -------------------------- |
| Identité      | Jumpbox primaire    | 200       | 10.73.132.0/24   | 0-65535      | 10.73.2.0/24          | 3389, 22               | TCP       | Allow  | Jumpbox local            |
| Sensible       | Jumpbox primaire    | 200       | 10.73.132.0/24   | 0-65535      | 10.77.2.0/23          | 3389, 22               | TCP       | Allow  | Jumpbox local            |
| Non sensible   | Jumpbox primaire    | 200       | 10.73.132.0/24   | 0-65535      | 10.77.66.0/23         | 3389, 22               | TCP       | Allow  | Jumpbox local            |
| Non-Prod       | Jumpbox primaire    | 200       | 10.73.132.0/24   | 0-65535      | 10.77.129.0/24        | 3389, 22               | TCP       | Allow  | Jumpbox local            |
| Sensible       | Jumpbox local       | 400       | 10.77.2.0/23     | 0-65535      | 10.77.4.0/23          | *                      | Any       | Allow  | Web                      |
| Non sensible   | Jumpbox local       | 400       | 10.77.66.0/23    | 0-65535      | 10.77.68.0/23         | *                      | Any       | Allow  | Web                      |
| Non-Prod       | Jumpbox local       | 400       | 10.77.129.0/24   | 0-65535      | 10.77.130.0/24        | *                      | Any       | Allow  | Web                      |
| Sensible       | Web                 | 600       | 10.77.4.0/23     | 0-65535      | 10.77.4.0/23          | *                      | TCP       | Allow  | Web                      |
| Non sensible   | Web                 | 600       | 10.77.68.0/23    | 0-65535      | 10.77.68.0/23         | *                      | TCP       | Allow  | Web                      |
| Non-Prod       | Web                 | 600       | 10.77.130.0/24   | 0-65535      | 10.77.130.0/24        | *                      | TCP       | Allow  | Web                      |
| Sensible       | Web                 | 800       | 10.77.4.0/23     | 0-65535      | 10.77.8.0/23          | *                      | TCP       | Deny   | Data                     |
| Non sensible   | Web                 | 800       | 10.77.68.0/23    | 0-65535      | 10.77.72.0/23         | *                      | TCP       | Deny   | Data                     |
| Non-Prod       | Web                 | 800       | 10.77.130.0/24   | 0-65535      | 10.77.132.0/24        | *                      | TCP       | Deny   | Data                     |
| Sensible       | Jumpbox local       | 1000      | 10.77.2.0/23     | 0-65535      | 10.77.6.0/23          | *                      | TCP       | Allow  | Application              |
| Non sensible   | Jumpbox local       | 1000      | 10.77.66.0/23    | 0-65535      | 10.77.70.0/23         | *                      | TCP       | Allow  | Application              |
| Non-Prod       | Jumpbox local       | 1000      | 10.77.129.0/24   | 0-65535      | 10.77.131.0/24        | *                      | TCP       | Allow  | Application              |
| Sensible       | Web                 | 1200      | 10.77.4.0/23     | 0-65535      | 10.77.6.0/23          | *                      | TCP       | Allow  | Application              |
| Non sensible   | Web                 | 1200      | 10.77.68.0/23    | 0-65535      | 10.77.70.0/23         | *                      | TCP       | Allow  | Application              |
| Non-Prod       | Web                 | 1200      | 10.77.130.0/24   | 0-65535      | 10.77.131.0/24        | *                      | TCP       | Allow  | Application              |
| Sensible       | Application         | 1400      | 10.77.6.0/23     | 0-65535      | 10.77.6.0/23          | *                      | TCP       | Allow  | Application              |
| Non sensible   | Application         | 1400      | 10.77.70.0/23    | 0-65535      | 10.77.70.0/23         | *                      | TCP       | Allow  | Application              |
| Non-Prod       | Application         | 1400      | 10.77.131.0/24   | 0-65535      | 10.77.131.0/24        | *                      | TCP       | Allow  | Application              |
| Sensible       | Jumpbox local       | 1600      | 10.77.2.0/23     | 0-65535      | 10.77.8.0/23          | *                      | TCP       | Allow  | Data                     |
| Non sensible   | Jumpbox local       | 1600      | 10.77.66.0/23    | 0-65535      | 10.77.72.0/23         | *                      | TCP       | Allow  | Data                     |
| Non-Prod       | Jumpbox local       | 1600      | 10.77.129.0/24   | 0-65535      | 10.77.132.0/24        | *                      | TCP       | Allow  | Data                     |
| Sensible       | Application         | 1800      | 10.77.6.0/23     | 0-65535      | 10.77.8.0/23          | 1433, 3306, 5432, 1434 | TCP,UDP   | Allow  | Data                     |
| Non sensible   | Application         | 1800      | 10.77.70.0/23    | 0-65535      | 10.77.72.0/23         | 1433, 3306, 5432, 1434 | TCP,UDP   | Allow  | Data                     |
| Non-Prod       | Application         | 1800      | 10.77.131.0/24   | 0-65535      | 10.77.132.0/24        | 1433, 3306, 5432, 1434 | TCP,UDP   | Allow  | Data                     |
| Sensible       | Data                | 2000      | 10.77.8.0/23     | 0-65535      | 10.77.8.0/23          | *                      | TCP       | Allow  | Data                     |
| Non sensible   | Data                | 2000      | 10.77.72.0/23    | 0-65535      | 10.77.72.0/23         | *                      | TCP       | Allow  | Data                     |
| Non-Prod       | Data                | 2000      | 10.77.132.0/24   | 0-65535      | 10.77.132.0/24        | *                      | TCP       | Allow  | Data                     |
| Sensible       | Application         | 2400      | 10.77.6.0/23     | 0-65535      | 10.77.0.0/23          | *                      | TCP       | Allow  | Private Endpoint         |
| Non sensible   | Application         | 2400      | 10.77.70.0/23    | 0-65535      | 10.77.64.0/23         | *                      | TCP       | Allow  | Private Endpoint         |
| Non-Prod       | Application         | 2400      | 10.77.131.0/24   | 0-65535      | 10.77.128.0/24        | *                      | TCP       | Allow  | Private Endpoint         |
| Sensible       | Data                | 2600      | 10.77.8.0/23     | 0-65535      | 10.77.0.0/23          | *                      | TCP       | Allow  | Private Endpoint         |
| Non sensible   | Data                | 2600      | 10.77.72.0/23    | 0-65535      | 10.77.64.0/23         | *                      | TCP       | Allow  | Private Endpoint         |
| Non-Prod       | Data                | 2600      | 10.77.132.0/24   | 0-65535      | 10.77.128.0/24        | *                      | TCP       | Allow  | Private Endpoint         |
| Sensible       | Web                 | 2800      | 10.77.4.0/23     | 0-65535      | 10.77.0.0/23          | *                      | TCP       | Deny   | Private Endpoint         |
| Non sensible   | Web                 | 2800      | 10.77.68.0/23    | 0-65535      | 10.77.64.0/23         | *                      | TCP       | Deny   | Private Endpoint         |
| Non-Prod       | Web                 | 2800      | 10.77.130.0/22   | 0-65535      | 10.77.128.0/24        | *                      | TCP       | Deny   | Private Endpoint         |
| Identité      | Jumpbox local       | 3000      | 10.73.2.0/24     | 0-65535      | 10.73.0.0/24          | *                      | TCP       | Allow  | DC                       |
| Identité      | Jumpbox primaire    | 3200      | 10.73.132.0/24   | 0-65535      | 10.73.2.0/24          | 3389, 22               | TCP       | Allow  | Jumpbox local            |

# Règles de trafic sortant

Ce sont les règles de trafic entrant qui bloquent ou autorisent explicitement le trafic. Par contre, les règles de trafic sortant dans les NSG sont celles par défaut

* Autoriser le trafic à l'intérieur du réseau virtuel (VNET)
* Autoriser le trafic sortant vers l'Internet (si le routage le permet)
* Bloquer tout autre trafic sortant

# Règles de trafic spécifiques "par sous-réseau"

Dans certains cas c'est désirable de dÉfinir des ouvertures spécifiques dans certains sous-réseaux, en fonction des charges de travail y déployées. Exemples spécifiques:

* Ouverture des ports spécifiques utilisés par Active Directory pour communiquer avec les contrôleurs de domaine sur site ainsi que pour permettre l'accès des charges de travail Windows dans les zones d'accueil.
* Ouverture des ports spécifiques utilisés pour la téléphonie dans le nuage, par exemple une "appliance" virtuelle

Pour l'instant cette fonctionnalité ne supporte pas l'utilisation des "Groupes de Sécurité Applicative" (ASG en anglais).

Pour chaque sous-réseau il y a une variable pré-définie `nsgCustom` définie au niveau de chaque sous-réesau dans les fichiers de paramétrage `cei-base-lz.yml` respectivement `cei-complexe-lz.yml`. Les variables de référence utilisées dans les définitions sont dans les fichiers de paramétrage `cei-base-nsg-custom.yml` respectivement `cei-complexe-nsg-custom.yml`.

Par exemple:

```
           subnetParam:
               privateEndpoint: 
                  subnetSuffix: '$(var-charges-sens-pe-suffix)'
                  createVmParam: '{}'
                  nsgCustom: '$(var-nsg-custom-nil)'
               jumpBox: 
                  subnetSuffix: '$(var-charges-sens-jb-suffix)'
                  createVmParam: '{"create":"true","vmParam": $(var-vm-jumpbox-param)}'
                  nsgCustom: '$(var-nsg-custom-nil)'
               web: 
                  subnetSuffix: '$(var-charges-sens-web-suffix)'
                  createVmParam: '{"create":"true","vmParam": $(var-vm-web-param)}'
                  nsgCustom: '$(var-nsg-custom-nil)'
               application: 
                  subnetSuffix: '$(var-charges-sens-app-suffix)'
                  createVmParam: '{"create":"true","vmParam": $(var-vm-app-param)}'
                  nsgCustom: '$(var-nsg-custom-nil)'
               data: 
                  subnetSuffix: '$(var-charges-sens-data-suffix)'
                  createVmParam: '{"create":"true","vmParam": $(var-vm-data-param)}'
                  nsgCustom: '$(var-nsg-custom-nil)'
```

Par défaut dans les fichiers de paramétrage `cei-base-lz.yml` respectivement `cei-complexe-lz.yml` on utilise `var-nsg-custom-nil` ce qui équivaut à aucune règle NSG personnalisée par sous-réseau.  Si on veut utiliser des règles NSG par sous-réseau il faut changer les affectations des variables `nsgCustom` dans les fichiers de paramétrage `cei-base-lz.yml` respectivement `cei-complexe-lz.yml` en faisant réference à des définitions spécifiques fournies dans les fichiers de paramétrage `cei-base-nsg-custom.yml` , respectivement `cei-complexe-nsg-custom.yml`.

Basé sur les valeurs des variables `nsgCustom` définies dans le paramétrage, dans le fichier de paramétrage avancé `cei-tpl-landingzone.yml` les variables correspondantes par sous-réseau sont crées. Comme on voit, l'absence d'une définition `nsgCuston `équivaut à une définition `var-nsg-custom-nil` . Par exemple:

```
              - name: var-lz-nsg-custom-jumpbox
                ${{ if eq(variables['var-nsgcust-jumpbox'],'') }}:
                  value: '{}'
                ${{ else }}:  
                  value: '${{lz.subnetParam.jumpBox.nsgCustom}}'  
              - name: var-lz-nsg-custom-web
                ${{ if eq(variables['var-nsgcust-web'],'') }}:
                  value: '{}'
                ${{ else }}:  
                  value: '${{lz.subnetParam.web.nsgCustom}}'  
              - name: var-lz-nsg-custom-app
                ${{ if eq(variables['var-nsgcust-app'],'') }}:
                  value: '{}'
                ${{ else }}:  
                  value: '${{lz.subnetParam.application.nsgCustom}}'  
              - name: var-lz-nsg-custom-data
                ${{ if eq(variables['var-nsgcust-data'],'') }}:
                  value: '{}'
                ${{ else }}:  
                  value: '${{lz.subnetParam.data.nsgCustom}}'  
              - name: var-lz-nsg-custom-pe
                ${{ if eq(variables['var-nsgcust-pe'],'') }}:
                  value: '{}'
                ${{ else }}:  
                  value: '${{lz.subnetParam.privateEndpoint.nsgCustom}}'  

```

Dans chaque définition de NSG au niveau du fichier de paramétrage `cei-tpl-lzvars.yml` les définitions de règles supplémentaires par sous-réseau sont inclues juste avant le "deny all" final. Exemple:

```
          {
            "name": "sr_inbound_allow_app_to_local_data_$(var-lz-short-env-name)_$(var-lz-short-name)-002",
            "properties" : 
            {
              "priority" : 510,
              "sourceAddressPrefix" : "$(var-charges-virtualNetwork-ip-prefix)$(var-lz-subnet-app-suffix)",
              "sourcePortRange" : "0-65535",
              "destinationAddressPrefix" : "$(var-charges-virtualNetwork-ip-prefix)$(var-lz-subnet-data-suffix)",
              "destinationPortRanges" : [ "1433", "3306", "5432", "1434" ],
              "protocol" : "Tcp",
              "access" : "Allow",
              "description" : "Permettre accès du subnet app local vers subnet data local",
              "direction" : "Inbound"
            }
          },
          $(var-lz-nsg-custom-data),
          {
            "name": "sr_inbound_default_deny_$(var-lz-short-env-name)_$(var-lz-short-name)-003",
            "properties" : 
            {
              "priority" : 4095,
              "sourceAddressPrefix" : "*",
              "sourcePortRange" : "0-65535",
              "destinationAddressPrefix" : "*",
              "destinationPortRange" : "*",
              "protocol" : "*",
              "access" : "Deny",
              "description" : "Refuser accès si pas de allow",
              "direction" : "Inbound"
            }
          }

```

Le même principe s'applique pour le paramétrage des règles NSG par sous-réseau au niveau de l'abonnement plateforme d'identité pour permettre l'accès sur les ports spécifiques à Active Directory, à partir des zones de charge et à partir du réseau local sur site. Le paramétrage est dans le fichier de `cei-platform.yml` au niveau de règles NSG appliquée sur le sous-réseau `dc` sur lequel les contrôleurs de domaine Active Directory sont déployés. Les règles dans la variable `var-nsg-custom-identite`sont définies dans les fichiers de paramétrage `cei-base-nsg-custom.yml`, respectivement `cei-complexe-nsg-custom.yml`.

```
 var-platform-identite-nsg-list: >
    [
 . . . 
      {
        "name": "$(var-identite-nsg-name-dc)",
        "tags": {
        },
        "securityRules": [
          {
            "name": "sr_inbound_allow_jumpbox_local_to_dc-001",
            "properties" : 
            {
              "priority" : 300,
              "sourceAddressPrefix" : "$(var-platform-identite-virtualNetwork-ip-prefix).2.0/24",
              "sourcePortRange" : "0-65535",
              "destinationAddressPrefix" : "$(var-platform-identite-virtualNetwork-ip-prefix).0.0/24",
              "destinationPortRanges" : [ "3389" , "22" ],
              "protocol" : "Tcp",
              "access" : "Allow",
              "description" : "Permettre acces RDP et SSH du jumpbox primaire Gestion vers sous-réseau jumpbox dans spoke identité",
              "direction" : "Inbound"
            }
          },
          {
            "name": "sr_inbound_allow_dc_to_dc_local-002",
            "properties" : 
            {
              "priority" : 310,
              "sourceAddressPrefix" : "$(var-platform-identite-virtualNetwork-ip-prefix).0.0/24",
              "sourcePortRange" : "0-65535",
              "destinationAddressPrefix" : "$(var-platform-identite-virtualNetwork-ip-prefix).0.0/24",
              "destinationPortRange" :  "*",
              "protocol" : "*",
              "access" : "Allow",
              "description" : "Permettre acces interne dans sous-réseau dc dans spoke identité",
              "direction" : "Inbound"
            }
          },
          $(var-nsg-custom-identite),
          {
            "name": "sr_inbound_default_deny_infra_003",
            "properties" : 
            {
              "priority" : 4095,
              "sourceAddressPrefix" : "*",
              "sourcePortRange" : "0-65535",
              "destinationAddressPrefix" : "*",
              "destinationPortRange" : "*",
              "protocol" : "*",
              "access" : "Deny",
              "description" : "Refuser accès si pas de allow",
              "direction" : "Inbound"
            }
          }
        ]
      },  
    . . . 

```

Pour la communication avec les contrôleurs de domaine Active Directory, un grand nombre de ports doivent être ouverts, entre les contrôleurs de domaine eux-même (pour la synchronisation) ainsi qu'à partir des charges de travail "client", soit dans le nuage soit sur le réseau local sur site. Exemple (toujours dans les fichiers `cei-*-nsg-custom.yml`)

Exemple

```
  var-addc-addc-ports-tcp: >
    [
      "88","464","135","49152-65535","389","636","445","3268","3269","53"
    ]

  var-addc-addc-ports-udp: >
    [
      "88","4444","123","464","389","445","53"
    ]

  var-client-addc-ports-tcp: >
    [
      "88","464","135","49152-65535","389","636","445","3268","3269","53"
    ]

  var-client-addc-ports-udp: >
    [
      "88","4444","123","464","389","445","53"
    ]
```
