function remove-mg($id, $targetmg)
{
	$WarningPreference = 'SilentlyContinue'
	#gets the parent item
	$parent = Get-AzManagementGroup -GroupId $id -Expand -Recurse

	#if the children is not null
	if($parent.Children -ne $null)
	{
	    foreach($children in $parent.Children)
		{
			#check if we have a subscription
			if($children.Type -eq '/subscriptions')
			{
			    $subid = $children.Name
			    Write-Host "Moving subscription $subid to Management Group $targetmg" -ForegroundColor White
			    New-AzManagementGroupSubscription -GroupName $targetmg -SubscriptionId $subid
			}
			else
			{
                #recurse if it is not null
                remove-mg $children.Name $targetmg
			}

		}
	}
	$temp = $parent.Name
    Write-Host "Removing Management Group $temp" -ForegroundColor White
    #removes the bottom most in the iteration.
    Remove-AzManagementGroup -InputObject $parent
}