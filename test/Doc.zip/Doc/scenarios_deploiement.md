#### Retour en arrière

* [Étapes du déploiement](etapes_deploiement.md)
* [Mise en contexte](mise_en_contexte.md)
* [Aperçu des procédures de paramétrage](parametrage.md)
* [Page d'accueil](../Readme.md)

# Aperçu des scénarios de déploiement

Le script V2.2 est basé sur le concept de scénario pour assurer la modularité et l'extensibilité. D'une part, il y a des scénarios prédéfinis (comme pour le scénario "base", pris en charge à ce jour), qui nécessitent un paramétrage "vanille" pour le déploiement. D'autre part, les usagers des OP et des établissements ont la possibilité de personnaliser les déploiements en créant leurs propres scénarios. Le paramétrage du script v2.2 est divisé en deux catégories :

* Paramétrage spécifique à un scénario
* Paramétrage "commun" indépendant du scénario choisi

## 1. Scénarios de déploiement

Il y a plusieurs scénarios de déploiement possibles avec le script v2.2, par exemple le scénario "base", qui est pris en charge. La sélection d'un scénario se fait lors du paramétrage initial du script, dans le fichier common.yml dans le répertoire azure-pipeline/config/variables. En dessous de ce répertoire, chaque scénario a son propre sous-répertoire qui contient plusieurs fichiers de configuration, spécifique au scénario respectif.


| Fichier                                | Utilisation pour le paramétrage                                                                                                                                                                                                           |
| :--------------------------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| cei-\<nom scenario\>-main.yml          | À ne pas toucher                                                                                                                                                                                                                      |
| cei-\<nom scenario\>-param.yml         | Contient les paramètres à changer le plus souvent lors d'un déploiement. Par exemple, les identificateurs des abonnements, des groupes de sécurité et les services de connectivité déployés.                                           |
| cei-\<nom scenario\>-hierarchie.yml    | À toucher seulement si on veut rajouter des abonnements dans la hiérarchie prédéfinie.                                                                                                                                                |
| cei-\<nom scenario\>-subscriptions.yml | Mettre ici les associations entre les abonnements (plateforme et zone d'accueil) et les groupes d'administration. À toucher seulement si on veut rajouter des abonnements et/ou des groupes d'administration dans la hiérarchie prédéfinie. |
| cei-\<nom scenario\>-lz.yml            | Mettre ici les identificateurs des abonnements et les paramètres des zones d'accueil.                                                                                                                                                          |
| cei-\<nom scenario\>-routage.yml    | Mettre ici les définitions des tables de routage entre les VNet des abonnements périphériques ("spoke") tels que gestion, identité et zones d'accueil, ainsi que vers Internet et vers sur site (*on-prem*).                                                         |

Le choix d'un scénario se fait en changeant la valeur de la variable mainVariablesFile dans common.yml. À ce jour, le scénario "base" est pris en charge et le paramétrage est le suivant :

* mainVariablesFile: scenario-base/cei-base-main.yml

Le scénario "complexe" permet aussi la compréhension des procédures de personnalisation des scénarios selon les besoins des OP et des établissements. Cette personnalisation, en vue de créer d'autres scénarios de déploiement, nécessite toutefois une maîtrise approfondie du script V2.2. Pour cet exemple, le paramétrage dans common.yml est le suivant :

* mainVariablesFile: scenario-complexe/cei-complexe-main.yml

La différence entre le scénario "base" et le scénario "complexe" réside dans la hiérarchie des zones d'accueil. Tous les scénarios déploient les abonnements de type "plateforme" ("connectivité" et optionnellement "identité" et/ou "gestion").

## 2. Abonnements "Plateforme"

Tous les scénarios déploient des abonnements de type plateforme, les mêmes pour tous les scénarios.


| Hiérarchie des groupes d'administration | Optionnel | Abonnement    | Utilisation                                                                                                                                                                                |
| ---------------------------------------- | ----------- | --------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| /Organisation/Plateforme/Connectivité | Non       | Connectivité | Accueille (comme service ou NVA) le coupe-feu, le WAF, le balanceur de charge applicative, la passerelle VPN , le service bastion, le service ASR et d'autres services type réseau ou sécurité. |
| /Organisation/Plateforme/Identité     | Oui       | Identité     | Accueille par exemple une instance de contrôleur de domaine AD.                                                                                                                                      |
| /Organisation/Plateforme/Identité     | Oui       | Gestion       | Accueille les services de surveillance (par exemple l'espace de travail LogAnalytics).                                                                                                             |

## 3. Zones d'accueil du scénario "base"

Le scénario "base" déploie une hiérarchie simplifiée de zones d'accueil.


| Hiérarchie des groupes d'administration        | Zone d'accueil par défaut | Utilisation recommandée                                                      |
| ----------------------------------------------- | ------------------------- | ------------------------------------------------------------------------------- |
| /Organisation/Charges/Production/NonSensibles | Données non sensibles  | Accueille des charges applicatives qui échangent des données non sensibles.  |
| /Organisation/Charges/Production/Sensibles    | Données sensibles      | Accueille des charges applicatives qui échangent des données sensibles.      |
| /Organisation/Charges/NonProduction           | Non-production          | Accueille des charges applicatives non-prod (développement, validation).      |
| /Organisation/Expérimentation                | Aucune                  | Accueille des abonnements pour les charges de travail non-prod et expérimentales. |
| /Décommissionnées                           | Aucune                  | Déplacer ici les abonnements avec des charges de travail dont on cesse l'utilisation.     |


## 4. Zones d'accueil du scénario "complexe"



| Hiérarchie des groupes d'administration            | Zone d'accueil par défaut      | Utilisation recommandée                                                     |
| ---------------------------------------------------- | ----------------------------- | ------------------------------------------------------------------------------ |
| /Organisation/Charges/Intranet/Production          | IntranetProduction          | Accueille des charges applicatives avec accès interne (production).         |
| /Organisation/Charges/Intranet/Acceptation         | IntranetAcceptation         | Accueille des charges applicatives avec accès interne (non-production).      |
| /Organisation/Charges/Intranet/Developement        | IntranetDeveloppement       | Accueille des charges applicatives avec accès interne (developement).        |
| /Organisation/Charges/ServicesEnLigne/Production   | ServicesEnLigneProduction   | Mettre ici des charges applicatives avec accès externe (production).         |
| /Organisation/Charges/ServicesEnLigne/Acceptation  | ServicesEnLigneAcceptation  | Accueille des charges applicatives avec accès externe (non-production).      |
| /Organisation/Charges/ServicesEnLigne/Developement | ServicesEnLigneDevelopement | Accueille des charges applicatives avec accès externe (developement).        |
| /Organisation/Charges/Bureautique/Production       | BureautiqueProduction       | Accueille des charges bureautiques avec accès direct usager (production).     |
| /Organisation/Charges/Bureautique/Acceptation      | BureautiqueAcceptation      | Accueille des charges bureautiques avec accès direct usager (non-production). |
| /Organisation/Charges/Bureautique/Developement     | BureautiqueDevelopement     | Accueille des charges bureautiques avec accès direct usager (developement).   |
| /Organisation/Carresdesable                        | Aucune                      | Accueille des abonnements pour charges de travail non-prod et expérimentales. |
| /Décommissionnées                                | Aucune                      | Déplacer ici les abonnements avec des charges de travail dont on cesse l'utilisation.    |
| /Preuvesdeconcept                                  | Aucune                      | Autre abonnement non-prod pour l'expérimentation                             |
