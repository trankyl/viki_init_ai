# Zone d'accueil IBM

## Table des matières

1. [Mise en contexte](#mise-en-contexte)
2. [Licence d'utilisation](Licence.md)
3. [Historique des versions](HistoVersions.md)
4. [Objectif de la zone d'accueil](#objectif-de-la-zone-d'accueil)
5. [Cloner le Dépôt de la zone d'accueil d'IBM](doc/clone.md)
6. [Architecture de la zone d'accueil](#architecture-de-la-zone-d'accueil)
7. [Structure de dossier](#structure-de-dossier)
8. [Architecture](doc/architecture.md)
10. [Description des sous réseaux](#description-des-sous-réseaux)
11. [Guide pas-à-pas de déploiement de la zone d'accueil d'IBM](doc/deploiement.md)
11. [Annexe I Abréviations](#annexe-i-abréviations)

## Mise en contexte

Le présent projet est réalisé dans le cadre du Décret 596-2020 visant la transposition infonuagique des infrastructures informatiques des ministères et des organismes publics (OP), des établissements du réseau de la santé et des services sociaux (RSSS), ainsi que ceux du réseau de l’éducation et de l’enseignement supérieur (REES).

À cet égard, le [Centre d’expertise en infonuagique (CEI)](https://www.quebec.ca/gouvernement/faire-affaire-gouvernement/services-organisations-publiques/service-dexpertise-en-infonuagique/centre-expertises-infonuagique) du ministère de la Cybersécurité et du Numérique (MCN), en collaboration avec IBM, a produit un script qui permet de fournir de manière automatisée une [zone d’accueil (Landing Zone en anglais)](https://docs.microsoft.com/fr-fr/azure/cloud-adoption-framework/ready/landing-zone/) sur la plateforme infonuagique IBM.

En ce qui concerne la conformité PBMM, le MCN en accord avec le Secrétariat du Conseil du trésor (SCT) et le Centre gouvernemental de cyberdéfense (CGC) a publié [les 12 exigences minimales de sécurité](https://ccti.isec.gouv.qc.ca/Documents%20partages/Forms/AllItems.aspx?RootFolder=%2fDocuments%20partages%2fdoc_soutien%2fExigences%20minimales%20de%20s%c3%a9curit%c3%a9%20dans%20le%20nuage&FolderCTID=0x012000D5848080D50BC84395D7F2C1DEE32CE7) qui doivent être respectées par tous les OP et les établissements pour héberger les données du gouvernement du Québec (Profil A ou B) dans le nuage.

En outre, la Direction générale du Programme de consolidation des centres de traitement informatique du MCN a publié un avis à la clientèle pour expliquer le processus d’approbation de l’architecture de la zone d’accueil des organismes publics qui doivent transposer leurs charges de travail en infonuagique externe. À cet effet, l’outil de conformité ([La liste de vérification de sécurité](https://ccti.isec.gouv.qc.ca/Documents%20partages/doc_soutien/Liste%20de%20v%C3%A9rification_conformit%C3%A9%20zone%20d%27accueil.docx) doit être rempli avant le déploiement des charges de travail et signé par un gestionnaire puisqu’il s’agit d’un document d’engagement confirmant que les contrôles recommandés sont en place.

[Retour vers le haut](#table-des-matières)


## Objectif de la zone d'accueil

Pour les OP et les établissements des réseaux de l'éducation et de la santé, la zone d’accueil représente une architecture conceptuelle et évolutive permettant d’exploiter l’environnement infonuagique à son maximum en respectant les meilleures pratiques et les normes gouvernementales établies par le MCN.

Cette architecture a été conçue en collaboration avec l’équipe du Centre d'expertise en infonuagique (CEI) en respectant l’ensemble de leurs exigences.

La création d’une zone d’accueil permet la préparation des éléments suivants :

- Création d’une zone d’accueil pour un OP ou un établissement
- Création des segments réseau nécessaires
- Déploiement du pare-feu
- Déploiement et configuration de la passerelle réseau
- Déploiement de la solution de journalisation
- Établissement du lien d'authentification avec les comptes racines

La solution permet de créer une zone d’accueil type à partir du début.

[Retour vers le haut](#table-des-matières)

## Architecture de la zone d'accueil

![image](./doc/images/architecture.png)

[Retour vers le haut](#table-des-matières)

## Structure de dossier

Ce projet de la zone d'accueil est structuré de la manière suivante :

- Les composants de la zone d'accueil ont été divisés en modules dans le dossier [`terraform`](terraform):
  - [terraform/00-landing-zone](terraform/00-landing-zone)
    - La zone d'accueil basée sur le [patron VSI](https://cloud.ibm.com/docs/framework-financial-services?topic=framework-financial-services-vpc-architecture-detailed-vsi) d'IBM Cloud pour les services financiers
  - [terraform/10-observability](terraform/10-observability)
    - [IBM Activity Tracker](https://cloud.ibm.com/docs/activity-tracker?topic=activity-tracker-getting-started)
    - [IBM Log Analysis](https://cloud.ibm.com/docs/log-analysis?topic=log-analysis-getting-started)
    - [IBM Cloud Monitoring](https://cloud.ibm.com/docs/monitoring?topic=monitoring-getting-started)
  - [terraform/21-fortigate-ha-multi](terraform/21-fortigate-ha-multi)
      - `21-fortigate-ha-multi` déploie un nuage privé virtuel (VPC) de périmètre avec une [paire de FortiGate HA](https://docs.fortinet.com/document/fortigate-public-cloud/7.2.0/ibm-cloud-administration-guide/944419/deploying-fortigate-vm-a-p-ha-on-ibm-vpc-cloud-byol) dans n'importe quelle combinaison de zones (zones 1, 2 et 3) dans la région choisie. Vous pouvez déployer une paire dans une seule zone ou dans des zones différentes.
  - [terraform/30-cloudinternetsvcs](terraform/30-cloudinternetsvcs)
    - [Cloud Internet Services](https://cloud.ibm.com/docs/cis?topic=cis-about-ibm-cloud-internet-services-cis), propulsés par CloudFlare, pour assurer la sécurité, la fiabilité et la performance des applications orientées Internet.

- Le dossier `pipeline_LZ_IBM` contient le pipeline créé pour automatiser le déploiement de la zone d'accueil comme démontré dans la documentation de [déploiement](doc/deploiement.md).
- Le dossier `doc` contient la documentation pour la zone d'accueil.

[Retour vers le haut](#table-des-matières)

## Description des sous réseaux

Chaque nuage privé virtuel (VPC) crée deux niveaux de sous-réseaux, chacun étant attaché à la liste de contrôle d'accès de réseau qui a été créée pour ce VPC-là. Le VPC de gestion a aussi un sous-réseau pour la création de la passerelle de VPN.

[Retour vers le haut](#table-des-matières)

#### Sous-réseaux de VPC de gestion

Niveau de sous-réseau | Nom du sous-réseau de la Zone 1 | Zone 1 CIDR   | Nom du sous-réseau de la Zone 2 | Zone 2 CIDR   | Nom du sous-réseau de la Zone 3 | Zone 3 CIDR   |
------------|------------------------------|---------------|--------------------|---------------|--------------------|---------------|
`vsi`       | `vsi-zone-1`                 | 10.10.10.0/24 | `vsi-zone-2`       | 10.15.10.0/24 | `vsi-zone-3`       | 10.20.10.0/24 |
`vpe`       | `vpe-zone-1`                 | 10.10.20.0/24 | `vpe-zone-2`       | 10.15.20.0/24 | `vsi-zone-3`       | 10.20.20.0/24 |
`vpn`       | `vpn-zone-1`                 | 10.10.30.0/24 |

[Retour vers le haut](#table-des-matières)

#### Sous-réseaux VPC de charges de travail (*Workload VPC Subnets*)

Niveau de sous-réseau | Nom du sous-réseau de la Zone 1 | Zone 1 CIDR    | Nom du sous-réseau de la Zone 2 | Zone 2 CIDR    | Nom du sous-réseau de la Zone 3 | Zone 3 CIDR    |
-------------|------------------------------|----------------|------------------------------|----------------|------------------------------|----------------|
`vsi`       | `vsi-zone-1`                 | 10.25.10.0/24  | `vsi-zone-2`                 | 10.30.10.0/24  | `vsi-zone-3`                 | 10.35.10.0/24  |
`vpe`       | `vpe-zone-1`                 | 10.25.20.0/24  | `vpe-zone-2`                 | 10.30.20.0/24  | `vsi-zone-3`                 | 10.35.20.0/24  |

[Retour vers le haut](#table-des-matières)

#### Sous-réseaux VPC pour les charges de travail et le développement (*Workload Dev VPC Subnets*)

Niveau de sous-réseau | Nom du sous-réseau de la Zone 1  | Zone 1 CIDR    | Nom du sous-réseau de la Zone 2 | Zone 2 CIDR   | Nom du sous-réseau de la Zone 3 | Zone 3 CIDR|
-------------|-------------------------------|----------------|--------------------|---------------|--------------------|------------|
`vsi`       | `vsi-zone-1`                  | 10.55.10.0/24  | `vsi-zone-2`       | 10.60.10.0/24 | `vsi-zone-3`       | 10.65.10.0/24 |
`vpe`       | `vpe-zone-1`                  | 10.55.20.0/24  | `vpe-zone-2`       | 10.60.20.0/24 | `vsi-zone-3`       | 10.65.20.0/24 |

[Retour vers le haut](#table-des-matières)

#### Sous-réseaux VPC de charges de travail bac à sable (*Workload sandbox VPC Subnets*)

Niveau de sous-réseau | Nom du sous-réseau de la Zone 1 | Zone 1 CIDR    | Nom du sous-réseau de la Zone 2 | Zone 2 CIDR   | Nom du sous-réseau de la Zone 3 | Zone 3 CIDR   |
-------------|------------------------------|----------------|--------------------|---------------|--------------------|---------------|
`vsi`       | `vsi-zone-1`                 | 10.40.10.0/24  | `vsi-zone-2`       | 10.45.10.0/24 | `vsi-zone-3`       | 10.50.10.0/24 |
`vpe`       | `vpe-zone-1`                 | 10.40.20.0/24  | `vpe-zone-2`       | 10.45.20.0/24 | `vsi-zone-3`       | 10.50.20.0/24 |

[Retour vers le haut](#table-des-matières)

#### Liste de contrôle d'accès

Une [liste de contrôle d'accès](https://cloud.ibm.com/docs/vpc?topic=vpc-using-acls) est créée pour chaque VPC pour permettre les communications entrantes dans le réseau, les communications entrantes venant des services d'IBM ainsi que toutes les communications sortantes.

Règles                        | Action | Direction | Source        | Destination 
----------------------------|--------|-----------|---------------|----------------
`allow-ibm-inbound`         | Allow  | Entrant   | 161.26.0.0/16 | 10.0.0.0/8
`allow-all-network-inbound` | Allow  | Entrant   | 10.0.0.0/8    | 10.0.0.0/8
`allow-all-outbound`        | Allow  | Sortant   | 0.0.0.0/0     | 0.0.0.0/0

Parce que les VPC de charges de travail de non-production sont connectés par la passerelle de transit au VPC de charges de travail de production, la liste de contrôle d'accès du VPC de charges de travail dispose de règles de refus supplémentaire. Ceci permet au trafic venant des environnements de non-production de ne pas entrer dans le VPC de production.

Règles                        | Action | Direction | Source        | Destination 
----------------------------|--------|-----------|---------------|----------------
`deny-sable-inbound-1`      | Deny  | Entrant   | 10.40.0.0/16   | 10.0.0.0/8
`deny-sable-inbound-2`      | Deny  | Entrant   | 10.45.0.0/16   | 10.0.0.0/8
`deny-sable-inbound-3`      | Deny  | Entrant   | 10.50.0.0/16   | 10.0.0.0/8
`deny-dev-inbound-1`        | Deny  | Entrant   | 10.55.0.0/16   | 10.0.0.0/8
`deny-dev-inbound-2`        | Deny  | Entrant   | 10.60.0.0/16   | 10.0.0.0/8
`deny-dev-inbound-3`        | Deny  | Entrant   | 10.65.0.0/16   | 10.0.0.0/8

[Retour vers le haut](#table-des-matières)

## Annexe I Abréviations
|**Abréviations**|**Définition**|**Traduction en français**|
|---|---|---|
|ACL|Access Control List|Liste de contrôle d'accès|
|API|Application Programming Interface|Interface de programmation d'applications|
|AppID|Application Identification|Identification de l'application|
|BOMS|Bill of material|Nomenclature|
|CLI|Command Line Interface|Interface de ligne de commande|
|cmd|Command|Commande|
|COS|Cloud object storage|Stockage d'objets en nuage|
|CPU|Central Processing Unit|Unité centrale de traitement|
|CRA scanners|Computing Research Association scanners|Association de recherche en informatique et scanneurs|
|CRN|Cloud registration Name|Nom d'enregistrement du nuage|
|CS|Cognitive Services|Services cognitifs|
|DDOS|Distributed denial-of-service|Déni de service distribué|
|DRA|Data Recovery Agent|Agent de récupération des données|
|DRS|Domain Name System|Système de noms de domaine|
|EDR|Enhanced data rate|Débit de données amélioré|
|EMS|Expanded Memory System /Execution Management System|Système de mémoire étendue / Système de gestion des exécutions|
|GIA|Government Information Awareness|Sensibilisation à l'information gouvernementale|
|HMAC|Hash-Based Message Authentification Code|Code d'authentification de message basé sur le hachage|
|HPCA|High performance computers Architecture|Architecture informatique haute performance|
|HPCS|Hyper Protect Crypto Service|Service de gestion de clés infonuagiques très protégé|
|IAM|Identity and Access Managment|Gestion des identités et des accès|
|KMS|Key Management Service|Service de gestion des clés|
|LAN|Local Area Network|Réseau local|
|LB|Load Balancer|Équilibreur de charge|
|LDAP|Lightweight Directory Access Protocol|Protocole d'accès à l'annuaire léger|
|MBaaS|Mobile Backend as a Service|Application mobile en tant que service|
|MG|Management Group|Groupe de gestion|
|MGMT|Management|Gestion|
|Mkdir|Make directory|Créer un répertoire|
|NAC|Network Access Control|Contrôle d'accès au réseau|
|NGFW|Next Generation Firewall|Pare-feu de nouvelle génération|
|NLS|National Language Support|Soutien aux langues nationales|
|NPL|Non Procural Language|Langage non procédural|
|NSG| Network Security Group|Groupe de sécurité réseau|
|OWASP|Open Web Application Security Projects|Projets ouverts de sécurité des applications Web|
|PaaS|Platform as a Service|Plateforme en tant que service|
|RADIUS|Remote Authentification Dial-In User Service|Service d'authentification à distance pour les utilisateurs connectés|
|Redis|Remote Dictionnary Server|Serveur de dictionnaire distant|
|Repo|Repository|Dépôt|
|ROKS|Red Hat OpenShift Kubernetes Service|Service Kubernetes de Red Hat Open Shift|
|RSA|Rivest-Shamir-Adleman|Algorithme de cryptage Rivest-Shamir-Adleman|
|SAML|Security Assertion Markup Language|Langage de balisage d'assertion de sécurité|
|SBQ|Service Bus Queues|Files d'attente de bus de service|
|SCC|Security and Compliance Center|Centre de sécurité et de conformité||
|SSH|Secure Shell|À la fois un programme informatique et un protocole de communication sécurisé|
|SSO|Single sign-on|Authentification unique|
|TACACS+|Terminal Access Controller Access-Control System Plus|Protocole d'authentification distante|
|TCO|Total cost of ownership|Coût total de possession|
|Tf-dir|Terraform directory|Répertoire Terraform|
|Tf-var-file|Terraform variable file|Fichier de variables Terraform|
|Vnet|Virtual Network|Réseau virtuel|
|VPC|Virtual Private Cloud|Nuage privé virtuel|
|VPE|Virtual Private Endpoint|Point d'accès privé virtuel|
|VPN|Virtual Private Network|Réseau privé virtuel|
|VSI|Virtual Server Instance|Instance de serveur virtuel|
|YML / YAML|Yet Another Markup Language|Format de représentation de données par sérialisation Unicode|

[Retour vers le haut](#table-des-matières)


 

