# Procédures de paramétrage et déploiement

## Sommaire

- [Procédures de paramétrage et déploiement](#procédures-de-paramétrage-et-déploiement)
  - [Sommaire](#sommaire)
  - [**Paramétrage**](#paramétrage)
  - [**Choix du scénario et paramètres communs**](#choix-du-scénario-et-paramètres-communs)
  - [**Structure des groupes d’administration**](#structure-des-groupes-dadministration)
    - [ **Hiérarchie**](#-hiérarchie)
    - [**Paramètres**](#paramètres)
  - [**Stratégies et initiatives**](#stratégies-et-initiatives)
  - [**Création et exécution des pipelines de déploiement**](#création-et-exécution-des-pipelines-de-déploiement)

## <a id="parametrage" ></a>**Paramétrage**

Le diagramme ci-dessous illustre à haut niveau le paramétrage pour le choix du scénario de base. Pour le scénario complexe, c'est très similaire.![Paramétrage](images\parametrage_script.png "Paramétrage")

## <a id="ChoixScenario" ></a>**Choix du scénario et paramètres communs**

Il y a deux scénarios pris en charge : le scénario de base et le scénario complexe. Les configurations décrites ci-dessous s'appliquent à celui de base.  Toutefois, pour chaque configuration faite dans le scénario de base, il y a sa correspondance pour le scénario complexe dans le répertoire ```..azure-pipeline/config/variables/scenario-complexe```

Il est possible de "personnaliser" les scénarios proposés. Cependant, le soutien relatif aux modifications réalisées dans les scripts est sous la responsabilité du client.

Premièrement, éditer le fichier [common.yml](../azure-pipeline/config/variables/common.yml "paramétrage commun") et valider que la variable ```mainVariablesFile``` contient

```yaml
mainVariablesFile: scenario-base/cei-base-main.yml
```

Après, ajuster le nom de la connexion de service (créée lors de la configuration DevOps) qui sera utilisé pour faire le déploiement dans Azure, en modifiant la valeur de la variable ```serviceConnectionName```.

> Important : **NE PAS MODIFIER** les variables suivantes :

* ```deploymentRegion``` (par défaut canadacentral). À titre informatif, jusqu’à présent, dans la région canadaest, il n'y a pas de la haute disponibilité.
* ```vmImageName``` (par défaut « ubuntu-latest »). Elle est utilisée pour les « agents » qui roulent les scripts de déploiement.
* ```deployOperation``` (par défaut « create »). Elle définit le comportement des scripts par rapport à la création « à neuf » des ressources à la place d'une simple actualisation.
* ```var-bashPreInjectScript``` et ```var-bashPostInjectScript```

---

## <a id="StructureGroupes" ></a>**Structure des groupes d’administration**

### <a id="hierarchie" ></a> **Hiérarchie**

La structure logique proposée est la suivante et elle ne doit pas être modifiée. Le fichier qui contient le code est [cei-base-hierarchie.yml](../azure-pipeline/config/variables/scenario-base/cei-base-hierarchie.yml "hiérarchie") pour le scénario "base" et [cei-complexe-hierarchie.yml](../azure-pipeline/config/variables/scenario-complexe/cei-complexe-hierarchie.yml "hiérarchie") pour le scénario "complexe". La structure est similaire, avec la différence que dans le scénario "complexe", la hiérarchie est plus complexe.

```yaml
var-managementgroup-hierarchy: 
    {
      "name": "Tenant Root Group",
      "id": "'$(var-tenantId)'",
      "children": [
        {
          "name": "'$(var-organisation-name)'",
          "id": "'$(var-organisation-id)'",
          "children": [
            {
              "name": "Plateforme", "id": "Plateforme",
              "children": [
                { "name": "Identité", "id": "Identite", "children": [] },
                { "name": "Connectivité", "id": "Connectivite", "children": [] },
                { "name": "Gestion", "id": "Gestion", "children": [] },
                { "name": "Perimetre", "id": "Perimetre", "children": [] }
              ]
            },
            {
              "name": "Charges", "id": "ZoneDeCharges",
              "children": [
                { "name": "Production", "id": "Production", 
                  "children": [
                    { "name": "Non Sensibles", "id": "NonSensibles", "children": [] },
                    { "name": "Sensibles", "id": "Sensibles", "children": [] }
                  ] 
                },
                { "name": "Non Production", "id": "NonProduction", "children": [] }
              ]
            },
            {
              "name": "Decommissionés", "id": "Decommissiones",
              "children": []
            },
            {
              "name": "Expérimentation", "id": "EnvironnementExperimentation",
              "children": []
            }
          ]  
        }
      ]
    }
```

**Microsoft Defender**

Par défaut, le déploiement de la zone d’accueil active "Microsoft Defender" plan 1 à partir de la racine de la structure des groupes d’administration, détaillée plus haut.

Pour activer "Microsoft Defender" plan 2, voir la [documentation associée](parametrage_azure_defender.md).

```yaml
  var-managementgroup-subscription-sensibles: 
    {
        "subscriptions":  ["'$(var-charges-sensibles-subscriptionId)'"],
        "managementgroup": "Sensibles",
        "azDefenderParam": $(var-azure-defender-param-P2)
    }
```

Voici le paramétrage attendu pour la [surveillance et renforcement de la posture de sécurité](surveillance_et_securite.md) dans la zone d'accueil Azure.

### <a id="parametres" ></a>**Paramètres**

Le paramétrage permet le déploiement de la zone d'accueil avec les informations uniques de chaque client. Pour attribuer les valeurs aux variables, ouvrir le fichier [cei-base-param.yml](../azure-pipeline/config/variables/scenario-base/cei-base-param.yml "paramétrage scenario base").

```Note :``` Les ID des objets (tenant, abonnements, groupes d'usagers, etc.) doivent être exprimés en format [GUID](https://www.techtarget.com/searchwindowsserver/definition/GUID-global-unique-identifier) {abcd1234-5678-9abc-def0-123456789abc}.

Les valeurs à assigner aux différentes variables sont les suivantes :

Informations du locataire Azure**

* ```var-tenantId``` : [ID de locataire Azure](https://learn.microsoft.com/fr-ca/azure/active-directory/fundamentals/active-directory-how-to-find-tenant) du déploiement
* ```var-organisation-name``` : nom de l'organisation du client (acronyme)

**Les abonnements plateforme**

* ```var-platform-hub-subscriptionId``` : ID de l'abonnement « connectivité » (*hub*)
* ```var-platform-gestion-subscriptionId``` : ID de l'abonnement « gestion »
* ```var-platform-identite-subscriptionId``` : ID de l'abonnement « identité »
* ```var-platform-perimetre-subscriptionId``` : ID de l'abonnement « perimetre » ```facultatif```

Note : si la valeur assignée à un abonnement ```facultatif``` est vide (```''```), aucune ressource n'y sera déployée

**Les abonnements charge de travail - scénario de base**

* ```var-charges-nonprod-subscriptionId``` : ID de l'abonnement « données non-production »
* ```var-charges-nonsensibles-subscriptionId``` : ID de l'abonnement « données non sensibles »
* ```var-charges-sensibles-subscriptionId``` : ID de l'abonnement « données sensibles » ```facultatif```
* ```var-carresdesable-subscriptionId``` : ID de l'abonnement « experimentation » ```facultatif```

Note : si la valeur assignée à un abonnement ```facultatif``` est vide (```''```), aucune ressource n'y sera déployée.

**Les abonnements charge de travail - scénario complexe**

* ```var-charges-intranet-production-subscriptionId``` : ID de l'abonnement « intranet production »
* ```var-charges-servicesenligne-production-subscriptionId``` : ID de l'abonnement « services en ligne production »
* ```var-charges-bureautique-production-subscriptionId``` : ID de l'abonnement « bureautique production »
* ```var-charges-intranet-acceptation-subscriptionId``` : ID de l'abonnement « intranet acceptation » ```facultatif```
* ```var-charges-servicesenligne-acceptation-subscriptionId``` : ID de l'abonnement « services en ligne acceptation » ```facultatif```
* ```var-charges-bureautique-acceptation-subscriptionId``` : ID de l'abonnement « bureautique acceptation » ```facultatif```
* ```var-charges-intranet-developement-subscriptionId``` : ID de l'abonnement « intranet développement » ```facultatif```
* ```var-charges-servicesenligne-developement-subscriptionId``` : ID de l'abonnement « services en ligne développement » ```facultatif```
* ```var-charges-bureautique-developement-subscriptionId``` : ID de l'abonnement « bureautique développement » ```facultatif```
* ```var-decommissionnes-subscriptionId``` : ID de l'abonnement ou on déplace les ressources décommissionnées » ```facultatif```
* ```var-carresdesable-subscriptionId``` : ID de l'abonnement « experimentation » ```facultatif```
* ```var-carresdesable-subscriptionId``` : ID de l'abonnement « experimentation » ```facultatif```

Note : si la valeur assignée à un abonnement ```facultatif``` est vide (```''```), aucune ressource n'y sera déployée.

**Ressources à déployer dans le *hub* (avec leurs valeurs ```par défaut```)**

* ```var-platform-hub-deploy-bastion``` : true
* ```var-platform-hub-deploy-appGateway``` : false
* ```var-platform-hub-deploy-privateDNS``` : true
* ```var-platform-hub-deploy-AzureFW``` : false
* ```var-platform-hub-deploy-Fortigate``` : true
* ```var-platform-hub-deploy-expressRouteGW```: false
* ```var-platform-hub-deploy-VPNGW```: false
* ```var-platform-hub-privIp-VPNGW```: false
* ```var-platform-hub-deploy-recoveryVault```: false
* ```var-platform-hub-deploy-resolver-outbound```: false
* ```var-platform-hub-deploy-resolver-inbound```: false
* ```var-fw-domain-rules```: liste vide (contient les règles d'acheminement des requetes DNS)

**Ressources à déployer dans le *spoke* Gestion**

* ```var-platform-gestion-deploy-bastion``` : true

**Ressources à déployer dans le *spoke* Périmètre**

* ```var-platform-perimetre-deploy-AzureFW``` : false
* ```var-platform-perimetre-deploy-appGateway``` : false

**Adressage**

L'adressage proposé est le suivant; pour plus d'information ou pour le modifier, voir [ici](plan_adressage.md).

* ```var-client-local-network-prefix``` : préfixes réseau de l'environnement « on-site » connecté à la ZA Azure, utilisés pour générer les tables de routage. Valeur ```défaut (exemple à personnaliser)```:

  ```exemple:
  var-client-local-network-prefix: >
    [
      "100.64.0.0/10",
      "10.0.0.0/8", 
      "192.168.0.0/24", 
      "172.16.0.0/12"
    ]
  ```
* ```var-platform-hub-virtualNetwork-ip-prefix``` : 10.84 - préfixe *vnet* HUB
* ```var-platform-hub-virtualNetwork-ip-suffix``` : '.0.0/17' - suffixe *vnet* HUB
* ```var-platform-perimetre-virtualNetwork-ip-prefix``` : 10.84 - préfixe *vnet spoke* périmètre
* ```var-platform-perimetre-virtualNetwork-ip-suffix``` : '.0.0/17' - suffixe *vnet spoke* périmètre
* ```var-platform-gestion-virtualNetwork-ip-prefix``` : 10.73 - préfixe *vnet spoke* gestion
* ```var-platform-gestion-virtualNetwork-ip-suffix``` : '.128.0/17' - suffixe *vnet spoke* gestion
* ```var-platform-gestion-jumpbox-subnet-suffix``` : '.132.0/24 - suffixe *subnet jumpbox* gestion
* ```var-platform-identite-virtualNetwork-ip-prefix``` : 10.73 - préfixe *vnet spoke* identité
* ```var-platform-identite-virtualNetwork-ip-suffix``` : '.0.0/17' - suffixe *vnet spoke* identité
* ```var-charges-virtualNetwork-ip-prefix``` : 10.77 - préfixe *vnets* charges
* ```var-charges-virtualNetwork-ip-suffix``` : '.0.0/16' - suffixe *vnets* charges
* ```var-charges-nonsens-assigne-suffix``` : '.64.0/18' - suffixe données non sensibles
* ```var-charges-nonsens-vnet-suffix``` : '.64.0/20' - suffixe *vnet spoke* données non sensibles
* ```var-charges-sens-assigne-suffix``` : '.0.0/18' - suffixe données sensibles
* ```var-charges-sens-vnet-suffix``` : '.0.0/20' - suffixe *vnet spoke* données sensibles
* ```var-charges-nonprod-assigne-suffix``` : '.128.0/17' - suffixe données non-production
* ```var-charges-nonprod-vnet-suffix``` : '.128.0/21' - suffixe *vnet spoke* non-production

**Routage**

Il y a trois catégories de routage. Pour chacune d'elles, le mode de routage et le "next-hop" sont configurables.

* Internet : toute plage d'adresse destination non hors les routes plus spécifiques (0.0.0.0/0)
* Client : routage vers l'environnement du client pour les plages dans ```var-client-local-network-prefix```
* Périphérique (*Spoke*) : routage interne dans la zone d'accueil entre l'abonnement Gestion et les autres périphériques (*spokes*)

Pour chaque catégorie, le mode peut être :

* ```'nva'```: le routage se fait via une adresse ```'next-hop'``` d'un dispositif NVA comme Fortigate, Azure Firewall ou autre. Dans ce cas, la variable ```'next-hop'``` pour le mode en cause doit être configurée.
* ```'vpn'```: le routage se fait via la passerelle VPN. Dans ce cas, laisser la variable ```'next-hop'``` vide (```''```).

Pour que le mode de routage ```'nva'``` fonctionne, un dispositif NVA doit être provisionné, soit Azure Firewall (dans le *hub* ou périmètre), soit FortiGate (dans le *hub*). Les valeurs ```'next-hop'``` à utiliser sont alors les suivantes, dans la variable var-platform-hub-egressVirtualApplianceIp :


| Dispositif NVA                     | Variable à mettre à 'true'          | Valeur de la variable var-platform-hub-egressVirtualApplianceIp |
| ------------------------------------ | --------------------------------------- | ----------------------------------------------------------------- |
| Pare-feu FortiGate dans le*hub*    | var-platform-hub-deploy-Fortigate     | var-platform-hub-egressFortigateIp                              |
| Azure Firewall dans le*hub*        | var-platform-hub-deploy-AzureFW       | var-platform-hub-egressAzureFirewallIp                          |
| Azure Firewall dans le périmètre | var-platform-perimetre-deploy-AzureFW | var-platform-perim-egressAzureFirewallIp                        |
| VPN Gateway comme NVA              | var-platform-hub-deploy-VPNGW         | var-platform-hub-egressVpnGatewayIp                             |

Important : La valeur de la variable var-platform-hub-egressVirtualApplianceIp doit être configurée en fonction du mode de routage, car cette variable est utilisée dans plusieurs pipelines.

Les variables qui contrôlent le mode de routage sont :

* ```var-mode-route-internet``` : 'nva' - par défaut routage Internet se fait via une NVA (par exemple Fortigate)
* ```var-mode-route-client```: 'nva' - par défaut routage Client se fait via une NVA (par exemple Fortigate) qui fourni aussi le tunnel VPN
* ```var-mode-route-spoke```: 'nva' - par défaut routage Spoke se fait via une NVA (par exemple FortiGate)

Les variables qui contrôlent le "next-hop" pour le mode de routage 'nva' sont :

* ```var-route-internet-nexthop```: par défaut ```$(var-platform-hub-egressVirtualApplianceIp)```
* ```var-route-spoke-nexthop```: par défaut ```$(var-platform-hub-egressVirtualApplianceIp)```
* ```var-route-client-nexthop```: par défaut ```$(var-platform-hub-egressVirtualApplianceIp)```

Les valeurs peuvent quand même être définies selon des besoins spécifiques.

**Étiquettes**

Les valeurs des étiquettes pour le nom du système et le courriel du « propriétaire » en respectant la syntaxe ```'"valeur"'```).

* ```var-common-tags-nom-système``` : nom du système, par exemple '"votrecss"'
* ```var-common-tags-nom-proprietaire``` : courriel du « propriétaire », par exemple '"votrecourriel@votrecss.gouv.qc.ca"'

La hiéarchie des trois étiquettes "racine" (OrganisationClient, Environnement, Projet) qui est appliquée sur toutes les abonnements est défini dans un fichier json. Le fichier qui contient ce code est [subscription-tags-assignment.yml](../azure-pipeline/config/variables/scenario-base/policy/builtin/policy-assignment/subscription-tags-assignment.yml) pour le scénario de base et [subscription-tags-assignment.yml](../azure-pipeline/config/variables/scenario-complexe/policy/builtin/policy-assignment/subscription-tags-assignment.yml) pour le scénario complexe.

```yaml
variables:
  var-builtin_policy-subscription-tags-assignment: >
    [
        {
          "tagName": "OrganisationClient",
          "assignmentScopeValues": [ 
            {
              "scopeType": "managementGroup",
              "scopeId": "$(var-organisation-id)",
              "tagValue": "$(var-organisation-id)"
            }]
          },
          {
          "tagName": "Environnement",
          "assignmentScopeValues": [ 
            {
              "scopeType": "managementGroup",
              "scopeId": "ZoneBureautiqueProduction",
              "tagValue": "Production"
            },
            {
              "scopeType": "managementGroup",
              "scopeId": "ZoneBureautiqueAcceptation",
              "tagValue": "Acceptation"
            },
            {
              "scopeType": "managementGroup",
              "scopeId": "ZoneBureautiqueDeveloppement",
              "tagValue": "Développement"
            },
            {
              "scopeType": "managementGroup",
              "scopeId": "ZoneIntranetProduction",
              "tagValue": "Production"
            },
            {
              "scopeType": "managementGroup",
              "scopeId": "ZoneIntranetAcceptation",
              "tagValue": "Acceptation"
            },
            ...
```

**Azure RBAC**

Pour l'assignation des *Azure role-based access control*, les variables sont les suivantes :

* ```var-principal-id-role-netops```: ID du groupe « netops » en charge de la gestion des ressources réseau
* ```var-principal-id-role-secops```: ID du groupe « secops » en charge de la gestion des ressources sécurité
* ```var-principal-id-role-devops```: ID du groupe « devops » en charge du soutien des charges de travail
* ```var-principal-id-role-appops```: ID du groupe « appops » en charge du soutien applicatif
* ```var-principal-id-role-subscr-owner```: ID du propriétaire (*owner*) des abonnements

Voir la [documentation rbac](rbac.md)

---

## <a id="StategiesInitiatives" ></a>**Stratégies et initiatives**

Voir la [documentation des Stratégies et initiatives](policies_initiatives.md). Les configurations sont spécifiques par scénario. Pour le scénario « base », les fichiers de configuration sont en dessous du répertoire ci-après.

```azure-pipeline/config/cariables/scenario-base/policy.```

Les valeurs par défaut sont en accord avec les meilleures pratiques en matière de sécurité et de conformité réglementaire. Ne pas modifier à moins d'obtenir un avis de sécurité par rapport aux changements envisagés.

---

## <a id="CreationPipelineEtExecution" ></a>**Création et exécution des pipelines de déploiement**

![Déploiement des pipelines](images\Deploiement_pipelines.png "Déploiement des pipelines")

Suivre les étapes [suivantes](etapes_deploiement.md "Étapes pour créer des pipelines et lancer le déploiement") afin de lancer le déploiement de la zone d'accueil Azure.

---

Pour plus d'information, suivre les liens ci-dessous :

* [Aperçu du script](clonage_et_apercu_script.md)
* [Procédure de clonage du dépôt source CEI](clonage_et_apercu_script.md)
* [Configurations nécessaires en Azure DevOps](clonage_et_apercu_script.md)
* [Aperçu de l'abonnement Plateforme Connectivité](connectivite.md)
* [Étapes du déploiement](etapes_deploiement.md)
* [Plan d'adressage](plan_adressage.md)
* [Accueil](../README.md "Retour à la page d'accueil")

```

```
