# Contrôles de sécurité pour les exigences 1, 2, 3 et 4

Liste des contrôles pour les quatre exigences suivantes :

1. Protéger les comptes racines
2. Gérer les comptes ayant le privilège administrateur
3. Limiter les accès à la console du nuage
4. Définir les comptes de surveillance d’entreprise

Contrôles communs aux exigences 01 à 04 :
 AC‑2, AC‑2(1), AC‑3, AC‑5, AC‑6, AC‑6(5), AC‑6(10), AC‑7, AC‑9, AC‑19, AC‑20(3), IA‑2, IA‑2(1), IA‑2(2), IA‑2(11), IA‑4, IA‑5, IA‑5(1), IA‑5(6), IA‑5(7), IA‑5(13), IA‑6, IA‑8.

## < --- Contrôle EX1234_AC-2--->

![EX123](image/AC2.PNG)

## Première Validation

   1. Responsabilité du fournisseur : Oui
   2. Commentaire : AWS fournit le service AWS Organizations permettant la centralisation de la gestion de comptes en regroupement plusieurs comptes AWS. AWS SEA s'appuie sur les unités d'organisation qui contient des comptes. Pour accéder au compte AWS, il existe deux types de comptes : Comptes IAM et Comptes fédéré (SSO).

      Par le biais de la console : AWS Organizations  -> AWS account

   3. [Lien Document](https://docs.aws.amazon.com/IAM/latest/UserGuide/id_roles.html?icmpid=docs_iam_help_panel)

## < --- Contrôle EX1234_AC-2_1--->

![EX123](image/AC2-1.PNG)

## Deuxième Validation

   1. Responsabilité du fournisseur : Oui
   2. Commentaire: AWS offre  les services AWS Config et Security Hub permettant de fournir les écarts détectés pour améliorer la gestion des comtpes.
  
      Par le biais de la console :
    AWS Config ->  Rules
    Security Hub -> Insights
    IAM -> Account settings -> Password Policy.

   3. [Lien Document](https://docs.aws.amazon.com/IAM/latest/UserGuide/id_credentials_passwords_account-policy.html?icmpid=docs_iam_console)
  
## < --- Contrôle EX1234_AC-3--->

![EX123](image/AC3.PNG)

## Troisième Validation

   1. Responsabilité du fournisseur : Oui
   2. Commentaire : La zone d'accueil applique des contrôles en se basant sur le SCP et les strategies IAM pour le gestion des permissions.

      Par le biais de la console :
   AWS Organizations -> SCP
   AWS SSO  ->  AWS accounts
   IAM ->  Roles

   3. [Lien Document](https://docs.aws.amazon.com/IAM/latest/UserGuide/access_policies.html?icmpid=docs_iam_help_panel)

## < --- Contrôle EX1234_AC-5--->

![EX123](image/AC5.PNG)

## Quatrième Validation

   1. Responsabilité du fournisseur : Oui
   2. Commentaire: La séparation des tâches est effectuée en fonction des unités d'organisation et des comptes systémes créés.

      Par le biais de la console :
   IAM ->  Roles

   3. [Lien Document](https://docs.aws.amazon.com/fr_fr/wellarchitected/latest/security-pillar/aws-account-management-and-separation.html)
  
## < --- Contrôle EX1234_AC-6--->

![EX123](image/AC6.PNG)

## Cinquième Validation

   1. Responsabilité du fournisseur : Oui
   2. Commentaire : Le principe du droit d’accès minimal autorise l’accès uniquement aux utilisateurs (ou aux processus exécutés en leur nom) qui en ont besoin pour accomplir les tâches qui leur ont été assignées, conformément aux missions et aux fonctions opérationnelles de l’organisation.
   3. [Lien Document](https://docs.aws.amazon.com/fr_fr/wellarchitected/latest/security-pillar/aws-account-management-and-separation.html)

## < --- Contrôle EX1234_AC-6_5--->

![EX123](image/AC6-5.PNG)

## Sixième Validation

   1. Responsabilité du fournisseur : Oui
   2. Commentaire : Les utilisateurs sont restreints aux accès données en fonction du groupe d'accès.
  
      Par le biais de la console : IAM ->  User groups

   3. [Lien Document](https://aws.amazon.com/fr/iam/)

## < --- Contrôle EX1234_AC-6_10--->

![EX123](image/AC6-10.PNG)

## Septième Validation

   1. Responsabilité du fournisseur : Oui
   2. Commentaire : Les utilisateurs sont restreints aux accès données en fonction du groupe d'accès.

      Par le biais de la console : IAM ->  User groups

   3. [Lien Document](https://aws.amazon.com/fr/iam/)

## < --- Contrôle EX1234_AC-7--->

![EX123](image/AC7.PNG)

## Huitième Validation

   1. Responsabilité du fournisseur : Oui
   2. Commentaire : Un objet de stratégie de groupe AD (*Group Policy Object* ou GPO) a été configuré dans le but de verrouiller le compte d’un utilisateur après un nombre préétabli d’échecs de connexion à l’intérieur d’un certain laps de temps. (Il est recommandé de fixer le nombre à trois échecs de connexion consécutifs dans un délai de 15 minutes).
   Les données des journaux du Domaine AD, qui comprennent les échecs de connexion, sont versées dans AWS CloudWatch.

      Par le biais de la console : AWS AD GPO/ password settings

   3. [Lien Document](https://docs.oracle.com/en/cloud/paas/identity-cloud/uaids/understand-criteria-password-policies.html)

## < --- Contrôle EX1234_AC-9--->

![EX123](image/AC9.PNG)

## Neuvième Validation

   1. Responsabilité du fournisseur: Non assigné
   2. Commentaire : Le système d’information indique à l’utilisateur, qui vient d’ouvrir une session sur le système, la date et l’heure de sa dernière ouverture de session (dernier accès).

      Par le biais de la console : IAM  ->  Users. La colonne « Dernière activité » permet de voir cette information.

## < --- Contrôle EX1234_AC-19--->

![EX123](image/AC19.PNG)

## Dixième Validation

   1. Responsabilité du fournisseur : Oui
   2. Commentaire : Capacité d'établir les restrictions d’utilisation, en matière de configuration et de connexion, ainsi que la mise en œuvre des dispositifs mobiles.

      Par le biais de la console : Réseau VPN  -> Points de terminaison VPN client

   3. [Lien Document](https://docs.aws.amazon.com/fr_fr/console/vpc/cvpn/what-is)
  
## < --- Contrôle EX1234_AC-20_3--->

![EX123](image/AC20-3.PNG)

## Onzième Validation

   1. Responsabilité du fournisseur : Oui
   2. Commentaire : Capacité de limiter; interdire l’utilisation de systèmes d’information, de composants système et de dispositifs inconnus, à des fins de traitement, de stockage ou de transmission d’information organisationnelle.

      Par le biais de la console : IAM ->  Users ou IAM ->  User groups

## < --- Contrôle EX1234_IA-2--->

![EX123](image/IA2.PNG)

## Douzième Validation

   1. Responsabilité du fournisseur : Oui
   2. Commentaire : Le système d’information identifie et authentifie les utilisateurs organisationnels (ou les processus exécutés en leur nom) de façon unique.

      Par le biais de la console : IAM Identity Center  

## < --- Contrôle EX1234_IA-2_1--->

![EX123](image/IA2-1.PNG)

## Treizième Validation

   1. Responsabilité du fournisseur : Oui
   2. Commentaire : Le système d’information applique l’authentification multifactorielle pour l’accès réseau aux comptes privilégiés.

      Par le biais de la console : IAM -> Dashboard

## < --- Contrôle EX1234_IA-2_2--->

![EX123](image/IA2-2.PNG)

## Quatorzième Validation

   1. Responsabilité du fournisseur : Oui
   2. Commentaire : Le système d’information applique l’authentification multifacteur pour l’accès réseau aux comptes privilégiés.

      Par le biais de la console : IAM -> Dashboard

## < --- Contrôle EX1234_IA-2_11--->

![EX123](image/IA2-11.PNG)

## Quinzième Validation

   1. Responsabilité du fournisseur : Oui
   2. Commentaire : Le système d’information utilise l’authentification multifacteur pour l’accès à distance aux comptes privilégiés et non privilégiés.

      Par le biais de la console : IAM -> Dashboard

## < --- Contrôle EX1234_IA-4--->

![EX123](image/IA4.PNG)

## Seizième Validation

   1. Responsabilité du fournisseur : Oui
   2. Commentaire : Gestion des identificateurs

      Par le biais de la console : IAM Identity Center ->  Utilisateurs

## < --- Contrôle EX1234_IA-5--->

![EX123](image/IA5.PNG)

## Dix-septième Validation

   1. Responsabilité du fournisseur : Oui
   2. Commentaire : Gestion des authentifiants

      Par le biais de la console : IAM  ->  Paramètres

## < --- Contrôle EX1234_IA-5_1--->

![EX123](image/IA5-1.PNG)

## Dix-huitième Validation

   1. Responsabilité du fournisseur : Oui
   2. Commentaire :  Authentification fondée sur un mot de passe

      Par le biais de la console : IAM  ->  Paramètres

## < --- Contrôle EX1234_IA-5_6--->

![EX123](image/IA5-6.PNG)

## Dix-neuvième Validation

   1. Responsabilité du fournisseur : Oui
   2. Commentaire : Protection des authentifiants

      Par le biais de la console : IAM  ->  Paramètres

## < --- Contrôle EX1234_IA-5_7--->

![EX123](image/IA5-7.PNG)

## Vingtaine Validation

   1. Responsabilité du fournisseur : Oui
   2. Commentaire : Aucune authentification statique intégrée non chiffrée. Une politique de mot de passe est mise en place au niveau de la zone d'accueil.

      Par le biais de la console : IAM  ->  Paramètres  

## < --- Contrôle EX1234_IA-5_13 --->

![EX123](image/IA5-13.PNG)

## Vingt-et-unième Validation

   1. Responsabilité du fournisseur : Oui
   2. Commentaire : Le service Active Directory (AD) contrôle, stocke et gère les authentifiants permettant d’accéder aux systèmes. Le service AD procède à l’authentification de l'utilisateur avant que le service d’authentification unique (*Single Sign On* ou SSO) utilise l’assertion créée en langage de balisage des assertions de sécurité (*Security Assertion Markup Language* ou SAML). Ceci permet d'appeler le service de création de jetons de sécurité (*Security Token Service* ou STS) d’AWS en vue d’établir les authentifiants temporaires (valides pour une courte durée) dont l’utilisateur pourra se servir pour ouvrir une session.

## < --- Contrôle EX1234_IA-6 --->

![EX123](image/IA6.PNG)

## Vingt-et-deuxième Validation

   1. Responsabilité du fournisseur : Sans objet
   2. Commentaire : Réinjection d'authentification. Le système d’information empêche les réinjections d’information durant le processus d’authentification afin de protéger l’information contre de possibles exploitations ou utilisations par des personnes non autorisées.

      Par le biais de la console : AWS WAF -> WEB ACLs

## < --- Contrôle EX1234_IA-8 --->

![EX123](image/IA8.PNG)

## Vingt-et-troisième Validation

   1. Responsabilité du fournisseur : Oui
   2. Commentaire : Le système d’information identifie de façon unique et authentifie les utilisateurs non organisationnels (ou les processus exécutés en leur nom).

      Par le biais de la console : IAM -> Fournisseurs d'identité

[Retour à la Page d'accueil](/ReadMe.md)
