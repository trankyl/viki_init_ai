#### Retour en arrière

* [Aperçu du script](apercu_script.md)
* [Aperçu de l'architecture des Zones d'Accueil](architecture_za.md)
* [Aperçu des procédures de paramétrage](parametrage.md)
* [Page d'accueil](../Readme.md)

# Aperçu des étiquettes (*tags*) utilisées par le script

## Personnalisation des étiquettes (*tags*)

### Étiquettes d'abonnement

La hiéarchie des trois étiquettes "racine" (OrganisationClient, Environnement, Projet) qui est appliquée sur tous les abonnements est défini dans un fichier json. Le fichier qui contient ce code est [subscription-tags-assignment.yml](../azure-pipeline/config/variables/scenario-base/policy/builtin/policy-assignment/subscription-tags-assignment.yml) pour le scénario de base et [subscription-tags-assignment.yml](../azure-pipeline/config/variables/scenario-complexe/policy/builtin/policy-assignment/subscription-tags-assignment.yml) pour le scénario complexe. Les étendues de l'application des politiques pour mettre en place ces tags diffèrent d'une étiquette à l'autre en raison du contexte de ceux-ci.

| Étiquette         | Étendue (Scope) | Contexte | Example de valeur |
| ------------------ | ---- | ---- | ----|
| OrganisationClient |  Groupe de gestion racine  | Le nom de l'organisation du client qui sera sur toutes les abonnement | EnvironnementOrganisationnel-CEI
| Environnement      |  Groupe de gestion    | Environnement des abonnements sous ce groupe de gestion     | Production |
| Projet             |  Abonnement | À quel projet l'abonnement est-il dédié | Projet 123 |

### Étiquettes de ressource

Il y a trois groupes d'étiquettes par défaut, l'un pour la production, un pour l'environnement non-production et un pour dev/test. Ces groupe d'étiquettes sont mis autant sur les groupes de ressource que sur les ressources en soit.
Il faut savoir que les ressources vont toujours hérité de l'ensemble des étiquettes des groupe de ressources et que quatres de ces étiquettes sont obligatoires.

| Étiquette    | Valeurs possibles  |
| -------------- | ------ |
| Disponibilité | tropfaible, faible, modéré  |
| Intégrité       | tropfaible, faible, modéré |
| Confidentialité     | tropfaible, faible, modéré |
| Criticité | sensible, nonsensible |

Il est possible de personnaliser et d'ajouter des étiquettes aux ressources déployées par le script, s'il y a des besoins particuliers additionnels (Autres façon de grouper les ressources pour des rapports de facturation, par exemple)

Un nombre d'étiquettes prédéfinies est configuré par le script. Ces trois sous-ensemble d'étiquettes correspondant à 3 zones différentes en terme de disponibilité, intégrité, criticité, confidentialité.

#### Prod
  
| Étiquette | Valeur |
| --------- | --------- |
| Disponibilité   | modéré|
| Intégrité   | modéré |
| Confidentialité | modéré |
| Criticité | sensible |

#### Non-Prod
  
| Étiquette | Valeur |
| --------- | --------- |
| Disponibilité   | faible |
| Intégrité   | faible |
| Confidentialité  | faible |
| Criticité  | nonsensible |

#### Dev / Test / Acceptation

| Étiquette | Valeur |
| --------- | --------- |
| Disponibilité   | tropfaible |
| Intégrité   | tropfaible |
| Confidentialité   | tropfaible |
| Criticité   | nonsensible |

```yaml
  var-common-prod-rgtags: >
    {
      "Proprietaire": $(var-common-tags-nom-proprietaire),
      "NomDuSysteme": $(var-common-tags-nom-système),
      "Confidentialité": "modéré",
      "Criticité": "sensible",
      "Disponibilite": "modéré",
      "Intégrité": "modéré",
    }

  var-common-prodnonsensible-rgtags: >
    {
      "Proprietaire": $(var-common-tags-nom-proprietaire),
      "NomDuSysteme": $(var-common-tags-nom-système),
      "Confidentialité": "faible",
      "Criticité": "nonsensible",
      "Disponibilité": "faible",
      "Intégrité": "faible",
    }

  var-common-devtest-rgtags: >
    {
      "Proprietaire": $(var-common-tags-nom-proprietaire),
      "NomDuSysteme": $(var-common-tags-nom-système),
      "Confidentialité": "tresfaible",
      "Criticité": "nonsensible",
      "Disponibilité": "tresfaible",
      "Intégrité": "tresfaible",
    }
```

Les étiquettes sont appliquées respectivement sur les groupes de ressources et ressources déployées par les commandes "az deployment..." pour la plateforme sont ceux de production:

ex:
```yaml

var-platform-hub-rgtags: '$(var-common-prod-rgtags)'
var-platform-hub-rtags: '$(var-common-prod-rgtags)'
...
var-platform-gestion-rgtags: '$(var-common-prod-rgtags)'
var-platform-gestion-rtags: '$(var-common-prod-rgtags)'
...
var-platform-identite-rgtags: '$(var-common-prod-rgtags)'
var-platform-identite-rtags: '$(var-common-prod-rgtags)'
...
var-platform-perimetre-rgtags: '$(var-common-prod-rgtags)'
var-platform-perimetre-rtags: '$(var-common-prod-rgtags)'

```

Pour ceux des zone d'accueil, cela va dépendre du type de la zone
ex:
```yaml
  commonTags: $(var-common-prodnonsensible-rgtags)
```

Pour la personnalisation des paramètres spécifiques au déploiement, les étiquettes suivantes doivent être modifiées :

* Le nom du système (variable: var-common-tags-nom-système)
* Le courriel du "proprietaire" désigné par l'organisme (pour y recevoir des notifications) (variable : var-common-tags-nom-proprietaire)

Les deux variables sont à modifier dans le fichier cei-base-params.yml. Il faut respecter la syntaxe des guillemets, c'est-à-dire en inclure dans deux pairs, simple et double :

```yaml
  var-common-tags-nom-proprietaire: '"e-mail-du-proprietaire@du.syste.me"'
  var-common-tags-nom-système:  '"Votre-nom de OP"'
```

## Mise à jour des étiquettes pour la version 2.2

Si vous aviez déployé préalablement des zone d'accueil avec le script dans une version antérieur à 2.2, il sera néecessaire de nettoyer les politiques de tags qui ne sont plus utilisées, ajuster les tags existant sur les groupes de ressources et possiblement déclencher des tâches de remédiation sur l'ensemble des ressources.
Ceci peut se faire automatiquement par le billet de deux pipelines qui se chargent de faire la mise à jour

- [tags-cleanup.yml](../azure-pipeline/tools/tags-cleanup.yml)
- [tags-remediation.yml](../azure-pipeline/tools/tags-remediation.yml)

Liens rapides:

* [Architecture des zones d'accueil](architecture_za.md2)
* [Structure du script](structure_script.md)
* [Aperçu du paramétrage](parametrage.md)
