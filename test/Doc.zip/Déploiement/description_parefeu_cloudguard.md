# Le pare-feu réseau CheckPoint CloudGuard dans Oracle Cloud Infrastructure

Au menu

- [Description](#description)
- [Fonctions de sécurité](#fonctions-de-sécurité)
- [Modèle de tarification](#modèle-de-tarification)
- [Coût](#coût)
- [Déploiement cluster CheckPoint CloudGuard dans OCI](#déploiement-cluster-checkpoint-cloudguard-dans-oci)
    - [Mode de fonctionnement](#mode-de-fonctionnement)
    - [Topologie](#topologie)
    - [Déploiement du cluster CheckPoint CloudGuard](#déploiement-du-cluster-checkpoint-cloudguard)
- [Comparaison avec les pare-feux FortiGate et OCI](#comparaison-avec-les-pare-feux-fortigate-et-oci)
- [Glossaire sur le pare-feu CheckPoint CloudGuardI](#glossaire-sur-le-pare-feu-checkpoint-cloudguard)

## Description

Check Point CloudGuard offre une prévention avancée des menaces multicouches pour protéger les actifs des clients dans Oracle Cloud Infrastructure contre les logiciels malveillants et les menaces sophistiquées. CloudGuard for OCI vous permet de sécuriser facilement et de manière transparente vos charges de travail tout en fournissant une connectivité sécurisée dans vos environnements cloud et sur site.

Conçu pour répondre aux exigences de sécurité dynamique des déploiements cloud, CloudGuard fournit des protections avancées contre les menaces pour inspecter le trafic entrant et sortant des sous-réseaux privés des réseaux cloud publics, privés et hybrides des clients. Les fonctions de sécurité entièrement intégrées incluent : pare-feu, IPS, reconnaissance d’identité, contrôle des applications, VPN IPsec, antivirus, anti-bot et protection SandBlast Zero-Day.

Check Point CloudGuard pour Oracle Cloud Infrastructure offre une connectivité sécurisée et une prévention avancée des menaces afin de protéger les actifs de l'entreprise dans les Clouds hybrides et les Clouds publics Oracle. Conçu pour répondre aux besoins dynamiques des environnements dans le Cloud, CloudGuard complète les contrôles natifs d’Oracle Cloud Infrastructure pour protéger les environnements virtuels contre les menaces les plus sophistiquées, tout en assurant une administration cohérente de la politique de sécurité et son exécution sur les réseaux physiques et dans le Cloud.

---


Avec la solution CloudGuard, vous pouvez :


- Ouvrir et maintenir des tunnels VPN
- Inspecter les données lorsqu’elles entrent et sortent du sous-réseau privé
- Réseaux séparés dans un réseau virtuel infonuagique ( VCN )
- Protégez vos ressources dans un réseau virtuel infonuagique ( VCN ) avec les lames logicielles Check Point
- Gérez cette solution de manière centralisée à partir de votre déploiement Check Point Security Management Server existant


## Fonctions de sécurité

Les contrôles de sécurité  de CloudGuard comprennent les éléments suivants :


- Contrôles d’accès (pare-feu)
- Journalisation
- Contrôle des applications
- Prévention des intrusions (IPS)
- Prévention avancée des menaces (antivirus/anti-bot/SandBlast Zero-Day Protection)
- Réseau privé virtuel (VPN) de site à site pour la communication avec le réseau local
- VPN d’accès à distance pour la communication avec les utilisateurs itinérants
- Traduction d’adresses réseau (NAT) pour le trafic Internet


Les protections de sécurité entièrement intégrées comprennent :

- Le pare-feu, de prévention des intrusions (IPS), d’antivirus et d’antibot protègent les services
dans le cloud contre les accès non autorisés et empêche les attaques
- Le contrôle des applications et le filtrage d’URL permettent aux entreprises de créer facilement des politiques granulaires basées sur utilisateurs ou groupes pour identifier, bloquer ou limiter l’utilisation des applications et des sites Web
- Data Loss Prevention protège les données sensibles contre le vol ou la perte involontaire
- La technologie sandbox SandBlast Zero-Day Protection offre la protection la plus avancée contre
Logiciels malveillants et attaques zero-day

Référence : <https://www.checkpoint.com/downloads/products/cloudguard-oracle-cloud-solution-brief.pdf>

## Modèle de tarification

Plusieurs options de licence sont disponibles :

- Achetez une licence pour les passerelles de sécurité réseau CloudGuard Check Point : apportez votre propre licence (BYOL).
- Attribuer une licence à Security Management Server : achetez une licence Open Server.
- Licence Pay-as-you-Go via Oracle Cloud Marketplace pour les passerelles de sécurité et la gestion de la sécurité.

## Coût


- Check Point CloudGuard est disponible dans les modèles de licence BYOL (Bring Your Own License) et de paiement à l’utilisation (pay-as-you-go) pour Security Management et Security Gateways dans Oracle Cloud Marketplace.

- La licence Check Point CloudGuard Network Security Gateway est basée sur le nombre de vCPU (un OCPU équivaut à deux vCPU).

- Les licences Check Point BYOL sont portables entre les instances. Par exemple, si vous migrez des charges de travail
à partir d’autres clouds publics qui utilisent également des licences BYOL, vous n’avez pas besoin d’acheter de nouvelles licences auprès de Point de contrôle. Vérifiez auprès de votre représentant Check Point si vous avez des questions ou si vous avez besoin d’une vérification de votre statut de la licence.

- Check Point Security Management est concédé sous licence par passerelle de sécurité gérée. Par exemple, deux clusters
comptent quatre pour la licence Security Management.

Exemple de coût :


![tarification_cloudguard_firewall_1_ocpu_PayG](../images/cloudguard/marketplace/tarification_cloudguard_firewall_1_ocpu_PayG.png)

**Note** : Vous ne pouvez pas lancer l'offre pay-as-you-go si vous utilisez un compte d'évaluation gratuit. Pour lancer cette offre, effectuez une mise à niveau vers un compte cloud payant.*

## Déploiement cluster CheckPoint CloudGuard dans OCI

CheckPoint CloudGuard pour Oracle étend la sécurité avancée de prévention des menaces pour protéger les environnements OCI des clients contre les logiciels malveillants et autres menaces sophistiquées. En tant que solution certifiée Oracle, CloudGuard vous permet de sécuriser facilement et de manière transparente vos charges de travail, données et ressources tout en fournissant une connectivité sécurisée dans vos environnements cloud et sur site.

### Conditions préalables

Vous devez être famillier  avec les concepts, fonctionnalités et termes généraux d'Oracle, notamment :

- Réseaux cloud virtuels (VCN)
- Machines virtuelles (VM)
- vNIC primaire/secondaire
- Adresses IP publiques
- Adresses IP principales/secondaires privées
- Tables de routage
- Groupe dynamique
- Stratégie
- Gestion des identités et des accès du BEC


Pour la configuration dans Oracle Cloud, vous devez avoir des connaissances de base sur :

- Passerelles de sécurité CheckPoint et serveurs de gestion CheckPoint
- Infrastructure Oracle Cloud

### Mode de fonctionnement

Un cluster de deux instances CloudGuard est utilisé pour assurer la haute-disponibilité de la posture de sécurité.

Lorsqu'un membre actif du cluster échoue, le membre du cluster de secours devient actif et prend possession des ressources du cluster. Dans le cadre de ce processus, le membre :

- Associe les adresses IP secondaires privées et publiques du cluster attaché à la vNIC principale
- Associe chaque paire d'adresses IP publiques/privées secondaires attachées à la vNIC principale (pour chaque service publié)
- Associe l'adresse IP privée secondaire attachée à la vNIC secondaire.

### Topologie

![topologie_checkpoint](../images/cloudguard/topologie_checkpoint.png)

Référence : https://sc1.checkpoint.com/documents/IaaS/WebAdminGuides/EN/CP_CloudGuard_Network_for_Oracle_Cloud_Getting_Started/Content/Resources/Images/Images-for-Oracle-GS/1.png

Cet exemple d'environnement est utilisé pour expliquer les étapes de configuration. Lorsque vous suivez les étapes de configuration ci-dessus, veillez à remplacer les adresses IP dans l'exemple pour refléter votre environnement.

### Déploiement du cluster CheckPoint CloudGuard

Suivez ces instructions pour déployer la solution CloudGuard Cluster de Check Point dans Oracle. Effectuez les étapes à partir du portail Oracle dans le(s) compartiment(s) préféré(s).

- Connectez-vous à votre tenant OCI.
- Sélectionnez l'offre CheckPoint CloudGuard appropriée dans la place de marché Oracle Cloud Marketplace.
- Déployez le cluster de pare-feu dans votre réseau virtuel infonuagique ( VCN ).

Vous trouverez dans le guide  [deploy_manuel_cloudguard.md](deploy_manuel_cloudguard.md) , plus de détails pour un déploiement pas à pas.


## Comparaison avec les pare-feux FortiGate et OCI


| Critère | Pare-feu natif OCI | Pare-feu FortiGate | Pare-feu CloudGuard |
|------ | ------------- | -------------| -------------|
| Utiliser les groupes de sécurité réseau pour contrôler le trafic | Oui | Non | Non |
| Déploiement par ORM | Oui | Oui | Oui |
| Déploiement par Terraform CLI | Oui | Oui | Oui |
| Licence BYOL | Non | Oui | Oui |
| Consommation à l'heure | Oui | / | Oui |
| Possibilité d'arrêter le pare-feu sans le supprimer, puis de le redémarrer | Non | Oui | Oui |
| Déploiement dans le sous-réseau de votre choix | Oui | Oui | Oui |
| Possibilité d'affecter manuellement une adresse IP au pare-feu | Oui | Non | Oui |
| Module Terraform | Oui | Oui | Oui |
| Journalisation - Le pare-feu réseau est intégré à Oracle Cloud Infrastructure Logging | Oui | / | Non |
| Mesures - Le pare-feu réseau est intégré à Oracle Cloud Infrastructure Monitoring | Oui | / | Oui |


## Glossaire sur le pare-feu CheckPoint CloudGuard

| Concept | Description |
|------ | ------------- |
| CloudGuard Security Management | Une console unique de gestion de la sécurité qui offre une visibilité, une gestion des stratégies, une journalisation, des rapports et un contrôle cohérents sur tous les environnements et réseaux cloud |
| CloudGuard Network Security Gateways | autre nom donné au pare-feu CheckPoint CloudGuard |
| Proxy ARP | Un proxy ARP ou parfois mandataire ARP, est un serveur qui répond aux requêtes ARP émises sur un réseau IP concernant une ou plusieurs adresses IP qui ne sont pas présentes sur ce réseau. |


[Retour à la Page d'accueil](../../README.md "Retour à la page d'accueil")
