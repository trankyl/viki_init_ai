
# La liste de contrôles de Sécurité

>## La liste de contrôles de sécurité
>
>|        ID       |                                               Nom                                                                    |       Conforme         |    Tester       |
>|-----------------|----------------------------------------------------------------------------------------------------------------------|------------------------|---------------- |
>| AC-2            | Gestion de comptes                                                                                                   |           Oui          |      Oui        |
>| AC-2(1)         | Gestion automatisé de compte de système                                                                              |           Oui          |      Non        |
>| AC-3            | Application de l'accès                                                                                               |           Oui          |      Partiel    |
>| AC-4            | Application du controle du flux d'information                                                                        |           Oui          |      Non        |
>| AC-5            | Séparation des taches                                                                                                |           Oui          |      Partiel    |
>| AC-6            | Droit de l'accès minimal                                                                                             |           Oui          |      Non        |
>| AC-6(10)        | Interdiction aux utilisateurs non privililégiés d'exécuter des fonction privililégiés                                |           Oui          |      Non        |
>| AC-7            | Tentative d'ouverture session infructeuses :Verrouillage automatique du compte                                       |           Oui          |      Non        |
>| AC-9            | Avis d'ouverture de session précédente (Accès)                                                                       |           Oui          |      Partiel    |
>| AC-19           | Contrôle d'accès pour les dispositifs mobiles                                                                        |           Oui          |      Non        |
>| AC-20(3)        | Utilisation de systèmes d'information externes n'appatient pas à l'organisation                                      |           Oui          |      Partiel    |
>| AU-2            | Évènements vèrifiables                                                                                               |           Oui          |      Partiel    |
>| AU-3            | Contenu des enregitrements de vérification                                                                           |           Oui          |      Oui        |
>| AU-6            | Examen, analyse et rapports de vérification                                                                          |           Oui          |      Non        |
>| AU-8            | Estampilles temporelles                                                                                              |           Oui          |      Oui        |
>| AU-9            | Protection de l'information de vérification                                                                          |           Oui          |      Non        |
>| AU-9(4)         | Protection de l'information de vérification: Accès par un sous-ensemble d'utilisateurs privililégiés                 |           Oui          |      Non        |
>| AU-12           | Génération d'enregitrements de vérification                                                                          |           Oui          |      Non        |
>| CM-2            | Configuration de référence                                                                                           |           Oui          |      Oui        |
>| CM-3            | Contrôle des changements de configuration                                                                            |           Oui          |      Non        |
>| CM-4            | Analyse des répercussions sur la sécurité                                                                            |           Oui          |      Partiel    |
>| CM-5            | Restrictions d'accès concernant les changements                                                                      |           Oui          |      Non        |
>| CM-8            | Inventaire des composants de système d'information                                                                   |           Oui          |      Oui        |
>| IA-2            | Identification et authentification (Utilisateurs organisations)                                                      |           Oui          |      Oui        |
>| IA-2(1)         | Identification et authentification: Accès réseau aux comptes privililégiés                                           |           Oui          |      Non        |
>| IA-2(2)         | Le système d'information applique l'authentification multifactorielle pour l’accès réseau aux comptes non privilégiés|           Oui          |      Non        |
>| IA-2(11)        | Identification et authentification: Accès à distance - Dispositif distinct                                           |           Oui          |      Non        |
>| IA-4            | Gestion des identificateurs                                                                                          |           Oui          |      Non        |
>| IA-5            | Gestion des identificateurs                                                                                          |           Oui          |      Non        |
>| IA-5(1)         | Authentification fondée sur un mot de passe                                                                          |           Oui          |      Oui        |
>| IA-5(6)         | Protection des authentifiants                                                                                        |           Oui          |      Non        |
>| IA-6            | Réinjection d'authentification                                                                                       |           Oui          |      Non        |
>| IA-8            | Identification et authentification (Utilisateurs non organisatationels)                                              |           Oui          |      Non        |
>| SA-22           | Composants systèmes non pris en charge                                                                               |           NA           |      NA         |
>| SC-5            | Protection contre les dénis de service                                                                               |           Oui          |      Non        |
>| SC-7            | Protection de la frontière                                                                                           |           Oui          |      Non        |
>| SC-7(5)         |  Refus par défaut / Permission par exception                                                                         |           Oui          |      Non        |
>| SC-8            | Confidentialité et intégrité des transmissions                                                                       |           Oui          |      Oui        |
>| SC-8(1)         | Protection cryptographique ou physique                                                                               |           Oui          |      Non        |
>| SC-12           | Établissement et gestion des clés cryptographiques                                                                   |           Oui          |      Non        |
>| SC-13           | Protection cryptographique                                                                                           |           Oui          |      Non        |
>| SC-17           | Certificats d'infrastructure a clé publique                                                                          |           Oui          |      Non        |
>| SC-28           | Protection de l'information inactive                                                                                 |           Oui          |      Oui        |
>| SC-28(1)        | Protection cryptographique                                                                                           |           Oui          |      Non        |
>| SI-2            | Correction des défauts                                                                                               |           Oui          |      Non        |
>| SI-3            | Protection contre les codes malveillants                                                                             |           Oui          |      Non        |
>| SC-3(7)         | Détection non axée sur les signatures                                                                                |           Oui          |      Non        |
>| SC-4            | Survaillance des systèmes d'informtion                                                                               |           Oui          |      Non        |
