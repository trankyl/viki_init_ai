#### Retour en arrière

* [Étapes du déploiement](etapes_deploiement.md)
* [Mise en contexte](mise_en_contexte.md)
* [Page d'accueil](../Readme.md)

# Aperçu des Zones d'accueil

Une zone d'accueil (*Landing Zone* en anglais, dans la documentation du fournisseur) est un abonnement destiné à héberger des charges de travail.

## 1. Information sur les zones d'accueil

Une zone d'accueil est un abonnement destiné à héberger des charges de travail, avec des politiques de sécurité et permissions d'accès par rôle RBAC (*Role Based Access Control* en anglais). On va utiliser le terme "zone d'accueil" à la place d'abonnement pour ce type d'abonnements. Par contre, les abonnements dans lesquels on héberge des services communs de type "plateforme" ne sont pas considérés comme des zones d'accueil.

Les zones d'accueil et les abonnements de type "plateforme" sont en dessous d'une hiérarchie de groupes de gestion, ce qui fait en sorte que les politiques de sécurité et les permissions RBAC se propagent en aval et peuvent être définies de manière plus spécifique à chaque niveau dans cette hiérarchie. Pour le scénario de base, voici la hiérarchie :

![Hiérarchie des groupes de gestion et abonnements](images/architecture_zones_daccueil_base_800px.png)

Pour le scénario complexe, la hiérarchie est en effet plus "complexe" :

![architecture_zones_daccueil_complexe](images/Architecture-Landing-zones-complexe.jpg "Architecture zones d'accueil scénario complexe")

Le découpage des groupes de gestion et des zones d'accueil suit les principes d'architecture de solution et de sécurité recommandés par les fournisseurs:

* Une séparation des zones **Plateforme** (qui hébergent des services communs) des zones **Charges** (qui hébergent des charges de travail applicatives) et des zones de l'environnement d'**Expérimentation** et celle des charges **Décommissionnés**

  * Cette séparation suit un principe clé du cadre d'adoption de l'infonuagique.
  * Les stratégies et politiques de sécurité, les permissions RBAC et la gestion des budgets sont de natures différentes et permettent de mettre une barrière logique de sécurité, de budget et de permissions RBAC entre les applications.
  * Les zones d'accueil  **Plateforme** regroupent des ressources et services communs de base servant à administrer les ressources dans les zones d'accueil **Charges de travail**.
* Les zones d'accueil **Charges de travail** regroupent des charges de travail applicatives d'usage interne ou externe. La nature différente des charges de travail impose une séparation entre **Intranet** et **Services en ligne** :

  * Les zones d'accueil **Intranet** hébergent des charges de travail accessibles qu'à partir du réseau privé d’entreprise.
  * Les zones d'accueil **Services en ligne** hébergent des charges de travail accessibles de l'Internet, souvent des applications de prestation publique de services.
  * La séparation en paliers **Production**, **Acceptation** et **Développement** permettent d'appliquer des stratégies, politiques de sécurité et permissions RBAC plus strictes dans les environnements de Production que dans non-production.
* Les zones **Décommissionnées** permettent de séparer les charges de travail inactives des charges actives en appliquant des stratégies spécifiques (par exemple : empêcher que des ressources soient déployées).

À l'intérieur de chaque zone d'accueil, les scripts du CEI configurent par défaut un nombre de ressources, groupées dans des groupes de ressources.

En général, il s'agit de ressources non payantes comme des réseaux virtuels (VNet), préfixes réseau (*subnet*) et tables de routage.

L'<ins>**exception notable**</ins> est la zone d'accueil de "connectivité" dans laquelle, en fonction des paramètres de configuration, certains services sont payants.

Les zones d'accueil sont situées en dessous d'une hiérarchie de groupes de gestion où les politiques de sécurité et les permissions RBAC se propagent, d'en haut en bas à travers cette hiérarchie à plusieurs niveaux, en devenant de plus en plus spécifiques à chaque niveau et, ultimement, s'appliquant.

---

## 2. Aperçu de la hiérarchie des abonnements de type plateforme

Le découpage recommandé des abonnements de type "plateforme" suit les meilleures pratiques de séparation des rôles et politiques de sécurité associées des fournisseurs.


| Abonnement plateforme    | Groupes gestion parent   | Usage envisagé                                          |
| -------------------------------------------------------- | -------------------------- | ---------------------------------------------------------- |
| Abonnement Gestion       | Plateforme/Gestion       | Optionnelle : Surveillance,  autres                      |
| Abonnement Identité         | Plateforme/Identité     | Optionnelle : coffre-fort de clés, contrôleur domaine      |
| Abonnement Connectivité | Plateforme/Connectivité | Services C/F et connectivité réseau, coffre-fort de sauvegarde |

---

## 3. Aperçu de la hiérarchie des zones d'accueil

Les découpages des zones d'accueil "par défaut", déployées par les scripts en dessous du groupe de gestion "Charges", sont ciblés à des scénarios spécifiques et standardisés, basés sur les meilleures pratiques recommandées par le CEI, les fournisseurs et les besoins communs des organisations. Ces découpages peuvent quand même être personnalisés en fonction de besoins spécifiques en utilisant la paramétrisation des scripts CEI 2.2.

Pour les configurations qui correspondent aux scénarios prédéfinis, plusieurs abonnements dans les zones d'accueil de type "Charges" peuvent être créés en fonction des besoins spécifiques d'un organisme, via une paramétrisation "vanille" du script de déploiement. Le scénario "base" est prédéfini et pris en charge à ce jour.

### 3.1 Découpage hiérarchie zones d'accueil - scénario "base"

L'exemple dans le tableau ci-bas est pour le scénario "base" envisagé pour les organismes du REES. Ce scénario simplifie le découpage des zones d'accueil au minimum requis pour certaines catégories d'OP. Ce découpage est basé sur les meilleures pratiques recommandées par le CEI, les fournisseurs et les besoins communs des organisations.


| Zone d'accueil                     | Groupe d'administration parent  | Usage envisagé                                                                                                                                                                                                                                                                             |
| ------------------------------------------------------------------------ | --------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Abonnements données non sensibles | Charges/Production              | Applications et bases de données offrant accès à des données non sensibles (nature des données à déterminer à la suite des "analyses de préjudice"). À noter que même si une partie des données en jeu sont considérées sensibles, l'ensemble des données sera considéré sensible. |
| Abonnements données sensibles         | Charges/Production              | Applications et bases de données offrant accès à des données sensibles (nature des données à déterminer à la suite des "analyses de préjudice"). À noter que des politiques de sécurité plus strictes s'appliquent aux zones d'accueil qui contiennent des données sensibles.          |
| Abonnements non-production         | Charges/NonProduction           | Optionnelle: des environnements d'essais d'acceptation ou de développement                                                                                                                                                                                                                 |
| Décommissionnés/*                                                    | Organisme/Décommissionné      | Des charges de travail inactives / non utilisées à être retirées                                                                                                                                                                                                                          |
| Expérimentation/*                                                     | Racine(tenant)/Expérimentation | Des zones d'accueil non-production, par exemple pour le développement (carrés de sable) et preuves de concept                                                                                                                                                                                |
|                                    |                                 |                                                                                                                                                                                                                                                                                             |

Les organisations peuvent rajouter, consolider, renommer ou enlever certaines zones d'accueil selon leurs besoins en modifiant les [paramètres des scripts](parametres_configurables.md).

### 3.2 Découpage hiérarchie zones d'accueil - scénario "complexe"


| Zone d'accueil                                           | Groupe d'administration parent | Usage envisagé                                                                                                                                                                     |
| ---------------------------------------------------------- | -------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Abonnements Intranet (Prod, Acceptation et Dev)          | Charges/Intranet               | Applications 3-tiers de type transactionnel, sans exposition vers l'Internet                                                                                                        |
| Abonnements Services en Ligne (Prod, Acceptation et Dev) | Charges/ServicesenLigne        | Applications 3-tiers de type portail exposées sur Internet via un balanceur de charge, et/ou un pare-feu, et/ou des applications virtuelles optionnellement hébergées dans la zone elle-même. |
| Abonnements Bureautique (Prod, Acceptation et Dev)       | Charges/Bureautique            | Optionnel : des solutions de type VDI comme Azure AVD ou Citrix |
| Décommissionnés/*                                      | Organisme/Décommissionné     | Des charges de travail inactives / non utilisées, à être retirées.                                                                                                                  |
| Preuves deconcept/*                                      | Organisme/Expérimentation     | Des zones d'accueil non-production, par exemple pour des preuves de concept                                                                                                             |
| Carrés de sable/*                                       | Organisme/Expérimentation     | Des zones d'accueil non-production, par exemple pour du développement (carrés de sable) et des preuves de concept                                                                        |

Les organisations peuvent rajouter, consolider, renommer ou enlever certaines zones d'accueil selon leurs besoins spécifiques.

### 3.2 Assignation des abonnements zone d'accueil aux groupes d'administration

Pour les abonnements non-plateforme, les identificateurs doivent être fournis dans le paramètre var-managementgroup-subscriptions (un dictionnaire JSON) qui associe les abonnements avec les groupes de gestion au-dessus. Ce paramétrage des abonnements doit être fait en unisson avec la personnalisation de la hiérarchie et des noms des groupes de gestion dans var-managementgroup-hierarchy (un autre dictionnaire en format JSON). Les défauts fournis dans ces paramètres sont juste des exemples, au niveau des zones d'accueil en dessous de **Charges**. Un exemple montre la correspondance du nom du groupe de gestion parent "IntranetProduction" :


| var-managementgroup-subscriptions                                | var-managementgroup-hierarchy                                |
| ------------------------------------------------------------------ | -------------------------------------------------------------- |
| ![souscription](images/var-managementgroup-subscriptions_v2.PNG) | ![souscription](images/var-managementgroup-hierarchy_v2.PNG) |
|                                                                  |                                                              |
