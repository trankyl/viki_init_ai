import json
import os
import sys
from datetime import datetime

# Constantes
REPORT_DIR = sys.argv[2]
FILE_PATH_BEFORE = sys.argv[1] + 'deploymentData/dataBefore.json'
FILE_PATH_AFTER = sys.argv[1] + 'deploymentData/dataAfter.json'

# Données avant opération
file_before = open(FILE_PATH_BEFORE)
data_before = json.load(file_before)
resources_before = list(data_before['items'])

# Données après opération
file_after = open(FILE_PATH_AFTER)
data_after = json.load(file_after)
resources_after = list(data_after['items'])

# Tri des données pour supprimées, ajoutées, non changées
deleted = [x for x in resources_before if x not in resources_after]
added = [x for x in resources_after if x not in resources_before]
stayed = [x for x in resources_after if x in resources_before]

reportData = {
    "ressourcesNonChangees" : {
        "nombre" : len(stayed),
        "infos" : stayed
    },
    "ressourcesSupprimees" : {
        "nombre" : len(deleted),
        "infos" : deleted
    },
    "ressourcesAjoutees" : {
        "nombre" : len(added),
        "infos" : added
    }
}

# Si le fichier n'existe pas
if not os.path.exists(REPORT_DIR):
    os.makedirs(REPORT_DIR)

file_name = str(datetime.now().strftime("%Y-%m-%d-%H_%M_%S"))

# json file
with open(os.path.join(REPORT_DIR, file_name + ".json"), 'w') as fp:
    fp.write(json.dumps(reportData,indent=3))

# log file
with open(os.path.join(REPORT_DIR, file_name + ".txt"), 'w') as fp:
    fp.write("\nRapport de déploiement " + file_name + "\n------\n\n")
    fp.write("Ressources non changées : " + str(len(stayed)) + "\n" + str(list(map(lambda x: x["name"], stayed))) + "\n\n")
    fp.write("Ressources supprimées : " + str(len(deleted))  + "\n" + str(list(map(lambda x: x["name"],deleted))) + "\n\n")
    fp.write("Ressources ajoutées : " + str(len(added)) + "\n" + str(list(map(lambda x: x["name"],added))) + "\n\n")

os.system("cat " + REPORT_DIR + "/" + file_name + ".txt")

file_before.close()
file_after.close()