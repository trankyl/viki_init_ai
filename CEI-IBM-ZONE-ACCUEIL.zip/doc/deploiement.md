# Guide pas-à-pas de déploiement de la zone d'acceuil d'IBM

## Table des matières

1. [Aperçu](#aperçu)
2. [Prérequis](#prérequis)
    - [Création d'un compte IBM Cloud](#création-d'un-compte-ibm-cloud)
    - [Clé API d'IBM](#clé-api-d'ibm)
    - [Création de la clé SSH](#création-de-la-clé-ssh)
    - [Personnalisation du script de la zone d'acceuil](#personnalisation-du-script-de-za)
    - [Configuration additionnelle pour le déploiement de FortiGate HA](#configuration-additionnelle-pour-le-déploiement-de-fortigate-ha)
      - [Affectation de variable](#affectation-de-variable)
      - [Exigences de la clé API pour FortiGate HA](#exigences-de-la-clé-api-pour-fortigate-ha)
3. [Lancer le déploiement](#lancer-le-déploiement)
    - [Exécution de pipeline](#exécution-de-pipeline)
    - [Processus manuel](#processus-manuel)
## Aperçu

### Déploiement automatique

Afin de faciliter le déploiement de la zone d'accueil IBM, nous vous fournissons une solution de pipeline afin d'automatiser le processus de déploiement.
Le fichier de pipeline se trouve dans le répertoire [`pipeline_LZ_IBM/pipeline_v2.yaml`](../pipeline_LZ_IBM/pipeline_v2.yaml). 
> Cette solution automatisée fonctionne **seulement** avec le pipeline d'Azure DevOps.

### Déploiement manuel

Afin de prévoir un besoin éventuel pour un déploiement local sans utiliser le processus automatisé, nous vous proposons les instructions nécessaires pour déployer manuellement la zone d'acceuil à la fin de cette documentation.
> Il vous faut toujours suivre les instructions fournies dans la section [Prérequis](#prérequis).


### Diagramme de déploiement complet

Après un déploiement avec succès, vous aurez une zone d'accueil comme montré dans l'image :

![Image](./images/module_doc_imgs/vsi-with-extensions.png)

[Retour vers le haut](#table-des-matières)

## Prérequis

Quelques étapes de configurations sont nécessaires afin de préparer le script au déploiement en utilisant le processus automatisé. **Ces étapes sont importantes pour
assurer un bon déroulement du déploiement**.

### Création d'un compte IBM Cloud
>À faire seulement si vous ne possédez pas un compte d'IBM Cloud.

Vous pouvez suivre l'instruction [ici](https://cloud.ibm.com/docs/account?topic=account-account-getting-started#account-gs-createlite) pour créer un compte IBM Cloud.

Un guide d'initialisation de compte d'IBM Cloud est aussi [disponible](https://cloud.ibm.com/docs/account?topic=account-account-getting-started) et mis à votre disposition.

### Clé API d'IBM

Pour déployer les ressources dans votre compte d'IBM Cloud, vous devez créer une clé API. Un [guide officiel](https://cloud.ibm.com/docs/account?topic=account-userapikey#create_user_key) est aussi disponible pour consultation. 

> **Si vous voulez également déployer FortiGate-HA, veuillez lire la section [Exigences de la clé API pour Fortigate HA](#exigences-de-la-clé-api-pour-fortigate-ha) avant de continuer**.

Les instructions sont suivantes :

1. Connectez-vous à [Cloud IBM](https://cloud.ibm.com).
2. Aller à Gérer -> Accès (IAM).
3. Dans la barre latérale, aller à "Clés d'API".
4. Cliquer sur "Créer" pour créer une clé API.
5. Choisir un nom et une description que vous jugez appropriés. (Cela n'a pas d'importance du point de vue du déploiement).

![Image](images/cle-api-ibm.png)

6. Une clé API sera créée. **Il est impératif de prendre note de la clé API à ce moment-ci, car il ne sera pas possible de la récupérer ultérieurement sans en créer une nouvelle**.

[Retour vers le haut](#table-des-matières)

### Création de la clé SSH

Vous devez ensuite créer localement une clé SSH afin d'établir une connexion sécurisée pour le processus du déploiement.

1. Si vous êtes sous Windows, ouvrez une invite de commande. Si vous êtes sous Mac/Linux, ouvrez un terminal :
2. Entrez la commande suivante :
```bash
ssh-keygen -b 4096 -t rsa
```
3. Une paire de clés SSH (privée et publique) sera créée. 
   - **Pour les usagers Linux/Mac** : normalement, la paire de clés sera sauvegardée dans le dossier par défaut `~/.ssh`. L'outil de SSH vous indiquera
   aussi l'emplacement et le nom de la paire de clés générée.
   - **Pour les usagers Windows** : normalement, la paire de clés sera sauvegardée dans le dossier par défaut `C:\Users\<nom d'usager\.ssh`.
5. Veuillez copier la clé publique générée (Un fichier de clé publique a `.pub` comme extension de fichier). Voici **un exemple** d'une clé publique générée complète :
```
ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABgQDGxEfGfzl4J4JBv51C+4RHJLpqlfPjSOmLtLOheWshxxMzO8QiZjhDt/898cqlIwujF3Jn9QWZqMdk/sbUqKcOQ74IqsfvRqnK5o+tUsTA+QbNn4dKzHe5gpUSK2p9aHO2ix7h9yw6rcyvuyYItFdMeaOSOlsmmJMgAJ+5S3l2cyqTZ3i4ur9B6ofOc73KXvoKDtjywA1oAvCq123bECjezzF16OrlTRIjKsMUwN/xkhuPIBvgHIAUYpA1ILFDCZYOA6LHzh4oeM386Y76L04rGyA9bCFJaiGNjCpE3ZV4BdJXWOg0okwhp9qbAwuE1QdVf3/IIMZ8s6h1JHovdYbUVvQclxPvcIdVBpGm1aldUD6AgBDkpnPmUgS2/eOlQLRjv8kRQWDU06/cCqmc/9ePXtupqDNfFWGiuOKNMtl1q26SJT4NTfbSBFvckURwxvs8eC4H7ow+qZT+u6Nz80TJUHy5Nzt3F2LYFoRjoaWrNTqmGYZ6Oe8A1ivRtnZCtZ8= test@iMac
```
 6. Répétez le processus pour créer une autre paire de clés SSH en changeant le nom de fichier de ssh.

### Personnalisation du script de la zone d'accueil

> **Si vous voulez également déployer FortiGate HA, veuillez lire les instructions dans la section [Affectation de variable](#affectation-de-variable)**.

Maintenant, vous devez préparer les scripts de la zone d'accueil pour le déploiement. Certains changements doivent néanmoins être apportés, notamment en ce qui concerne l'intégration de la clé SSH.

1. Ouvrir le fichier [`override.json`](../terraform/00-landing-zone/patterns/vsi/override.json) se trouvant dans [`terraform/00-landing-zone/patterns/vsi`](../terraform/00-landing-zone/patterns/vsi) et le fichier [`terraform.tfvars`](../terraform/00-landing-zone/patterns/vsi/terraform.tfvars) se trouvant dans [`terraform/00-landing-zone/patterns/vsi`](../terraform/00-landing-zone/patterns/vsi).
2. Assurez-vous que la variable `prefix` se trouvant dans le fichier `terraform.tfvars` correspond bien au préfixe de ressources dans `override.json`.
    - Le préfixe d'une ressource, nommée par exemple `demo-slz-xxxx`, est `demo`.
    - Vous êtes libre de changer le nom de la ressource dans `override.json`, mais vous devez changer le préfixe dans `terraform.tfvars`.
3. Assurez-vous que la variable `override` dans `terraform.tfvars` égale à `true`.
4. Copier la clé SSH publique (comme indiqué à la fin) générée dans la section précédente dans la variable `ssh_public_key` dans `terraform.tfvars`.
5. Dans `override.json`, faire une recherche avec le mot de "ssh". Insérer la même clé SSH publique dans le champ `public_key`.
   - Nous avons deux environnements, une de « non-production » et l'autre « production ». (Chacun possède une variable `public_key`).
   
> **Afin de mieux gérer l’accès aux ressources, vous devez utiliser deux clés différentes pour ces deux environnements**.

[Retour vers le haut](#table-des-matières)

### Configuration additionnelle pour le déploiement de FortiGate HA

#### Exigences de la clé API pour FortiGate HA

1. Assurez-vous que votre groupe d'accès a bien un accès au service de _**VPC Infrastructure Services**_ comportant les rôles de _IP Spoofing Operator_ et de _Console Administrator_. Si vous n'êtes pas le propriétaire du compte, vous devez également assigner le rôle de _Responsable_ (sous-rubrique de _Accès au service_) et de _Administrator_ (sous-rubrique de _Accès à la plateforme_).

![Image](images/fortigate-rights.png)
  
#### Affectation de variable

Si vous voulez également déployer FortiGate HA, vous devez effectuer les étapes suivantes :

1. Ouvrir le fichier [`terraform.tfvars`](../terraform/21-fortigate-ha-multi/terraform.tfvars) dans [`terraform/21-fortigate-ha-multi`](../terraform/21-fortigate-ha-multi).
2. Pour la variable **`fortigate_allowed_cidrs`**, spécifier les adresses IP (format CIDR) qui sont autorisées à accéder à l'interface Web de FortiGate.
   - Si vous ne l'affectez pas, vous n'aurez pas d'accès aux serveurs de FortiGate à moins que vous mettiez manuellement à jour la liste de contrôle d'accès (*Access Control List*) et le groupe de sécurité (*Security Group*) pour permettre le trafic de TCP (Port 443) et optionnellement TCP (Port 22, ssh) et ICMP Type 8 (Ping).
3. Pour la variable **`fortigate_zone_subnet_cidrs`**, spécifier la ou les zones dans lesquelles vous souhaitez déployer l'instance de FortiGate. 
   - **Par défaut**, le script va déployer la paire de FortiGate dans les Zones 1 et 3 de la région choisie.


[Retour vers le haut](#table-des-matières)

## Lancer le déploiement

> Si vous optez pour l'option automatique, veuillez suivre les instructions dans la section suivante. Sinon, veuillez lire la section [processus manuel](#processus-manuel) pour déployer manuellement la zone d'accueil.

### Exécution de pipeline 

![Image](images/pipeline-variable.png)

Maintenant, vous êtes prêt pour lancer le processus de déploiement par le pipeline dans Azure DevOps.

1. Cliquer sur "Run Pipeline".
2. Azure vous demandera de vérifier les variables nécessaires pour exécuter le pipeline. Nous vous présentons ces variables :
   - `API Key for IBM Cloud`: Vous devez mettre la clé d'API que vous avez générée au début de ce guide.
   - `Terraform Command`
     - `apply` : Exécuter `terraform apply` pour déployer les ressources.
     - `destroy` : Exécuter `terraform destroy` pour détruire les ressources.
   - Trois cases sont à cocher selon votre besoin. Seuls les modules cochés seront déployés.
     - `Observability Services`
     - `Fortigate HA`
     - `Cloud Internet Services`
   - `User Running Pipeline`: Le nom d'utilisateur qui exécute le pipeline.
   - `Email of user running pipeline`: L'adresse courriel de l'utilisateur qui exécute le pipeline.
3. Après avoir rempli les cases et choisi les modules à déployer, cliquer sur "Run" pour lancer le pipeline. Le pipeline se chargera du reste en créant toutes les ressources nécessaires dans votre nuage IBM.
Cela pourrait prendre quelques minutes.
4. Vous pouvez ensuite vérifier, dans le journal de chaque travail/étape, le résultat d'exécution de `Terraform apply` ainsi que les informations pertinentes.


![Image](images/resultat-pipeline.png)

[Retour vers le haut](#table-des-matières)

### Processus manuel

> **Vous devez d'abord déployer la fondation de la zone d'accueil (`00-landing-zone`)**. Après, vous êtes libre de choisir parmi les trois modules supplémentaires : `10-observability`,`21-fortigate-ha-multi`,`30-cloudinternetsvcs`. 
#### Déploiement de la fondation de la zone d'accueil, de FortiGate ou des services Internet infonuagiques.

1. Naviguer dans le dossier [`terraform/00-landing-zone/patterns/vsi`](../terraform/00-landing-zone/patterns/vsi) pour la fondation de la zone d'acceuil, ou [`terraform/21-fortigate-ha-multi`](../terraform/21-fortigate-ha-multi) pour le FortiGate, ou [`terraform/30-cloudinternetsvcs`](../terraform/30-cloudinternetsvcs) pour les services Internet infonuagiques. 
2. Fournir la clé API d'IBM Cloud en tant que variable d'environnement (ex. : `export TF_VAR_ibmcloud_api_key="<votre clé API d'IBM Cloud>"`).
3. Exécuter `terraform init` pour initialiser le répertoire et la configuration.
4. Exécuter `terraform plan` pour prévoir les changements que Terraform compte effectuer dans votre infrastructure.
5. Exécuter `terraform apply` pour déployer ou modifier votre infrastructure.

#### Déploiement des services d'observabilité

1. Naviguer dans le dossier [`terraform/10-observability`](../terraform/10-observability).
2. Fournir la clé API d'IBM Cloud en tant que variable d'environnement (ex. : `export TF_VAR_ibmcloud_api_key="<votre clé API d'IBM Cloud>"`).
3. Fournir la variable `IBMCLOUD_ATRACKER_API_ENDPOINT`en tant que variable d'environnement (ex. : `export IBMCLOUD_ATRACKER_API_ENDPOINT="https://us-east.atracker.cloud.ibm.com"`).
3. Exécuter `terraform init` pour initialiser le répertoire et la configuration.
4. Exécuter `terraform plan` pour prévoir les changements que Terraform compte effectuer dans votre infrastructure.
5. Exécuter `terraform apply` pour déployer ou modifier votre infrastructure.

[Retour vers le haut](#table-des-matières)
