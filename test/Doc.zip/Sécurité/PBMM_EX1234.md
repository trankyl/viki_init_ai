# Contrôles de sécurité pour les exigences 1,2,3 et 4

Liste des contrôles pour les quatre exigences suivantes :

1. Protéger les comptes racines
2. Gérer les comptes ayant le privilège administrateur
3. Limiter les accès à la console du nuage
4. Définir les comptes de surveillance d’entreprise

Contrôles communs aux exigences 01 à 04 :

AC‑2, AC‑2(1), AC‑3, AC‑5, AC‑6, AC‑6(5), AC‑6(10), AC‑7, AC‑9, AC‑19, AC‑20(3), IA‑2, IA‑2(1), IA‑2(2), IA‑2(11), IA‑4, IA‑5, IA‑5(1), IA‑5(6), IA‑5(7), IA‑5(13), IA‑6, IA‑8.

## < --- Contrôle EX1234_AC-2--->

![EX123](../images/EX1234_AC-2.PNG)

## Validation Contrôle EX1234_AC-2

   1. Responsabilité fournisseur : Oui
   2. Commentaire : Le script déploie par défaut les groupes suivants : les administrateurs systèmes, les administrateurs de base de données, les administrateurs réseau, les administrateurs IAM, les conseillers et les auditeurs de sécurité, les administrateurs d'applications et les administrateurs cyberdéfense.
      Des stratégies (*policies*) sont attachées à chaque groupe pour les permissions d'accès.
   3. [Lien Document](https://docs.cloud.oracle.com/fr-ca/iaas/Content/Identity/Concepts/policysyntax.htm)

## < --- Contrôle EX1234_AC-2_1--->

![EX123](../images/EX1234_AC-2_1.PNG)

## Validation Contrôle EX1234_AC-2_1

   1. Responsabilité fournisseur : Oui
   2. Commentaire : Les ressources d'Oracle Cloud Infrastructure peuvent être gérées par la console, l'interface utilisateur basée sur le navigateur, mais d'une façon manuelle, il n'y a pas d'automatisation.
      Lorsque votre société s'inscrit à un compte Oracle et à un domaine d'identité, Oracle configure un administrateur par défaut pour le compte. Cette personne est le premier utilisateur du service GIA pour votre société.
   Elle est responsable de la configuration initiale des autres administrateurs. Votre location est fournie avec un groupe appelé Administrateurs. Par défaut, l'administrateur appartient automatiquement à ce groupe. Vous ne pouvez pas supprimer ce groupe; il doit toujours comprendre au moins un utilisateur.
   3. [Lien Document](https://docs.oracle.com/fr-ca/iaas/Content/Identity/getstarted/identity-domains.htm#The)
  
## < --- Contrôle EX1234_AC-3--->

![EX123](../images/EX1234_AC-3.PNG)

## Validation Contrôle EX1234_AC-3

   1. Responsabilité fournisseur : Oui
   2. Commentaire : Par défaut, Oracle OCI est une architecture de confiance zéro (*'Zero Trust'*). Les stratégies (*policies*) sont obligatoires pour la lecture et les modifications de toute ressource OCI.  Le contrôle consiste à vérifier si le script de la zone d'accueil (*landing zone*) a déployé des stratégies.
      Des stratégies sont attachées à chaque groupe pour restreindre les permissions et les autorisations d'accès.
      Par exemple, une stratégie est implémentée par défaut pour autoriser au groupe CEI02-grp-admincybde la lecture de la ressource Object-Storage "Allow group CEI02-grp-admincybdef to read objectstorage-namespaces in tenancy".
   3. [Lien Document](https://docs.oracle.com/fr-ca/iaas/Content/Identity/Concepts/policies.htm)

## < --- Contrôle EX1234_AC-5--->

![EX123](../images/EX1234_AC-5.PNG)

## Validation Contrôle EX1234_AC-5

   1. Responsabilité fournisseur : Oui
   2. Commentaire : Lorsque l'organisation ouvre un compte Oracle et un domaine d'identité, Oracle configure un administrateur par défaut pour le compte. Cette personne sera le premier utilisateur IAM de votre entreprise et sera responsable de la configuration initiale des administrateurs supplémentaires. La location est livrée avec un groupe appelé Administrateurs.
      L'OP doit minimiser le nombre d'utilisateurs ayant le privilège Admin.
      La création des groupes (les administateurs systèmes, les administrateurs de base de données, les administrateurs réseau, les administrateurs IAM, les conseillers et les auditeurs de sécurité, les administrateurs d'applications et les administrateurs cyberdéfense) a été déployée par défaut au niveau du script.
   3. [Lien Document](https://docs.oracle.com/fr-ca/iaas/Content/Identity/Concepts/overview.htm#T)
  
## < --- Contrôle EX1234_AC-6--->

![EX123](../images/EX1234_AC-6.PNG)

## Validation Contrôle EX1234_AC-6

   1. Responsabilité fournisseur : Oui
   2. Commentaire : La création des groupes (les administrateurs systèmes, les administrateurs de base de données, les administrateurs réseau, les administrateurs IAM, les conseillers et les auditeurs de sécurité, les administrateurs d'applications et les administrateurs cyberdéfense) a été déployée par défaut au niveau du script.
      Chaque OP doit respecter sa matrice d'accès logique toute en respectant le principe de moindre privilège.
   3. [Lien Document](https://docs.oracle.com/fr-ca/iaas/Content/Security/Reference/iam_security.htm#IAM_Users_and_Groups)

## < --- Contrôle EX1234_AC-6_5--->

![EX123](../images/EX1234_AC-6_5.PNG)

## Validation Contrôle EX1234_AC-6_5

   1. Responsabilité fournisseur : Oui
   2. Commentaire : L'OP doit s'assurer que chaque utilisateur appartient à un ou plusieurs groupes avec des déclarations de stratégie qui leur sont appliquées. À la création d'un nouvel utilisateur, celui-ci n'a accès à aucune ressource par défaut. Il s'agit d'une approche de confiance zéro (*zero trust*). Il faut donc explicitement l'ajouter à des groupes pour lui assigner des privilèges à des ressources.  
      Pour donner des accès, il faut ajouter cet utilisateur à un ou plusieurs groupes générés par le script de zone d'accueil.
   La gestion des comptes privilèges se fait par la console : **Identité & Sécurité -> Groups**.
      Les autorisations sur toutes les ressources sont accordées uniquement au groupe d'administrateurs de location. Dans le cas contraire, un écart sera soulevé lors de l'exécution du script de vérification de la conformité.
      CIS Section 1, CIS Recommendation 1.2
   3. [Lien Document](https://docs.oracle.com/fr-ca/iaas/Content/Identity/Concepts/policies.htm)

## < --- Contrôle EX1234_AC-6_10--->

![EX123](../images/EX1234_AC-6_10.PNG)

## Validation Contrôle EX1234_AC-6_10

   1. Responsabilité fournisseur : Oui
   2. Commentaire : OCI propose plusieurs stratégies qui limitent l'accès admin. Chaque OP a donc la responsabilité de gérer le privilège selon son besoin.
      À la création d'un nouvel utilisateur, celui-ci n'a accès à aucune ressource par défaut. Il s'agit d'une approche de confiance zéro (*zero trust*). Il faut donc explicitement l'ajouter à des groupes pour lui assigner des privilèges à des ressources. Il y a plusieurs groupes créés par le script de zone d'accueil qui segmente les tâches d'administration. Exemple : admin réseau, admin base de données, etc.  
      Il suffit d'ajouter les bons utilisateurs à ces groupes pour définir la façon dont votre location (*tenant*) sera gérée.  
   3. [Lien Document](https://docs.oracle.com/fr-ca/iaas/Content/Security/Reference/iam_security.htm#IAM_Users_and_Groups)

## < --- Contrôle EX1234_AC-7--->

![EX123](../images/EX1234_AC-7.PNG)

## Validation Contrôle EX1234_AC-7

   1. Responsabilité fournisseur : Oui
   2. Commentaire : Il y a une politique de gestion des mots de passe au niveau IDCS qui contrôle la complexité et le verrouillage automatique des accès. Vous pouvez définir plusieurs politiques ou personnaliser celle par défaut.
      La gestion de politique de mot de passe se fait par la console : **IDCS-->Setting-->Password Policy**
   3. [Lien Document](https://docs.oracle.com/en/cloud/paas/identity-cloud/uaids/understand-criteria-password-policies.html)

## < --- Contrôle EX1234_AC-9--->

![EX123](../images/EX1234_AC-9.PNG)

## Validation Contrôle EX1234_AC-9

   1. Responsabilité fournisseur : Non assigné

## < --- Contrôle EX1234_AC-19--->

![EX123](../images/EX1234_AC-19.PNG)

## Validation Contrôle EX1234_AC-19

   1. Responsabilité fournisseur : Oui
   2. Commentaire : Il est possible d'activer la sécurité adaptative qui ajoute une protection concernant les dispositifs mobiles. À noter que cette fonctionnalité entraîne des coûts additionnels.
      La vérification se fait par **IDCS --> Security --> Adaptive Security**.
   3. [Lien Document](https://docs.oracle.com/en/cloud/paas/identity-cloud/uaids/manage-adaptive-security-oracle-identity-cloud-service1.html)
  
## < --- Contrôle EX1234_AC-20_3--->

![EX123](../images/EX1234_AC-20_3.PNG)

## Validation Contrôle EX1234_AC-20_3

   1. Responsabilité fournisseur : Oui
   2. Commentaire : Il est possible d'activer la sécurité adaptative qui ajoute une protection concernant les dispositifs mobiles. À noter que cette fonctionnalité entraîne des coûts additionnels.
      La vérification se fait par **IDCS --> Security --> Adaptive Security**.
   3. [Lien Document](https://docs.oracle.com/en/cloud/paas/identity-cloud/uaids/manage-adaptive-security-oracle-identity-cloud-service1.html)

## < --- Contrôle EX1234_IA-2--->

![EX123](../images/EX1234_IA-2.PNG)

## Validation Contrôle EX1234_IA-2

   1. Responsabilité fournisseur : Oui
   2. Commentaire : Le service de gestion des identités et des accès (IAM) fournit des fonctions de gestion des identités et des accès tels que l'authentification, l'authentification unique (SSO) et la gestion du cycle de vie des identités. Tout utilisateur doit être enregistré à ce service comme prérequis à l'utilisation des ressources d'Oracle OCI. Toutes les actions des utilisateurs sont en permanence auditées dans OCI Audit. L'audit n'est pas altérable même par l'administrateur du locataire (*tenant*). Ce contrôle est géré par défaut au niveau de la zone d'accueil en passant par la création de groupes.
   Il faut explicitement ajouter les utilisateurs aux bons groupes.
   La gestion des utilisateurs se fait par **Identité & Sécurité --> Users**.
   3. [Lien Document](https://docs.oracle.com/fr-ca/iaas/Content/Identity/home1.htm)

## < --- Contrôle EX1234_IA-2_1--->

![EX123](../images/EX1234_IA2_1.PNG)

## Validation Contrôle EX1234_IA-2_1

   1. Responsabilité fournisseur : Oui
   2. Commentaire : Il suffit d'activer l'authentification multifacteur (MFA) au niveau IAM ou IDCS.
      Au niveau IAM : **Identité & Sécurité --> Users --> Enable Multi-Factor Authentication**
      Au niveau IDCS : **SECURITY --> MFA**
   3. [Lien Document](https://docs.oracle.com/fr-ca/iaas/Content/Identity/Tasks/usingmfa.htm)

## < --- Contrôle EX1234_IA-2_2--->

![EX123](../images/EX1234_IA-2_2.PNG)

## Validation Contrôle EX1234_IA-2_2

   1. Responsabilité fournisseur : Oui
   2. Commentaire : Il suffit d'activer l'authentification multifacteur (MFA) au niveau IAM ou IDCS.
      Au niveau IAM : **Identité & Sécurité --> Users --> Enable Multi-Factor Authentication**
      Au niveau IDCS : **SECURITY --> MFA**
   3. [Lien Document](https://docs.oracle.com/fr-ca/iaas/Content/Identity/Tasks/usingmfa.htm)

## < --- Contrôle EX1234_IA-2_11--->

![EX123](../images/ex1234_IA2-11.PNG)

## Validation Contrôle EX1234_IA-2_11

   1. Responsabilité fournisseur : Oui
   2. Commentaire : OCI prend en charge l'authentification multifactorielle. Chaque OP choisit la méthode selon son besoin.
      Pour renforcer la sécurité, il est recommandé d'ajouter cette stratégie : allow group … in ... where request.user.mfaTotpVerified='true'.
   3. [Lien Document](https://docs.oracle.com/fr-ca/iaas/Content/Identity/Tasks/usingmfa.htm#Working_with_MFA)

## < --- Contrôle EX1234_IA-4--->

![EX123](../images/EX1234_IA-4.PNG)

## Validation Contrôle EX1234_IA-4

   1. Responsabilité fournisseur : Oui
   2. Commentaire : IA-4A : Chaque utilisateur, groupe d’utilisateurs, stratégie, et la plupart des ressources infonuagiques, ont un identificateur unique appelé OCID.
      Les OCID sont générés automatiquement par le système. Il comporte des préfixes identifiant, entre autres, le type de ressource et un numéro généré par le système. Tous les OCID sont uniques. Les OCID ne peuvent pas être réutilisés. Les OCID sont détruits lorsque les utilisateurs, groupes d’utilisateurs ou n’importe quelle ressource infonuagique sont détruits.
      IA-4D : La plupart des types de ressources Oracle Cloud Infrastructure ont un ID unique attribué par Oracle appelé Oracle Cloud Identifier (OCID). Il est inclus dans les informations de la ressource à la fois dans la console et dans l'API.
      Cet identifiant est obligatoire et généré automatiquement par le système. Il n'est pas possible de le réutiliser ou de le saisir manuellement. La durée de vie des identifiants est reliée à la durée de vie des ressources OCI associées. Il n'y a pas de fin de vie automatique aux OCID.
      Par exemple, pour le compartiment  CEI02-audit-sch-bucket identifié par ocid1.bucket.oc1.ca-montreal-1.aaaaaaaa5zg3slixli3k2ozx3vrswajo4jjkn6nfyt2piyyore56bls3e6la.
      IA-4E : La gestion de mot de passe se fait par IDCS Console :**IDCS ->Setting->Password Policy -> Password Rules**.
   3. [Lien Document](https://docs.oracle.com/fr-ca/iaas/Content/General/Concepts/identifiers.htm)

## < --- Contrôle EX1234_IA-5--->

![EX123](../images/EX1234_IA-5.PNG)

## Validation Contrôle EX1234_IA-5

   1. Responsabilité fournisseur : Oui
   2. Commentaire : La gestion de mot de passe se fait par IDCS Console :**IDCS ->Setting->Password Policy -> Password Rules**.
   3. [Lien Document](https://docs.oracle.com/en/cloud/paas/identity-cloud/uaids/manage-oracle-identity-cloud-service-password-policies1.html)

## < --- Contrôle EX1234_IA-5_1--->

![EX123](../images/EX1234_IA-5_1.PNG)

## Validation Contrôle EX1234_IA-5_1

   1. FI Responsable : Oui
   2. Commentaire :  IA_5(1)a et IA_5(1)b : La politique de mot de passe par défaut est définie dans le service IAM ou IDCS. Pour le compte local, la politique de mot de passe est comme suit : la longueur minimale du mot de passe (en caractères) est 8 et il doit contenir au moins 1 caractère numérique, 1 caractère spécial, 1 caractère majuscule, 1 caractère minuscule.  
      Pour les comptes fédérés, la gestion de mot de passe se fait par IDCS Console :**IDCS-->Setting-->Password Policy**. Il est possible de changer le minimum pour 12 caractères ou plus et de forcer une complexité supérieure.
      IA_5(1)d : La durée de vie du mot de passe est personnalisable, la gestion de mot de passe se fait par IDCS Console :**IDCS-->Setting-->Password Policy**.
   IA_5(1)e : Le nombre de générations est personnalisable. La gestion de mot de passe se fait par IDCS Console :**IDCS-->Setting-->Password Policy**.
   3. [Lien Document](https://docs.oracle.com/en/cloud/paas/identity-cloud/uaids/manage-oracle-identity-cloud-service-password-policies1.html)

## < --- Contrôle EX1234_IA-5_6--->

![EX123](../images/EX1234_IA-5_6.PNG)

## Validation Contrôle EX1234_IA-5_6

   1. Responsabilité fournisseur : Oui
   2. Commentaire : OCI ne permet pas l'utilisation de nom d'utilisateur et de mot de passe codés en dur dans des scripts ou invocations d'API. Il faut obligatoirement utiliser des jetons chiffrés. Les OP doivent créer ces jetons.
      **Identité & Sécurité --> User--> nom utilisateur --> Auth Tokens**
   3. [Lien Document](https://docs.oracle.com/fr-ca/iaas/Content/Identity/Tasks/managingcompartments.htm#Working)

## < --- Contrôle EX1234_IA-5_7--->

![EX123](../images/EX1234_IA-5_7.PNG)

## Validation Contrôle EX1234_IA-5_7

   1. Responsabilité fournisseur : Oui
   2. Commentaire : OCI ne permet pas l'utilisation de nom d'utilisateur et de mot de passe codés en dur dans des scripts ou invocations d'API. Il faut obligatoirement utiliser des jetons chiffrés. Les OP doivent créer ces jetons.
      **Identité & Sécurité --> User--> nom utilisateur --> Auth Tokens**
   3. [Lien Document](https://docs.oracle.com/fr-ca/iaas/Content/Identity/Tasks/managingcredentials.htm#Working)

## < --- Contrôle EX1234_IA-5_13 --->

![EX123](../images/EX1234_IA-5_13.PNG)

## Validation Contrôle EX1234_IA-5_13

   1. Responsabilité fournisseur : Oui
   2. Commentaire : OCI ne permet pas l'utilisation de nom d'utilisateur et de mot de passe codés en dur dans des scripts ou invocations d'API. Il faut obligatoirement utiliser des jetons chiffrés. Les OP doivent créer ces jetons.
      **Identité & Sécurité --> User--> nom utilisateur --> Auth Tokens**
   3. [Lien Document](https://docs.oracle.com/fr-ca/iaas/Content/Identity/Tasks/managingcredentials.htm#Working)
  
## < --- Contrôle EX1234_IA-6 --->

![EX123](../images/EX1234_IA-6.PNG)

## Validation Contrôle EX1234_IA-6

   1. Responsabilité fournisseur : Sans objet

## < --- Contrôle EX1234_IA-8 --->

![EX123](../images/EX1234_IA-8.PNG)

## Validation Contrôle EX1234_IA-8

   1. Responsabilité fournisseur : Oui
   2. Commentaire : L'OP peut utiliser des groupes spécifiques pour isoler certains utilisateurs non organisationnels à travers **Identité & Sécurité->Groups**.
   3. [Lien Document](https://docs.oracle.com/fr-fr/iaas/Content/Identity/users/about-managing-users.htm)

[Retour à la liste des exigences](OCI_12_exigences.md)
