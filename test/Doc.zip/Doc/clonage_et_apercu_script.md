# Clonage et prise de connaissance du script

**Sommaire**

* [Prérequis](#prerequis "Prérequis pour le déploiement de la Zone Accueil Azure")
* [Configuration dans Azure DevOps](#ConfigurationDansAzureDevOps "Configuration dans Azure DevOps")
* [Clonage du dépôt source du CEI](#ClonageImportationDuDepotSourceDuCEI "Clonage-Importation du dépôt source du CEI")
* [Aperçu structure du script](#ApercuStructureDuScript "Prise de connaissance du contenu du script")
* [Accueil](../README.md "Retour à la page d'accueil")

---

## <a id="prerequis" ></a>1. Prérequis

### 1.1. Prérequis dans Azure DevOps

Azure DevOps fournit des services de développement pour permettre aux équipes de planifier le travail, de collaborer sur le développement de code, de créer et de déployer des applications. Le CEI a fait le choix d'utiliser Azure DevOps afin de partager facilement ses travaux avec sa clientèle.

* Avoir une [organisation dans Azure DevOps](https://docs.microsoft.com/fr-ca/azure/devops/organizations/accounts/create-organization?view=azure-devops) et un [référentiel](https://docs.microsoft.com/fr-fr/azure/devops/repos/git/create-new-repo?view=azure-devops) de type Azure DevOps pour la gestion et le partage du code source et l'exécution des pipelines CI/CD.
* Respecter les [conditions préalables](https://docs.microsoft.com/fr-ca/azure/devops/repos/git/import-git-repository?view=azure-devops#prerequisites) pour créer ou importer un dépôt dans Azure DevOps de votre organisation.
* L'utilisateur, qui crée un pipeline, doit avoir le rôle d'[Administrateur du projet Azure DevOps](https://docs.microsoft.com/fr-fr/azure/devops/organizations/security/look-up-project-administrators?view=azure-devops&tabs=preview-page).
* Afin de bénéficier d'un [travail parallèle hébergé par Microsoft](https://docs.microsoft.com/fr-ca/azure/devops/pipelines/licensing/concurrent-jobs?view=azure-devops&tabs=ms-hosted), vous devez remplir le [formulaire de demande](https://aka.ms/azpipelines-parallelism-request).
  Par contre, si vous ne le faites pas, vous devez assigner un abonnement pour acheter des travaux parallèles et être membre du ```groupe Administrateurs de collection de projets``` ou être ```propriétaire de l’organisation```.

### 1.2. Prérequis pour la création d'une connexion de service

Pour effectivement créer une connexion de service Azure Resource Manager (ARM), vous devez respecter les contraintes suivantes :

* L'utilisateur en cours doit avoir le rôle [Administrateur général](https://docs.microsoft.com/fr-fr/azure/active-directory/roles/manage-roles-portal#assign-a-role) dans Azure Active Directory.
* L'utilisateur en cours doit avoir le rôle [Propriétaire](https://docs.microsoft.com/fr-ca/azure/role-based-access-control/role-assignments-portal?tabs=current) dans l'abonnement Azure.

### 1.3. Prérequis pour le clonage-importation du référentiel privé du CEI

* Pour utiliser ce script, vous devez présenter une demande au chargé de projet du Programme de consolidation des CTI (PCCTI) afin d'obtenir les droits d’accès au référentiel de gestion du code source du CEI.
* Pour créer ou importer un dépôt, vous devez être membre du groupe de sécurité [Administrateurs de projet](https://docs.microsoft.com/fr-fr/azure/devops/organizations/security/look-up-project-administrators?view=azure-devops&tabs=preview-page) ou disposer de l’autorisation **Créer** au niveau du projet Git défini sur [Autoriser](https://docs.microsoft.com/fr-ca/azure/devops/repos/git/set-git-repository-permissions?view=azure-devops).

---

## <a id="ConfigurationDansAzureDevOps" ></a>2. Configuration dans Azure DevOps

### 2.1 Création d’une connexion de service automatique pour ARM dans Azure DevOps

Vous pouvez créer le service connexion comme suit :

1. À partir de votre navigateur Web, ouvrir le projet d’équipe de votre organisation Azure DevOps.
2. Dans votre projet, sélectionner ```Paramètres du projet```, puis ```Connexions de service```.

![Svceprinipal.png](images\Svceprinipal.png "Vue Connexions de service")

3. Cliquer sur ```Nouvelle connexion de service``` pour ajouter une nouvelle connexion de service. Puis, dans la fenêtre ```Nouvelle connexion de service``` , sélectionner ```Azure Resource Manager```. Cliquer sur ```Suivant``` lorsque vous avez terminé.

![typeconnexion](images\typeconnexion.png "Liste des types de connexions de service")

3. Sélectionner ```Principal de service (automatique)```, puis cliquer sur le bouton ```Suivant```.

![nouveausvceconn](images\nouveausvceconn.png)

4. Sélectionner ```Groupe d'administration```, puis sélectionner le groupe d'administration racine (*root*) dans la liste déroulante.
5. Saisir le nom de la connexion de service.
6. Saisir éventuellement une description sur la connexion de service.
7. Cliquer sur ```Enregistrer``` lorsque vous avez terminé.

### 2.2 Création d’un environnement

Un environnement est une collection de ressources, où nous allons déployer l'infrastructure de la zone d'accueil Azure à partir d’un pipeline. L'environnement peut contenir une ou plusieurs machines virtuelles, conteneurs, applications Web ou tout service utilisé pour héberger la zone d'accueil Azure.

Vous devez créer un environnement en suivant les étapes ci-dessous :

1. Vous connecter à votre organisation : https://dev.azure.com/{yourorganization}, puis sélectionner votre projet.
2. Sélectionner ```Pipelines``` , puis ```Environments``` et cliquer sur le bouton ```Créer un environnement```.

La fenêtre contextuelle **```Nouvel environnement```** s'affiche.

3. Dans le champ ```Name``` , saisir ```main```.

*N.B.* :

Le nom de l'environnement doit correspondre au nom de la branche dans votre dépot.
Par défaut, le dépôt du CEI vient avec la branche *main*. Si vous migrez le script dans une autre branche (Ex. : *bacasable*), votre environnement devra se nommer *bacasable*.

4. Dans le champ ```Description``` , saisir la description de l'environnement.
5. Dans le champ ```Ressource``` , cliquer  ```Aucun```.
6. Cliquer sur le bouton  ```Créer```.

![createnewenvironment.png](images/createnewenvironment.png)

---

## <a id="ClonageImportationDuDepotSourceDuCEI" ></a>3. Clonage-Importation du dépôt source du CEI

Voici l’URL du dépôt source du CEI que vous devez importer.

[https://dev.azure.com/ccticei/Migration/_git/CEI-Azure-Zone-Accueil](https://dev.azure.com/ccticei/Migration/_git/CEI-Azure-Zone-Accueil)

Suivre les étapes suivantes pour importer le dépôt du CEI dans un nouveau dépôt.

1. À partir de votre navigateur Web, ouvrir le projet d’équipe de votre organisation Azure DevOps.
2. Puis, sélectionner ```Dépôts``` et cliquer sur ```Fichiers```  pour ouvrir la vue **Fichiers**.

![reposfiles.png](images/reposfiles.png)

La  page Web **```Fichiers```** s'affiche.

3. Dans la vue **```Fichiers```** , aller dans la liste déroulante du dépôt et sélectionner la ligne ```Importer le référentiel```.

![importrepository.png](images/importrepository.png)

La fenêtre contextuelle **```Import a Git repository```** s'affiche.

4. Sélectionner ```Git``` dans la liste déroulante ```Source type```.

![importrepodialog.png](images/importrepodialog.png)

5. Dans le champ obligatoire ```Clone URL``` , saisir l'[URL de clonage du référentiel source du CEI](https://ccticei@dev.azure.com/ccticei/Migration/_git/CEI-Azure-Zone-Accueil).
6. Dans le champ obligatoire ```Nom``` , saisir le nom de votre nouveau référentiel Git.
7. Cocher ```Nécessite une autorisation``` afin d'entrer vos informations d’identification au dépôt source du CEI.

Il faut à présent récupérer les informations d’identification du dépôt source du CEI.

7. À partir d'**un autre navigateur Web**, ouvrir le [référentiel source du CEI](https://dev.azure.com/ccticei/Migration/_git/CEI-Azure-Zone-Accueil).

![clonagedepotsourcecei.png](images/clonagedepotsourcecei.png)

8. Cliquer ensuite sur le bouton ```Clone```.

La fenêtre contextuelle **```Clone a repository```** s'affiche.

![clonerepodialog.png](images/clonerepodialog.png)

9. S'assurer que ```Ligne de commande``` est positionnée sur ```HTTPS``` et cliquer sur le bouton ```Générer les informations d'identification Git```.

![credentialclonerepo.png](images/credentialclonerepo.png)

Le système affiche le nom d’utilisateur et le mot de passe ou le jeton d’accès personnel (PAT).

10. Copier le nom utilisateur dans le champ ```Nom utilisateur``` dans le premier navigateur Web qui affiche le dépôt cible de l'importation.
11. Copier le mot de passe ou le jeton d’accès personnel dans le champ ```Mot de passe / Jeton d’accès personnel``` dans le premier navigateur Web qui affiche le dépôt cible de l'importation.

![importrepodialog.png](images/importrepodialog2.png)

12. Enfin, cliquer sur le bouton ```Importer```.

Attendre quelques secondes, puis actualiser le navigateur Web afin de visualiser l'arborescence de scripts importée.

---

## <a id="ApercuStructureDuScript" ></a>4. Aperçu structure du script

Pour vous aider à comprendre plus rapidement la structure du référentiel, voici un aperçu des fichiers et dossiers dans le script importé.

Le script de déploiement v2 contient plusieurs éléments dont une petite partie prend en charge le paramétrage.

#### 4.1. Structure du script V2.2


| Répertoire / sous-répertoire | Utilisation                                                                                                                                                                                                                                                                                                                 |
| -------------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| **azure-pipeline**             | Contient les « pipelines » de premier niveau - des fichiers .yml qu'il faut rouler en ordre dans Azure DevOps pour le déploiement. Voir la section[pipelines](#LesPipelines) pour plus de détails.                                                                                                                      |
| */config/variables*            | En dessous de azure-pipeline, le sous-répertoire config/variables contient les fichiers de[paramétrage](parametrage_deploiements.md) communs, ainsi que des sous-répertoires spécifiques par scénario.                                                                                                                 |
| */templates*                   | En dessous de azure-pipeline, le sous-répertoire templates contient des modules .yml (*templates*) pour les déploiements « Plateforme » et « Zones d'accueil », appelés dans les pipelines de 1er niveau. Rien à configurer/paramétrer pour cet aspect.                                                            |
| **Doc**                        | Contient les modules documentaires markdown inclus par le Readme.md de 1er niveau.                                                                                                                                                                                                                                          |
| **Images**                     | Contient les images incluses dans la documentation par le biais des liens dans les documents markdown.                                                                                                                                                                                                                      |
| **hub-and-spokes**             | Contient les scripts Bicep en charge du déploiement des abonnements et ressources « Plateforme » (*hub*) ainsi que les scripts Bicep de déploiement des abonnements et ressources « zone d'accueil » (*spoke*). Ces scripts font référence à des « modules » Bicep. Rien à configurer/paramétrer de ce côté. |
| **module**                     | Contient les modules Bicep pour le déploiement des ressources Azure. Rien à configurer/paramétrer sur ce point.                                                                                                                                                                                                          |
| **scripts**                    | Contient des scripts PowerShell utilisés par le pipeline*wipe-tenant* pour effacer les ressources créées par un déploiement avant de redéployer. Rien à configurer/paramétrer sur ce point.                                                                                                                          |
| **test-scenarios**             | Contient des scripts Bicep utilisés pour des essais unitaires après un déploiement. Rien à configurer/paramétrer sur ce point.                                                                                                                                                                                         |

---

### <a id="LesPipelines"></a>4.2. Les pipelines

Les pipelines sont des scripts .yml dans le langage spécifique de domaine (DSL) de Azure Devops.


| Pipeline                 | Ordre | Description                                                                                                                                                                                                                                                                                                                                    |
| -------------------------- | ------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| management-groups.yml    | 1     | Premier pipeline à rouler. Crée la hiérarchie de groupes d'administration selon le fichier paramétrage « hierarchie.yml » dans chaque sous-répertoire de paramétrage « par scénario » en dessous du répertoire**azure-pipeline**/config/variables.                                                                                 |
| assign-subscriptions.yml | 2     | Associe les abonnements (créés préalablement) de type « Plateforme » et « Zone d'accueil » aux groupes d'administration correspondants, selon la hiérarchie des groupes d'administration et abonnements dans chaque sous-répertoire de paramétrage « par scénario » en dessous du répertoire**azure-pipeline**/config/variables. |
| platform.yml             | 3     | Déploie les ressources et les services activés (comme vnet, pare-feu, balancement de charge, passerelle réseau virtuel) dans les abonnements « Plateforme », puis déploie Azure Defender for Cloud dans chacun des abonnements Plateforme.                                                                                               |
| landingzones.yml         | 4     | Déploie les ressources, les services activés (comme vnet, routage, groupes de sécurité réseau) et Azure Defender for Cloud dans les abonnements « Zone d'accueil ».                                                                                                                                                                     |
| policy.yml               | 5     | Déploie les stratégies de sécurité essentielles, groupées dans des « initiatives », au niveau du groupe d'administration, au sommet. Ces stratégies (*policies*) peuvent être renchéries au niveau des zones d'accueil selon les pratiques en vigueur chez les OP.                                                                   |
| rbac.yml                 | 6     | Associe les permissions (rôles) prédéfinies aux groupes d'usagers dont les identificateurs sont spécifiés par le biais de la paramétrisation.                                                                                                                                                                                            |
|                          |       |                                                                                                                                                                                                                                                                                                                                                |

Il y a aussi d'autre pipelines de type "Outil" soit

- [wipe-tenant.yml](../azure-pipeline/tools/wipe-tenant.yml "Pipeline de nettoyage") : sert à détruire les ressources créées lors d'un déploiement avant de redéployer. Il est à noter que les groupes d'administration doivent être enlevés manuellement.
- [tags-cleanup.yml](../azure-pipeline/tools/tags-cleanup.yml "Pipeline de nettoyage d'étiquette pré version 2.2") : sert à détruire les politiques plus utilisés en lien avec les tags (assignments et definitions). Ajuste aussi les tags courant vers nouveaux tags.
- [tags-remediation.yml](../azure-pipeline/tools/tags-remediation.yml "Pipeline de nettoyage") : crée un ensemble de tâche de remédiation sur tout ce qui a trait aux étiquettes.
  
---

### 4.3. Le paramétrage

Les fichiers de paramétrage se trouvent en dessous du sous-répertoire **config/variables** du répertoire azure-pipeline. Il y a des fichiers de paramétrage communs (non spécifiques à un scénario de déploiement) et des fichiers de paramétrage spécifiques « par scénario » en dessous des sous-répertoires dont les noms correspondent aux scénarios.

Le choix d'un scénario de déploiement se fait en indiquant le fichier de paramétrage « racine » d'un scénario dans le fichier [common.yml](../azure-pipeline/config/variables/common.yml "paramétrage commun").

Les usagers n'ont pas besoin de modifier les fichiers de paramétrage communs, à moins que ce ne soit dans des cas d'usage « avancés » où il faut bien maîtriser les procédures et les fonctionnalités en jeu.

Suivre le lien pour le détail des [paramètres et procédures de paramétrage](parametrage_deploiements.md).

#### 4.3.1 Fichiers de paramétrage communs


| Fichier paramétrage         | Cas d'usage      | Description                                                                                                                                                                                                                                                                                                                                                               |
| ------------------------------ | ------------------ | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| common.yml               | par déploiement | Spécifie le scénario de déploiement et d'autres paramètres à ajuster pour chaque déploiement.                                                                                                                                                                                                                                                                       |
| cei-platform.yml             | usage avancé    | Définit les paramètres des ressources et services à déployer dans les abonnements plateforme, basé sur des paramètres « par scénario ».                                                                                                                                                                                                                          |
| cei-perimetre.yml            | usage avancé    | Définit les paramètres des ressources et services à déployer dans l'abonnement périmètre.                                                                                                                                                                                                                                                                           |
| cei-tpl-landingzone.yml      | usage avancé    | Définit les plages d'adresse à provisionner dans les VNet des zones d'accueil, selon le paramétrage « par scénario ». À modifier au cas où on veut enlever ou rajouter des sous-réseaux dans ces VNet.                                                                                                                                                           |
| cei-tpl-lzvars.yml               | usage avancé    | Définit les tables de routage, groupes de sécurité réseau (NSG) et attributs des sous-réseaux dans les VNet des zones d'accueil. À modifier au cas où on veut enlever ou rajouter des sous-réseaux dans ces VNet ou en modifier les attributs, modifier des tables de routage ou des règles de sécurité réseau.                                               |
| cei-rbac.yml                 | usage avancé    | Définit les associations entre les groupes d'usagers et leurs permissions (rôles) spécifiques. Les groupes d'usagers ainsi que les rôles à leur assigner doivent être définis préalablement. Voir la section [RBAC](rbac.md) pour plus de détails.                                                                                                                |
| cei-tags.yml                 | usage avancé    | Définit les étiquettes (*tags*) à appliquer sur les ressources créées par le déploiement. Les noms des étiquettes, étant utilisés « tels quels » dans les scripts, ne doivent pas être modifiés. Voir la section [Tags](tags.md) pour plus de détails. |
| cei-assign-subscriptions.yml | usage avancé    | Un pipeline qui déploie l'association des abonnements aux groupes d'administration, comme définis dans le paramétrage « par scénario ». Aucun changement n'est requis.                                                                                                                                                                                              |

#### 4.3.2 Fichiers de paramétrage par scénario - scénario « base »

Ces fichiers se trouvent dans le sous-répertoire /scenario-base en dessous de /config/variables.


| Fichier paramétrage       | Utilisation      | Description                                                                                                                                                                                                                                                                                                               |
| ---------------------------- | ------------------ | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| cei-base-param.yml         | par déploiement | On trouve ici les paramètres qui varient d'un déploiement à l'autre. Voir les liens[Paramétrage des déploiements](parametrage_deploiements.md) et [Paramétrage par scénario](parametrage_scenarios.md).                                                                                                            |
| cei-base-defender.yml      | usage avancé    | On trouve ici les paramètres pour la configuration (liste de diffusion, espace de travail LogAnalytics dédiée à la sécurité, plan P1, plan P2) de Azure Defender for Cloud dans un abonnement.                                                                                                                      |
| cei-base-hierarchie.yml    | usage avancé    | On trouve ici la hiérarchie des groupes de gestion, l'assignation des abonnements « Plateforme » et « Zone d'accueil » et l'assignation d'un plan Azure Defender par groupe d'administration. En général, pas besoin de modifier à moins qu'on rajoute ou élimine des zones d'accueil ou abonnements plateforme. |
| cei-base-jb-vm.yml         | usage avancé    | Contient la configuration des machines virtuelles*jumpbox* dans les périphériques (*spokes*) gestion et identité.                                                                                                                                                                                                      |
| cei-base-lz.yml            | usage avancé    | On trouve ici le plan d'adressage pour les zones d'accueil. À ne pas modifier à moins de situations spéciales, si on veut changer les sous-réseaux.                                                                                                                                                                   |
| cei-base-main.yml          | usage avancé    | Ce fichier est référencé dans[common.yml](../azure-pipeline/config/variables/common.yml "paramétrage commun") (dans /config/vars) et inclut en tant que gabarits (*templates*) les autres fichiers de configuration. À ne pas modifier à moins d'un besoin de changements majeurs des scripts.                      |
| cei-base-routage.yml       | usage avancé    | Définit les tables de routage pour la communication entre les périphériques (*spokes*), avec Internet et les environnements sur site (*on-prem*) par le biais des liens VPN / ExpressRoute.                                                                                                                            |
| cei-base-subscriptions.yml | usage avancé    | Utilisé pour l'assignation des abonnements aux groupes de gestion. À changer si on rajoute ou enlève des zones d'accueil.                                                                                                                                                                                              |
| cei-base-vm-param.yml      | usage avancé    | Définit des configurations pour machine virtuelle (SKU, interface réseau, taille disque dur, système d'exploitation et sa version).                                                                                                                                                                                    |

Un scénario « complexe » est fourni dans **/scenario-complexe** en dessous de /config/variables, pour faciliter des déploiements plus élaborés.

#### 4.3.3 Fichiers de paramétrage par scénario - scénario « complexe »

Ces fichiers se trouvent dans le sous-répertoire /scenario-complexe en dessous de /config/variables.


| Fichier de paramétrage        | Utilisation      | Description                                                                                                                                                                                                                                                                                                               |
| -------------------------------- | ------------------ | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| cei-complexe-param.yml         | par déploiement | On trouve ici les paramètres qui varient d'un déploiement à l'autre. Voir les liens[Paramétrage des déploiements](parametrage_deploiements.md) et [Paramétrage par scénario](parametrage_scenarios.md).                                                                                                            |
| cei-complexe-defender.yml      | usage avancé    | On trouve ici les paramètres pour la configuration (liste de diffusion, espace de travail LogAnalytics dédiée à la sécurité, plan P1, plan P2) de Azure Defender for Cloud dans un abonnement.                                                                                                                      |
| cei-complexe-hierarchie.yml    | usage avancé    | On trouve ici la hiérarchie des groupes de gestion, l'assignation des abonnements « Plateforme » et « Zone d'accueil » et l'assignation d'un plan Azure Defender par groupe d'administration. En général, pas besoin de modifier à moins qu'on rajoute ou élimine des zones d'accueil ou abonnements plateforme. |
| cei-complexe-jb-vm.yml         | usage avancé    | Contient la configuration des machines virtuelles*jumpbox* dans les périphériques (*spokes*) gestion et identité.                                                                                                                                                                                                      |
| cei-complexe-lz.yml            | usage avancé    | On trouve ici le plan d'adressage pour les zones d'accueil. À ne pas modifier à moins de situations spéciales, si on veut changer les sous-réseaux.                                                                                                                                                                   |
| cei-complexe-main.yml          | usage avancé    | Ce fichier est référencé dans[common.yml](../azure-pipeline/config/variables/common.yml "paramétrage commun") (dans /config/vars) et inclut en tant que gabarits (*templates*) les autres fichiers de configuration. À ne pas modifier à moins d'un besoin de changements majeurs des scripts.                      |
| cei-complexe-routage.yml       | usage avancé    | Définit les tables de routage pour la communication entre les périphériques (*spokes*), avec Internet et avec les environnements sur site (*on-prem*) par le biais des liens VPN / ExpressRoute.                                                                                                                       |
| cei-complexe-subscriptions.yml | usage avancé    | Utilisé pour l'assignation des abonnements aux groupes de gestion. À changer si on rajoute ou enlève des zones d'accueil.                                                                                                                                                                                              |
| cei-complexe-vm-param.yml      | usage avancé    | Définit des configurations pour machine virtuelle (SKU, interface réseau, taille disque dur, système d'exploitation et sa version).                                                                                                                                                                                    |

Ce scénario « complexe », fourni dans **/scenario-complexe** en dessous de /config/variables, facilite des déploiements plus élaborés à l'échelle entreprise.

---

Étapes suivantes :

* [Paramétrage et exécution du script](parametrage_deploiements.md "Paramétrage du déploiement de la Zone Accueil Azure et exécution des pipelines")
* [Accueil](../README.md "Retour à la page d'accueil")
