<<<<<<< HEAD
# Déploiement

# Table des matières

1. [Prérequis]()
2. [Début]()
3. 
4.
5.
=======
# Déploiement de ZA Google

## Sommaire

Ce repo se sert à créer une zone d'accueil qui conforme à PBMM.

Afin de satisfaire aux prérequis pour déployer les configurations de Terraform:

- Un environnement de Shell où Terraform, jq et GCloud SDK peuvent être tous installés
- Un Google Cloud Platform Organization, où l'administrateur exécutant le code a le droit de "Organizational Admin"
- Utilise le lien suivant pour cloner automatiquement ce repo publique au directoire *cloudshell_open* dans shell.cloud.google.com

[![Open this project in Google Cloud Shell](http://gstatic.com/cloudssh/images/open-btn.png)](https://console.cloud.google.com/cloudshell/open?git_repo=https://github.com/GoogleCloudPlatform/pbmm-on-gcp-onboarding&page=editor&tutorial=README.md)

## Prérequis

### Installation

Le script de Bootstrap s'écrit pour linux de distribution commune. Il requis que les outils suivant soient installés:

- GCloud SDK
- JQ (pour enquêtes JSON)
- Terraform >= 1.0

[Installer GCloud](https://cloud.google.com/sdk/docs/install#linux)

[Télécharger Terraform](https://www.terraform.io/downloads.html)

Installer jq (Plupart de distribution de linux vient avec)
```
sudo apt-get install jq -q -y 
```

Déplacer Terraform à un endroit utilisable dans PATH, souvent comme suivant:

```
VER=1.0.11
curl https://releases.hashicorp.com/terraform/$VER/terraform_$VER_linux_amd64.zip --output terraform_$VER_linux_amd64.zip
unzip terraform_$VER_llinux_amd64.zip
sudo cp ./terraform /usr/bin
sudo chmod +x /usr/bin/terraform
```

### Environnement Cloud

Le bootstrap présume que votre compte Google a le droit d'administrateur organisationel dans l'organisation ciblé de GCP

Quelques commandes simples de gcloud pour vérifier si vous avez les permissions:

En utilisant un environnement authentifié de gcloud sdk:
```
# Prints the active account
gcloud config list account --format "value(core.account)"

# What domain and what user?
DOMAIN=google.com
EMAIL=youremail@example.com
# or this: EMAIL=$(gcloud config list account --format "value(core.account)")

# Get the Org ID for IAM policy query
ORG_ID=$(gcloud organizations list --filter="DISPLAY_NAME:$DOMAIN" --format="value(ID)")

# search for the email in the IAM policy
gcloud organizations get-iam-policy $ORG_ID --filter="bindings.role:roles/resourcemanager.organizationAdmin" --format="value(bindings.members)" | grep $EMAIL
```

## Using the Bootstrap Script

### Veuillez lire l'avertissement suivant

Le script boostrap devrait être exécuté par **un utilisateur ayant des privilèges élevées, une seule fois sans interruption, avec l'utilisation de la convention permanente de nommage**

Les raisons sont:
- Les permission pour ledit utilisateur sont temporaires, changer utilisateurs avant les taches d'automations exécute les opérations interdit l'accès à ce processus aux autres utilisateurs
- Accomplir ce processus sans interruption permet à tous les utilisateurs de contribuer à régler des problèmes dans l'environnement en contribuant du code.
- *Project_Ids* sont globalement consistents à travers du plateforme de Google Cloud. Les projects prennent 7 jours pour être supprimés, et ne libéreront pas le nom unique avant qu'ils soient entièrement supprimés

### Prérequis
0. Exécute la commande suivant pour autoriser et mettre en place le projet boostrap
```
gcloud config set project <project_id>
```
1. Exécute *writeids.sh* dans le dossier racin pour remplacer/un-reamplcer les IDs de votre organisation/facture/dossier dans tous les *tfvars* suivants entre 2-4 par (REPLACE_WITH_BILLING_ID, REPLACE_FOLDER_ID, REPLACE_ORGANIZATION_ID)
```
replace (fill b=billing, o=organization, f=folder)
./writeids.sh -c fill -b 1111-2222-3333 -o 444455559999 -f 012345678901
with project/billing/organization derived from the current default project
- note: when using multiple billing accounts - the billing account currently associated with the project will be used - use the above command to specify a different account or reassociate a different billing account to the project 

./writeids.sh -c fill -f 012345678901

revert (unfill)
./writeids.sh -c unfill -b 1111-2222-3333 -o 444455559999 -f 012345678901
```
2. Mettre à jour `environments/bootstrap/organization-config.auto.tfvars` et `environments/bootstrap/bootstrap.auto.tfvars`avec les valeurs de configuration pour votre environnement
3. Mettre à jour `environments/common/common.auto.tfvars` avec les valeurs qui seront partagées entre les environnements de production et non-production
4. Dans les directoires de `environments/nonprod` et `environments/prod`, configurer tous les fichiers de vairable qui terminement par *.auto.tfvars pour la configuration de l'environnement
5. Incrémenter le quota de votre facture/projet au-delà de 5 et 8 (les valeurs par défaut). Il y aura 7 nouveaux projets qui seront créées. Donc, le quota de 8 projets doit être incrémenté jusqu'à 20 si vous avez des autres projets. Le deuxième quota à incrémenter est le quota d'association de facture/projet - la valeur par défaut est 5 par compte facturable. Voir l'exemple suivant où le quota a été incrémenté de 5 à 20 dans 3 minutes en séléctionnant "paid services" dans [l'enquête de quota](https://support.google.com/code/contact/billing_quota_increase). L'exemple détaillé est [ici](https://github.com/GoogleCloudPlatform/pbmm-on-gcp-onboarding/issues/97#issuecomment-1168703512)

## Déployer la zone d'accueil

Après avoir satisfait tous les pré-requis, depuis bash - exécute `bootstrap.sh` se trouvant dans `environments/bootstrap/`
```
cd environments/bootstrap
./bootstrap.sh run
```

Le script va demander d'entrer le domaine et l'utilisateur qui va déployer les ressources de bootstrap et lance les commandes de gcloud et terraform

À la fin du script, le courriel et le nom d'utilisateur de votre utilisateur git seront demandés - vous pouvez utiliser quoi que ce soit y compris les détails de votre github dans ce CSR

Initiallement, les 4 tâches de cloud build seront exécutées (boostrap, common, nonprod, prod) - ils seront échoués tel qu'attendu jusqu'à ce que *bootstrap* et *common* soient exécutés en séquence avant nonprod et prod.

Afin d'assurer un build bien en séquence pour la premières fois et d'utiliser le fil CSR/Cloud-build - modifie n'importe quel fichier*auto.tfvars* (un CR ou espace) dans bootstrap, common, non-prod et prod en séquence jusqu'à ce que tous les builds soient verts.

<img width="1422" alt="Screen Shot 2022-06-28 at 8 52 51 AM" src="https://user-images.githubusercontent.com/94715080/176244607-bda70b5b-4834-4381-8c44-59e56953e456.png">

<img width="1340" alt="Screen Shot 2022-06-28 at 8 56 04 AM" src="https://user-images.githubusercontent.com/94715080/176244541-79aa8822-b0bb-4162-8a23-2230d39c0348.png">

<img width="1770" alt="Screen Shot 2022-06-28 at 10 25 30 AM" src="https://user-images.githubusercontent.com/94715080/176244299-22ced347-e8d5-4e3b-b5ed-7d8efb02c52f.png">

À ce stade, la zone d'accueil est bien mis en place et prête. Des changemens normales comme une re-configuration de pare-feu lancera un build appropiré via un commit/push de CSR
At this point the landing zone is up and ready and any normal changes like a firewall change will trigger the appropriate build via a CSR commit/push.

