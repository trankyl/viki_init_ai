# Contrôles de sécurité pour l'exigence 6

06: Protéger les données au repos

Contrôles liés à l'exigence 06 :
 SC-12, SC-13, SC-17,SC-28, SC-28(1)

## < --- Contrôle EX6_SC-12--->

![EX6](image/SC12.PNG)

## Première Validation

   1. Responsabilité du fournisseur : Oui
   2. Commentaire : Établissement et gestion des clé cryptographiques. La zone d'accueil utilise un serveur KMS pour la gestion des clés. Les données au repos sont chiffrées par une clé de chiffrement symétrique.
      Par le biais de la console : KMS  ->  Customer managed key ou KMS  ->  AWS managed key

## < --- Contrôle EX6_SC-13--->

![EX6](image/SC13.PNG)

## Deuxième Validation

   1. Responsabilité du fournisseur
   2. Commentaire : Protection cryptographique. La zone d'accueil utilise le service KMS pour la gestion des clés.
Les données au repos et en transit sont chiffrées. La partie définie par l'organisation devra être gérée par l'organisation.
      Par le biais de la console : KMS  ->  Customer managed key ou KMS  ->  AWS managed key

## < --- Contrôle EX6_SC-17--->

![EX6](image/SC17.PNG)

## Troisième Validation

   1. Responsabilité du fournisseur : Oui
   2. Commentaire : Certificats d'infrastructure à clé publique. Les clés de chiffrement peuvent être créées, importées, supprimées et gérées à partir d'AWS Management Console.
Le service AWS Certificate Manager permet de se procurer, de gérer et de déployer des certificats.
      Par le biais de la console : KMS  ->  Customer managed key ou KMS  ->  AWS managed key

## < --- Contrôle EX6_SC-28--->

![EX6](image/SC28.PNG)  

## Quatrième Validation

   1. Responsabilité du fournisseur : Oui
   2. Commentaire : Le système d’information protège la confidentialité et l’intégrité de l’information inactive désignée par l’organisation.
      Par le biais de la console : KMS  ->  Customer managed key ou KMS  ->  AWS managed key

## < --- Contrôle EX6_SC28(1)--->

![EX6](image/SC28-1.PNG)  

## Cinquième Validation

   1. Responsabilité du fournisseur : Oui
   2. Commentaire : Les organisations mettent en œuvre des mécanismes cryptographiques visant à prévenir la divulgation et la modification non autorisées des informations désignées par l’organisation.
      Par le biais de la console : KMS  ->  Customer managed key ou KMS  ->  AWS managed key

[Retour à la Page d'accueil](/ReadMe.md)
