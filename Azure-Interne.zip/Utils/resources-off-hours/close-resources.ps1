param(
    [string]$filtersString,
    [bool]$removeResourcesBas,
    [bool]$removeResourcesVpng
)

# Fonction permettant de voir si un string contient au moins une valeur dans une liste
function containsArrayValue{
    param([string]$sentence,[array]$values)

    foreach($value in $values){
        if($sentence -like ("*$value*")){
            return $true;
        }
    }
    return $false;
}
$countFermees = 0
$countSupprimees = 0

echo "##[section]Fermeture des ressources pour tous les abonnements filtrés"
echo "---------"
echo " "
$filters = $filtersString.Split(" ")
$allSubscriptions = Get-AzSubscription | where{containsArrayValue $_.Name $filters -and $_.State -ne 'Disabled'}
foreach($sub in $allSubscriptions){
    echo "Parcours de l'abonnement $($sub.name)"
    Set-AzContext -Subscription $($sub.id) | Out-Null
    $rgNames = Get-AzResourceGroup | % {$_.ResourceGroupName}
    foreach($rgName in $rgNames){


        if($removeResourcesBas -or $removeResourcesVpng){
            #Azure Bastion (Remove)
            if($removeResourcesBas){
                $bastions = Get-AzBastion -ResourceGroupName $rgName
                $countSupprimees = $countSupprimees + $bastions.count
                if($bastions){
                    echo " "
                    echo "##[warning] Arrêt de AzBastion"
                    echo "##[group] Suppression des agents AzBastion de $($sub.name) pour $($rgName) : "
                    $bastions.name
                    echo "##[endgroup]"
                    echo " "
                    $bastions | Remove-AzBastion -Force
                }
            }
            #Virtual Network Gateway (Remove)
            if($removeResourcesVpng){
                $vnGws = Get-AzVirtualNetworkGateway -ResourceGroupName $rgName
                $countSupprimees = $countSupprimees + $vnGws.count
                if($vnGws){
                    echo " "
                    echo "##[warning] Arrêt de VnGw"
                    echo "##[group] Suppression des VN Gateways de $($sub.name) pour $($rgName) : "
                    $vnGws.name
                    echo "##[endgroup]"
                    echo " "
                    $vnGws | Remove-AzVirtualNetworkGateway -Force
                }
            }

            $countSupprimees = $countSupprimees + $bastions.count + $vnGws.count


        #Vms
        $vmsStatuses = Get-AzVm -ResourceGroupName $rgName -WarningAction:SilentlyContinue -Status | where{$_.PowerState.contains("running")}
        if($vmsStatuses){
            echo " "
            echo "##[warning] Arrêt de VMs"
            echo "##[group]Arrêt des VMS de $($sub.name) pour $($rgName) : "
            $vmsStatuses.name
            echo "##[endgroup]"
            echo " "
            foreach($vmStatus in $vmsStatuses){
                Stop-AzVm -ResourceGroupName $rgName -Name $vmStatus.Name -Force
            }
        }
        #Firewalls (deallocate)
        $fws = Get-AzFirewall -ResourceGroupName $rgName
        if($fws){
            echo " "
            echo "##[warning] Arrêt de AzFw"
            echo "##[group]Deallocation des AzFirewall de $($sub.name) pour $($rgName) : "
            foreach($fw in $fws) {
                echo "$($fw.Name)"
                $fw.Deallocate()
                $fw | Set-AzFirewall
            }
            echo "##[endgroup]"
            echo " "
        }
        #Application Gateway (Stop)
        $agws = Get-AzApplicationGateway -ResourceGroupName $rgName | Where { $_.OperationalState -eq "Running" }
        if($agws){
            echo " "
            echo "##[warning] Arrêt de AGW"
            echo "##[group]Arrêt des AGW de $($sub.name) pour $($rgName) : "
            $agws.name
            echo "##[endgroup]"
            echo " "
            $agws | Stop-AzApplicationGateway
        }
        $countFermees = $countFermees + $vmsStatuses.count + $fws.count + $agws.count
        }
    }
}
echo "$countFermees ressources fermées (VMs, Firewalls ou Application Gateways)"
echo "$countSupprimees ressources supprimées (Azure Bastion ou VN Gateways)"