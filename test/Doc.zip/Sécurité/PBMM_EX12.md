# Contrôles de sécurité pour l'exigence minimale 12

12 : Restreindre les accès aux produits de la place de marché infonuagique

Contrôles liés à l'exigences 12 : CM-2, CM-3, CM-4, CM-5, CM-8

## < --- Contrôle EX12_CM-2--->

![EX11](../images/ex11_CM-2.PNG)

## Validation Contrôle EX12_CM-2

   1. Responsabilité fournisseur : Oui
   2. Commentaire : Le script de zone d'accueil met en place une architecture de référence. Tous les changements de configuration au locataire (*tenant*) créent automatiquement un enregistrement dans OCI Audit. Par le biais d'OIC Audit, il est possible de visualiser et de rechercher ces enregistrements. Des notifications sont également disponibles par OCI Notifications. Il est possible de s'abonner à un ou plusieurs sujets (*'topic'*) du service de notifications.
   3. [Lien Document](https://docs.oracle.com/en-us/iaas/Content/Audit/home.htm)

## < --- Contrôle EX12_CM-3--->

![EX11](../images/ex11_CM-3.PNG)

## Validation Contrôle EX12_CM-3

   1. Responsabilité fournisseur : Oui
   2. Commentaire : Les changements de configuration au locataire (*tenant*) crée automatiquement un enregistrement dans OCI Audit. Par le biais d'OIC Audit, il est possible de visualiser et de rechercher ces enregistrements. Des notifications sont également disponibles par OCI Notifications. Il est possible de s'abonner à un ou plusieurs sujets (*'topic'*) du service de notifications.

   3. [Lien Document](https://docs.oracle.com/en-us/iaas/Content/Audit/home.htm)

## < --- Contrôle EX12_CM-4--->

![EX11](../images/ex11_CM-4.PNG)

## Validation Contrôle EX12_CM-4

   1. Responsabilité fournisseur : Oui
   2. Commentaire : La journalisation des changements de configuration peut être consultée par Oracle Cloud Guard ou OIC Audit. Si les changements ont été effectués avec Terraform, il est alors possible de consulter les journaux des tâches Terraform et d'utiliser la fonctionnalité *'drift detection'*.

   Identité & Sécurité --> Cloud Guard -->  Filters (Detector type = IAAS - Activity Detector et Detector type = IAAS - Configuration Detector)
      
   Observability & Management-->Audit (Request action types= POST, PUT, PATCH)
      
   Developer Services-->Resource Manager-->Stacks --> Stack details : run drift detection

   3. [Lien Document](https://docs.oracle.com/en-us/iaas/releasenotes/changes/7023f3dc-fb23-4ebe-bc9d-691845db50e8/)

## < --- Contrôle EX12_CM5--->

![EX11](../images/ex11_CM-5.PNG)

## Validation Contrôle EX12_CM5

   1. Responsabilité fournisseur : Oui
   2. Commentaire : Les changements de configuration ne peuvent être effectués que par les utilisateurs OCI associés aux bons groupes et stratégies (*policies*) créés par le script de zone d'accueil. Il est possible de rendre les changements de configuration plus difficiles par l'utilisation de Security Zones.  
   Identity and Security -->Groups
   Identity and Security -->Politiques
   Identity and Security -->Security Zones
   3. [Lien Document](https://docs.oracle.com/en-us/iaas/Content/Identity/Concepts/policygetstarted.htm)

## < --- Contrôle EX12_CM-8--->

![EX11](../images/ex11_CM-8.PNG)

## Validation Contrôle EX12_CM-8

   1. Responsabilité fournisseur : Oui
   2. Commentaire : OCI fournit le service Tenancy Explorer qui permet de lister toutes les ressources.
    Au niveau de la zone d'accueil, CEIZA-02 fournit un inventaire sur les compartiments, le gestionnaire de ressources (*Resources Manager*), les stratégies (*policies), la DRG Route Table, la DRG Route Distribution et la passerelle de routage dynamique (DRG).
   3. [Lien Document](https://docs.oracle.com/en-us/iaas/Content/General/Concepts/compartmentexplorer.htm)

[Retour à la liste des exigences](OCI_12_exigences.md)
