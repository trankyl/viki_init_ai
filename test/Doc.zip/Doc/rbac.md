#### Retour en arrière

* [Aperçu du script](apercu_script.md)
* [Aperçu de l'architecture des Zones d'Accueil](architecture_za.md)
* [Aperçu des procédures de paramétrage](parametrage.md)
* [Paramétrage du déploiement](parametrage_deploiements.md)
* [Page d'accueil](../Readme.md)

## Personnalisation du contrôle d'accès par rôle (RBAC) pour les groupes prédéfinis d'usagers

Par défaut, le script v2.2 considère cinq groupes d'usagers, dont les ID sont définis dans le fichier de paramétrisation (par exemple cei-base-param.yml).

L'assignation des rôles aux groupes d'usagers se trouve dans la variable **var-rbac-custom-roles-assignements** dans le fichier nommé **cei-rbac.yml** situé dans le dossier **azure-pipeline -> config -> variables**.

**IMPORTANT** : il ne faut pas changer le nom des variables (en bleu), seulement les valeurs (en orange) :

La première variable liste les groupes d'administration sur lesquels les rôles personnalisés seront appliqués; par défaut, les rôles sont appliqués au niveau du groupe de la racine du locataire (*Tenant Root Group*) :

```yaml
  var-rbac-assignable-scopes: >
    [
      "/providers/Microsoft.Management/managementGroups/'$(var-tenantId)'"
    ]
```

</br>

Pour changer le champ d'application à partir duquel les rôles seront appliqués, il suffit de remplacer `'$(var-tenantId)'` par l'ID d'un groupe d'administration. En voici deux exemples :

- Pour déployer à partir du niveau de l'organisation

  ```yaml
  var-rbac-assignable-scopes: >
      [
      "/providers/Microsoft.Management/managementGroups/'$(var-organisation-id)'"
      ]
  ```
- Pour déployer à partir du niveau "Plateforme"

  ```yaml
  var-rbac-assignable-scopes: >
      [
      "/providers/Microsoft.Management/managementGroups/Plateforme"
      ]
  ```

</br>

Si vous avez déjà déployé les groupes d'administration, vous pouvez trouver l'ID de chacun d'eux par le biais du portail en allant sur **Overview** dans la page **Management Groups** ou en passant par Azure CLI avec la commande :

```bash
az account management-group list
```

<br>

Dans la variable **var-rbac-custom-roles-assignements** par défaut, les rôles sont assignés au niveau de l'organisation. Pour modifier le champ d'application, changer la valeur de `scopeId` par l'ID du groupe d'administration ciblé. Ou encore, vous pouvez également changer le type du champ d'application pour un abonnement au lieu d'un groupe d'administration. Dans ce cas, changer la valeur du `type` pour `"subscription"` et le `scopeId` par l'ID de l'abonnement :

```yaml
  var-rbac-custom-roles-assignements: >
    [
      {
        "scopeId": "'$(var-organisation-id)'",
        "type": "managementGroup",
        "roles": [
          {
            "principalid": "'$(var-principal-id-role-netops)'",
            "rolename": "NetOps"
          },
          {
            "principalid": "'$(var-principal-id-role-secops)'",
            "rolename": "SecOps"
          },
          {
            "principalid": "'$(var-principal-id-role-subscr-owner)'",
            "rolename": "SubscriptionOwner"
          },
          {
            "principalid": "'$(var-principal-id-role-devops)'",
            "rolename": "DevOps"
          },
          {
            "principalid": "'$(var-principal-id-role-appops)'",
            "rolename": "AppOps"
          }
        ]
      }
    ]
  
  # exemple pour un scope = subscription
  # {
  #   "scopeId": "'$(var-platform-hub-subscriptionId)'",
  #   "type": "subscription",
  #   "roles": [
  #     {
  #       "principalid": "'$(var-principal-id-role-devops)'",
  #       "rolename": "DevOps"
  #     },
  #     {
  #       "principalid": "'$(var-principal-id-role-appops)'",
  #       "rolename": "AppOps"
  #     }
  #   ]
  # }
```

</br>

La troisième variable permet d'assigner les rôles préexistants (*built-in roles*) :

- scopeId = ID du groupe d'administration (*Management Group* ou de l'abonnement (*subscription*) Azure
- type = Niveau de l'assignation : groupe d'administration ou abonnement (typiquement au niveau du groupe d'administration pour ces rôles)
- roles:
  - principalid = l'objet ID de l'utilisateur ou du groupe de sécurité d'Azure AD
  - rolename = nom du rôle à assigner (NetOps, SecOps, DevOps, AppOps, SubscriptionOwner)
  - id = ID du rôle préexistant (https://docs.microsoft.com/en-us/azure/role-based-access-control/built-in-roles)

</br>

Voici différents exemples:

- Ajout de deux rôles au niveau du groupe d'administration (*Management Group*) de l'organisation

  ```yaml
  var-rbac-builtin-roles-assignements: >
      [
          {
              "scopeId": "'$(var-organisation-id)'",
              "type": "managementGroup",
              "roles": [
                  {
                      "principalid": "16dce394-b115-4ed3-8839-e966ae91c2df",
                      "rolename": "Desktop Virtualization Reader",
                      "id": "49a72310-ab8d-41df-bbb0-79b649203868"
                  },
                  {
                      "principalid": "16dce394-b115-4ed3-8839-e966ae91c2df",
                      "rolename": "Storage Account Contributor",
                      "id": "17d1049b-9a84-46fb-8f53-869881c3d3ab"
                  }
              ]
          }    
      ]
  ```
- Ajout d'un rôle sur deux différents abonnements (*subscriptions*) :

  ```yaml
  var-rbac-builtin-roles-assignements: >
      [
          {
              "scopeId": "c12c1c16-33a1-487b-954d-41c89c60f349",
              "type": "subscription",
              "roles": [
                  {
                      "principalid": "16dce394-b115-4ed3-8839-e966ae91c2df",
                      "rolename": "Desktop Virtualization Reader",
                      "id": "49a72310-ab8d-41df-bbb0-79b649203868"
                 }
              ]
          },    
          {
              "scopeId": "47b7735b-770e-4598-a7da-8b91488b4c88",
              "type": "subscription",
              "roles": [
                  {
                      "principalid": "028f4ed7-e2a9-465e-a8f4-9c0ffdfdc027",
                      "rolename": "Storage Account Contributor",
                      "id": "17d1049b-9a84-46fb-8f53-869881c3d3ab"
                  }
              ]
          }    
      ]
  ```

</br>