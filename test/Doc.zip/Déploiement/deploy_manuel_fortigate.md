# Scénario de déploiement de la zone d'accueil OCI sans pare-feu et configuration manuelle d’un FortiGate

L'objectif de cette documentation est de fournir les prérequis et les étapes pour le déploiement automatique d'une zone d'accueil OCI (Oracle Cloud Infrastructure) sans pare-feu.

Puis, dans ladite zone d'accueil, nous irons ajouter manuellement un pare-feu FortiGate.

Au menu :

* [Prérequis](#prérequis "Prérequis pour le déploiement du pare-feu Fortigate")
* [Déploiement de la zone d'accueil Oracle sans pare-feu](#déploiement-de-la-zone-daccueil-oracle-sans-pare-feu)
* [Options de déploiement du pare-feu FortiGate](#options-de-déploiement-du-pare-feu-fortigate)
* [Déploiement du pare-feu FortiGate depuis Oracle Cloud Marketplace](#déploiement-de-fortigate-depuis-oracle-cloud-marketplace)
* [Console Web d'administration du pare-feu FortiGate](#console-web-d-administration-du-pare-feu-fortigate)
* [Accueil](../../README.md "Retour à la page d'accueil")

---

## Prérequis

Vous devez [remplir les mêmes conditions](../Déploiement/PreRequis.md) pour un déploiement automatique d'une zone d'accueil OCI *avec* un pare-feu FortiGate.

---

## Déploiement de la zone d'accueil Oracle sans pare-feu

Afin de déployer une zone d'accueil OCI sans pare-feu, vous devez configurer une pile (*stack*) dans Oracle Resource Manager (ORM).
Pour ce faire, suivez le guide de déploiement dans la page [Deploi_Script.md](../Déploiement/Deploi_Script.md),

à l'exception de l'écran 11, à l'étape 7, où vous devez :

* Cochez *Utiliser le réseau virtuel infonuagique de la zone démilitarisée pour y déployer des pares-feux tiers ?* , et
* Décochez ```Déployer un pare-feu Fortigate dans la zone démilitarisée ?```.

![decocher_use_fortigate](../images/fortigate/deploisansparefeu/decocher_use_fortigate.png)

---

## Options de déploiement du pare-feu FortiGate


**Note** : Les paramètres et configurations choisis sont à titre indicatif. Ces choix restent à la discrétion de chacun et peuvent engendrer des coûts, des engagements vis a vis du fournisseur 'Fortinet' et des comportements différents pour chacun.


Vous pouvez déployer une architecture de pare-feux en utilisant l'une des trois approches suivantes :

1. Importer un [script Terraform dans une pile (*stack*) Oracle Resource Manager](https://github.com/oracle-quickstart/oci-fortinet/tree/master/use-cases/drg-ha-use-case#deploy-using-oracle-resource-manager).
2. Utiliser un script avec ligne de commande [Terraform CLI](https://github.com/oracle-quickstart/oci-fortinet/tree/master/use-cases/drg-ha-use-case#deploy-using-the-terraform-cli).
3. Utiliser une image FortiGate depuis la place de marché (*Marketplace*) d'Oracle Cloud.

Dans notre scénario, nous allons déployer deux pare-feux par le biais d'Oracle Cloud Marketplace.

---

## Déploiement de FortiGate depuis Oracle Cloud Marketplace

Deux instances FortiGate seront déployées dans la zone d'accueil OCI.

Pour le déploiement de chacune des instances, suivre les étapes suivantes :

1- Accédez au site Web d'Oracle Cloud Marketplace : <http://cloud.oracle.com/marketplace>.
2- Cliquez sur **Se connecter**, en haut de la page Oracle Cloud Marketplace.
3- Entrez le nom d'utilisateur et le mot de passe de votre compte Oracle.
4- Cliquez sur **Se connecter**.

![page-accueil-oci-marketplace](../images/fortigate/marketplace/page-accueil-oci-marketplace.png)

5- Dans la barre de recherche, tapez **fortigate**.

![recherche_fortigate](../images/fortigate/marketplace/recherche_fortigate.png)

6- Sélectionnez l'image ```*FortiGate Next-Gen Firewall (BYOL)*```.

Une page Web *FortiGate Next-Gen Firewall (BYOL)* s'affiche.

![page_web_FortiGate_Next-Gen_Firewall](../images/fortigate/marketplace/page_web_FortiGate_Next-Gen_Firewall.png)

**Note** : Le choix d'une image avec l'option BYOL est propre à notre situation de test, vous devez donc revoir votre gestion de licence.

7- Dans cette page Web, sélectionnez ```7.2.2 SR-IOV Paravirtualized Mode``` dans la liste déroulante ```Version```.

**Note** : La version (7.2.2) de l'image 'FortiGate' choisie est juste à titre indicatif, vous devez choisir la version qui répond à vos objectifs.

8- Dans le champ compartiment, sélectionnez ```cmp-conne-001``` dans le compartiment englobant.

9- Cochez la case ```J'ai pris connaissance des Conditions d'utilisation d'Oracle et des Conditions générales de partenariat, et je les accepte.```.

10- Cliquez sur le bouton ```Lancer l'instance```.

![4_choix_parametre_deploiement_fortigate-Gen_Firewall](../images/fortigate/marketplace/4_choix_parametre_deploiement_fortigate.png)

La page Web *Créer une instance de calcul* s'affiche.

11- Dans le champ Nom, donnez un nom à votre instance FortiGate.
12- Dans le champ Créer dans le compartiment, sélectionnez le compartiment dans lequel sera déployé le pare-feu.

![5_selectionner_compartiment_2](../images/fortigate/marketplace/5_selectionner_compartiment_2.png)

Par défaut, ORM choisit le meilleur domaine de panne et de disponibilité. Dans la capture d'écran, c'est AD-1 qui a été sélectionné.

Nous allons manuellement définir un domaine de disponibilité (AD-1) pour la première instance de FortiGate.

La deuxième instance FortiGate sera déployée dans un domaine de disponibilité différent (AD-3).

13- Dans la section *Placement*, cliquez sur ```Afficher les options avancées``` et dans la liste déroulante ```Domaine de pannes```, sélectionnez ```FAULT-DOMAIN-1```.

![4_2_domaine_disponibilite](../images/fortigate/marketplace/4_2_domaine_disponibilite.png)

Pour la deuxième instance FortiGate, sélectionnez ```FAULT-DOMAIN-3``` dans la liste déroulante.

14- Dans la section **Image et forme**, cliquez sur le bouton **Change Shape**.

**Note** : La configuration pour les instances ci-dessous (OCPU, forme, mémoire vive) vise à répondre à des besoins de tests seulement et est juste à titre indicatif. Vous devez donc choisir une configuration des instances répondant à vos objectifs de traitement.

Dans la nouvelle boîte de dialogue à droite, choisissez ```4 OCPU``` et ```64 GB``` de mémoire vive.

![4_3_shape_vm](../images/fortigate/marketplace/4_3_shape_vm.png)

Cliquez sur le bouton ```Sélectionner une forme``` pour valider vos choix.

**Note** : Assurez-vous que le nombre de OCPU sélectionné correspond aux critères de la licence BYOL.

Allez plus bas à la section *Fonctions de réseau* de la page Web en cours.

15- Dans la section *Réseau principal*, cochez l'option ```Sélectionner un réseau cloud virtuel existant```, puis sélectionnez le réseau virtuel infonuagique qui hébergera le pare-feu.

16- Dans la section *Sous-réseau*, cochez l'option ```Sélectionner un sous-réseau existant```, puis sélectionnez le sous-réseau qui hébergera le pare-feu.

17- Dans la section *Adresse IP publique*, cochez l'option ```Affecter une adresse IPv4 publique```.

L'affectation d'une adresse IP publique rend cette instance accessible à partir d'Internet. Si vous n'êtes pas certain d'avoir besoin d'une adresse IP publique, vous pourrez en affecter une ultérieurement.

![5_adresse_ip_3](../images/fortigate/marketplace/5_adresse_ip_3.png)

18- Dans la section *Ajouter des clés SSH*, cochez l'option ```Coller des clés publiques```, puis copier-coller votre clé SSH dans le champ ```Clés SSH```.

![5_cle_ssh_4](../images/fortigate/marketplace/5_cle_ssh_4.png)

La page des [Prérequis.md](PreRequis.md) décrit les étapes pour générer cette clé SSH.

19- Dans la section *Volume d'initialisation*, cochez l'option ```Indiquer une taille personnalisée de volume d'initialisation```, saisissez la ```Taille du volume d'initialisation``` et définissez le nombre de ```VPU```.

![5_volume_initialisation_5.png](../images/fortigate/marketplace/5_volume_initialisation_5.png)

Une fois le formulaire rempli, vous avez deux options :

* Cliquer sur le bouton ```Créer``` pour déployer le pare-feu.
* Cliquer sur le bouton ```Enregistrer en tant que pile``` pour enregistrer la ressource en tant que pile Terraform réutilisable visant à créer une instance à l'aide de Oracle Resource Manager (ORM).

Cliquez sur le bouton ```Créer``` et le pare-feu sera déployé.

![6_pare_feu_deploye.png](../images/fortigate/marketplace/6_pare_feu_deploye.png)

## Console Web d'administration du pare-feu FortiGate

Une fois que vous avez déployé l'infrastructure de pare-feux, vous devez vous assurer que votre configuration est correctement appliquée sur les pare-feux FortiGate et l'ajuster en fonction de vos [besoins](../Architecture/Architecture.md).

Connectez-vous à la console Web d'administration du pare-feu FortiGate :

1-  Dans un navigateur Web,

    - Connectez-vous à la console Web d'administration du pare-feu **FortiGate-1**. Tapez l'adresse suivante <https://public_ip> , en prenant soin de remplacer **public_ip** par l'adresse de votre pare-feu.
    - Connectez-vous à la console Web d'administration du pare-feu **FortiGate-2**. Tapez l'adresse suivante <https://public_ip> , en prenant soin de remplacer **public_ip** par l'adresse de votre pare-feu.
2- À la première connexion, utilisez la paire d'identifiants suivants (**admin/<instance_ocid>**) pour vous connecter à votre pare-feu.

![1_copier_ocid_fortigate](../images/fortigate/1_copier_ocid_fortigate.png)

![3_premiere_connexion](../images/fortigate/3_premiere_connexion.png)

3- Changez votre mot de passe, puis reconnectez-vous avec la paire (**admin/VotreNouveauMotDePasse**).

![4_changement_password](../images/fortigate/4_changement_password.png)

4- Importer votre fichier de licence

Si l'image FortiGate utilise le modèle 'Apportez votre propre licence' (BYOL), vous verrez une invite pour télécharger une licence. Sélectionnez le fichier de licence, puis chargez-le. Sélectionnez ```OK``` et redémarrez la machine virtuelle FortiGate.

![7_upload_licence](../images/fortigate/marketplace/7_upload_licence.png)

5- Après le redémarrage, reconnectez-vous avec les informations d'identification de l'administrateur (**admin/VotreNouveauMotDePasse**) pour valider la licence.

---

[Retour à la Page d'accueil](../../README.md "Retour à la page d'accueil")
