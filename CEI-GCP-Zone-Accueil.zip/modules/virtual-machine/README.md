# Machine Virtuelle GCE

Créer un VM de Linux et Windows sur GCE avec l'option d'ajouter des disques et des polices de snapshot.

Inclure ce module dans votre espace de travail en ajoutant le bloc de module montré dans l'exemple suivant. Voir l'onglet "Entrée" pour voir toutes les variables pouvant être définies.

```hcl

# Module must be repeated for each VM you wish to create. Terraform 0.13 will add `count` and `for_each` to the module resource.
module "VM1" {
  source  = "./modules/virtual-machine"
  version = "v0.1.3" # change version to the last one

  vm_name     = "foo"
  vm_env      = "bar"
  vm_zone     = "northamerica-northeast1-a"
  image       = "rhel-latest"
  subnet_name = "snet-bfpte-app-nane"

  label_environment     = "test"
  label_owner           = "test"
  label_snow_queue = "test"
  label_application     = "test"

  service_account_email_address = "<my-service-account>@<my-project>.iam.gserviceaccount.com"

  # disks is optional and can have many maps in the list, a disk will be created for each map and attached to the VM
  disks = [
    {
      id   = "app-disk"
      size = 20
      type = "pd-ssd"
    },
    {
      id   = "1"
      size = 90
      type = "pd-ssd"
    }
  ]
}
```

<!-- BEGINNING OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
## Exigences

Pas d'exigences

## Fournisseurs

| Nom                                                        | Version |
|------------------------------------------------------------|---------|
| <a name="provider_google"></a> [google](#provider\_google) | n/a |

## Modules

| Nom                                                                                | Source | Version |
|------------------------------------------------------------------------------------|--------|---------|
| <a name="module_boot_disk_name"></a> [boot\_disk\_name](#module\_boot\_disk\_name) | ../terraform-gc-naming//modules/gcp/managed_disk_os | 2.6.2 |
| <a name="module_data_disk_name"></a> [data\_disk\_name](#module\_data\_disk\_name) | ../terraform-gc-naming//modules/gcp/managed_disk_data | 2.6.2 |
| <a name="module_vm_name"></a> [vm\_name](#module\_vm\_name)                        | ../terraform-gc-naming//modules/gcp/virtual_machine | 2.6.2 |

## Resources

| Nom                                                                                                                                                                                                 | Type |
|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|------|
| [google_compute_disk.vm_disk](https://registry.terraform.io/providers/hashicorp/google/latest/docs/resources/compute_disk)                                                                          | resource |
| [google_compute_disk_resource_policy_attachment.additional_disk_attachment](https://registry.terraform.io/providers/hashicorp/google/latest/docs/resources/compute_disk_resource_policy_attachment) | resource |
| [google_compute_disk_resource_policy_attachment.os_disk_attachment](https://registry.terraform.io/providers/hashicorp/google/latest/docs/resources/compute_disk_resource_policy_attachment)         | resource |
| [google_compute_instance.virtual_machine](https://registry.terraform.io/providers/hashicorp/google/latest/docs/resources/compute_instance)                                                          | resource |

## Entrées

| Nom                                                                                                                                                    | Description                                                                                      | Type | Défaut                               | Requis |
|--------------------------------------------------------------------------------------------------------------------------------------------------------|--------------------------------------------------------------------------------------------------|------|--------------------------------------|:-----:|
| <a name="input_boot_disk_size"></a> [boot\_disk\_size](#input\_boot\_disk\_size)                                                                       | Capacité de disque de boot/root                                                                  | `string` | `"20"`                               |  non   |
| <a name="input_boot_disk_type"></a> [boot\_disk\_type](#input\_boot\_disk\_type)                                                                       | Type de disque, options valides: [pd-ssd,pd-standard]                                            | `string` | `"pd-standard"`                      |  non   |
| <a name="input_can_ip_forward"></a> [can\_ip\_forward](#input\_can\_ip\_forward)                                                                       | Capacité d'agir comme un router dans le réseau                                                   | `bool` | `false`                              |  non   |
| <a name="input_compute_resource_policy"></a> [compute\_resource\_policy](#input\_compute\_resource\_policy)                                            | Police de snapshot de disque, si vide, aucune police sera appliquée                              | `string` | `""`                                 |  non   |
| <a name="input_compute_resource_policy_non_bootdisk"></a> [compute\_resource\_policy\_non\_bootdisk](#input\_compute\_resource\_policy\_non\_bootdisk) | Police de snapshot de disque, si vide, aucune police sera appliquée                              | `string` | `""`                                 |  non   |
| <a name="input_department_code"></a> [department\_code](#input\_department\_code)                                                                      | Code pour département, partie du module de nonmmage                                               | `string` | n/a                                  |  oui  |
| <a name="input_device_type"></a> [device\_type](#input\_device\_type)                                                                                  | Type d'appareil à fins de nommage                                                                | `string` | n/a                                  |  oui  |
| <a name="input_disks"></a> [disks](#input\_disks)                                                                                                      | Dictionnaire de disques pour des disques supplémentaires                                         | <pre>list(object({<br>    id   = string<br>    type = string<br>    size = number<br>  }))</pre> | `[]`                                 |  non   |
| <a name="input_domain"></a> [domain](#input\_domain)                                                                                                   | Domaine utilisé dans le nom d'hôte de vm                                                         | `string` | `"c3.ssc-spc.cloud-nuage.canada.ca"` |  non   |
| <a name="input_environment"></a> [environment](#input\_environment)                                                                                    | S-Sandbox P-Production Q-Quality D-development                                                   | `string` | n/a                                  |  oui  |
| <a name="input_image"></a> [image](#input\_image)                                                                                                      | Nom d'image                                                                                      | `string` | `"rhel-latest"`                      |  non   |
| <a name="input_image_location"></a> [image\_location](#input\_image\_location)                                                                         | Projet d'image source de l'instance                                                              | `any` | n/a                                  |  oui  |
| <a name="input_labels"></a> [labels](#input\_labels)                                                                                                   | Étiquette à utiliser pour le VM                                                                  | `map(string)` | `{}`                                 |  non   |
| <a name="input_location"></a> [location](#input\_location)                                                                                             | Emplacement pour placement de nommage et de ressource                                            | `string` | `"northamerica-northeast1"`          |  non   |
| <a name="input_machine_type"></a> [machine\_type](#input\_machine\_type)                                                                               | Taille de VM                                                                                     | `string` | `"n1-standard-2"`                    |  non   |
| <a name="input_metadata"></a> [metadata](#input\_metadata)                                                                                             | custom\_metadata à ajouter dans l'instance                                                       | `map(string)` | `{}`                                 |  non   |
| <a name="input_metadata_startup_script"></a> [metadata\_startup\_script](#input\_metadata\_startup\_script)                                            | Script de stratup pour vm                                                                        | `string` | `null`                               |  non   |
| <a name="input_network_interfaces"></a> [network\_interfaces](#input\_network\_interfaces)                                                             | Dictionnaire d'objets contenant les interfaces de réseau. ID définit l'ordre dêtre attaché au VM | <pre>list(object({<br>    id                 = string # sets the order of the attachement to the VM<br>    subnetwork         = string<br>    subnetwork_project = string<br>    network_ip         = optional(string)<br>    access_config = optional(list(object({<br>      nat_ip = string<br>    })))<br>  }))</pre> | n/a                                  |  oui  |
| <a name="input_network_tags"></a> [network\_tags](#input\_network\_tags)                                                                               | Étiquette de réseau pour les règles de pare-feu                                                  | `list` | `[]`                                 |  non   |
| <a name="input_number_suffix"></a> [number\_suffix](#input\_number\_suffix)                                                                            | Suffix de nombre pour le nom de ressource                                                        | `string` | `"01"`                               |  non   |
| <a name="input_project"></a> [project](#input\_project)                                                                                                | Nom de projet                                                                                    | `string` | n/a                                  |  oui  |
| <a name="input_service_account_email_address"></a> [service\_account\_email\_address](#input\_service\_account\_email\_address)                        | Compte de service pour exécuter le VM                                                            | `any` | n/a                                  |  oui  |
| <a name="input_service_account_scopes"></a> [service\_account\_scopes](#input\_service\_account\_scopes)                                               | Portée de GCP que VM devrait être capable d'accèder et/ou changer                                | `list` | `[]`                                 |  non   |
| <a name="input_user_defined_string"></a> [user\_defined\_string](#input\_user\_defined\_string)                                                        | String défini par l'usager                                                                       | `string` | n/a                                  |  oui  |
| <a name="input_vm_zone"></a> [vm\_zone](#input\_vm\_zone)                                                                                              | Zone de GCE pour déployer le VM                                                                  | `string` | `"northamerica-northeast1-a"`        |  non   |

## Sorties

| Nom                                                                                | Description                           |
|------------------------------------------------------------------------------------|---------------------------------------|
| <a name="output_can_ip_forward"></a> [can\_ip\_forward](#output\_can\_ip\_forward) | n/a                                   |
| <a name="output_domain"></a> [domain](#output\_domain)                             | Sorti de domaine pour des cas de test |
| <a name="output_hostname"></a> [hostname](#output\_hostname)                       | n/a                                   |
| <a name="output_instance_id"></a> [instance\_id](#output\_instance\_id)            | n/a                                   |
| <a name="output_ip_addresses"></a> [ip\_addresses](#output\_ip\_addresses)         | Adresses d'IP                         |
| <a name="output_name"></a> [name](#output\_name)                                   | n/a                                   |
| <a name="output_self_link"></a> [self\_link](#output\_self\_link)                  | n/a                                   |
| <a name="output_tags"></a> [tags](#output\_tags)                                   | n/a                                   |
| <a name="output_zone"></a> [zone](#output\_zone)                                   | n/a                                   |
<!-- END OF PRE-COMMIT-TERRAFORM DOCS HOOK -->