# Plan de test haut niveau pour la release v.2.2.1

## Policies
- [ ] Validation de la conformité de la zone d'accueil selon des prédéfinies acceptable
- [ ] Remédiation des *resource tags*
  - [ ] Les tags par rapport à l'organisation sont bien mis et définis dans le code
  - [ ] Les tags par rapport aux abonnements sont bien mis et définis dans le code
  - [ ] L'héritage suite à la remédiation se fait bien des abonnements vers les groupes de ressources
  - [ ] Les tags sont bel et bien obligatoires lors de la création ou modification d'un *resource group*.
  - [ ] Remédiation de public endpoint sur storage account et keyvault
  - [ ] La remédiation de *public endpoint* est appliquée sur le *storage account* et le *keyvault*
  - [ ] Il n'y a pas de *builtin* qui sont obsolète dans les initiatives utilisées
- [ ] *Resource Lock*
    - [ ] La remédiation applique les verrouillages sur les groupes de ressources de production
## Wipe Tenant
- [ ] Le nettoyage se fait même avec le *Resource Lock*
## BGP Propagation
- [ ] On peut configurer le paramètre BGP visuellement à la valeur *true* ou *false*
## Register resource provider
- [ ] La liste des fournisseurs de ressources est bien installée **avant** la fin du pipeline d'assignation des abonnements
## Service en lignes
- [ ] Les conflits d'addressages sont gérés
- [ ] Le *peering* est fait avec le hub
- [ ] Le routage NSG est fonctionnel
- [ ] Les services en lignes sont fonctionnels avec le *jumpbox* aussi.
## AVD
- Dans un abonnement dédié à Windows ADDS avec toutes les ressources nécessaires,
  - On doit aller dans le *Virtual Network* et faire un *peering* avec le *Virtual Network* du hub, dans l'abonnement connectivité.
  - En haut de la page d'ajout de *peering*, dans la section *This virtual network*, on crée un peering link "adds-to-hub", dont le *Virtual Network Gateway* sera mis à `Use the remote virtual network's gateway or Route Server`.
  - En bas de la page, dans la section *Remote virtual network*, on crée un peering link "hub-to-adds" dont le *Virtual Network Gateway* sera mis à `Use this virtual network's gateway or Route Server`.
  - On doit ensuite rouler le pipeline `Common` de AVD.
    - [X] Les ressources sont déployées par le pipeline Commun dans l'abonnement AVD paramétré.
- On doit ensuite rouler le pipeline `Instance` d'AVD
  - [X] Les ressources sont déployées pour le pipeline Instance 1.
  - [ ] Dans ADDS avec le compte de *domain admin*, ont voit la machine virtuelle AVD dans ``Server Manager > AVD > Storage``.
- [ ] Les ressources sont déployées pour le pipeline Instance 2.
- [ ] Lorsqu'un Domain Controller est déployé dans l'abonnement Identité, AVD peut communiquer avec ce Domain Controller.
## NSG / ASG
- Lorsqu'on prend le dossier cei-base-asg-custom.yml et décommente les lignes qui sont commentées. Pour les conflits, on garde la version décommentée et on commente celle qui avait avant. Une fois fini, on peut rouler le pipeline 3 et 4.
  - [X] Les règles des NSG ont changé
  - [X] Les nouveaux ASG sont référés dans les règles des NSG
- Lorsqu'on prend le dossier cei-base-nsg-custom.yml et décommente les lignes qui sont commentées. Pour les conflits, on garde la version décommentée et on commente celle qui avait avant. Une fois fini, on peut rouler le pipeline 3 et 4.
  - [X] Les ASG sont créés.

Procédure de vérification :

![photo-resources](/Documentation/Doc/v2-2-1-tests/img/test-nsg-asg-resources.png)

> Ici on peut voir les ressources qui doivent être créées. On voit les Application security groups (ASG) et les Network security groups (NSG).

<br/>

![photo-rules-list](/Documentation/Doc/v2-2-1-tests/img/test-nsg-asg-nsg-rules-list.png)

> Ici on peut voir les règles du NSG qui ont été changé par les pipelines. Les règles créées sont celles qui commencent par ``sr_``.

<br/>

![photo-app-rules](/Documentation/Doc/v2-2-1-tests/img/test-nsg-asg-app-rules.png)

> Ici, on peut voir une des règles dans un nouveau NSG. Étant donné que la colonne Destination était à `Multiple`, ont voit que la règle contient comme destination plusieurs ASG, soit `nprod_asgapp1`, `nprod_asgapp2`, `nprod_asgapp3`.

<br/>
<br/>

## DNS Resolver
- [x] Lorsqu'on prend le dossier cei-base-dnsresolver.yml et décommente les lignes qui sont commentées et vice-versa.
  - [x] Les règles du DNS Resolver ont été ajoutées

## Groupes de variable
- [x] Les groupes de variables sont bien fonctionnels pour tous les pipelines
  - [x] [Pour le pipeline 1 - Azure - ManagementGroups](#pipeline-1---azure---managementgroups)
    - [x] Pour le scénario de base
    - [x] Pour le scénario complexe
    - [x] Avec "None" comme organisation
    - [x] Avec "what-if" comme paramètre
  - [x] [Pour le pipeline 2 - Azure - AssignSubscriptions](#pipeline-2---azure---assignsubscriptions)
    - [x] Avec "None" comme organisation
    - [x] Pour le scénario de base
    - [x] Pour le scénario complexe
  - [x] [Pour le pipeline 3 - Azure - Platform](#pipeline-3---azure---platform)
    - [x] Pour le scénario de base
    - [x] Pour le scénario complexe
  - [x] [Pour le pipeline 4 - Azure - LandingZone](#pipeline-4---azure---landingzone)
    - [x] Pour le scénario de base
    - [x] Pour le scénario complexe
  - [x] [Pour le pipeline 5 - Azure - Policy](#pipeline-5---azure---policy)
    - [x] Pour le scénario de base
    - [x] Pour le scénario complexe
  - [x] [Pour le pipeline 6 - Azure - RBAC](#pipeline-6---azure---rbac)
    - [x] Pour le scénario de base
    - [x] Pour le scénario complexe
  - [ ] Pour le pipeline Azure - Wipe Tenant
- [x] Le mot de clé None fait que le groupe de variables n'est pas utilisé pour les pipelines visés
- [x] Toutes les valeurs des variables présentes dans le code ont priorité sur les valeurs du groupe de variables

## Mise à jour
- [ ] La mise à jour se fait correctement pour chacun des six pipelines
  - [X] Avec le paramétrage de base
    - [X] [Pour le pipeline 1 - Azure - ManagementGroups](#pipeline-1---azure---managementgroups)
    - [X] [Pour le pipeline 2 - Azure - AssignSubscriptions](#pipeline-2---azure---assignsubscriptions)
    - [x] [Pour le pipeline 3 - Azure - Platform](#pipeline-3---azure---platform)
    - [X] [Pour le pipeline 4 - Azure - LandingZone](#pipeline-4---azure---landingzone)
    - [X] [Pour le pipeline 5 - Azure - Policy](#pipeline-5---azure---policy)
    - [X] [Pour le pipeline 6 - Azure - RBAC](#pipeline-6---azure---rbac)
  - [ ] Avec le paramétrage complexe
    - [ ] [Pour le pipeline 1 - Azure - ManagementGroups](#pipeline-1---azure---managementgroups)
    - [ ] [Pour le pipeline 2 - Azure - AssignSubscriptions](#pipeline-2---azure---assignsubscriptions)
    - [ ] [Pour le pipeline 3 - Azure - Platform](#pipeline-3---azure---platform)
    - [ ] [Pour le pipeline 4 - Azure - LandingZone](#pipeline-4---azure---landingzone)
    - [ ] [Pour le pipeline 5 - Azure - Policy](#pipeline-5---azure---policy)
    - [ ] [Pour le pipeline 6 - Azure - RBAC](#pipeline-6---azure---rbac)


## Checkbox et pipeline adhoc pour Wipe Policies
- [ ] Les anciennes *policies* sont bien nettoyées avant de procéder à l'assignation des nouvelles *policies*

# Vérifications à faire par test
*S'applique aussi à tous les éléments de la sous-branche.*

## Pipeline 1 - Azure - ManagementGroups
- [ ] Le management group "racine" a été créé
- [ ] Les management groups "enfants" ont été créés
  - **Scénario de base**
    - Charges
      - Non Production
        - ServicesEnLigneNonProduction
      - Production
        - Non sensibles
        - Sensibles
        - ServicesEnLigneProduction
    - Decommissionés
    - Expérimentation
    - Plateforme
      - Connectivité
      - Gestion
      - Identité
      - Perimetre
  - **Scénario complexe**
    - Charges
      - Bureautique
        - BureautiqueAcceptation
        - BureautiqueDevelopement
        - BureautiqueProduction
      - Intranet
        - IntranetAcceptation
        - IntranetDevelopement
        - IntranetProduction
      - Non Production
      - Production
        - Non sensibles
        - Sensibles
      - ServicesEnLigne
        - ServicesEnLigneAcceptation
        - ServicesEnLigneDevelopement
        - ServicesEnLigneProduction
    - Decommissionés
    - Expérimentation
      - CarresDeSable
      - PreuvesDeConcept
    - Plateforme
      - Connectivité
      - Gestion
      - Identité
      - Perimetre
- [ ] Si ``var-unique-mg-names`` est à yes, l'identifiant de chacun des management groups contient un ``uniqueString`` à la fin


## Pipeline 2 - Azure - AssignSubscriptions

- [ ] Les abonnements ont été attribués aux bons endroits
  - **Scénario de base**
    - Charges
      - Non Production
        - **aze-xx-nonproduction**
        - ServicesEnLigneNonProduction
          - **aze-xx-sel-dev**
      - Production
        - Non sensibles
          - **aze-xx-nonsensibles**
        - Sensibles
          - **aze-xx-sensibles**
        - ServicesEnLigneProduction
          - **aze-xx-sel-prod**
    - Decommissionés
    - Expérimentation
    - Plateforme
      - Connectivité
        - **aze-xx-connectivite**
      - Gestion
        - **aze-xx-gestion** `SEULEMENT si var-deploy-platform-management est mis à true`
      - Identité
        - **aze-xx-identite** `SEULEMENT si var-deploy-platform-identity est mis à true`
      - Perimetre
        - **aze-xx-perimetre**
  - **Scénario complexe**
    - Charges
      - Bureautique
        - BureautiqueAcceptation
          - **AZE_xx_BUR_UAT**
        - BureautiqueDevelopement
          - **AZE_xx_BUR_DEV**
        - BureautiqueProduction
          - **AZE_xx_BUR_Prod**
      - Intranet
        - IntranetAcceptation
          - **AZE_xx_INT_UAT**
        - IntranetDevelopement
          - **AZE_xx_INT_DEV**
        - IntranetProduction
          - **AZE_xx_INT_Prod**
      - Non Production
      - Production
        - Non sensibles
        - Sensibles
      - ServicesEnLigne
        - ServicesEnLigneAcceptation
          - **AZE_xx_SEL_UAT**
        - ServicesEnLigneDevelopement
          - **AZE_xx_SEL_DEV**
        - ServicesEnLigneProduction
          - **AZE_xx_SEL_Prod**
    - Decommissionés
    - Expérimentation
      - CarresDeSable
      - PreuvesDeConcept
    - Plateforme
      - Connectivité
        - **aze-xx-connectivite**
      - Gestion
        - **aze-xx-gestion** `SEULEMENT si var-deploy-platform-management est mis à true`
      - Identité
        - **aze-xx-identite** `SEULEMENT si var-deploy-platform-identity est mis à true`
      - Perimetre
        - **aze-xx-perimetre**
- [ ] Les abonnements ont les mêmes identifiants que ceux dans le groupe de variable ou le fichier cei-xx-param.yml

## Pipeline 3 - Azure - Platform
- [ ] Les ressources sont créés dans différents abonnements si les valeurs suivantes sont mises à `true`
  - [ ] var-platform-gestion-deploy-bastion
    - [ ] Déploie Azure Bastion dans le spoke Gestion
    - [ ] Azure Bastion est fonctionnel
  - [ ] var-platform-hub-deploy-appGateway
    - [ ] Déploie un Application Gateway dans le hub (connectivité)
    - [ ] Le Application Gateway est fonctionnel
  - [ ] var-platform-hub-deploy-AzureFW
    - [ ] Déploie un Azure Firewall dans le hub (connectivité)
    - [ ] Le Azure Firewall est fonctionnel
  - [ ] var-platform-hub-deploy-bastion
  - [ ] var-platform-hub-deploy-expressRouteGW
  - [ ] var-platform-hub-deploy-Fortigate
  - [ ] var-platform-hub-deploy-privateDNS
  - [ ] var-platform-hub-deploy-recoveryVault
  - [ ] var-platform-hub-deploy-resolver-inbound
  - [ ] var-platform-hub-deploy-resolver-outbound
  - [ ] var-platform-hub-deploy-VPNGW
  - [ ] var-platform-perimetre-deploy-appGateway
  - [ ] var-platform-perimetre-deploy-AzureFW

## Pipeline 4 - Azure - LandingZone

## Pipeline 5 - Azure - Policy

## Pipeline 6 - Azure - RBAC