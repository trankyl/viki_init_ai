# Vocabulaire

| Abréviation | Nom Complet | Description |
| ----------- | ----------- | ----------- |
| ACL  | Access Control List |  |
| API | Application Programming Interface |  |
| CLI | Command Line Interface |  |
| cmd | command | |
| COS | Cloud Object Storage | |
| CPU | Central Processing Unit | |
| CRN | Cloud Registration Name | |
| CS | Cognitive Service | |
| DDOS | Distributed Denial-of-service||
|DRA|Data Recovery Agent||
|EDR|Enhanced Data Rate||
|EMS|Expanded Memory System||
|GIA|Government Information Awareness||
|HMAC|Hash-Based Message Authentification Code||
|HPC|High Performance Computers||
|IAM|Identity and Access Management||
|KMS|Key Management Service||
|LAN|Local Area Network||
|LB|Load Balancer||
|LDAP|Lightweight Directory Access Protocol
Mobile Backend as a Service
||
|MBaaS|Mobile Backend as a Service||
|MG|Management Group||
|MGMT|Management||
|MKdir|Make Directory||
|NAC|Network Access Control||
|NGFW|Next Gen Firewall||
|NLS|National Language Support||
|NPL|Non Procedural Language||
|NSG|Network Security Group||
|OWASP|Open Web Application Security Projects||
|Paas|Platform as a Service||
|Redis|Remote Dictionnary Server||
|Repo|Repository||
|RSA|Rivest-Shamir-Adleman||
|SAML|Security Assertion Markup Language||
|SBQ|Service bus Queues||
|SCC|Security and Compliance Center||
|SSH|Secure Shell||
|SSO|Single Sign-on||
|TACACS+|Terminal Access Controller Access-Control System Plus||
|TCO|Total Cost of Ownership||
|Tf-dir|Terraform Directory||
|Tf-var-file|||
|Vnet|Virtual Network||
|VPC|Virtual Private Cloud||
|VPE|Virtual Private Endpoint||
|VPN|Virtual Private Network||
|VSI|Virtual Server Instance||
|YML/YAML|Yet Another Markup Language||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
||||
