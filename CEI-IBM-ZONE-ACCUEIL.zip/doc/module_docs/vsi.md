# Module VSI sur VPC 

Ce module permet aux utilisateurs de créer un nombre illimité d’instances de serveur virtuel (VSI) sur plusieurs sous-réseaux comportant un nombre illimité de volumes de stockage en bloc, reliés par un nombre illimité d'équilibreurs de charge.

![module-vsi](../images/module_doc_imgs/vsi-lb.png)

## Table des matières

1. [Prérequis](#prerequis)
2. [Serveurs virtuels](#serveurs-virtuels)
3. [Volumes de stockage en bloc](#volumes-de-stockage-en-bloc)
4. [Adresses IP flottantes](#adresses-ip-flottantes)
5. [Équilibreurs de charge](#Équilibreurs-de-charge)
6. [Variables du module ](#module-variables)
7. [Sorties du module](#sorties-du-module)
8. [En tant que module dans une architecture plus large](#module-dans-une-architecture-plus-large)

---

## Prérequis

Un nuage privé virtuel (VPC) existant ainsi qu’une une clé SSH de VPC

---

## Serveurs virtuels

Ce module permet de créer des serveurs virtuels sur un nombre illimité de sous-réseaux dans un seul nuage privé virtuel (VPC) relié par un seul groupe de sécurité. Vous pouvez spécifier le nombre de serveurs virtuels à provisionner sur chaque sous-réseau en utilisant la variable `vsi_per_subnet`. Les serveurs virtuels utilisent un préfixe pour créer dynamiquement des noms. Ces noms sont également utilisés comme adresse Terraform pour chaque serveur virtuel, ce qui permet une référence facile:

```terraform
module.vsi["test-vsi"].ibm_is_instance.vsi["test-vsi-1"]
module.vsi["test-vsi"].ibm_is_instance.vsi["test-vsi-2"]
module.vsi["test-vsi"].ibm_is_instance.vsi["test-vsi-3"]
```
---

## Volumes de stockage en bloc

Ce module permet aux utilisateurs de créer un nombre quelconque de volumes de stockage en blocs identiques. Chaque volume de stockage spécifié dans la variable `volumes` sera créé et attaché à chaque serveur virtuel. Ces volumes de stockage en bloc utilisent le nom du serveur virtuel ainsi que le nom du volume pour créer des adresses facilement identifiables et gérables dans Terraform:

```terraform
module.vsi["test-vsi"].ibm_is_volume.volume["test-vsi-1-one"]
module.vsi["test-vsi"].ibm_is_volume.volume["test-vsi-2-one"]
module.vsi["test-vsi"].ibm_is_volume.volume["test-vsi-3-one"]
module.vsi["test-vsi"].ibm_is_volume.volume["test-vsi-1-two"]
module.vsi["test-vsi"].ibm_is_volume.volume["test-vsi-2-two"]
module.vsi["test-vsi"].ibm_is_volume.volume["test-vsi-3-two"]
```

---

## Adresses IP flottantes

En utilisant la variable `enable_floating_ip`, une IP flottante sera attribuée à chaque instance de serveur virtuel (VSI) créé par ce module. Cette adresse IP flottante sera affichée dans la sortie si elle est provisionnée.

---

## Équilibreurs de charge

Ce module vous permet de créer un nombre quelconque d'équilibreurs de charge d'application pour équilibrer le trafic entre tous les serveurs virtuels créés par ce module. Chaque équilibreur de charge peut éventuellement être ajouté à son propre groupe de sécurité. La variable `load_balancers` permet de configurer le groupe dorsal (*back-end pool*) et le détecteur frontal (*listener front-end*) pour chaque équilibreur de charge.

---

## Variables du module

Name                             | Type                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     | Description
-------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------
resource_group_id                | chaîne de caractères                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   | ID du groupe de ressources pour créer le VPC.
prefix                           | chaîne de caractères                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   | La clé API de la plateforme IBM Cloud nécessaire pour déployer des ressources activées par IAM.
tags                             | liste(chaîne de caractères)                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             | Liste des étiquettes à appliquer aux ressources créées par ce module.
vpc_id                           | chaîne de caractères                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   | ID du VPC
subnets                          | list( object({ name = string id = string zone = string cidr = string }) )                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                | Liste d'ID de sous-réseaux où le VSI sera déployé.
image_id                         | chaîne de caractères                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   | ID de l'image utilisée pour le VSI.  Exécuter 'ibmcloud is images' pour trouver les images disponibles dans une région.
ssh_key_ids                      | liste(chaîne de caractères)                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             | ID des clés SSH à utiliser pour créer le VSI
machine_type                     | chaîne de caractères                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   | Type de machine VSI. Exécuter 'ibmcloud is instance-profiles' pour obtenir une liste des profils régionaux.
vsi_per_subnet                   | chaîne de caractères                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   | Nombre d'instances VSI instances pour chaque sous-réseau
user_data                        | chaîne de caractères                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   | Données utilisateur pour initialiser le déploiement de VSI
boot_volume_encryption_key       | chaîne de caractères                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   | CRN de la clé de cryptage du volume de démarrage
enable_floating_ip               | booléen                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     | Créer une adresse IP flottante pour chaque serveur virtuel créé
allow_ip_spoofing                | booléen                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     | Autoriser l'usurpation d'adresses IP sur l'interface réseau primaire
create_security_group            | booléen                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     | Créer un groupe de sécurité pour VSI. Si cette option est à false, la valeur par défaut sera utilisée.
security_group                   | object({ name = string rules = list( object({ name = string direction = string source = string tcp = optional( object({ port_max = number port_min = number }) ) udp = optional( object({ port_max = number port_min = number }) ) icmp = optional( object({ type = number code = number }) ) }) ) })                                                                                                                                                                                                                                                                                                                    | Groupe de securité créé pour le VSI
security_group_ids               | liste(chaîne de caractères)                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             | ID des groupes de sécurité supplémentaires à ajouter à l'interface primaire de déploiement VSI. Une interface VSI peut avoir un maximum de cinq (5) groupes de sécurité.
block_storage_volumes            | list( object({ name = string profile = string capacity = optional(number) iops = optional(number) encryption_key = optional(string) }) )                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 | Liste décrivant les volumes de stockage en bloc qui seront attachés à chaque VSI
load_balancers                   | list( object({ name = string type = string listener_port = number listener_protocol = string connection_limit = number algorithm = string protocol = string health_delay = number health_retries = number health_timeout = number health_type = string pool_member_port = string security_group = optional( object({ name = string rules = list( object({ name = string direction = string source = string tcp = optional( object({ port_max = number port_min = number }) ) udp = optional( object({ port_max = number port_min = number }) ) icmp = optional( object({ type = number code = number }) ) }) ) }) ) }) ) | Équilibreurs de charge à ajouter au VSI
secondary_subnets                | list( object({ name = string id = string zone = string cidr = string }) )                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                | Liste des interfaces réseau secondaires à ajouter à VSI Les sous-réseaux secondaires doivent être dans la même zone que VSI. Cette option n'est recommandée que pour le déploiement d’un (1) VSI.
secondary_use_vsi_security_group | booléen                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     | Utilise le groupe de sécurité créé par ce module dans l'interface secondaire
secondary_security_group_ids     | liste(chaîne de caractères)                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             | ID des groupes de sécurité supplémentaires à ajouter aux interfaces secondaires du déploiement VSI. Une interface VSI peut avoir un maximum de cinq (5) groupes de sécurité.
secondary_allow_ip_spoofing      | booléen                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     | Autoriser l'usurpation d'adresses IP sur les interfaces réseau supplémentaires

---

## Sorties du module

Name                 | Description
-------------------- | -----------------------------------------------------------
ids                | ID (identifiants) des VSI
vsi_security_group | Groupe de sécurité des VSI
list               | Liste des VSI avec nom, ID, zone et adresse IPv4 primaire
lb_hostnames       | Noms d'hôtes pour l'équilibreur de charge créé
lb_security_groups | Groupes de sécurité de l'équilibreur de charge

---

## En tant que module dans une architecture plus large
```
module vsi {
  source                           = "github.com/Cloud-Schematics/vsi-module.git"
  resource_group_id                = var.resource_group_id
  prefix                           = var.prefix
  tags                             = var.tags
  vpc_id                           = var.vpc_id
  subnets                          = var.subnets
  image_id                         = var.image_id
  ssh_key_ids                      = var.ssh_key_ids
  machine_type                     = var.machine_type
  vsi_per_subnet                   = var.vsi_per_subnet
  user_data                        = var.user_data
  boot_volume_encryption_key       = var.boot_volume_encryption_key
  enable_floating_ip               = var.enable_floating_ip
  allow_ip_spoofing                = var.allow_ip_spoofing
  create_security_group            = var.create_security_group
  security_group                   = var.security_group
  security_group_ids               = var.security_group_ids
  block_storage_volumes            = var.block_storage_volumes
  load_balancers                   = var.load_balancers
  secondary_subnets                = var.secondary_subnets
  secondary_use_vsi_security_group = var.secondary_use_vsi_security_group
  secondary_security_group_ids     = var.secondary_security_group_ids
  secondary_allow_ip_spoofing      = var.secondary_allow_ip_spoofing
}
```