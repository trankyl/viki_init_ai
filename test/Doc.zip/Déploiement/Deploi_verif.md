# Vérification du déploiement

## Sommaire

- [Vérification des réseaux déployés en utilisant la topologie réseau](#vérification-des-réseaux-déployés-en-utilisant-la-topologie-réseau)
- [Vérification de la création des deux serveurs de calcul pour les pare-feux de FortiGate](#vérification-de-la-création-des-deux-serveurs-de-calcul-pour-les-pare-feux-de-fortigate)

Pour confirmer que le résultat du déploiement prend en compte nos attentes, nous allons vérifier le résultat à partir des contrôles listés dans le sommaire de ce document.
Comme décrit dans le document de base, ces vérifications sont en relation avec les valeurs et les paramètres fournis lors de l'installation.
Comme exemple, nous vérifions que les serveurs de calcul des pare-feux FortiGate sont déployés et que le nombre de réseaux déployés est bel et bien neuf, comme indiqué dans les variables de déploiement.

## Vérification des réseaux déployés en utilisant la topologie réseau

  Comme indiqué à l'étape 5, nous nous attendons à un déploiement de neuf VCN, à savoir :  

- 3 réseaux pour la production, appelés ici PROD;  
- 3 réseaux pour la non-production, appelés ici NonProd;  
- 1 réseau pour le bac à sable, appelé ici Sandbox;  
- 1 réseau pour le non classé, appelé ici Unclassified;  
- 1 réseau concentrateur.

  Pour confirmer que ces réseaux sont créés comme prévu, nous allons visualiser la 'topologie réseau' en suivant les étapes ci-dessous.

  - À partir de la console et du menu se trouvant à gauche de l'écran :  
    - Choisir **'Service de réseau'**  
      - Dans les choix du 'Service de réseau' affichés à gauche de l'écran  
        - Choisir **'Visualiseur de réseau'**  
        

### Écran 25

   ![Network Visualizer](../images/DP_Ecran25.jpg)

  -À partir de l'écran **Visualiseur de réseau** :  
    - Assurez-vous que les ressources affichées sont celles appartenant au compartiment utilisé pour l'installation, sinon changez le compartiment.  
    - Assurez-vous que le champ **Inclure les compartiments enfants** est coché, cela permettra d'inclure tous les compartiments qui sont dans le compartiment englobant.  
    - Finalement, assurez-vous que les neuf réseaux sont créés comme prévu.  

### Écran 26

  ![Network Visualizer](../images/DP_Ecran26.JPG)

## Vérification de la création des deux serveurs de calcul pour les pare-feux de FortiGate

Les deux serveurs de calcul seront créés dans le compartiment de connectivité.  
Dans notre cas, les deux serveurs seront dans :  

- Compartiment  : *cmp-connectivite-002*  ( lors de notre déploiement pour documenter le guide en cours  )   
- Réseau        : *vcn-cmp-connectivite-002*  ( lors de notre déploiement pour documenter le guide en cours  )   
- Sous-réseau   : *snetr-vcn-cmp-conne-mgmt-cam1-001*  ( lors de notre déploiement pour documenter le guide en cours  )     

### Écran 27 / Écran 28

  ![Network Visualizer](../images/DP_Ecran28.JPG)

  ![Network Visualizer](../images/DP_Ecran27.JPG)  

  Dans la capture d'écran ci-dessus, pour chaque instance Fortigate déployée , vérifier que les configurations suivantes sont conformes aux configurations commandées dans le fichier **modules/network/fortigate/userdata.tpl** dans le script Terraform :  

- Préfixe dans le nom de l'instance FortiGate (Fortigate-FirewallXXX)  
- Forme du serveur de calcul (VM.Standard2.4)  
- Nombre de OCPU (4)
- Domaine de disponibilité
- Domaine d'erreur  

  Vous pouvez poursuivre une vérification plus détaillée d'une instance en cliquant sur l'hyperlien dans la colonne Nom (*Name*); le système vous affichera la page Web **Détails de l'instance**.

![Détail Instance FortiGate](../images/DP_Ecran_Fortigate_01.png)  

  Sur la page Web *Détails de l'instance*, à gauche dans la section *Ressources* , cliquer sur *Cartes vNIC attachées* afin de voir les configurations des quatre cartes d'interface réseau virtuelle (vNIC) attachées à l'instance FortiGate.

![Détail Instance FortiGate](../images/DP_Ecran_Fortigate_vNIC_02.png)

Pour terminer la vérification, connectez-vous à la page Web d'administration de l'instance FortiGate.

L'URL de cette page Web a la forme suivante :

*<https://{ip_publique_instance_firewall>}*   , où *ip_publique_instance_firewall* est l'adresse IP publique de votre instance FortiGate.

Par exemple, pour se connecter au FortiGate-Firewall-1, aller à l'adresse <https://168.138.79.162>.


[Retour à la Page d'accueil](../../README.md "Retour à la page d'accueil")
