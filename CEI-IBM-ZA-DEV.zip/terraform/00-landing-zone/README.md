# Secure Landing Zone (00-landing-zone)

This template is based on the IBM Cloud Framework for Financial Services [reference architecture for VPC with Virtual Servers](https://cloud.ibm.com/docs/framework-financial-services?topic=framework-financial-services-vpc-architecture-detailed-vsi).

The terraform is derived from scripts in the *Deploy infrastructure as code for the IBM Cloud for Financial Services* Toolchain that you can find [here](https://cloud.ibm.com/devops/setup/deploy?repository=https%3A%2F%2Fca-tor.git.cloud.ibm.com%2Fopen-toolchain%2Flanding-zone&env_id=ibm:yp:ca-tor) or by navigating in your IBM Cloud Account to `DevOps->Toolchains->Create a Toolchain` and searching on the keyword *Financial*.  It is customized for the Quebec Government.

## Table of Contents

1. [Overview](#overview)
2. [Prerequisites](#prerequisites)
    - [Generating an SSH Key on Windows / Mac / Linux](#generating-an-ssh-key-on-windows--mac--linux)
2. [Running the scripts](#running-the-scripts)
3. [Variables provided in terraform.tfvars](#variables-provided-in-terraformtfvars)
4. [Configuration with override.json](#configuration-with-overridejson)
    - [Resource Groups](#resource-groups)
    - [Cloud Services](#cloud-services)
      - [Key Management](#key-management)
      - [Cloud Object Storage](#cloud-object-storage)
    - [VPC Infrastructure](#vpc-infrastructure)
      - [Network Access Control Lists](#network-access-control-lists)
      - [Subnets](#subnets)
      - [Default VPC Security Group](#default-vpc-security-group)
    - [Flow Logs](#flow-logs)
    - [Virtual Private Endpoints](#virtual-private-endpoints)
    - [Virtual Server Deployments](#virtual-sever-deployments)
      - [Boot Volume Encryption](#boot-volume-encryption)
      - [Virtual Server Image](#virtual-server-image)
      - [Virtual Server Profile](#virtual-server-profile)
      - [Additional Components](#additional-components)


---
## Overview

`00-landing-zone` can be used to create a fully customizable VPC environment. The defaults are configured for the Quebec Government, but can be further configured based on workload requirements.  This document describes the defaults and how to override those.

This pattern creates:

- A resource group for cloud services and for each VPC.
- Object Storage instances for [Network Flow Logs](https://cloud.ibm.com/docs/vpc?topic=vpc-flow-logs).
- A Key Protect instance with Key Rings and encryption keys used to encrypt Flow Logs stored in Object Storage buckets and Virtual Server Instance boot and data volumes
- Management and Workload Virtual Private Clouds (VPCs) connected by a [Transit Gateway](https://cloud.ibm.com/docs/transit-gateway?topic=transit-gateway-about).  There are workload VPCs for environments: dev, sable and production.  Note that the Management VPC only has a Virtual Server in Zone 1.  This would typically be used as a Bastion server or Jump server for Operations activities.
- A [Flow Log](https://cloud.ibm.com/docs/vpc?topic=vpc-flow-logs) collector for each VPC
- All necessary networking rules to allow communication
- Virtual Private Endpoint Gateways (https://cloud.ibm.com/docs/vpc?topic=vpc-about-vpe) for Cloud Object storage in each VPC
- A VPN Gateway in the Management VPC
- Virtual Server Instances (VSIs) in the Workload VPCs

 ![vsi](../../docs/images/vsi.png) 

## Prerequisites

Prequisites for all Terraform scripts in this package, please review [this README](../README.md)

In addition, you need a production and non-production ssh public/private key pair for access to your IBM Cloud Virtual Server Instances.

### Generating an SSH Key on Windows / Mac / Linux

1. In Windows, open up a Command Prompt.  For Mac and Linux, open up a terminal
2. Type the command:
   ``` 
   ssh-keygen -b 4096 -t rsa
   ```
3. Enter the file in which you would like to save the keys.
4. When it prompts for passphrase, just press `Enter`.
5. You should now have a private and public key file at the location you entered with the filename in step 3 above.  The public key will have the `.pub` extenstion.  You will need the contents of this file for the configuration of Secure Landing Zone.
6. To copy public key to the clipboard for future reference, type the command: 
   ```
   pbcopy < <name of SSH key>.pub
   ```

   Once provisioned, to `ssh` to a Virtual Server Instance, you can use the following command
   ```
   ssh root@<ip of instance> -i <private key filename>
   ```

## Running the scripts

To run the scripts locally, follow these steps:

3. Navigate to the [vsi](patterns/vsi) directory.
4. Provide your [terraform.tfvars file](patterns/vsi/terraform.tfvars) with required variables, such as prefix, region, etc.  See the rest of this document for the details on how to configure.
5. Review [override.json](patterns/vsi/override.json) to make sure it is configured as you want.
5. Provide your IBM Cloud API key through an environment variable (ex: export TF_VAR_ibmcloud_api_key="`<YOUR IBM Cloud API Key>)`"
6. Run `terraform init` to initialize the working directory and configuration.
7. Run `terraform plan` to preview the changes that Terraform plans to make to your infrastructure.
8. Run `terraform apply` to execute the plan to create or modify your infrastructure.
9. Once you no longer need the infrastructure, you can run `terraform destroy` to delete the resources.


## Variables provided in terraform.tfvars

Name                                | Type         | Description                                                                                                                                                                                                                                                                                                                                                     | Sensitive | Default
----------------------------------- | ------------ | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | --------- | --------------------------------------------------------
ibmcloud_api_key                    | string       | The IBM Cloud platform API key needed to deploy IAM enabled resources.                                                                                                                                                                                                                                                                                          | true      | 
TF_VERSION                          | string       | The version of the Terraform engine that's used in the Schematics workspace.                                                                                                                                                                                                                                                                                    |           | 1.3 or 1.4
prefix                              | string       | A unique identifier for resources. Must begin with a lowercase letter and end with a lowerccase letter or number. This prefix will be prepended to any resources provisioned by this template. Prefixes must be 16 or fewer characters.                                                                                                                         |           | 
ssh_public_key                      | string       | An [ssh public key](https://cloud.ibm.com/docs/vpc?topic=vpc-ssh-keys) | | 
region                              | string       | Region where VPC will be created. To find your VPC region, use `ibmcloud is regions` command to find available regions.                                                                                                                                                                                      
override                            | bool         | Override default values with custom JSON template. This uses the file `override.json` to allow users to create a fully customized environment.                                                                                                                                                                                                                  |           | true

---

## Configuration with override.json

The rest of the pattern customization is managed in [override.json](../00-landing-zone/patterns/vsi/override.json).  The full set of available attributes for each resource type can be found by examining [variables.tf in 00-landing-zone/landing-zone](../00-landing-zone/landing-zone/variables.tf).

Examples will follow in each section.

---

### Resource Groups

Resource groups are defined in [override.json](../00-landing-zone/patterns/vsi/override.json#L70).  This is the set of resource groups defined by default for the Quebec Landing Zone.

Name            | Description
----------------|------------------------------------------------
`<prefix>-slz-management-rg`     | Management Virtual Infrastructure Components
`<prefix>-slz-workload-rg`       | Workload Production Virtual Infrastructure Components
`<prefix>-slz-workload-dev-rg`   | Workload Development Environment Virtual Server Components
`<prefix>-slz-workload-sable-rg` | Workload Sandbox Environment Virtual Server COmponents
`<prefix>-slz-service-rg`        | Cloud Service Instances

Each of these resource groups will have the `prefix` variable and a hyphen prepended to the name (ex. `demo-slz-management-rg` if the prefix is `demo`).

If you navigate to  [override.json](../00-landing-zone/patterns/vsi/override.json#L70), you will see how this is defined:

```
    "resource_groups": [
        {
            "create": false,
            "name": "slz-service-rg",
            "use_prefix": true
        },
        {
            "create": true,
            "name": "slz-management-rg",
            "use_prefix": true
        },
        {
            "create": true,
            "name": "slz-workload-rg",
            "use_prefix": true            
        },
        {
            "create": true,
            "name": "slz-workload-sable-rg",
            "use_prefix": true            
        },
        {
            "create": true,
            "name": "slz-workload-dev-rg",
            "use_prefix": true
        }       
    ],
```

Notice the attributes for each resource group.  You can find the supported attributes in [variables.tf ](../00-landing-zone/landing-zone/variables.tf#L33).

```
variable "resource_groups" {
  description = "Object describing resource groups to create or reference"
  type = list(
    object({
      name       = string
      create     = optional(bool)
      use_prefix = optional(bool)
    })
  )

  validation {
    error_message = "Each group must have a unique name."
    condition     = length(distinct(var.resource_groups.*.name)) == length(var.resource_groups.*.name)
  }
}
```

The create parameter indicates whether to create the resource group, or if this is just providing a reference.  In the case of `slz-service-rg`, these resource group is created in [main.tf](../00-landing-zone/patterns/vsi/main.tf) so the `create` parameter is false.  The `use_prefix` parameter indicates whether to prepend the prefix to the name of the resource group.

---

### Cloud Services

This diagram shows the Cloud Services in the solution: 

* [Key Management](https://cloud.ibm.com/docs/key-protect?topic=key-protect-about) 
* [Cloud Object Storage](https://cloud.ibm.com/docs/cloud-object-storage?topic=cloud-object-storage-about-cloud-object-storage).


![services](../../docs/images/resources.png)

#### Key Management

By default a Key Protect instance is created unless the `hs_crypto_instance_name` variable is provided. Key Protect instances by default will be provisioned in the `<prefix>-service-rg` resource group.

Available Key Management parameters can be found in [variables.tf](../00-landing-zone/landing-zone/kms/variables.tf)

In [override.json](../00-landing-zone/patterns/vsi/override.json#L43) search for the `key_management` configuration.  Note that there's no `use_prefix` parameter, so in this case, the prefix must be hard-coded if you want it in the key_management, key_ring and key resource names.

---

##### Encryption Keys and Key Rings

Key Name                  | Key Ring Name            | Description
--------------------------|--------------------------|-------------------------------------------
`<prefix>-slz-flowlogs-prod-key`    | `<prefix>-slz-prod-ring`    | Landing Zone encryption key for production flow logs |
`<prefix>-slz-flowlogs-nonprod-key` | `<prefix>-slz-nonprod-ring` | Landing Zone encryption key for non-production flow logs |
`<prefix>-vsi-prod-volume-key`      | `<prefix>-slz-prod-ring`    | Landing Zone encryption key for production vsi volumes | 
`<prefix>-slz-nonprod-volume-key`   | `<prefix>-slz-nonprod-ring` | Landing Zone encryption key for non-production vsi volumes |



---

#### Cloud Object Storage

One Cloud Object Storage instance is created in the `<prefix>-service-rg` resource group.  This is used for buckets that capture network flow logs from each VPC.  

In [override.json](../00-landing-zone/patterns/vsi/override.json#L2) search for the `cos` configuration. Note that there's no `use_prefix` parameter. but the prefix is always prepended to the COS storage instance and bucket names.  Additionally, there is a `random_suffix` parameter on `cos` which causes it to generate a random suffix that is added to the end of the cos instance and bucket names.  This is useful because COS bucket names must be globally unique and sometimes cleanup can take a while.

Look for `cos` in [variables.tf](../00-landing-zone/landing-zone/variables.tf#487) for other optional attributes.  There are several that could be useful depending on your requirements, including the archive option.
 

Name            | Description
----------------|------------------------------------------------
`<prefix>-cos-<random-suffix>`           | Object storage

---

##### Object Storage Buckets

These buckets are for the network flow logs from each VPC.  **NOTE** You may want to set an expiration policy on the buckets as they quickly collect a lot of data.  Alternatively, you can set an archive policy to move data to "cold storage" tier.


Name                                             | Instance                       | Encryption Key                     | Description
-------------------------------------------------|--------------------------------|------------------------------------|---------------------------------------------
`<prefix>-management-bucket-<random-suffix>`     | `<prefix>-cos-<random-suffix>` | `<prefix>-slz-flowlogs-prod-key`   | Bucket for flow logs from Management VPC
`<prefix>-workload-bucket-<random-suffix>`       | `<prefix>-cos-<random-suffix>` | `<prefix>-slz-flowlogs-prod-key`   | Bucket for flow logs from Workload VPC
`<prefix>-workload-dev-bucket-<random-suffix>`   | `<prefix>-cos-<random-suffix>` | `<prefix>-slz-flowlogs-nonprod-key` | Bucket for flow logs from Workload Dev VPC
`<prefix>-workload-sable-bucket-<random-suffix>` | `<prefix>-cos-<random-suffix>` | `<prefix>-slz-flowlogs-nonprod-key` | Bucket for flow logs from Workload Sable VPC

---


### VPC Infrastructure

By default, four VPCs are created `<prefix>-management-vpc`, `<prefix>-workload-vpc`, `<prefix>-workload-dev-vpc` and `<prefix>-workload-sable-vpc`. All the components of each VPC are in a dedicated resource group.


![network](../../docs/images/network.png)


Public Gateways allow egress and are associated with a subnet.  By default, no Public Gateways are provisioned, but they can be added by updating the `use_public_gateways` parameter for specific zones on the `vpc` configuration and then adding `public_gateway: true` for subnets in a zone where you need the gateway.  

To see all the parameters available for VPC configuration see [variables.tf](./landing-zone/variables.tf#L159).

To add, remove, rename or modify VPCs in the solution, update the `vpc` configuration in [override.json](../00-landing-zone/patterns/vsi/override.json#L2)

This entry from `override.json` is for the Management VPC.  If you do not need this VPC, you can simply delete this block.  You can see that it includes configuration for:

* Default Security Group rules
* Flow Log bucket name for the VPC.  This name is cross-referenced in the `cos` configuration
* Network Access Control List (ACL) rules for an Access Control List called `management-acl`
* Names for the VPC and Default Route Table, Security Group and Network ACL
* Subnet configurations
* Public Gateways

```
"vpcs": [
        {
            "default_security_group_rules": [
  
            ],
            "flow_logs_bucket_name": "management-bucket",
            "network_acls": [
                {
                    "name": "management-acl",
                    "rules": [
                        {
                            "action": "allow",
                            "destination": "10.0.0.0/8",
                            "direction": "inbound",
                            "name": "allow-ibm-inbound",
                            "source": "161.26.0.0/16"
                        },
                        {
                            "action": "allow",
                            "destination": "10.0.0.0/8",
                            "direction": "inbound",
                            "name": "allow-all-network-inbound",
                            "source": "10.0.0.0/8"
                        },
                        {
                            "action": "allow",
                            "destination": "0.0.0.0/0",
                            "direction": "outbound",
                            "name": "allow-all-outbound",
                            "source": "0.0.0.0/0"
                        }
                    ]
                }
            ],
            "prefix": "management",
            "default_network_acl_name":"demo-management-default-acl",
            "default_security_group_name":"demo-management-default-sg",
            "default_routing_table_name":"demo-management-default-rt",             
            "resource_group": "demo-slz-management-rg",
            "subnets": {
                "zone-1": [
                    {
                        "acl_name": "management-acl",
                        "cidr": "10.10.10.0/24",
                        "name": "vsi-zone-1",
                        "public_gateway": false
                    },
                    {
                        "acl_name": "management-acl",
                        "cidr": "10.10.20.0/24",
                        "name": "vpe-zone-1",
                        "public_gateway": false
                    },
                    {
                        "acl_name": "management-acl",
                        "cidr": "10.10.30.0/24",
                        "name": "vpn-zone-1",
                        "public_gateway": false
                    }
                ],
                "zone-2": [
                    {
                        "acl_name": "management-acl",
                        "cidr": "10.15.10.0/24",
                        "name": "vsi-zone-2",
                        "public_gateway": false
                    },
                    {
                        "acl_name": "management-acl",
                        "cidr": "10.15.20.0/24",
                        "name": "vpe-zone-2",
                        "public_gateway": false
                    }
                ],
                "zone-3": [
                    {
                        "acl_name": "management-acl",
                        "cidr": "10.20.10.0/24",
                        "name": "vsi-zone-3",
                        "public_gateway": false
                    },
                    {
                        "acl_name": "management-acl",
                        "cidr": "10.20.20.0/24",
                        "name": "vpe-zone-3",
                        "public_gateway": false
                    }
                ]
            },
            "use_public_gateways": {
                "zone-1": false,
                "zone-2": false,
                "zone-3": false
            }
        },
```
---

#### Network Access Control Lists

A [Network Access Control List](https://cloud.ibm.com/docs/vpc?topic=vpc-using-acls) is created for each VPC to allow inbound communication within the network, inbound communication from IBM services, and to allow all outbound traffic.


Rule                        | Action | Direction | Source        | Destination 
----------------------------|--------|-----------|---------------|----------------
`allow-ibm-inbound`         | Allow  | Inbound   | 161.26.0.0/16 | 10.0.0.0/8
`allow-all-network-inbound` | Allow  | Inbound   | 10.0.0.0/8    | 10.0.0.0/8
`allow-all-outbound`        | Allow  | Outbound  | 0.0.0.0/0     | 0.0.0.0/0

**IMPORTANT:** Because the non-production workload VPCs are connected via Transit Gateway to the production workload VPC, the workload VPC Access Control List additionally has these deny rules so that traffic from the non-production environments cannot enter the production VPC.

Rule                        | Action | Direction | Source        | Destination 
----------------------------|--------|-----------|---------------|----------------
`deny-sable-inbound-1`      | Deny  | Inbound   | 10.40.0.0/16   | 10.0.0.0/8
`deny-sable-inbound-2`      | Deny  | Inbound   | 10.45.0.0/16   | 10.0.0.0/8
`deny-sable-inbound-3`      | Deny  | Inbound   | 10.50.0.0/16   | 10.0.0.0/8
`deny-dev-inbound-1`        | Deny  | Inbound   | 10.55.0.0/16   | 10.0.0.0/8
`deny-dev-inbound-2`        | Deny  | Inbound   | 10.60.0.0/16   | 10.0.0.0/8
`deny-dev-inbound-3`        | Deny  | Inbound   | 10.65.0.0/16   | 10.0.0.0/8


---

#### Subnets

Each VPC creates two tiers of subnets, each attached to the Network ACL created for that VPC. The Management VPC also has a subnet created for creation of the VPN Gateway

##### Management VPC Subnets

Subnet Tier | Zone 1 Subnet Name | Zone 1 CIDR   | Zone 2 Subnet Name | Zone 2 CIDR   | Zone 3 Subnet Name | Zone 3 CIDR   |
------------|--------------------|---------------|--------------------|---------------|--------------------|---------------|
`vsi`       | `vsi-zone-1`       | 10.10.10.0/24 | `vsi-zone-2`       | 10.15.10.0/24 | `vsi-zone-3`       | 10.20.10.0/24 |
`vpe`       | `vpe-zone-1`       | 10.10.20.0/24 | `vpe-zone-2`       | 10.15.20.0/24 | `vsi-zone-3`       | 10.20.20.0/24 |
`vpn`       | `vpn-zone-1`       | 10.10.30.0/24 |


##### Workload VPC Subnets

Subnet Tier | Zone 1 Subnet Name | Zone 1 CIDR   | Zone 2 Subnet Name | Zone 2 CIDR   | Zone 3 Subnet Name | Zone 3 CIDR   |
------------|--------------------|---------------|--------------------|---------------|--------------------|---------------|
`vsi`       | `vsi-zone-1`       | 10.25.10.0/24 | `vsi-zone-2`       | 10.30.10.0/24 | `vsi-zone-3`       | 10.35.10.0/24 |
`vpe`       | `vpe-zone-1`       | 10.25.20.0/24 | `vpe-zone-2`       | 10.30.20.0/24 | `vsi-zone-3`       | 10.35.20.0/24 |

##### Workload Dev VPC Subnets

Subnet Tier | Zone 1 Subnet Name | Zone 1 CIDR   | Zone 2 Subnet Name | Zone 2 CIDR   | Zone 3 Subnet Name | Zone 3 CIDR   |
------------|--------------------|---------------|--------------------|---------------|--------------------|---------------|
`vsi`       | `vsi-zone-1`       | 10.55.10.0/24 | `vsi-zone-2`       | 10.60.10.0/24 | `vsi-zone-3`       | 10.65.10.0/24 |
`vpe`       | `vpe-zone-1`       | 10.55.20.0/24 | `vpe-zone-2`       | 10.60.20.0/24 | `vsi-zone-3`       | 10.65.20.0/24 |

##### Workload Sable VPC Subnets

Subnet Tier | Zone 1 Subnet Name | Zone 1 CIDR   | Zone 2 Subnet Name | Zone 2 CIDR   | Zone 3 Subnet Name | Zone 3 CIDR   |
------------|--------------------|---------------|--------------------|---------------|--------------------|---------------|
`vsi`       | `vsi-zone-1`       | 10.40.10.0/24 | `vsi-zone-2`       | 10.45.10.0/24 | `vsi-zone-3`       | 10.50.10.0/24 |
`vpe`       | `vpe-zone-1`       | 10.40.20.0/24 | `vpe-zone-2`       | 10.45.20.0/24 | `vsi-zone-3`       | 10.50.20.0/24 |

---

#### Default VPC Security Group

The default VPC [Security Group](https://cloud.ibm.com/docs/security-groups?topic=security-groups-about-ibm-security-groups) allows all outbound traffic and inbound traffic from within the security group.

The default security group rules are defined in the `default_security_group_rules` attribute of the `vpcs` configuration in `override.json`.

Security Groups can also be defined for the interfaces on a specific VSI and will be used instead of the default.


### Flow Logs

Using the COS bucket provisioned for each VPC network, a [flow log collector](https://cloud.ibm.com/docs/vpc?topic=vpc-flow-logs) is created.

![flow logs](../../docs/images/flowlogs.png)

----

### Virtual Private Endpoints

Each VPC dyamically has a [Virtual Private Endpoint](https://cloud.ibm.com/docs/vpc?topic=vpc-about-vpe) address for the `cos` instance created in each zone of that VPC's `vpe` subnet tier.

![vpe](../../docs/images/vpe.png)

---

### Virtual Sever Deployments

Identical virtual server deployments are created on each zone of the `vsi` tier of each VPC. The number of these Virtual Servers can be changed using the `vsi_per_subnet` parameter of the `vsi` configuration in `override.json`.  The full set of variables for Virtual Servers that can be specified in `override.json` can be found in [here in variables.tf](./landing-zone/variables.tf#L258)

By default, there is one server in the VSI subnet in each zone for the Workload VPCs.  The Management VPC only has one Virtual Server in Zone 1.

#### Boot Volume Encryption

Boot volumes for each virtual server are encrypted using `<demo>-vsi-prod-volume-key` for the virtual servers in the workload VPC, and using `<demo>-vsi-nonprod-volume-key` for the virtuals servers in the Workload Dev and Workload Sable VPCs.  This allows you to manage the lifecycle of production and non-production keys separately and to separately authorize access to these keys.  The key is specified in the `boot_volume_encryption_key_name` parameter of the `vsi` configuration.

#### Virtual Server Image

To find available virtual servers in your region, use the IBM Cloud CLI Command:

```shell
ibmcloud is images
```

You can then specify this in the `image_name` parameter.  By default, the image used for all Virtual Servers is `ibm-ubuntu-18-04-6-minimal-amd64-2`.


#### Virtual Server Profile

To find available hardware configurations in your region, use the IBM Cloud CLI Command:

```shell
ibmcloud is instance-profiles
```

You can then specify this in the `machine_type` parameter.  By default, the profile used for all Virtual Servers is `cx2-4x8`.

#### Additional Components

Virtual Server components like additional block storage and Load Balancers can be configured using `override.json` and those variable definitions can be found [here in variables.tf](./landing-zone/variables.tf#304)
