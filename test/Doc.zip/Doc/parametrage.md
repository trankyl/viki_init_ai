#### Retour en arrière

* [Étapes du déploiement](etapes_deploiement.md)
* [Mise en contexte](mise_en_contexte.md)
* [Paramétrage de la plateforme](parametrage_plateforme.md)
* [Paramétrage des zones d'accueil](parametrage_za_charge.md)
* [Aperçu de l'étiquettage](tags.md)
* [Page d'accueil](../Readme.md)

# Aperçu du paramétrage du script V2

Le script V2.2 est conçu de façon modulaire et extensible, en utilisant le concept de "scénario" par rapport à l'adoption de certaines architectures de Zones d'accueil. Les scénarios se distinguent par rapport à l'arborescence de groupes d'administration et Zones d'accueil correspondantes. Il y a des scénario prédéfinis qui sont pris en charge, par exemple celui "base". Toutefois, avec un niveau suffisant d'expertise, les OP peuvent personnaliser le paramétrage en se définissant des scénarios spécifiques à leurs besoins. Pour le scénario "complexe", le paramétrage est très similaire sauf pour les ID des abonnements qui sont plus nombreux. En effet, fonctionnellement et d'un point de vue paramétrage, les deux scénarios sont identiques, mis à part le paramétrage "par défaut" qui peut être différent.

## 1. Paramétrage des scripts V2 pour le scénario "base" et "complexe"

À ce jour, les scénario "base" et "complexe" sont pris en charge par le script v2 et les paragraphes suivants en font référence. Pour le scénario "complexe" le paramétrage est très similaire avec deux différences dans le fichier de paramétrage (cei-complexe-param.yml) :

- Le routage inter périphérique (*inter-spoke*) par défaut se fait par le pare-feu dans le concentrateur réseau (*hub*).
- La hiérarchie des zones d'accueil déployées suit l'architecture déployée par l'ancienne version v1.1 du script.
- Il n'y a pas de zone de données sensibles donc c'est juste le plan P1 de Azure Defender qui est appliqué

En réalité il n'y a pas de contrainte pour le scénario complexe d'un point de vue paramétrage pour le rendre similaire au scénario de base d'un point de vue fonctionnalité.

Il y a plusieurs niveaux de paramétrage qui répondent à des besoins spécifiques.

Pour le scénario "base" voici les fichiers de paramétrage:


| Besoin                                                                                                                           | Occurrence  | Difficulté | Fichier de configuration          |
| ---------------------------------------------------------------------------------------------------------------------------------- | ------------- | ------------- | :---------------------------------- |
| Déploiement de scénarios prédéfinis (plateforme et zones d'accueil)                                                          | Obligatoire | Facile      | cei-base-param.yml                |
| Personnalisation du paramétrage Azure Defender                                                                                  | Optionnel   | Avancé     | cei-base-defender.yml             |
| Personnalisation du plan adressage                                                                                               | Optionnel   | Avancé     | cei-base-lz.yml                   |
| Personnalisation du routage                                                                                                      | Optionnel   | Avancé     | cei-base-routage.yml              |
| Personnalisation de la hiérarchie des groupes d'administration et des zones d'accueil                                           | Optionnel   | Avancé     | cei-base-hierarchie.yml           |
| Personnalisation des abonnements plateforme et zones d'accueil                                                                   | Optionnel   | Avancé     | cei-base-subscriptions.yml        |
| Personnalisation des règles NSG par sous-réseau                                                                                | Optionnel   | Avancé     | cei-base-nsg-custom.yml           |
| Personnalisation du paramétrage des machines virtuelles "relais" ("jump-box")                                                   | Optionnel   | Avancé     | cei-base-jb-vm.yml                |
| Paramétrage de la configuration automatique des VM de test dans les zones de charges (activer inclusion dans cei-base-main.yml) | Optionnel   | Avancé     | cei-base-test-vm.yml              |
| Rajout fichiers de paramétrage supplémentaire selon besoins                                                                    | Optionnel   | Avancé     | cei-base-main.yml                 |
| Paramétrage de l'affectation des stratégies intégrés (en dessous de policy/builtin/policy-assignment)                        | Optionnel   | Avancé     | parameters.assignbuiltin.yml      |
| Paramétrage de l'affectation des stratégies personnalisées(en dessous de policy/custom/assignments/policy)                    | Optionnel   | Avancé     | parameters.assigncustompolicy.yml |
| Paramétrage de l'affectation des initiatives personnalisées(en dessous de policy/custom/assignments/policy)                    | Optionnel   | Avancé     | parameters.assigncustompolicy.yml |

Pour le scénario "complexe le paramétrage est similaire:


| Besoin                                                                                                                           | Occurrence  | Difficulté | Fichier de configuration             |
| ---------------------------------------------------------------------------------------------------------------------------------- | ------------- | ------------- | :------------------------------------- |
| Déploiement de scénarios prédéfinis (plateforme et zones d'accueil)                                                          | Obligatoire | Facile      | cei-complexe-param.yml               |
| Personnalisation du paramétrage Azure Defender                                                                                  | Optionnel   | Avancé     | cei-complexe-defender.yml            |
| Personnalisation du plan adressage                                                                                               | Optionnel   | Avancé     | cei-complexe-lz.yml                  |
| Personnalisation du routage                                                                                                      | Optionnel   | Avancé     | cei-complexe-routage.yml             |
| Personnalisation de la hiérarchie des groupes d'administration et des zones d'accueil                                           | Optionnel   | Avancé     | cei-complexe-hierarchie.yml          |
| Personnalisation des abonnements plateforme et zones d'accueil                                                                   | Optionnel   | Avancé     | cei-complexe-subscriptions.yml       |
| Personnalisation des règles NSG par sous-réseau                                                                                | Optionnel   | Avancé     | cei-complexe-nsg-custom.yml          |
| Personnalisation du paramétrage des machines virtuelles "relais" ("jump-box")                                                   | Optionnel   | Avancé     | cei-complexe-jb-vm.yml               |
| Paramétrage de la configuration automatique des VM de test dans les zones de charges (activer inclusion dans cei-base-main.yml) | Optionnel   | Avancé     | cei-complexe-test-vm.yml             |
| Rajout fichiers de paramétrage supplémentaire selon besoins                                                                    | Optionnel   | Avancé     | cei-complexe-main.yml                |
| Paramétrage de l'affectation des stratégies intégrés (en dessous de policy/builtin/policy-assignment)                        | Optionnel   | Avancé     | parameters.assignbuiltin.yml         |
| Paramétrage de l'affectation des stratégies personnalisées(en dessous de policy/custom/assignments/policy)                    | Optionnel   | Avancé     | parameters.assigncustompolicy.yml    |
| Paramétrage de l'affectation des initiatives personnalisées(en dessous de policy/custom/assignments/policy)                    | Optionnel   | Avancé     | parameters.assigncustompolicyset.yml |

Les fichiers de paramétrage ci-bas sont communs pour tous les scénarios:


| Besoin                                                                                                                                                                                                   | Occurrence | Difficulté | Fichier de configuration |
| ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ------------ | ------------- | :------------------------- |
| Personnalisation d'étiquettes (*tags*)                                                                                                                                                                  | Optionnel  | Facile      | cei-tags.yml             |
| Personnalisation des groupes de contrôle d'accès (RBAC)                                                                                                                                                | Optionnel  | Avancé     | cei-rbac.yml             |
| Personnalisation du déploiement plateforme                                                                                                                                                              | Optionnel  | Avancé     | cei-platform.yml         |
| Personnalisation du déploiement périmètre                                                                                                                                                             | Optionnel  | Avancé     | cei-perimetre.yml        |
| Personnalisation avancé du paramétrage des zones de charge (pour des besoins très spéciaux et demandant un très haut niveau de maitrise du script)                                                  | Optionnel  | Avancé     | cei-tpl-landingzone.yml  |
| Personnalisation avancé du paramétrage des zones de charge (pour des besoins très spéciaux et demandant un très haut niveau de maitrise du script - par exemple les règles NSG et routage de base) | Optionnel  | Avancé     | cei-tpl-lzvars.yml       |


### 1.1 Paramétrage pour le déploiement du scénario prédéfini "base"

Les paramètres suivants doivent être configurés de façon obligatoire, avec chaque déploiement, dans le fichier cei-base-param.yml (pour plus de détails, voir le [scénario de déploiement](scenarios_deploiement.md)) :

* L'ID du *tenant* de l'organisme
* Des paramètres spécifiques au déploiement de la "plateforme" (voir aussi [paramétrage plateforme](parametrage_plateforme.md))
  * Les ID des abonnements plateforme
  * Les préfixes réseau assignés aux VNet des abonnements plateforme
  * La région où on veut déployer la plateforme
  * Le choix de déployer ou non certains abonnements "plateforme"
  * Le choix de déployer ou non certains services dans les abonnements "plateforme"
* Des paramètres spécifiques au déploiement des zones d'accueil pour les charges de travail (voir aussi [paramétrage zones de charge](parametrage_za_charge.md))
  * Les ID des abonnements pour les zones d'accueil
  * Optionnellement, l'ID de l'abonnement pour la zone "carrés de sable"
  * Le plan d'adressage pour les sous-réseaux dans les zones d'accueil

## 2. Personnalisation des étiquettes (*tags*)

Il existe 2 catégorie de paramétrage d'étiquettes, soit les étiquettes d'abonnement et les étiquettes de ressources.

### 2.1 Étiquettes d'abonnements

La hiéarchie des trois étiquettes "racine" (OrganisationClient, Environnement, Projet) qui est appliquée sur toutes les abonnements est défini dans un fichier json. Le fichier qui contient ce code est [subscription-tags-assignment.yml](../azure-pipeline/config/variables/scenario-base/policy/builtin/policy-assignment/subscription-tags-assignment.yml) pour le scénario de base et [subscription-tags-assignment.yml](../azure-pipeline/config/variables/scenario-complexe/policy/builtin/policy-assignment/subscription-tags-assignment.yml) pour le scénario complexe. Les étendues de l'application des politiques pour mettre en place ces tags diffère d'une étiquette à l'autre en raison du contexte de ceux-ci.

| Étiquette         | Étendue (Scope) | Contexte | Example de valeur |
| ------------------ | ---- | ---- | ----|
| OrganisationClient |  Groupe de gestion racine  | Le nom de l'organisation du client qui sera sur toutes les abonnement | EnvironnementOrganisationnel-CEI
| Environnement      |  Groupe de gestion    | Environnement des abonnements sous ce groupe de gestion     | Production |
| Projet             |  Abonnement | À quel projet l'abonnement est-il dédié | Projet 123 |

### 2.2 Étiquettes de ressource

Il y a trois groupes d'étiquettes par défaut, l'un pour la production, un pour l'environnement non-production et un pour dev/test. Ces groupe d'étiquettes sont mis autant sur les groupes de ressource que sur les ressources en soit.
Il faut savoir que les ressources vont toujours hérité de l'ensemble des étiquettes des groupe de ressources et que quatres de ces étiquettes sont obligatoires.


| Étiquette    | Valeurs possibles  |
| -------------- | ------ |
| Disponibilité | tropfaible, faible, modéré  |
| Intégrité       | tropfaible, faible, modéré |
| Confidentialité | tropfaible, faible, modéré |
| Criticité | sensible, nonsensible |

Il est possible de personnaliser et d'ajouter des étiquettes aux ressources déployées par le script, s'il y a des besoins particuliers additionnels (Autres façon de grouper les ressources pour des rapports de facturation, par exemple)
Pour plus de détails, voir la configuration des étiquettes.

## 3. Personnalisation des contrôles d'accès "par rôle"

Il y a cinq groupes d'usagers à prédéfinir; des rôles personnalisés (*custom*) prédéfinis seront assignés par défaut à ces groupes. Ces assignations sont définies dans le fichier cei-rbac.yml.


| Groupe usagers | Variable de l'ID du groupe         | Rôle personnalisé assigné |
| ---------------- | ------------------------------------ | ------------------------------ |
| NetOps         | var-principal-id-role-netops       | NetOps                       |
| SecOps         | var-principal-id-role-secops       | SecOps                       |
| DevOps         | var-principal-id-role-devops       | DevOps                       |
| AppOps         | var-principal-id-role-appops       | AppOps                       |
| Owner          | var-principal-id-role-subscr-owner | SubscriptionOwner            |

On peut aussi assigner des rôles prédéfinis, rajouter des groupes et des rôles.
Dans Azure, un rôle représente un groupe de permissions et ces rôles doivent être prédéfinis avant de rouler le pipeline rbac.yml. Pour plus de détails, voir la [documentation rbac](rbac.md).
