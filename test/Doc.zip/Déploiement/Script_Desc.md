# Description du script

## Zone d'accueil - infrastructure du script

Ici, le fonctionnement du script responsable du déploiement de la zone d'accueil OCI est décrit de manière détaillée pour faciliter sa compréhension, son entretien et l'améliorer.

* [Aperçu de la structure du script](#aperçu-de-la-structure-du-script)
* [Variables utilisées lors du paramétrage du déploiement](#variables-utilisées-lors-du-paramétrage-du-déploiement)
* [Modules du script](#modules-du-script)
  * [Module IAM](#module-iam)
    * [iam-compartment](#iam-compartment)
    * [iam-group](#iam-group)
    * [iam-policy](#iam_policies)
  * [Module Networking](#module-networking)
    * [drg](#drg)
    * [fortigate](#fortigate)
    * [vcn-basic](#vcn-basic)
    * [vcn-routing](#vcn-routing)
  * [Module Security](#module-security)
    * [bastion](#bastion)
    * [keys](#keys)
    * [vaults](#vaults)
* [Variables du script](#variables-du-script)
  * [Déclaration et définition des variables du script](#déclaration-et-définition-des-variables-du-script)
    * [Variables input](#variables-input)
* [Scripts de configuration](#scripts-de-configuration)
  * [Configuration](#configuration)
    * [iam_compartments](#iam-compartment)
    * [iam_groups](#iam-group)
    * [iam_policies](#iam_policies)
    * [net_drg](#net_drg)
    * [net_dmz](#net_dmz)
    * [net_dmz_nsgs](#net_dmz_nsgs)
    * [net_nsgs](#net_nsgs)
    * [net_vcn](#net_vcn)
    * [bastion](#bastion)
    * [mon_cloud_guard](#mon_cloud_guard)
    * [mon_flow_logs](#mon_flow_logs)
    * [mon_notifications](#mon_notifications)
    * [mon_oss_logs](#mon_oss_logs)

---  

### Aperçu de la structure du script  
  
Pour vous aider à comprendre plus rapidement la structure du référentiel, voici un aperçu des fichiers et dossiers dans le script importé.

Ce script de déploiement basé sur Terraform a deux modules racines et divers modules enfants. Les modules racines sont les dossiers `config` et `pre-config`. Ils font des appels aux modules enfants pour la création de ressources. Les modules enfants sont définis dans le dossier `modules`. En règle générale, les modules enfants parcourent les cartes d'objets créées par les modules racines.

| Répertoire / Sous-répertoire | Utilisation    |
| -------------------------------- | ----------------------- |
| `config`             | Module racine, à partir duquel se fait la création de toutes les ressources d'infrastructure requises, en utilisant les modules enfants définis dans le répertoire modules. |
| `config/locals.tf`  |  Les variables locales au module config sont définies dans ce fichier.   |
| `config/outputs.tf`  |  Définit les valeurs de sortie durant l'exécution d'un module enfant.  |
| `config/provider.tf`  |  Contient la configuration du fournisseur qui permettra à Terraform de se connecter à Oracle Cloud afin d'y provisionner des ressources.  |
| `config/quickstart-input.tfvars`  | Dans le cas où on utilise Terraform CLI, ce script Terraform permet de définir les paramètres de déploiement de la zone d'accueil Oracle, tels que la région, le locataire (*tenant*), le préfixe des noms de ressources, les adresses électroniques des administrateurs.  |
| `config/variables.tf`             | Script Terraform où sont définies les valeurs par défaut des variables locales du module config. |
| `Doc` | Contient les fichiers markdown inclus par le Readme.md de premier niveau.    |
| `images`  | Contient les images incluses dans la documentation markdown.  |
| `modules` | Contient les modules enfants Terraform pour le déploiement des ressources dans Oracle Cloud Infrastructure. |
| `pre-config`   | Pour un utilisateur qui n'est pas Administrateur du Tenant , ce dossier contient les configurations du module racine qui sera utilisé pour provisionner la zone d'accueil Oracle dans OCI. |
| `pre-config/locals.tf`  |  Contient les variables locales Terraform pour le module pre-config   |
| `pre-config/provider.tf`  |  Contient la configuration du fournisseur qui permettra à Terraform de se connecter à Oracle Cloud afin d'y provisionner des ressources  |
| `pre-config/variables.tf`   | Script Terraform où sont définies les valeurs par défaut des variables locales du module racine pre-config |
`scripts`  | Contient des outils autour de la gestion de la zone d'accueil Oracle      |
| `scripts/cis_reports.py`  |  script de validation de la conformité d'une zone d’accueil déployée  |
| `README.md`  |  Documentation markdown sur la zone d'accueil Oracle |

---  

Les noms de fichiers dans les modules racines sont explicites. Ils sont précédés d'une référence au nom de la section correspondante dans le document [CIS OCI Foundations Benchmark](https://www.cisecurity.org/benchmark/oracle_cloud/), suivi du service ou de la ressource OCI qu'ils implémentent. Par exemple,

* `iam_compartments.tf` fait référence à la section `IAM` et implémente des `compartiments`,  
* `net_vcn.tf` fait référence à la section `Networking` et implémente `VCN`.  
* `mon_notifications.tf` fait référence à la section `Surveillance` et implémente les `notifications`.  

Les modules racines ont également un fichier `locals.tf`, où la plupart des variables locales sont définies (notez que certaines sont définies directement dans les fichiers qui les utilisent). Les variables locales sont utilisées pour traiter les paramètres de déploiement et créer les entrées requises pour les modules enfants. Par exemple, de nombreux noms de ressources et mappages d'objets sont créés en tant que variables locales.

De petites personnalisations, telles que la modification des noms de ressources, la modification d'un groupe de sécurité réseau ou même l'ajout d'un nouveau sous-réseau à un VCN, peuvent être réalisées en modifiant les variables locales.

Afin de se connecter à Oracle Cloud et y provisionner des ressources, Terraform a besoin d'un fournisseur de service. Le fichier `provider.tf` contient la configuration pour interagir avec Oracle Cloud.

---
  
### Variables utilisées lors du paramétrage du déploiement  

Dans [la procédure de déploiement de la zone d'accueil Oracle](Deploi_Script.md), vous allez paramétrer un déploiement en définissant une pile du service Oracle Resource Management (ORM).

Les variables suivantes dans le fichier [variables.tf](../../config/variables.tf) du module racine sont affectées lors du paramétrage :

| Champ dans la Pile ORM   | Nom Variable   |
| ----------------------   | -----------------------  |
| `Région`                          | region                   |
| `Préfixe dans le nom des ressources déployées`                   | service_label            |
| `Déploiement dans un compartiment englobant ?`   | use_enclosing_compartment            |
| `Nom du compartiment englobant`  | existing_enclosing_compartment_ocid |
| `CRÉER ou RÉ-UTILISER des stratégies dans le compartiment racine ?`  | policies_in_root_compartment |
| `Utiliser les groupes d'utilisateurs existants ?`  | use_existing_groups |
| `Liste des plages d’adresse CIDR pour les réseaux virtuels dans le compartiment Production`  | prod_vcn_cidrs |
| `Liste des plages d’adresse CIDR pour les réseaux virtuels dans le compartiment non-production`  | nonprod_vcn_cidrs |
| `Liste des plages d’adresse CIDR pour les réseaux virtuels dans le compartiment carré de sable`  | sandbox_vcn_cidrs |
| `Liste des plages d’adresse CIDR pour les réseaux virtuels dans le compartiment Non classifié`  | unclassified_vcn_cidrs |
| `Nom personnalisé du réseau virtuel infonuagique (DMZ) dans le compartiment Connectivité`  | nom_vcn_dmz |
| `Noms personnalisés des réseaux virtuels infonuagiques en production`  | prod_vcn_names |
| `Noms personnalisés des réseaux virtuels infonuagiques en non-production`  | nonprod_vcn_names |
| `Noms personnalisés des réseaux virtuels infonuagiques dans le Carré de sable`  | sandbox_vcn_names |
| `Noms personnalisés des réseaux virtuels infonuagiques dans la zone non classifiée`  | unclassified_vcn_names |
| `Connecter les réseaux virtuels infonuagiques de la Zone d’Accueil au réseau sur site ?`  | is_vcn_onprem_connected |
| `Identifiant OCID d’une passerelle de routage dynamique existante`  | existing_drg_id |
| `Déployer une architecture en étoile ( Hub & Spoke ) ?`  | hub_spoke_architecture |
| `Utiliser le réseau virtuel infonuagique de la zone démilitarisée pour y déployer des pares-feux tiers ?`  | dmz_for_firewall |
| `Déployer un pare-feu Fortigate dans la zone démilitarisée ?`  | use_fortigate |
| `Clé publique SSH pour les instances Fortigate`  | ssh_public_key |
| `Nombre de sous-réseaux dans le réseau virtuel infonuagique de la zone démilitarisée (DMZ)`  | dmz_number_of_subnets |
| `Taille de la plage d’adresses CIDR du sous-réseau DMZ`  | dmz_subnet_size |
| `Bloquer l'accès à Internet ?`  | no_internet_access |
| `Liste des plages adresses IP (dans la notation CIDR ), du réseau sur-site`  | onprem_cidrs |
| `Plage d’adresses IP (dans la notation CIDR) du réseau sur site autorisées à se connecter via SSH`  | onprem_src_ssh_cidrs |
| `Adresses électroniques des administrateurs réseau`  | network_admin_email_endpoints |  
| `Adresses électroniques des administrateurs de la sécurité`  | security_admin_email_endpoints |  
| `État de la configuration de Cloud Guard`  | cloud_guard_configuration_status |  
| `Créer un Service Connector Hub pour les journaux d'audit (cela peut entraîner des frais)`  | create_service_connector_audit |  
| `Cible du Service Connector Hub` (pour Audit Logs)  | service_connector_audit_target |
| `État du Service Connector Hub` (pour Audit Logs) | service_connector_audit_state |
| `Préfixe du nom d'objet pour la cible de type stockage d'objets` (pour Audit Logs) | sch_audit_objStore_objNamePrefix |
| `Créer un Service Connector Hub pour les journaux de flux de réseaux virtuels (cela peut entraîner des frais)`  | create_service_connector_vcnFlowLogs |  
| `Cible du Service Connector Hub` (pour VCN Flow Logs) | service_connector_vcnFlowLogs_target |
| `État du Service Connector Hub` (pour VCN Flow Logs) | service_connector_vcnFlowLogs_state |
| `Préfixe du nom d'objet pour la cible de type stockage d'objets` (pour VCN Flow Logs) | sch_vcnFlowLogs_objStore_objNamePrefix |
| `Activer l'analyse des vulnérabilités ?`  | vss_create |
| `Quand scanner ? HEBDOMADAIRE (WEEKLY) ou QUOTIDIEN (DAILY).`  | vss_scan_schedule |
| `Journée d’analyse`  | vss_scan_day |  
| `Jeton d'accès personnel au dépôt privé de configurations Fortigate`  | jeton_access_repos_fortigate | 
| `Nom utilisateur pour dépôt de configurations Fortigate`  | nom_utilisateur_repos_fortigate | 
| `Courriel utilisateur pour dépôt de configurations Fortigate`  | email_utilisateur_repos_fortigate | 
| `Nom Organisation Azure DevOps ayant les fichiers de configurations pour deploiement de Fortigate`  | organisation_azuredevops_fortigate |   
| `Nom du projet Azure DevOps ayant les fichiers de configurations pour deploiement de Fortigate`  | projet_azuredevops_fortigate |   
| `Nom du repos Azure DevOps ayant les fichiers de configurations pour deploiement de Fortigate`  | nom_repos_fortigate |    
  
---  

### Modules du script

Ici, le fonctionnement du script responsable du déploiement de la zone d'accueil OCI est décrit de manière détaillée pour faciliter sa compréhension, son entretien et l'améliorer.  

#### Module IAM

---

##### iam-compartment

* Définition

Ce module est responsable de la création des ressources de type compartiment en utilisant l'interface OCI.

* Structure

Ce module est composé de trois éléments, chacun défini dans un fichier séparé.

###### [variables.tf](../../modules/iam/iam-compartment/variables.tf)  

Le premier fichier, *variables.tf*, définit la structure des données où les paramètres seront reçus pour la création de tous les compartiments demandés. La structure des données qui est définie dans ce dossier est une collection de type mappe (*Map*) où chaque élément est composé d'une clé unique qui est le nom du compartiment et qui est associée à une valeur de celle-ci. Cette valeur est un objet de type Compartiment qui regroupe les attributs demandés pour sa création en utilisant la ressource *oci_identity_compartment*.
  
   Paramètres d'entrée au module :

   | variable | description |
   |------|-------------|
   | compartments | la liste des compartiments à créer

      map(
         object(
            {
               parent_id     = string
               name          = string
               description   = string
               enable_delete = string
            }
         )
      )

On peut visualiser graphiquement la structure comme ceci :

La structure des données de type *Map* où chaque registre est le nom du compartiment comme clé et un objet de type compartiment qui regroupe les attributs du compartiment à créer.

Exemple :  

   clé : prod-cmp  

      {
         parent_id     : top-cmp
         name          : cmp-prod-001
         description   : production cmp
         enable_delete : true
      }

   clé : sandbox-cmp  

      {
         parent_id     : top-cmp
         name          : cmp-casae-001
         description   : sand box  cmp
         enable_delete : true
      }

Objet (Compartiment) : regroupe les attributs pour la création d'un compartiment en OCI; est défini dans le fichier *variables.tf*.

      object(
         {
            parent_id     = string
            name          = string
            description   = string
            enable_delete = string
         }
      )

###### [main.tf](../../modules/iam/iam-compartment/main.tf)  

Le deuxième fichier est *main.tf* où est située la logique de la création des compartiments.

###### [outputs.tf](../../modules/iam/iam-compartment/outputs.tf)  

Le troisième fichier, *outputs.tf*, définit les compartiments à présenter durant l'exécution de ce module.

   | variable | description |
   |------|-------------|
   | compartments | compartiments, dans var.compartments|

* Fonctionnement

Le code intéressé dans la création des compartiments d'OCI appelle le module *iam-compartiment* en passant comme paramètre une *Map* avec la structure présentée et les attributs de chaque compartiment à créer.

Une fois les paramètres passés à ce module, la logique définie dans le fichier *main.tf* est exécutée, où une boucle (*for*) prend l'élément de la Mappe pour ensuite appeler la ressource *oci_identity_compartment* avec les données de cet élément pour la création du compartiment. Il en va ainsi jusqu'au dernier élément de la *Map*.

Une fois l'exécution de la logique de ce module (main.tf) terminée, le fichier *output* est exécuté là où il est défini qu'il présente
les données des compartiments qui ont été envoyées pour les créer.

* Ressource associée

   | Ressource |
   |------|
   | [oci_identity_compartment](https://registry.terraform.io/providers/hashicorp/oci/latest/docs/resources/identity_compartment) |

##### iam-group

* Définition

Ce module est responsable de créer les groupes et d'assigner les utilisateurs au groupe pertinent, donc de créer les adhésions.

* Structure

Ce module se compose de trois éléments, chacun défini dans un fichier séparé.

###### [variables.tf](../../modules/iam/iam-group/variables.tf)  

Ce premier fichier, variables.tf, définit la structure des données où les paramètres seront reçus pour
la création de tous les groupes demandés. La structure des données qui est définie dans ce dossier est une collection de type *Map* où chaque élément est composé d'une clé unique qui est le nom du group et
qui est associée à une valeur de celle-ci. Cette valeur est un objet de type Group qui regroupe les attributs demandés pour sa création en utilisant de ressource *oci_identity_group*.

Il est important de noter que la liste des utilisateurs à assigner à ce groupe vient dans l'attribut *user_ids*.

      map(
         object(
            {
               description  = string,
               user_ids     = list(string),
               defined_tags = map(string),
            }
         )
      )

Le deuxième paramètre attendu par ce composant est tenancy_ocid, qui est l'OCID de la location (*tenancy*) où les groupes seront créés.

   | variable | description |
   |------|-------------|
   | groups | la liste des groupes à créer|
   | tenancy\_ocid | OCID du tenancy.|

###### [main.tf](../../modules/iam/iam-group/main.tf)

Ce deuxième fichier est *main.tf* où est située la logique de la création des groupes et qui permet d'assigner les utilisateurs aux groupes.

###### [outputs.tf](../../modules/iam/iam-group/outputs.tf)

Ce troisième fichier, *outputs.tf*, définit les valeurs de sortie durant l'exécution de ce module. C'est pour ce module qu'il y a la liste de groupes créés et celle des utilisateurs ajoutés à leur groupe respectif.

   | variable | description |
   |------|-------------|
   | groups | la liste des groupes créés|
   | memberships | la liste des utilisateurs ajoutés à un groupe respectif  |

* Fonctionnement

Le code intéressé dans la création des groupes d'OCI appelle le module *iam-group* en passant comme paramètre une *Map* avec les attributs de chaque groupe à créer et l'OCID du *tenancy* où ils seront créés.
Une fois les paramètres passés à ce module, la logique définie dans le fichier *main.tf* est exécutée.

La logique consiste à :

1. En premier lieu, une boucle (*for*) est exécutée au travers de la *Map* qui est passée comme paramètre contenant tous les groupes à créer. Dans cette boucle, chaque élément (groupe) de la *Map* est obtenu et est créé en appelant la ressource *oci_identity_group* avec les paramètres du groupe. Chaque groupe créé est gardé dans la variable locale *groups*.
2. En utilisant la source de données (*Data Source*) *oci_identity_users*, une liste de tous les utilisateurs est obtenue dans le compartiment reçu comme paramètre. La liste est gardée dans la variable locale *users*.
3. Ensuite, la *Map* des groupes passés est parcourue au travers d'une boucle (*for*) et la liste des utilisateurs à assigner à chaque groupe est obtenue. La liste est regroupée par nom de groupe comme *Map* dans une liste locale dénommée *group_memberships*. Ensuite, la fonction *flatten* est appliquée pour regrouper tous les *arrays* de la liste dans un seul *array*.
   Exemple :  
      [{g1=u1,u2,u3}],[{g2=u4,u5,u6}],[{g3=u7}] => [{g1=u1,u2,u3},{g2=u4,u5,u6},{g3=u7}]

4. Ensuite, dans une boucle (*for*), la variable locale group_memberships, qui a été créée lors de l'étape précédente avec la liste des adhésions, est parcourue. Dans cette boucle, chaque élément est obtenu (adhésions par groupe) et l'adhésion est créée en appelant la ressource *oci_identity_user_group_membership* pour chaque utilisateur.
   Pour effectuer la résolution de l'identifiant du groupe à l'intérieur de la boucle, la variable locale *groups* est utilisée; elle qui contient le résultat de la création des groupes de la première étape. Pour résoudre l'identifiant de l'utilisateur, la variable locale *users* est utilisée et elle contient le résultat de la requête de la deuxième étape.

4- Ressource associée

   | Ressource |
   |------|
   | [oci_identity_group](https://registry.terraform.io/providers/hashicorp/oci/latest/docs/resources/identity_group) |
   | [oci_identity_user_group_membership](https://registry.terraform.io/providers/hashicorp/oci/latest/docs/resources/identity_user_group_membership) |

   | Data Source |
   |------|
   | [oci_identity_users](https://registry.terraform.io/providers/hashicorp/oci/latest/docs/data-sources/identity_users) |

#### iam-policy

1- Définition

Ce module est responsable de créer les stratégies (*policies*) et assigner les déclarations (*statements*).

2- Structure

Ce module comporte trois éléments, chacun défini dans un fichier séparé.

##### [variables.tf](../../modules/iam/iam-policy/variables.tf)

Ce premier fichier, *variables.tf*, définit la structure des données où les paramètres seront reçus pour
la création de toutes les stratégies (*policies*) demandées. La structure des données qui est définie dans ce dossier est une collection de type *Map* où chaque élément est composé d'une clé unique qui est le nom de la stratégie (*policy*) et
qui est associée à une valeur de celle-ci. Cette valeur est un objet de type *Policy* qui regroupe les attributs demandés pour sa création en utilisant de ressource *oci_identity_policy*.

Il est important de noter que la liste des déclarations (*statements*) à assigner à cette stratégie (*policy*) vient dans l'attribut *statements*.

      map(
         object(
            {
               description  = string
               compartment_id = string
               statements = list(string)<br>  
            }
         )
      )

   | variable | description |
   |------|-------------|
   | policies | la liste des stratégies (*policies*) à créer

##### [main.tf](../../modules/iam/iam-policy/main.tf)

Ce deuxième fichier est *main.tf* où est située la logique de la création des stratégies (*policies*) et qui permet d'assigner les déclarations (*statements*).

##### [outputs.tf](../../modules/iam/iam-policy/outputs.tf)

Ce troisième fichier, *outputs.tf*, définit les valeurs de sortie durant l'exécution de ce module. C'est pour ce module qu'il y a la liste de stratégies (*policies*) créées.

   | variable | description |
   |------|-------------|
   | policies | la liste des stratégies (*policies*) créées  

3- Fonctionnement

Le code intéressé dans la création des stratégies (*policies*) appelle le module *iam-policy* en passant comme paramètre une *Map* avec les attributs de chaque stratégie (*policy*) à créer et l'OCID du *tenancy* où ils seront créés.

Une fois les paramètres passés à ce module, la logique définie dans le fichier *main.tf* est exécutée.

La logique consiste en une boucle FOR qui est exécutée au travers de la *Map* qui est passée comme paramètre contenant toutes les stratégies (*policies*) à créer. Dans cette boucle, chaque élément (*policy*) de la *Map* est obtenu et est créé en appelant la ressource *oci_identity_policy* avec les paramètres de la stratégie (*policy*).

4- Ressource associée

   | Ressource |
   |------|
   | [oci_identity_policy](https://registry.terraform.io/providers/hashicorp/oci/latest/docs/resources/identity_policy) |

### Module Networking

---

#### drg

1. Définition

   Ce module est responsable de créer la passerelle de routage dynamique (DRG) dans le compartiment spécifié.

2. Structure

   Ce module comporte trois éléments, chacun défini dans un fichier séparé.

##### [variables.tf](../../modules/network/drg/variables.tf)

   Ce premier fichier, *variables.tf*, définit la structure des données où les paramètres seront reçus pour
   la création de la DRG demandée. La structure des données qui est définie dans ce dossier est constituée des attributs demandés pour sa création en utilisant la ressource *oci_core_drg*.

   | variable | description |
   |------|-------------|
   | compartment\_id | OCID du compartiment où la DRG sera créée |
   | is\_create\_drg | si une DRG doit être créée ou non |
   | service\_label | étiquette à utiliser comme partie du nom de la ressource |

##### [main.tf](../../modules/network/drg/main.tf)

   Ce deuxième fichier est *main.tf* où est située la logique de la création de la DRG dans le compartiment.

      resource "oci_core_drg" "this" {
         count          = var.is_create_drg == true ? 1 : 0
         compartment_id = var.compartment_id
         display_name   = "drg-${var.service_label}"
      }

##### [outputs.tf](../../modules/network/drg/outputs.tf)

   Ce troisième fichier, *outputs.tf*, définit les valeurs de sortie durant l'exécution de ce module. C'est pour ce module que le *DRG* est créé. Si le DRG n'a pas été créé, la sortie est *null*.

   | variable | description |
   |------|-------------|
   | drg | attributs du *drg* créé

3- Fonctionnement

   Le code intéressé dans la création d'une DRG appelle le module *drg* en passant comme paramètres les attributs de la *DRG* à créer.
   Une fois les paramètres passés à ce module, la logique définie dans le fichier *main.tf* est exécutée.

   La logique consiste à appeler la ressource *oci_core_drg* avec les paramètres *compartment\_id* et *service\_label*, si la variable *is\_create\_drg* est *true*. Si la variable *is\_create\_drg* est false, la ressource ne sera pas créée.

4- Ressource associée

   | Ressource |
   |------|
   | [oci_core_drg](https://registry.terraform.io/providers/hashicorp/oci/latest/docs/resources/core_drg) |

#### FortiGate  

1. Définition

   Ce module permet de créer et de configurer automatiquement deux instances de pare-feu *FortiGate* dans le compartiment de connectivité, plus précisément dans le sous-réseau *snetr-vcn-cmp-conne-mgmt-cam1-001* du réseau virtuel infonuagique *vcn-cmp-conne-conce-cam1-001*.

2. Structure

   Ce module consiste en différents éléments, chacun défini dans un fichier séparé.

##### [variables.tf](../../modules/network/fortigate/variables.tf)

   Ce premier fichier, *variables.tf*, définit les paramètres pour la création du *Fortigate* demandé. La ressource *"oci_core_instance* va utiliser ces paramètres pour déployer les instances de FortiGate.

   | variable | description |type | valeur par défaut |
   |------|-------------|-------------|-------------|
   | mp\_subscription_enabled | Spécifie si on doit s'abonner à la place de marché (*Marketplace*) | Booléen | true |  
   | mp\_listing\_id | Identifiant OCID de l'image du Fortigate utilisée depuis la place de marché. La valeur par défaut correcpond à FortiOS 7.0.5 | Chaîne de caractères | ocid1.image.oc1..aaaaaaaasqn4zerim4l4mmmilnmcj5npl7mam7abpzekiwsyoc5b7plevula |
   | mp\_listing\_resource\_version |  Version de l'image du FortiGate utilisée depuis la place de marché. La valeur par défaut correspond à FortiOS 7.0.5 | Chaîne de caractères | 7.0.5_SR-IOV_Paravirtualized_Mode |
   | tenancy_ocid |  Identifiant OCID du locataire Oracle dans lequel sera déployé le pare-feu FortiGate | Chaîne de caractères | Aucune |
   | network_compartment |  Identifiant OCID du compartiment dans lequel sera déployé le pare-feu FortiGate | Chaîne de caractères | Aucune |
   | drg_ocid |  Identifiant OCID de la passerelle de routage dynamique dans la zone d'accueil | Chaîne de caractères | Aucune |
   | firewall_vcn |  Identifiant OCID du réseau virtuel qui hébergera les pare-feux | Chaîne de caractères | Aucune |
   | spoke_vcns |  Liste des identifiants OCID des périphériques (*spokes*) | Liste | Aucune |
   | vm_compute_shape | Code du modèle de machine virtuelle à instancier | Chaîne de caractères | VM.Standard2.4 |
   | vm_display_name | Préfixe dans le nom de l'instance de la machine virtuelle | Chaîne de caractères | FortiGate-Firewall |
   | vm_flex_shape_ocpus | Nombre de OCPU dans l'instance de machine virtuelle | Entier | 4 |
   | ssh_public_key | Clé publique SSH pour les instances FortiGate. | Chaîne de caractères | Aucune |
   | instance_launch_options_network_type | Type d'attachement des cartes d'interface réseau (NIC) | Chaîne de caractères | PARAVIRTUALIZED |
   | availability_domain_name | Nom du domaine de disponibilité | Chaîne de caractères | Aucune |
   | service_label | Préfixe à ajouter au nom des ressources créées | Chaîne de caractères | Aucune |
   | fgt_byol_license_files  | liste optionnelle de Nom+extension des fichiers licences FortiGate BYOL. Les fichiers licences doivent être déposés dans le dossier **modules/network/fortigate**  | Liste de chaînes de caractères | ["license1.lic", "license2.lic"] |
   | dynamic_group_description | Description du groupe dynamique | Chaînes de caractères | Dynamic Group to Support Firewall HA |
   | dynamic_group_name | Nom du groupe dynamique | Chaînes de caractères | firewall-ha-dynamic-group |
   | dynamic_group_policy_description | Description du groupe dynamique sur les stratégies | Chaînes de caractères | Dynamic Group Policy for Firewall HA |
   | dynamic_group_policy_name | Nom du groupe dynamique sur les stratégies | Chaînes de caractères | firewall-ha-dynamic-group-policy |

##### [userdata.tpl](../../modules/network/fortigate/userdata.tpl)

   Ce fichier contient le script qui était utilisé pour la configuration manuelle des instances Fortigate déployées.

   Ce fichier sera appelé par [compute.tf](../modules/network/fortigate/compute.tf) qui va automatiser la configuration des instances FortiGate.

      metadata = {
         ssh_authorized_keys = var.ssh_public_key
         user_data = base64encode(templatefile("${path.module}/userdata.tpl", {
            license_file                         = fileexists("${path.module}/${var.fgt_byol_license_files[count.index]}") ? "${file("${path.module}/${var.fgt_byol_license_files[count.index]}")}" : ""
            compute-compartment-ocid             = var.network_compartment
            fgt_vm_name                          = "FortiGate-${count.index+1}"
            fgt_ha_priority                      = (count.index+1)*100
            fgt_ha_peer_ip                       = cidrhost ( data.oci_core_subnets.dmz_vcn_subnets_ha.subnets.0.cidr_block, 11+((count.index+1)%2) )
            fgt_ha_ip                            = cidrhost ( data.oci_core_subnets.dmz_vcn_subnets_ha.subnets.0.cidr_block, 11+count.index )
            fgt_ha_ip_mask                       = cidrnetmask ( data.oci_core_subnets.dmz_vcn_subnets_ha.subnets.0.cidr_block )
            fgt_mgmt_ip                          = cidrhost ( data.oci_core_subnets.dmz_vcn_subnets_mgmt.subnets.0.cidr_block, 11+count.index )
            fgt_mgmt_ip_mask                     = cidrnetmask ( data.oci_core_subnets.dmz_vcn_subnets_mgmt.subnets.0.cidr_block )
            fgt_mgmt_ip_gw                       = data.oci_core_subnets.dmz_vcn_subnets_mgmt.subnets.0.virtual_router_ip
            fgt_untrust_floating_private_ip      = cidrhost ( data.oci_core_subnets.dmz_vcn_subnets_outdoor.subnets.0.cidr_block, 10 )
            fgt_untrust_floating_private_ip_mask = cidrnetmask ( data.oci_core_subnets.dmz_vcn_subnets_outdoor.subnets.0.cidr_block )
            fgt_untrust_gw                       = data.oci_core_subnets.dmz_vcn_subnets_outdoor.subnets.0.virtual_router_ip
            fgt_trust_floating_private_ip        = cidrhost ( data.oci_core_subnets.dmz_vcn_subnets_indoor.subnets.0.cidr_block, 10 )
            fgt_trust_floating_private_ip_mask   = cidrnetmask ( data.oci_core_subnets.dmz_vcn_subnets_indoor.subnets.0.cidr_block )
            fgt_trust_gw                         = data.oci_core_subnets.dmz_vcn_subnets_indoor.subnets.0.virtual_router_ip
            tenancy-ocid                         = var.tenancy_ocid
            spoke_vcns                           = data.oci_core_vcn.spokes
         }))
      }

##### [compute.tf](../../modules/network/fortigate/compute.tf)

   Le fichier *compute.tf* contient la logique de création et de configuration d'une instance FortiGate dans le compartiment connectivité.  

   Ce fichier s'appuie sur :

* les paramètres de déploiement des FortiGate définis dans le fichier [variables.tf](../modules/network/fortigate/variables.tf).
* le fichier [userdata.tpl](../modules/network/fortigate/userdata.tpl) qui contient les configurations à faire sur une instance FortiGate.  

      resource "oci_core_instance" "firewall-vms" {
         depends_on = [oci_core_app_catalog_subscription.mp_image_subscription]
         count      = 2
      }

##### [locals.tf](../../modules/network/fortigate/locals.tf)

   Les valeurs des variables locales sont définies dans ce fichier, Les variables locales sont des variables qui pourront être utilisées seulement dans ce module.  

      locals {
         dmz_subnet_names = ["snetr-vcn-cmp-conne-publ-cam1-001", "snetr-vcn-cmp-conne-prive-cam1-001", "snetr-vcn-cmp-conne-mgmt-cam1-001", "snetr-vcn-cmp-conne-ha-cam1-001", "snetr-vcn-cmp-conne-diag-cam1-001"]
         dmz_vcn_name = "vcn-cmp-conne-conce-cam1-001"

         # local.use_existing_network defined in network.tf and referenced here
         use_existing_network = true
         
         ### Marketplace
         mp_subscription_enabled  = var.mp_subscription_enabled ? 1 : 0
         listing_id               = var.mp_listing_id
         listing_resource_id      = var.mp_listing_resource_id
         listing_resource_version = var.mp_listing_resource_version
         is_flex_shape            = var.vm_compute_shape == "VM.Standard.E3.Flex" ? [var.vm_flex_shape_ocpus] : []
         }

##### [marketplace.tf](../../modules/network/fortigate/marketplace.tf)

   Le fichier *marketplace.tf* permet de :  

* d'obtenir les termes de la machine virtuelle, dont les caractéristiques sont définies dans *variables.tf* :  

      resource "oci_core_app_catalog_listing_resource_version_agreement" "mp_image_agreement" {
         count = local.mp_subscription_enabled

         listing_id               = local.listing_id
         listing_resource_version = local.listing_resource_version
      }

* d'accepter les termes de l'image de la machine virtuelle, de souscrire à l'agrément et de placer l'image dans un compartiment particulier :  

      resource "oci_core_app_catalog_subscription" "mp_image_subscription" {
         count = local.mp_subscription_enabled
         compartment_id           = var.network_compartment
         eula_link                = oci_core_app_catalog_listing_resource_version_agreement.mp_image_agreement[0].eula_link
         listing_id               = oci_core_app_catalog_listing_resource_version_agreement.mp_image_agreement[0].listing_id
         listing_resource_version = oci_core_app_catalog_listing_resource_version_agreement.mp_image_agreement[0].listing_resource_version
         oracle_terms_of_use_link = oci_core_app_catalog_listing_resource_version_agreement.mp_image_agreement[0].oracle_terms_of_use_link
         signature                = oci_core_app_catalog_listing_resource_version_agreement.mp_image_agreement[0].signature
         time_retrieved           = oci_core_app_catalog_listing_resource_version_agreement.mp_image_agreement[0].time_retrieved

         timeouts {
            create = "20m"
         }
      }

* d'obtenir l'image de la machine virtuelle à instancier :

      data "oci_core_app_catalog_subscriptions" "mp_image_subscription" {
         count = local.mp_subscription_enabled

         compartment_id = var.network_compartment
         listing_id     = local.listing_id

         filter {
            name   = "listing_resource_version"
            values = [local.listing_resource_version]
         }
      }

##### [network.tf](../../modules/network/fortigate/network.tf)

   Le fichier *network.tf* permet de :

* Créer une table de routage du *VCN Ingress* vers le Hub :

      resource "oci_core_route_table" "vcn_ingress_route_table" {
         compartment_id = var.network_compartment
         vcn_id         = var.firewall_vcn
         display_name   = "VCN-INGRESS"
         route_rules {
            destination       = "0.0.0.0/0"
            destination_type  = "CIDR_BLOCK"
            network_entity_id = oci_core_private_ip.cluster_indoor_ip.id
         }
      }

* Attacher une passerelle de routage dynamique (DRG) vers le Hub :  

      resource "oci_core_drg_attachment" "hub_drg_attachment" {
         drg_id             = var.drg_ocid
         # vcn_id             = local.use_existing_network ? var.vcn_id : oci_core_vcn.hub.0.id
         display_name       = "attae-vcn-cmp-conne-conce-cam1-001-to-drg-cmp-conne-cam1-001"
         drg_route_table_id = oci_core_drg_route_table.from_firewall_route_table.id
         network_details {
            id   = var.firewall_vcn
            type = "VCN"
            route_table_id = oci_core_route_table.vcn_ingress_route_table.id
         }
      }

* Attacher une passerelle de routage dynamique (DRG) vers chacun des périphériques (*spoke*) :  

      resource "oci_core_drg_attachment" "spoke_drg_attachments" {
         for_each           = var.spoke_vcns 
         drg_id             = var.drg_ocid
         vcn_id             = each.value
         display_name       = "attae-${each.key}-to-drg-cmp-conne-cam1-001"
         drg_route_table_id = oci_core_drg_route_table.to_firewall_route_table.id
      }

* Créer une règle pour le trafic sortant, du pare-feu vers la passerelle de routage dynamique (DRG) :

      resource "oci_core_drg_route_table" "from_firewall_route_table" {
         drg_id                           = var.drg_ocid
         display_name                     = "From-Firewall"
         import_drg_route_distribution_id = oci_core_drg_route_distribution.firewall_drg_route_distribution.id
      }

* Créer une règle pour le trafic entrant, de la la passerelle de routage dynamique (DRG) vers le pare-feu :  

      resource "oci_core_drg_route_table" "to_firewall_route_table" {
         drg_id       = var.drg_ocid
         display_name = "To-Firewall"
      }

* Définir la route vers Internet :  

      resource "oci_core_drg_route_table_route_rule" "to_firewall_drg_route_table_route_rule" {
         drg_route_table_id         = oci_core_drg_route_table.to_firewall_route_table.id
         destination                = "0.0.0.0/0"
         destination_type           = "CIDR_BLOCK"
         next_hop_drg_attachment_id = oci_core_drg_attachment.hub_drg_attachment.id
      }

* Définir le transit :

      resource "oci_core_drg_route_distribution" "firewall_drg_route_distribution" {
         distribution_type = "IMPORT"
         drg_id            = var.drg_ocid
         display_name      = "Transit-Spokes"
      }

##### [output.tf](../../modules/network/fortigate/output.tf)  

      Le fichier, *outputs.tf*, définit les valeurs de sortie durant l'exécution de ce module. C'est pour ce module que le FortiGate est créé. Si le FortiGate n'a pas été créé, la sortie est *null*.

      | variable | description |
      |------|-------------|
      | firewallA_instance_public_ips | adresse IP publique du FortiGate A |
      | firewallA_instance_private_ips | adresse IP privée du FortiGate A |
      | firewallB_instance_private_ips | adresse IP privée du FortiGate B |
      | firewallB_instance_public_ips | adresse IP publique du FortiGate B |
      | firewall_instance_ids | Identifiant de chacune des deux instances de FortiFate déployées |
      | instance_https_urls | URL de la page Web d'administration de chacune des deux instances de FortiGate |

3- Fonctionnement

   Voire la logique décrite dans la section [compute.tf](#computetf).
  
4- Ressource associée

   | Ressource |
   |------|
   | [oci_core_instance](https://registry.terraform.io/providers/oracle/oci/latest/docs/data-sources/core_instance) |

#### vcn-basic

1. Définition

   Ce module est responsable de créer les VCN, sous-réseaux, passerelle Internet, passerelles NAT, et les listes de sécurité dans le compartiment spécifié.  

2. Structure

Ce module comporte trois éléments, chacun défini dans un fichier séparé.

##### [variables.tf](../../modules/network/vcn-basic/variables.tf)

   Ce premier fichier, variables.tf, définit la structure des données où les paramètres seront reçus pour la création des VCN, sous-réseaux, passerelles et listes de sécurité.

   | variable | description |
   |------|-------------|
   | compartment\_id | OCID du compartiment où les ressources seront créées. |
   | drg\_id | Si une DRG doit être créée ou non. |
   | service\_gateway\_cidr | Le service OSN CIDR accessible à travers de *Service Gateway* |
   | service\_label | Étiquette à utiliser comme partie du nom de la ressource |
   | vcns | VCN à créer |

##### [main.tf](../../modules/network/vcn-basic/main.tf)

   Ce deuxième fichier est *main.tf* où est située la logique de la création des ressources dans le compartiment.

   Suivant la logique de création des VCN :

      resource "oci_core_vcn" "these" {
         for_each       = var.vcns
            display_name   = each.key
            dns_label      = substr(join("", regexall("[a-zA-Z0-9]+", each.value.dns_label)), 0, 15)
            cidr_block     = each.value.cidr
            compartment_id = each.value.compartment_id
      }  

La logique consiste en une boucle (*for_each*) qui prend l'élément du paramètre d'entrée (var.vcns) pour ensuite appeler la ressource *oci_core_vcn* avec les données de cet élément pour la création du VCN,
   en faisant la même chose jusqu'au dernier élément de la *Map* (var.vcns). Pour déterminer le *dns_label*, une expression régulière est d'abord appliquée pour obtenir, à partir de l'attribut dns_label du vcn, les chaînes qui ne sont que des caractères alphanumériques et en extraire les 15 premiers caractères, puis l'assigner au paramètre dns_label de la ressource *oci_core_vcn*.

   Suivant la logique de création des passerelles Internet (*Internet Gateways*) :

      resource "oci_core_internet_gateway" "these" {
         for_each       = { for k, v in var.vcns : k => v if v.is_create_igw == true }
         compartment_id = each.value.compartment_id
         vcn_id         = oci_core_vcn.these[each.key].id
         display_name   = "igw-${each.key}"
      }

   La logique consiste en une boucle (*for_each*) qui prend l'élément du paramètre d'entrée (var.vcns). Si l'attribut de l'élément pris a dans son attribut *is_create_igw*, comme *true*, la ressource *oci_core_internet_gateway* est appelée avec les données de cet élément pour la création du *internet_gateway* dans le *vcn* spécifié.
   En faisant la même chose jusqu'au dernier élément de la *Map* (var.vcns). Pour effectuer la résolution de l'identifiant du *vcn* à l'intérieur de la boucle, le résultat de la création des vcns *oci_core_vcn.these* est utilisé.

   Suivant la logique de création des passerelles NAT (*NAT Gateways*) :

      resource "oci_core_nat_gateway" "these" {
         for_each       = { for k, v in var.vcns : k => v if v.is_create_igw == true }
         compartment_id = each.value.compartment_id
         display_name   = "ngw-${each.key}"
         vcn_id         = oci_core_vcn.these[each.key].id
         block_traffic  = each.value.block_nat_traffic
      }

   La logique consiste en une boucle (*for_each*) qui prend l'élément du paramètre d'entrée (var.vcns). Si l'attribut de l'élément pris a dans son attribut *is_create_igw*, comme *true*, la ressource *oci_core_nat_gateway* est appelée avec les données de cet élément pour la création du *nat_gateway* dans le *vcn* spécifié, 
   en faisant la même chose jusqu'au dernier élément de la *Map* (var.vcns). Pour effectuer la résolution de l'identifiant du *vcn* à l'intérieur de la boucle, le résultat de la création des VCN *oci_core_vcn.these* est utilisé.

   Suivant la logique de création des *Service Gateways* :

      resource "oci_core_service_gateway" "these" {
         for_each       = var.vcns
         compartment_id = each.value.compartment_id
         display_name   = "sgw-${each.key}"
         vcn_id         = oci_core_vcn.these[each.key].id
         services {
            service_id = local.osn_cidrs[var.service_gateway_cidr]
         }
      }

   La logique consiste en une boucle (*for_each*) qui prend l'élément du paramètre d'entrée (var.vcns), pour ensuite appeler la ressource *oci_core_service_gateway* avec les données de cet élément pour la création du *service_gateway* dans le *vcn* spécifié,
   en faisant la même chose jusqu'au dernier élément de la *Map* (var.vcns). Pour effectuer la résolution de l'identifiant du *vcn* à l'intérieur de la boucle, le résultat de la création des VCN *oci_core_vcn.these* est utilisé.
   Pour effectuer la résolution de l'identifiant du *service* à l'intérieur de la boucle, le résultat de la source de données (*data source*) *data.oci_core_services.all_services.services* est utilisée.
   Suivant la logique de création des *DRG attachment to VCN * :

      resource "oci_core_drg_attachment" "these" {
         for_each     = { for k, v in var.vcns : k => v if v.is_attach_drg == true }
         drg_id       = var.drg_id
         vcn_id       = oci_core_vcn.these[each.key].id
         display_name = "${each.key}-drg-attachment"
      }

   La logique consiste en une boucle (*for_each*) qui prend l'élément du paramètre d'entrée (var.vcns). Si l'attribut de l'élément pris a dans son attribut *is_attach_drg*, comme *true*, la ressource *oci_core_drg_attachment* est appelée avec les données de cet élément pour la création de la DRG dans le VCN spécifié,
   en faisant la même chose jusqu'au dernier élément de la *Map* (var.vcns). Pour effectuer la résolution de l'identifiant du VCN à l'intérieur de la boucle, le résultat de la création des VCN *oci_core_vcn.these* est utilisé.

   Suivant la logique de création des sous-réseaux (*Subnets* :

   resource "oci_core_subnet" "these" {
         for_each                   = {
            for subnet in local.subnets : "${subnet.vcn_name}.${subnet.subnet_key}" => subnet }
            display_name               = each.value.display_name
            vcn_id                     = oci_core_vcn.these[each.value.vcn_name].id
            cidr_block                 = each.value.cidr
            compartment_id             = each.value.compartment_id
            prohibit_public_ip_on_vnic = each.value.private
            dns_label                  = each.value.dns_label
            dhcp_options_id            = each.value.dhcp_options_id
            defined_tags               = each.value.defined_tags
            security_list_ids          = concat([oci_core_default_security_list.these[each.value.vcn_name].id], #oci_core_security_list.these["${sl.subnet_name}.${sl.sec_list_name}"].id]
            [for sl in local.security_lists : oci_core_security_list.these["${sl.subnet_name}.${sl.sec_list_name}"].id if sl.subnet_name == each.value.display_name])
      }

   La logique consiste en une boucle (for_each) qui prend l'élément de la variable locale *var.subnets*, et pour chaque élément, une *Map* est créée. Cette *Map* représente les données d'un sous-réseau (*subnet*).
   Ensuite, avec les valeurs de cette *Map* (subnet), les différents paramètres de la ressource *oci_core_subnet* sont définis. Pour définir le paramètre *security_list_ids*, les identifiants sont obtenus à partir des listes de sécurité créées par défaut
   par la ressource *oci_core_default_security_list* pour le *subnet* correspondant. Il les concatène ensuite avec les identifiants des listes de sécurité (*security list*) créées avec la ressource *oci_core_security_list* pour le *subnet* correspondant.
   Finalement, la ressource *oci_core_subnet* est appelée avec les données de cet élément pour la création du *subnet* dans le VCN spécifié.

   Suivant la logique de création des listes de sécurité par défaut (*default_security_lists*) :

      resource "oci_core_default_security_list" "these" {
         for_each = oci_core_vcn.these
         manage_default_resource_id = each.value.default_security_list_id
         ingress_security_rules {
            protocol  = "1"
            stateless = false
            source    = "0.0.0.0/0"
               icmp_options {
               type = 3
               code = 4
            }
         }
         ingress_security_rules {
            protocol  = "1"
            stateless = false
            source    = each.value.cidr_block
            icmp_options {
               type = 3
               code = null
            }
         }
      }

   La logique consiste en une boucle (for each) qui prend l'élément du résultat de création des VCN de la ressource *oci_core_vcn* pour définir les attributs *manage_default_resource_id* et *source*. Ensuite, la ressource *oci_core_default_security_list* est appelée avec les données de cet élément pour la création de la liste de sécurité par défaut (*default security list*) dans le VCN spécifié, en faisant la même chose jusqu'au dernier élément de la *Map* (vcns).

   Suivant la logique de création des listes de sécurité (*security_lists*) :

      resource "oci_core_security_list" "these" 
      {
         for_each = {
            for sec_list in local.security_lists : "${sec_list.subnet_name}.${sec_list.sec_list_name}" => sec_list
         }
   
         vcn_id         = oci_core_vcn.these[each.value.vcn_name].id
         compartment_id = each.value.compartment_id
         #display_name   = "${each.value.subnet_name}-${each.value.sec_list_name}"
         display_name   = "sl-${each.value.subnet_name}"
         defined_tags   = each.value.defined_tags
         freeform_tags  = each.value.freeform_tags
      
         dynamic "egress_security_rules" {
            iterator = rule
            for_each = [for x in each.value.egress_rules != null ? each.value.egress_rules : local.default_security_list_opt.egress_rules :
            {
               proto : x.protocol
               dst : x.dst
               dst_type : x.dst_type
               stateless : x.stateless
               icmp_type : x.icmp_type
               icmp_code : x.icmp_code
               description : x.description
            } if x.is_create && x.protocol == "1" && x.icmp_type != null]
      
            content {
               protocol         = rule.value.proto
               destination      = rule.value.dst
               destination_type = rule.value.dst_type
               stateless        = rule.value.stateless
               description      = rule.value.description
               icmp_options {
                 type = rule.value.icmp_type
                 code = rule.value.icmp_code
               }
            }
         }
      }

   La logique consiste en une boucle (for_each) qui prend les éléments de la liste d'objets des listes de sécurité (*security_lists*). Chaque objet sec_list est identifié par le nom du sous-réseau et le nom de la liste. Il regroupe les attributs requis pour la création d'une liste de sécurité par le moyen de recours *oci_core_security_list*.
   Dans cette boucle, les paramètres requis par la ressource *oci_core_security_list* sont définis avec les valeurs de l'objet *sec_list*.

   Pour définir les valeurs des règles de sortie *egress_rules*, une autre boucle interne de type dynamique nommée *egress_security_rules* est utilisée. Dans cette boucle interne (dynamique), le paramètre contenu (*content*) et le paramètre d'options correspondant sont définis, en fonction de l'évaluation du protocole et des options qui lui sont associées au sein de la liste de sécurité à définir.
   Par exemple, si le protocole est 1 (ICMP) et que *icmp_type* n'est pas ''null'', les paramètres facultatifs de ce protocole sont définis :

      icmp_options {
         type = rule.value.icmp_type
         code = rule.value.icmp_code
      }

   C'est ainsi que les règles de sortie (*egress_rules*) continuent d'être définies tout en gardant dans la variable locale *default_security_list_opt.egress_rules*.  

   Pour la configuration automatique des instances de pare-feu FortiGate (*Fortigate-Firewall*, les règles de sécurité de sortie *egress_security_rules* suivantes ont été ajoutées au script :  

      dynamic "egress_security_rules" {
         iterator = rule
         for_each = [for x in each.value.egress_rules != null ? each.value.egress_rules : local.default_security_list_opt.egress_rules :
            {
            proto : x.protocol
            dst : x.dst
            dst_type : x.dst_type
            stateless : x.stateless
            dst_port_min : x.dst_port_min
            dst_port_max : x.dst_port_max
            description : x.description
         } if x.is_create && x.protocol == "all" ]

         content {
            protocol         = rule.value.proto
            destination      = rule.value.dst
            destination_type = rule.value.dst_type
            stateless        = rule.value.stateless
            description      = rule.value.description

         }
      }

   À la fin, avec tous les paramètres des listes de sécurité définis par VCN, les listes de sécurité sont créées en appelant la ressource *oci_core_security_list*.  

   Pour la configuration automatique des instances de pare-feu FortiGate, les règles de sécurité suivantes ont été ajoutées au script :  

      dynamic "egress_security_rules" {
         iterator = rule
         for_each = [for x in each.value.egress_rules != null ? each.value.egress_rules : local.default_security_list_opt.egress_rules :
            {
            proto : x.protocol
            dst : x.dst
            dst_type : x.dst_type
            stateless : x.stateless
            dst_port_min : x.dst_port_min
            dst_port_max : x.dst_port_max
            description : x.description
         } if x.is_create && x.protocol == "all" ]

         content {
            protocol         = rule.value.proto
            destination      = rule.value.dst
            destination_type = rule.value.dst_type
            stateless        = rule.value.stateless
            description      = rule.value.description

         }
      }

      dynamic "ingress_security_rules" {
         iterator = rule
         for_each = [for x in each.value.ingress_rules != null ? each.value.ingress_rules : local.default_security_list_opt.ingress_rules :
         {
            proto : x.protocol
            src : x.src
            src_type : x.src_type
            stateless : x.stateless
            dst_port_min : x.dst_port_min
            dst_port_max : x.dst_port_max
            description : x.description
         } if x.is_create && x.protocol == "all" ]

         content {
            protocol    = rule.value.proto
            source      = rule.value.src
            source_type = rule.value.src_type
            stateless   = rule.value.stateless
            description = rule.value.description
         }
      }

##### [outputs.tf](../../modules/network/vcn-basic/outputs.tf)

   Ce troisième fichier, *outputs.tf*, définit les valeurs de sortie durant l'exécution de ce module. C'est pour ce module que la passerelle de routage dynamique (DRG) est créée. Si la DRG n'a pas été créée, la sortie est *null*.

   | variable | description |
   |------|-------------|
   | all\_services | All services |
   | internet\_gateways | The Internet gateways, indexed by display\_name. |
   | nat\_gateways | The NAT gateways, indexed by display\_name. |
   | security\_lists | All Network Security Lists |
   | service\_gateways | The Service gateways, indexed by display\_name. |
   | subnets | The subnets, indexed by display\_name. |
   | vcns | The VCNs, indexed by display\_name. |

3- Fonctionnement

   Le code intéressé dans la création des VCN s’appelle le module *network/vcn-basic* en passant comme paramètres :  

* L’identifiant du compartiment (compartment_id) où les VCN doivent être créés.  
* Un paramètre pour déterminer si une DRG doit être créée.  
* Le *service_gateway_cidr*  
* L’information des *VCN* à créer  

   L’information de chaque VCN à créer doit inclure :

* Le cidr
* dns_label
* l’attribut is_create_igw pour déterminer si un igw doit être créé
* l’attribut is_attach_drg pour déterminer si la drg s’attache à la vcn
* les subnets avec leur liste de sécurité respective associée

   Une fois les paramètres passés à ce module, la logique définie dans le fichier main.tf est exécutée. La logique consiste à obtenir *osn_cidrs* à partir du data_source *data.oci_core_services* et à les assigner à la variable locale *osn_cidrs* pour son utilisation ultérieure.
   Ensuite, à partir du paramètre d’entrée *var.vcns*, les *subnets* de chaque *vcn* sont obtenus et sont assignés à la variable locale *subnets* pour son utilisation ultérieure.
   En faisant l’utilisation de la variable *subnets* définie dans l’étape précédente, les listes de sécurité sont obtenues pour chaque *subnet* et sont assignées à la variable locale *security_lists* pour son utilisation ultérieure.
   Finalement, avec les paramètres d'entrée et les variables locales définis dans les étapes précédentes, les ressources suivantes sont créées :

* La création des *VCN* en utilisant des ressources *oci_core_vcn* et le paramètre *var.vcns*
* La création des *internet_gateway* en utilisant la ressource *oci_core_internet_gateways* et le paramètre *var.vcns*
* La création des *nat_gateways* en utilisant la ressource *oci_core_nat_gateway* et le paramètre *var.vcns*
* La création des *service_gateways* en utilisant la ressource *oci_core_service_gateway* et le paramètre *var.vcns* et la variable locale *osn_cidrs*
* La création du *drg_attachment* en utilisant la ressource *oci_core_drg_attachment* et le paramètre *var.vcns*
* La création des *subnets* en utilisant la ressource *oci_core_subnet* et la variable locale *subnets*
* La création des *default_security_list* en utilisant la ressource *oci_core_default_security_list* et le résultat de la création des *vcns* de la ressource *oci_core_vcn.these*
* La création des *security_list* en utilisant la ressource *oci_core_security_list* et la variable locale chargée précédemment *local.security_lists*

   La création de chaque ressource est décrite de manière détaillée dans le numéral *main.tf* qui a été fait précédemment.

4- Ressource associée

   | Ressource |
   |------|
   | [oci_core_default_security_list](https://registry.terraform.io/providers/hashicorp/oci/latest/docs/resources/core_default_security_list) |
   | [oci_core_drg_attachment](https://registry.terraform.io/providers/hashicorp/oci/latest/docs/resources/core_drg_attachment) |
   | [oci_core_internet_gateway](https://registry.terraform.io/providers/hashicorp/oci/latest/docs/resources/core_internet_gateway) |
   | [oci_core_nat_gateway](https://registry.terraform.io/providers/hashicorp/oci/latest/docs/resources/core_nat_gateway) |
   | [oci_core_security_list](https://registry.terraform.io/providers/hashicorp/oci/latest/docs/resources/core_security_list) |
   | [oci_core_service_gateway](https://registry.terraform.io/providers/hashicorp/oci/latest/docs/resources/core_service_gateway) |
   | [oci_core_subnet](https://registry.terraform.io/providers/hashicorp/oci/latest/docs/resources/core_subnet) |
   | [oci_core_vcn](https://registry.terraform.io/providers/hashicorp/oci/latest/docs/resources/core_vcn) |

   | Source de données (*Data Source*) |
   |------|
   |  [oci_core_services](https://registry.terraform.io/providers/hashicorp/oci/latest/docs/data-sources/core_services)  |

#### vcn-routing

1. Définition

   Ce module est responsable de créer les règles de routage (*route_rules*) dans le sous-réseau (*subnet*) spécifié.

2. Structure

   Ce module consiste en trois éléments, chacun défini dans un fichier séparé.

##### [variables.tf](../../modules/network/vcn-routing/variables.tf)

   Ce premier fichier, variables.tf, définit la structure des données où les paramètres seront reçus pour la création des règles de routage des sous-réseaux (*subnets route rules*).

   | variable | description |
   |------|-------------|
   | compartment\_id | OCID du compartiment où les ressources seront créées |
   | subnets\_route\_tables | règles de routage des sous-réseaux (*subnets route rules*) à créer |

      subnets_route_table

      map(
         object(
            {      
               compartment_id    = string,
               vcn_id            = string,
               subnet_id         = string,
               route_rules = list(
                  object(
                     {
                        is_create         = bool
                        destination       = string
                        destination_type  = string
                        network_entity_id = string
                        description       = string
                     }
                  )
               )
               defined_tags      = map(string)
            }
         )
      )

##### [main.tf](../../modules/network/vcn-routing/main.tf)

   Ce deuxième fichier est *main.tf* où est située la logique de la création des règles de routage (*route_rules*) dans les sous-réseaux (*subnets*).

   Suivant la logique de création des tables de routage (*route_tables) :

      resource "oci_core_route_table" "these" {
        for_each       = var.subnets_route_tables
        display_name   = each.key
        vcn_id         = each.value.vcn_id
        compartment_id = var.compartment_id
        dynamic "route_rules" {
          iterator = rule
          for_each = [for r in each.value.route_rules : {
            dst : r.destination
            dst_type : r.destination_type
            ntwk_entity_id : r.network_entity_id
            description : r.description
          } if r.is_create == true]
      
          content {
            destination       = rule.value.dst
            destination_type  = rule.value.dst_type
            network_entity_id = rule.value.ntwk_entity_id
            description       = rule.value.description
          }
        }
      }

   La logique consiste en une boucle (for_each) qui prend les éléments de la liste d'objets de *subnets_route_tables*. Chaque objet subnets_route_table regroupe les attributs requis pour la création d'une *subnet_route_table* par le moyen de recours *oci_core_route_table*.
   Dans cette boucle, les paramètres requis par la ressource *oci_core_route_table* sont définis avec les valeurs de l'objet *subnets_route_table*.

   Pour définir les valeurs des règles de routage (*route_rules*), une autre boucle interne de type *dynamique* nommée *route_rules* est utilisée. Dans cette boucle interne (dynamique), le paramètre contenu (*content*) est défini, en fonction de l'évaluation de la condition *is_create == true*.
   Par exemple, si le protocole est 1 (ICMP) et que *icmp_type* n'est pas ''null'', les paramètres facultatifs de ce protocole sont définis :
   C'est ainsi que les règles de routage (*route_rules*) continuent d'être définies.
   À la fin, avec tous les paramètres de table de routage (*route_table*) définis, les *subnets_route_tables* sont créées en appelant la ressource *oci_core_route_table*.

##### [outputs.tf](../../modules/network/vcn-routing/outputs.tf)

   Ce troisième fichier, *outputs.tf*, définit les valeurs de sortie durant l'exécution de ce module. C'est pour ce module que les tables de routage (*route tables*) sont créées.

   | variable | description |
   |------|-------------|
   | subnets\_route\_tables | les tables de routage (*route tables*) créées |

3- Fonctionnement

   Le code intéressé dans la création des *route_rules* s’appelle le module *network/vcn-routing* en passant comme paramètres :

* L’identifiant du compartiment (compartment_id) où les tables de routage (*route tables*) doivent être créées.
* L’information des *route tables* à créer.

   L’information de chaque *route tables* à créer doit inclure :

* destination
* destination_type
* l’attribut *is_create* pour déterminer si *route tables* doit être créée
* le *network_entity_id*

   Une fois les paramètres passés à ce module, la logique définie dans le fichier main.tf est exécutée.
   À partir du paramètre d’entrée *var.subnets_route_tables*, les *route_tables* sont obtenues pour la création des *route_tables* en utilisant la ressource *oci_core_route_table*.
   La création de *route tables* est décrite de manière détaillée dans le numéral *main.tf* qui a été fait précédemment.

4- Ressource associée

   | Ressource |
   |------|
   | [oci_core_route_table_attachment](https://registry.terraform.io/providers/hashicorp/oci/latest/docs/resources/core_route_table_attachment) |
   | [oci_core_route_table](https://registry.terraform.io/providers/hashicorp/oci/latest/docs/resources/core_route_table) |

### Module Security

---

#### Dossier Bastion

1- Définition

   Ce module est responsable de créer les bastions.

2- Structure

   Ce module consiste en deux éléments, chacun défini dans un fichier séparé.

##### [variables.tf](../../modules/security/bastion/variables.tf)

   Ce premier fichier, *variables.tf*, définit la structure des données où les paramètres seront reçus pour
   la création de tous les bastions demandés. La structure des données qui est définie dans ce dossier est une collection de type *Map* où chaque élément est composé d'une clé unique qui est le nom du bastion et
   qui est associée à une valeur de celle-ci. Cette valeur est un objet de type bastion qui regroupe les attributs demandés pour sa création en utilisant de ressource *oci_bastion_bastion*.

      bastion

      map(
         object(
            {
               name = string,
               compartment_id = string,
               target_subnet_id = string,
               client_cidr_block_allow_list = list(string),
               max_session_ttl_in_seconds = number
            }
         )
      )

   | variable | description |
   |------|-------------|
   | bastions | la liste des bastions à créer.

##### [main.tf](../../modules/security/bastion/main.tf)

   Ce deuxième fichier est *main.tf* où est située la logique de la création des bastions.

      resource "oci_bastion_bastion" "these" {
        for_each = var.bastions  
          bastion_type     = "STANDARD"
          compartment_id   = each.value.compartment_id
          target_subnet_id = each.value.target_subnet_id
          name             = each.value.name
          client_cidr_block_allow_list = each.value.client_cidr_block_allow_list
          max_session_ttl_in_seconds   = each.value.max_session_ttl_in_seconds
      }
  
   La logique consiste en une boucle (for_each) qui est exécutée au travers de la *Map* qui est passée comme paramètre qui contient tous les bastions à créer. Dans cette boucle, chaque élément (bastion) de la *Map* est obtenu et est créé, en appelant la ressource *oci_bastion_bastion* avec les attributs du *Bastion*.

3- Fonctionnement

   Le code intéressé dans la création des bastions appelle le module *security/bastion* en passant comme paramètre une *Map* avec les attributs de chaque *bastion* à créer.
   Une fois les paramètres passés à ce module, la logique définie dans le fichier *main.tf* est exécutée.

4- Ressource associée

   | Ressource |
   |------|
   | [oci_bastion_bastion](https://registry.terraform.io/providers/hashicorp/oci/latest/docs/resources/bastion_bastion) |

#### keys

1. Définition

   Ce module est responsable de créer les clés (*keys*).

2. Structure

   Ce module consiste en trois éléments, chacun défini dans un fichier séparé.

##### [variables.tf](../../modules/security/keys/variables.tf)

   Ce premier fichier, *variables.tf*, définit la structure des données où les paramètres seront reçus pour
   la création de toutes les clés (*keys*) demandées. La structure des données qui est définie dans ce dossier est une collection de type *Map* où chaque élément est composé d'une clé unique qui est le nom de la *key* et
   qui est associée à une valeur de celle-ci. Cette valeur est un objet de type *key* qui regroupe les attributs demandés pour sa création en utilisant de ressource *oci_kms_key*.

         keys

      map(
         object(
            {
               key_shape_algorithm = string,
               key_shape_length = string
            }
         )
      )

   | variable | description |
   |------|-------------|
   | keys | la liste des clés (*keys*) à créer.
   | compartment\_id | Le compartiment par défaut OCID à utiliser pour les ressources (sauf indication contraire). |
   | vault\_mgmt\_endPoint | KMS |

##### [main.tf](../../modules/security/keys/main.tf)

   Ce deuxième fichier est *main.tf* où est située la logique de la création des clés (*keys*).

      resource "oci_kms_key" "these" {
         for_each = var.keys
            compartment_id      = var.compartment_id
            display_name        = each.key
            management_endpoint = var.vault_mgmt_endPoint
            
            key_shape {
               algorithm = each.value.key_shape_algorithm
               length    = each.value.key_shape_length
            }
      }

   La logique consiste en une boucle (for_each) qui est exécutée au travers de la *Map* qui est passée comme paramètre qui contient toutes les clés (*keys*) à créer. Dans cette boucle, chaque élément (*key*) de la *Map* est obtenu et est créé, en appelant la ressource *oci_kms_key* avec les attributs de la clé (*key*).

##### [outputs.tf](../../modules/security/keys/outputs.tf)

   Ce troisième fichier, *outputs.tf*, définit les valeurs de sortie durant l'exécution de ce module. C'est pour ce module que les clés (*keys*) est créées.

3- Fonctionnement

   Le code intéressé dans la création des clés (*keys*) appelle le module *security/keys* en passant comme paramètre une *Map* avec les attributs de chaque *key* à créer.
   Une fois les paramètres passés à ce module, la logique définie dans le fichier *main.tf* est exécutée.

4- Ressource associée

   | Ressource |
   |------|
   | [oci_kms_key](https://registry.terraform.io/providers/hashicorp/oci/latest/docs/resources/kms_key) |

#### vaults

1. Définition

   Ce module est responsable de créer les coffre-fort à secrets (*vaults*).

2. Structure

   Ce module consiste en trois éléments, chacun défini dans un fichier séparé.

##### [variables.tf](../../modules/security/vaults/variables.tf)

   Ce premier fichier, *variables.tf*, définit la structure des données où les paramètres seront reçus pour
   la création de tous les coffre-fort à secrets (*vaults*) demandés. La structure des données définie dans ce dossier est une chaîne de caractères (*string*) qui est le nom du coffre-fort à secrets (*vault*) et
   une *string* qui est le type du *vault*.

      variable "vault_name" {
        type        = string
        description = "Vault Name"
        default     = ""
      } 
      
      variable "vault_type" {
        type        = string
        description = "Vault Type - DEFAULT (Shared)"
        default     = "DEFAULT"
      }

   | variable | description |
   |------|-------------|
   | compartment\_id | Le compartiment par défaut OCID à utiliser pour les ressources (sauf indication contraire). |
   | vault\_name | nom du coffre-fort à secrets |
   | vault\_type | type de coffre-fort à secret |

##### [main.tf](../../modules/security/vaults/main.tf)

   Ce deuxième fichier est *main.tf* où est située la logique de la création des coffre-fort à secrets (*vaults*).

      resource "oci_kms_vault" "this" {
          compartment_id = var.compartment_id
          display_name   = var.vault_name
          vault_type     = var.vault_type
      }

La logique consiste à prendre le paramètre qui contient le nom (*name*) et le type (*type*) du coffre-fort à secrets (*vault*) à créer, et appeler la ressource *oci_kms_vault* avec les attributs du *vault* pour le créer.

##### [outputs.tf](../../modules/security/vaults/outputs.tf)  

   Ce troisième fichier, *outputs.tf*, définit les valeurs de sortie durant l'exécution de ce module. C'est pour ce module que le coffre-fort à secret (*vault*) est créé.

   | variable | description |
   |------|-------------|
   | vault | le coffre-fort à secrets créé |

3- Fonctionnement

   Le code intéressé dans la création du coffre-fort à secrets (*vault*) appelle le module *security/vaults* en passant comme paramètres les attributs du *vault* à créer.
   Une fois les paramètres passés à ce module, la logique définie dans le fichier *main.tf* est exécutée.  

4- Ressource associée

   | Ressource |
   |------|
   | [oci_kms_vault](https://registry.terraform.io/providers/hashicorp/oci/latest/docs/resources/kms_vault) |

---

### Variables du script

#### Déclaration et définition des variables du script

#### Variables input  

La définition des variables d'entrée du script responsable du déploiement de la zone d'accueil OCI se trouve dans le fichier *variables.tf* situé dans le répertoire *config/*.

#### Environment

| Nom | Description | Type | Défault | Obligatoire | OCI|
|------|------------------|------|-------------|--------|:-----:|
|tenancy_ocid|Cette variable représente l'identifiant unique du *tenancy*. Elle est utilisée pour s'authentifier auprès du *provider oci*|String|  |Oui|Tenancy id|
|region|Cette variable représente l'identifiant unique de la *region*.|String|  |Oui|Region|
|service_label|Cette variable représente un préfixe à ajouter au nom des ressources à créer et permet leur identification unique.|String|  |Oui|Étiquette de déploiement|
|use_enclosing_compartment|Définit si les compartiments de zone d'accueil (*Landing Zone*) sont créés dans un compartiment qui les englobe. Si *false*, les compartiments de la *Landing Zone* sont créés sous le compartiment *root*.|boolean|false|No|Use an enclosing compartment|
|existing_enclosing_compartment_ocid|Cette variable représente l'identifiant unique du compartiment englobant où les compartiments seront créés.|String|null|No|Existing enclosing compartment|
|policies_in_root_compartment|Définit si les stratégies (*policies*) requises au niveau du compartiment *root* doivent être créées ou simplement utilisées. (USE)|String|CREATE|Oui|CREATE or USE policies in the root compartment|
|use_existing_groups|Indique si les groupes existants doivent être réutilisés pour cette "Landing Zone". Si false, un ensemble de groupes est créé.|boolean|false|No|Use existing groups|

#### Networking

| Nom | Description | Type | Défault | Obligatoire | OCI|
|------|------------------|------|-------------|--------|:-----:|
|prod_vcn_cidrs|Liste des blocs CIDR pour les VCN dans le *Prod Compartment* à créer en notation CIDR.|list|["10.1.0.0/20"]|Oui|Prod VCNs CIDR Blocks|
|nonprod_vcn_cidrs|Liste des blocs CIDR pour les VCN dans le *NonProd Compartment* à créer en notation CIDR.|list|["10.2.0.0/20"]|Oui|NonProd VCNs CIDR Blocks|
|sandbox_vcn_cidrs|Liste des blocs CIDR pour les VCN du *Sandbox Compartment* à créer en notation CIDR.|list|["10.3.0.0/20"]|Oui|Sandbox VCNs CIDR Blocks|
|unclassified_vcn_cidrs|Liste des blocs CIDR pour les VCN dans le *unclassified Compartment* à créer en notation CIDR.|list|["10.4.0.0/20"]|Si|Unclassified VCNs CIDR Blocks|
|prod_vcn_names|Liste des noms personnalisés à attribuer aux VCN dans le compartiment *Prod Compartment*, en remplaçant les noms de VCN par défaut. (**service-label**-**index**-vcn).|list|liste vide|No|Prod VCNs Custom Names|
|nonprod_vcn_names|Liste des noms personnalisés à attribuer aux VCN dans le compartiment *NonProd Compartment*, en remplaçant les noms de VCN par défaut. (**service-label**-**index**-vcn).|list|liste vide|No|NonProd VCNs Custom Names|
|sandbox_vcn_names|Liste des noms personnalisés à attribuer aux VCN dans le compartiment *Sandbox*, en remplaçant les noms de VCN par défaut. (**service-label**-**index**-vcn).|list|liste vide|No|Sandbox VCNs Custom Names|
|unclassified_vcn_names|Liste des noms personnalisés à attribuer aux VCN dans le compartiment *unclassified*, en remplaçant les noms de VCN par défaut. (**service-label**-**index**-vcn).|list|liste vide|No|Unclassified VCNs Custom Names|
|is_vcn_onprem_connected|Si les VCN sont connectés au *on-premises network*, auquel cas une DRG est créée et attachée aux VCN.|boolean|false|No|Connect Landing Zone VCN(s) to on-premises network|
|existing_drg_id|L'OCID DRG d'une DRG existante, si vous utilisez une DRG existante.|string|chaîne vide|Si|Existing DRG OCID|
|dmz_vcn_cidr|Bloc CIDR pour le VCN DMZ. Tout le trafic sera acheminé par la DMZ. Obligatoire si hub_spoke_architecture est vrai.|string|10.0.0.0/20|Oui|DMZ VCN CIDR Block|
|dmz_for_firewall|Si 3rd Party Firewall sera déployée dans la DMZ.|boolean|false|No|Use DMZ VCN for 3er-Party Firewalls|
|use_fortigate|Utilisera FortiGate comme pare-feu en charge dans la DMZ.|boolean|false|No|Use Fortigate as 3er-Party Firewalls in DMZ|
|ssh_public_key|Clé publique SSH pour les instances FortiGate.|string|chaîne vide|No|SSH Public Key for Fortigate instances|
|dmz_number_of_subnets|Le nombre de sous-réseaux à créer dans le VCN DMZ. Si vous utilisez le VCN DMZ pour un déploiement d'appareils réseau.|number|4|Oui|Number of Subnets in the DMZ VCN|
|dmz_subnet_size|Le nombre de bits supplémentaires avec lesquels étendre le préfixe DMZ VCN CIDR.|number|4|No|Size of the DMZ Subnet CIDRs|

#### Exadata Cloud Service

| Nom | Description | Type | Défault | Obligatoire | OCI|
|------|------------------|------|-------------|--------|:-----:|
|exacs_vcn_cidrs|Liste des blocs CIDR pour les VCN Exadata Cloud Service à créer en notation CIDR. Si hub_spoke_architecture est vrai, ces *VCN* sont transformés en VCN spoke.|list|liste vide|No|Exadata VCNs CIDR Blocks|

#### Connectivity

| Nom | Description | Type | Défault | Obligatoire | OCI|
|------|------------------|------|-------------|--------|:-----:|
|no_internet_access|Détermine si le réseau aura un accès direct à Internet. Si false, une *Internet Gateway* et une *NAT Gateway* sont créées. Si vrai, la *Internet Gateway* et la *NAT Gateway* ne sont PAS créées.|boolean|false|No|Block Internet Access|
|public_src_bastion_cidrs|Les plages d'adresses IP externes en notation CIDR sont autorisées à établir des connexions entrantes SSH.|list|liste vide|No|Inbound SSH CIDR Blocks|
|public_src_lbr_cidrs|Les plages d'adresses IP externes en notation CIDR sont autorisées à établir des connexions entrantes HTTPS.|list|liste vide|No|Inbound HTTPS CIDR Blocks|
|public_dst_cidrs|Les adresses IP externes en notation CIDR pour les connexions sortantes HTTPS.|list|liste vide|No|Outbound HTTPS CIDR Blocks|
|onprem_cidrs|Liste des blocs CIDR *on-premises* autorisés à se connecter au réseau Landing Zone par une DRG|list|liste vide|No|On-premises Network CIDR Blocks|
|onprem_src_ssh_cidrs|Liste des blocs CIDR *on-premises* autorisés à se connecter au réseau Landing Zone via SSH. Ils doivent être un sous-ensemble de onprem_cidrs.|list|liste vide|No|On-premises Network CIDR Blocks Allowed to Connect over SSH|

#### Notifications

| Nom | Description | Type | Défault | Obligatoire | OCI|
|------|------------------|------|-------------|--------|:-----:|
|network_admin_email_endpoints|liste des adresses e-mail pour toutes les notifications liées au réseau.|list|liste vide|No|Network Admin Email Endpoints|
|security_admin_email_endpoints|liste des adresses e-mail pour toutes les notifications liées à la sécurité.|list|liste vide|No|Security Admin Email Endpoints|

#### Cloud Guard

| Nom | Description | Type | Défault | Obligatoire | OCI|
|------|------------------|------|-------------|--------|:-----:|
|cloud_guard_configuration_status|détermine si Cloud Guard doit être activé dans la *tenancy*. Si 'ENABLE', une cible est créée pour le compartiment *root*.|string|ENABLE|No|Cloud Guard Configuration Status|

#### Logging Consolidation Service Connector Hub For Audit Logs

| Nom | Description | Type | Défault | Obligatoire | OCI|
|------|------------------|------|-------------|--------|:-----:|
|create_service_connector_audit|créer Service Connector Hub for Audit logs.|boolean|false|No|Create Service Connector Hub for Audit Logs|
|service_connector_audit_target|destination pour *Service Connector Hub for Audit Logs*. Les valeurs valides sont objectstorage, streaming ou functions. En cas de diffusion/fonctions, indiquez l'OCID de flux/fonction et l'OCID de compartiment dans les variables ci-dessous.|string|objectstorage|No|Service Connector Hub Target|
|service_connector_audit_state|état dans lequel créer le *Service Connector Hub for Audit logs*. Les valeurs valides sont ACTIVE et INACTIVE.|string|INACTIVE|No|Service Connector Hub State|
|sch_audit_objStore_objNamePrefix|applicable uniquement pour le type de cible objectStorage. Le préfixe des objets pour *Audit logs*.|string|sch-audit|No|Object Name Prefix for Object Storage Target|

#### Logging Consolidation Service Connector Hub For VCN Flow Logs

| Nom | Description | Type | Défault | Obligatoire | OCI|
|------|------------------|------|-------------|--------|:-----:|
|create_service_connector_vcnFlowLogs|crée le *Service Connector Hub for VCN Flow logs*.|boolean|false|No|Create Service Connector Hub for VCN Flow Logs|
|service_connector_vcnFlowLogs_target|destination pour *Service Connector Hub for VCN Flow Logs*. Les valeurs valides sont objectstorage, streaming ou functions. Dans le cas de *streaming/functions*, indiquez l'OCID de fonction et l'OCID de compartiment.|string|objectstorage|No|Service Connector Hub Target|
|service_connector_vcnFlowLogs_state|état dans lequel créer le *Service Connector Hub for VCN Flow logs*. Les valeurs valides sont *ACTIVE* ou *INACTIVE* (insensible à la casse).|string|INACTIVE|No|Service Connector Hub |
|sch_vcnFlowLogs_objStore_objNamePrefix|applicable uniquement pour le type de cible "objectStorage". Le préfixe des objets pour *VCN Flow logs*.|string|sch-vcnFlowLogs|No|Object Name Prefix for Object Storage Target|

#### Vulnerability Scanning

| Nom | Description | Type | Défault | Obligatoire | OCI|
|------|------------------|------|-------------|--------|:-----:|
|vss_create|si oui ou non les recettes et les cibles *Vulnerability Scanning Service* doivent être créées dans la Landing Zone.|boolean|true|No|Enable Vulnerability Scanning|
|vss_scan_schedule|la planification d'analyse pour la recette du *Vulnerability Scanning Service*, si elle est activée. Les valeurs valides sont WEEKLY ou DAILY.|string|WEEKLY|No|Scanning Schedule|
|vss_scan_day|le jour de la semaine pour la recette du service d'analyse des vulnérabilités, s'il est activé. Ne s'applique que si vss_scan_schedule est WEEKLY.|string|SUNDAY|No|Scanning Day|

#### Others

| Nom | Description | Type | Défault | Obligatoire | OCI|
|------|------------------|------|-------------|--------|:-----:|
|user_ocid|Cette variable représente l'identifiant unique du *user*. Elle est utilisée pour s'authentifier auprès du *provider oci*.|String|chaîne vide|Oui|  |
|fingerprint|Cette variable représente le *fingerprint*. Elle est utilisée pour s'authentifier auprès du *provider oci*|String|chaîne vide|No|  |
|private_key_path|Cette variable représente le *key_path*. Elle est utilisée pour s'authentifier auprès du *provider oci*|String|chaîne vide|No|  |
|private_key_password|Cette variable représente le *key_password*. Elle est utilisée pour s'authentifier auprès du *provider oci*|String|chaîne vide|Oui|  |
|existing_iam_admin_group_name|Cette variable représente le nom du groupe *admin* existant.|String|chaîne vide|No|  |
|existing_sys_admin_group_name|Cette variable représente le nom du groupe *sys_admin* existant.|String|chaîne vide|No|  |
|existing_sys_admin_nonprod_group_name|Cette variable représente le nom du groupe *sys_admin_nonprod* existant.|String|chaîne vide|No|  |
|existing_security_admin_group_name|Cette variable représente le nom du groupe *security_admin* existant.|String|chaîne vide|No|  |
|existing_cybersecurity_admin_group_name|Cette variable représente le nom du groupe *cybersecurity_admin* existant.|String|chaîne vide|No|  |
|existing_network_admin_group_name|Cette variable représente le nom du groupe *network_admin* existant.|String|chaîne vide|No|  |
|existing_appdev_admin_group_name|Cette variable représente le nom du groupe *appdev_admin* existant.|String|chaîne vide|No|  |
|existing_database_admin_group_name|Cette variable représente le nom du groupe *database_admin* existant.|String|chaîne vide|No|  |
|existing_database_admin_nonprod_group_name|Cette variable représente le nom du groupe *database_admin_nonprod_* existant.|String|chaîne vide|No|  |
|existing_auditor_group_name|Cette variable représente le nom du groupe *auditor* existant.|String|chaîne vide|No|  |
|existing_exainfra_admin_group_name|Cette variable représente le nom du groupe *exainfra_admin* existant.|String|chaîne vide|No|  |
|hub_spoke_architecture|détermine si une architecture réseau Hub & Spoke doit être déployée. Permet le *inter-spoke routing*.|boolean|false|No|
|exacs_vcn_names|liste des noms personnalisés des VCN Exadata, remplaçant les noms par défaut des VCN Exadata. Chaque nom fourni se rapporte à un et un seul VCN, la nième valeur s'appliquant à la nième valeur dans  exacs_vcn_cidrs.|list|liste vide|No|
|exacs_client_subnet_cidrs|liste des blocs CIDR pour les *subnets* clients des VCN d'Exadata Cloud Service, en notation CIDR.|list|liste vide|No|
|exacs_backup_subnet_cidrs|liste des blocs CIDR pour les *subnets* de sauvegarde des VCN Exadata Cloud Service, en notation CIDR. Chaque valeur CIDR fournie concerne un et un seul VCN.|list|liste vide|No|
|deploy_exainfra_cmp|si un compartiment pour l'infrastructure Exadata doit être créé. Si false, l'infrastructure Exadata doit être créée dans le compartiment de la base de données.|boolean|true|No|
|service_connector_audit_target_OCID|applicable uniquement pour le type de streaming/functions. OCID de la cible stream/function pour le *Service Connector Hub for Audit logs*.|string|chaîne vide|No|
|service_connector_audit_target_cmpt_OCID|applicable uniquement pour le type de streaming/functions. OCID du compartiment contenant la cible du stream/function pour le *Service Connector Hub for Audit logs*.|string|chaîne vide|No|
|service_connector_vcnFlowLogs_target_OCID|applicable uniquement pour les types de cibles *streaming/functions*. OCID de la cible *stream/function* pour le *Service Connector Hub for VCN Flow logs*|string|chaîne vide|No|
|service_connector_vcnFlowLogs_target_cmpt_OCID|applicable uniquement pour les types de cible *streaming/fonctions*. OCID du compartiment contenant la cible "stream/function" pour le service *Connector Hub for VCN Flow logs*.|string|chaîne vide|No|

#### data sources

Cette *data source* fournit la liste des régions dans Oracle Cloud Infrastructure. L'attribut *Regions* est exporté. Cet attribut est une liste d'objets Région (références) où chaque *Région* a une *key* composée d'un code de région à 3 lettres et du nom de la région.  

   data "oci_identity_regions" "these" {}

Cette *data source* fournit des détails sur une ressource *Tenancy* spécifique dans le service Oracle Cloud Infrastructure Identity. Cette *data source* reçoit l'OCID du *Tenancy* comme argument. Et elle exporte les attributs suivants du *Tenancy*: id, name, description, home_region_key, upi_idcs_compatibility_layer_endpoint et tags.  

      data "oci_identity_tenancy" "this" {
         tenancy_id = var.tenancy_ocid
      }

Cette *data source* fournit des détails sur une ressource *Compartment* spécifique dans le service Oracle Cloud Infrastructure Identity. Cette *data source* reçoit l'OCID du *Compartment* comme argument. Et elle exporte les attributs du *Compartment* suivants: compartment_id (parent ocid), id, name, state, description, time_created, is_accessible, inactive_state et tags.  

      data "oci_identity_compartment" "existing_enclosing_compartment" {
         id = var.existing_enclosing_compartment_ocid != null ? var.existing_enclosing_compartment_ocid : local.parent_compartment_id
      }

Cette *data source* obtient la liste des groupes dans un compartiment spécifique puis filtre cette liste avec le nom de l'*admin_group*. Cette *data source* reçoit l'OCID du Compartiment comme argument et le nom du *admin_group* comme paramètre pour filtrer la liste des groupes. L'attribut *groups* est exporté. Cet attribut est une liste qui contient dans ce cas un seul groupe, qui est le groupe dont le nom correspond à celui de l'*admin_group*. Ce groupe a les attributs suivants: compartment_id (parent ocid), id, name, state, description, time_created, is_accessible, inactive_state et tags.  

      data "oci_identity_groups" "existing_iam_admin_group" {
         compartment_id = var.tenancy_ocid
         filter {
            name   = "name"
            values = [var.existing_iam_admin_group_name]
         }
      }

Cette *data source* obtient la liste des groupes dans un compartiment spécifique puis filtre cette liste avec le nom de *security_admin_group*. Cette *data source* reçoit l'OCID du Compartiment comme argument et le nom du *security_admin_group* comme paramètre pour filtrer la liste des groupes. L'attribut *groups* est exporté. Cet attribut est une liste qui contient dans ce cas un seul groupe, qui est le groupe dont le nom correspond à celui de *security_admin_group*. Ce groupe a les attributs suivants: compartment_id (parent ocid), id, name, state, description, time_created, is_accessible, inactive_state et tags.

      data "oci_identity_groups" "existing_security_admin_group" {
         compartment_id = var.tenancy_ocid
         filter {
            name   = "name"
            values = [var.existing_security_admin_group_name]
         }
      }

Cette *data source* obtient la liste des groupes dans un compartiment spécifique puis filtre cette liste avec le nom de *cybersecurity_admin_group*. Cette *data source* reçoit l'OCID du Compartiment comme argument et le nom du *cybersecurity_admin_group* comme paramètre pour filtrer la liste des groupes. L'attribut *groups* est exporté. Cet attribut est une liste qui contient dans ce cas un seul groupe, qui est le groupe dont le nom correspond à celui de *cybersecurity_admin_group*. Ce groupe a les attributs suivants: compartment_id (parent ocid), id, name, state, description, time_created, is_accessible, inactive_state et tags.

      data "oci_identity_groups" "existing_cybersecurity_admin_group" {
         compartment_id = var.tenancy_ocid
         filter {
            name   = "name"
            values = [var.existing_cybersecurity_admin_group_name]
         }
      }

Cette *data source* obtient la liste des groupes dans un compartiment spécifique puis filtre cette liste avec le nom de '*network_admin_group*. Cette *data source* reçoit l'OCID du Compartiment comme argument et le nom du *network_admin_group* comme paramètre pour filtrer la liste des groupes. L'attribut *groups* est exporté. Cet attribut est une liste qui contient dans ce cas un seul groupe, qui est le groupe dont le nom correspond à celui de *network_admin_group*. Ce groupe a les attributs suivants: compartment_id (parent ocid), id, name, state, description, time_created, is_accessible, inactive_state et tags.  

      data "oci_identity_groups" "existing_network_admin_group" {
         compartment_id = var.tenancy_ocid
         filter {
            name   = "name"
            values = [var.existing_network_admin_group_name]
         }
      }

Cette *data source* obtient la liste des groupes dans un compartiment spécifique puis filtre cette liste avec le nom de l'*appdev_admin_group*. Cette *data source* reçoit l'OCID du Compartiment comme argument et le nom du *appdev_admin_group* comme paramètre pour filtrer la liste des groupes. L'attribut *groups* est exporté. Cet attribut est une liste qui contient dans ce cas un seul groupe, qui est le groupe dont le nom correspond à celui de l'*appdev_admin_group*. Ce groupe a les attributs suivants: compartment_id (parent ocid), id, name, state, description, time_created, is_accessible, inactive_state et tags.  

      data "oci_identity_groups" "existing_appdev_admin_group" {
         compartment_id = var.tenancy_ocid
         filter {
            name   = "name"
            values = [var.existing_appdev_admin_group_name]
         }
      }

Cette *data source* obtient la liste des groupes dans un compartiment spécifique puis filtre cette liste avec le nom de *database_admin_group*. Cette *data source* reçoit l'OCID du Compartiment comme argument et le nom du *database_admin_group* comme paramètre pour filtrer la liste des groupes. L'attribut *groups* est exporté. Cet attribut est une liste qui contient dans ce cas un seul groupe, qui est le groupe dont le nom correspond à celui de l'*database_admin_group*. Ce groupe a les attributs suivants: compartment_id (parent ocid), id, name, state, description, time_created, is_accessible, inactive_state et tags.  

      data "oci_identity_groups" "existing_database_admin_group" {
         compartment_id = var.tenancy_ocid
         filter {
            name   = "name"
            values = [var.existing_database_admin_group_name]
         }
      }

Cette *data source* obtient la liste des groupes dans un compartiment spécifique puis filtre cette liste avec le nom de l'*database_admin_nonprod_group*. Cette *data source* reçoit l'OCID du Compartiment comme argument et le nom du *database_admin_nonprod_group* comme paramètre pour filtrer la liste des groupes. L'attribut *groups* est exporté. Cet attribut est une liste qui contient dans ce cas un seul groupe, qui est le groupe dont le nom correspond à celui de l'*database_admin_nonprod_group*. Ce groupe a les attributs suivants: compartment_id (parent ocid), id, name, state, description, time_created, is_accessible, inactive_state et tags.  

      data "oci_identity_groups" "existing_database_admin_nonprod_group" {
         compartment_id = var.tenancy_ocid
         filter {
            name   = "name"
            values = [var.existing_database_admin_nonprod_group_name]
         }
      }

Cette *data source* obtient la liste des groupes dans un compartiment spécifique puis filtre cette liste avec le nom de l'*auditor_group*. Cette *data source* reçoit l'OCID du Compartiment comme argument et le nom du *auditor_group* comme paramètre pour filtrer la liste des groupes. L'attribut *groups* est exporté. Cet attribut est une liste qui contient dans ce cas un seul groupe, qui est le groupe dont le nom correspond à celui de l'*auditor_group*. Ce groupe a les attributs suivants: compartment_id (parent ocid), id, name, state, description, time_created, is_accessible, inactive_state et tags.  

      data "oci_identity_groups" "existing_auditor_group" {
         compartment_id = var.tenancy_ocid
         filter {
            name   = "name"
            values = [var.existing_auditor_group_name]
         }
      }

Cette *data source* obtient la liste des groupes dans un compartiment spécifique puis filtre cette liste avec le nom de '*sys_admin_group*. Cette *data source* reçoit l'OCID du Compartiment comme argument et le nom du *sys_admin_group* comme paramètre pour filtrer la liste des groupes. L'attribut *groups* est exporté. Cet attribut est une liste qui contient dans ce cas un seul groupe, qui est le groupe dont le nom correspond à celui de l'*sys_admin_group*. Ce groupe a les attributs suivants: compartment_id (parent ocid), id, name, state, description, time_created, is_accessible, inactive_state et tags.  

      data "oci_identity_groups" "existing_sys_admin_group" {
         compartment_id = var.tenancy_ocid
         filter {
            name   = "name"
            values = [var.existing_sys_admin_group_name]
         }
      }

Cette *data source* obtient la liste des groupes dans un compartiment spécifique puis filtre cette liste avec le nom de l'*sys_admin_nonprod_group*. Cette *data source* reçoit l'OCID du Compartiment comme argument et le nom du *sys_admin_nonprod_group* comme paramètre pour filtrer la liste des groupes. L'attribut *groups* est exporté. Cet attribut est une liste qui contient dans ce cas un seul groupe, qui est le groupe dont le nom correspond à celui de *sys_admin_nonprod_group*. Ce groupe a les attributs suivants: compartment_id (parent ocid), id, name, state, description, time_created, is_accessible, inactive_state et tags.  

      data "oci_identity_groups" "existing_sys_admin_nonprod_group" {
         compartment_id = var.tenancy_ocid
         filter {
            name   = "name"
            values = [var.existing_sys_admin_nonprod_group_name]
         }
      }

Cette *data source* obtient la liste des groupes dans un compartiment spécifique puis filtre cette liste avec le nom de l'*exainfra_admin_group*. Cette *data source* reçoit l'OCID du Compartiment comme argument et le nom du *exainfra_admin_group* comme paramètre pour filtrer la liste des groupes. L'attribut *groups* est exporté. Cet attribut est une liste qui contient dans ce cas un seul groupe, qui est le groupe dont le nom correspond à celui de l'*exainfra_admin_group*. Ce groupe a les attributs suivants: compartment_id (parent ocid), id, name, state, description, time_created, is_accessible, inactive_state et tags.

      data "oci_identity_groups" "existing_exainfra_admin_group" {
         compartment_id = var.tenancy_ocid
         filter {
            name   = "name"
            values = [var.existing_exainfra_admin_group_name]
         }
      }

Cette *data source* fournit des détails sur une ressource *Cloud Guard Configuration* spécifique dans le service Oracle Cloud Infrastructure Cloud Guard. Cette *data source* reçoit l'OCID du *Compartment* comme argument. Cette *data source* exporte les attributs : reporting_region, self_manage_resources et status.  

      data "oci_cloud_guard_cloud_guard_configuration" "this" {
         compartment_id = var.tenancy_ocid
      }

Cette *data source* fournit des détails sur une ressource *Namespace* spécifique dans le service Oracle Cloud Infrastructure Object Storage. Cette *data source* reçoit l'OCID du Compartiment comme argument. L'attribut *Namespace* est exporté.  

      data "oci_objectstorage_namespace" "this" {
         compartment_id = var.tenancy_ocid
      }

---

### Scripts de configuration

#### Configuration

1. Définition

   Le module appelé *config* est le module principal, à partir duquel se fait la création de toutes les ressources d'infrastructure requises, en utilisant les modules définis dans le répertoire *modules*.

2. Structure

   Ce module est composé des fichiers suivants : variables.tf, locals.tf, outputs.tf, [data_sources.tf](../config/data_sources.tf) et des autres fichiers où chacun réalise la création des ressources pertinentes selon leur nom.
   C'est-à-dire, la création des ressources de type compartiment se fera dans le fichier *iam_compartments*, dans le fichier *iam_groups* sera la création des groupes, dans le fichier *net_vcn* la création des VCN et ainsi de suite.

##### [variables.tf](../config/variables.tf)

   Où se déclare et se définit la valeur par défaut de toutes les variables qui sont utilisées dans la configuration des ressources de l'infrastructure.
   C'est-à-dire, tous les paramètres qui pourraient être reçus comme entrée au module et sa valeur par défaut sont déclarés, au cas où ce paramètre ne soit pas fourni en exécutant le script.  
   Par exemple, dans la variable *use_enclosing_compartment* si elle n'est pas reçue comme paramètre true, la valeur false (par défaut) sera prise en compte. Le script réalisera une logique déterminée selon cette valeur. Pour ce cas, il créera ou non le compartiment en *root* dépendamment de si la valeur est *true* ou *false*.  

      variable "use_enclosing_compartment" {
         type        = bool
         default     = false
         description = "Whether the Landing Zone compartments are created within an enclosing compartment. If false, the Landing Zone compartments are created under the root compartment."
      }

##### [locals.tf](../config/locals.tf)

   Les valeurs aux variables locales sont définies dans ce fichier, c'est-à-dire aux variables qui pourront être utilisées seulement dans ce module.
   Par exemple, la variable locale *prod_compartment* est définie avec une *Map* qui a comme **__key**  *prod-cmp* et comme valeur assignée cette **__key** le nom du compartiment *cmp-prod-001*.  

      prod_compartment = {key:"prod-cmp", name:"cmp-prod-001"}

##### [outputs.tf](../config/outputs.tf)

   Défini les valeurs de sortie durant l'exécution de ce module.

3- Fonctionnement

   En utilisant les paramètres d'entre déclarés dans le fichier *variables.tf* et les valeurs statiques (hardcoded) définies dans le fichier *locals.tf*, chaque script charge les valeurs requises par le module à utiliser, dépendamment du type de ressource d'infrastructure responsable à créer.

   Par exemple, dans le script *iam_compartments.tf* charge les données requises par le module *iam-compartment*  

         cmps = {
            (local.security_compartment.key) = {
               parent_id     = local.parent_compartment_id
               name          = local.security_compartment.name
               description   = "Landing Zone compartment for all security related resources: vaults, topics, notifications, logging, scanning, and others."
               enable_delete = local.enable_cmp_delete
            }
         }

   et une fois chargées dans le paramètre, le script invoque ce module pour la création des ressources, dans ce cas-ci les compartiments.  

      module "lz_compartments" {
         source    = "../../modules/iam/iam-compartment"
         providers = { 
            oci = oci.home 
         }
         compartments = local.cmps
      }

#### [iam_compartments](../config/iam_compartments.tf)

Dans ce script, les donnes les données des compartiments à créer dans la structure des données requises comme paramètre pour le module *iam-compartment* sont chargées. Ensuite, avec ce paramètre (*Map*), le module *iam-compartment* est appelé pour faire la création des compartiments.

La logique détaillée de ce script est la suivante :

1. Ça commence avec l'exécution du module *module lz_top_compartment*, lequel prend comme paramètre entrée les variables *use_enclosing_compartment* et *existing_enclosing_compartment_ocid*, où la variable *use_enclosing_compartment* peut être *true* ou *false*. La variable *existing_enclosing_compartment_ocid* peut être un string (ocid) ou elle peut être null.
Ensuite, la condition (use_enclosing_compartment==true && existing_enclosing_compartment_ocid == null) est évaluée et selon cette évaluation les actions suivantes sont exécutées :
Si la condition est respectée, un compartiment racine sera donc créé avec le nom défini dans la variable locale *default_enclosing_compartment.name*'
Si la condition n'est pas respectée, aucun compartiment racine ne sera créé (enclosing compartment).

2. Le parent_compartment_id s'obtient et c'est pour cela que la condicion d'entrée (use_enclosing_compartment == true) est vérifiée.
Si la condition est remplie (use_enclosing_compartment= true) la variable d'entrée *existing_enclosing_compartment_ocid != null* sera évaluée. Si la condition que l'ocid est passé comme paramètre d'entrée est remplie, cet ocid sera donc retourné. Si la condition (existing_enclosing_compartment_ocid!=null) n'est pas remplie, l'ocid du compartiment racine créé dans l'étape 1 sera obtenu.
Si la condition n'est pas remplie (use_enclosing_compartment=false), c'est-à-dire qu'aucun compartiment racine ait été passé comme paramètre et non plus créé par défaut. L'ocid tenancy, c'est-à-dire l'ocid de *root* est donc retourné

3. L'ocid retourné dans l'étape 2 est assigné à la variable locale *parent_compartment_id*.

4. Les compartiments à créer sont chargés dans une *Map* en utilisant comme *parent_id* de chaque compartiment l'ocid obtenu dans l'étape 2. Le *name* et l'attribut *enable_delete* sont obtenus pour chaque compartiment des valeurs définies (hardcoded) dans le fichier locals.tf

#### [iam_groups](../config/iam_groups.tf)

Dans ce script, les données des *groups* à créer dans la structure des données requises comme paramètre pour le module *iam-group* sont chargées. Ensuite, avec ce paramètre (*Map*), le module *iam-group* est appelé pour faire la création des compartiments.

La logique détaillée de ce script est la suivante :

1. chacun des objets de type groupe est créé avec les attributs: description, user_ids et defined_tags, et est assigné à une variable nommée avec le nom du groupe, qui est extrait de *[locals.tf](../config/locals.tf)*. Pour l'attribut description de chaque objet, le nom du compartiment est ajouté. Le nom du compartiment est obtenu à partir de *locals.tf*.
2. la variable locale de type *Map* nommée *default_groups* est définie avec tous les objets de type group créés à l'étape 1.
3. il est déterminé si un groupe exadata est requis en fonction de la condition *length(var.exacs_vcn_cidrs) > 0 && var.deploy_exainfra_cmp == true*. Il est évalué si un *cidr* pour le *vcn exadata* a été passé en tant que paramètre d'entrée et si le paramètre qui indique qu'il existe un *compartiment* pour exadata est vrai. Si les deux conditions sont vraies, un groupe est créé pour *exadata* et assigné à la variable locale *exainfra_group*. Si un paramètre pour le *cidr* exadata *vcn* n'est pas transmis ou si l'indicateur de déploiement *cmp* pour exadata est faux, un objet *null* est assigné à la variable locale *exainfra_group*.
4. la fusion (*merge*) de *default_groups* chargé à l'étape 2 et de *exainfra_group* chargé à l'étape 3 est assignée à la variable locale *groupes*.
5. si la condition *var.use_existing_groups == false* est *false* le module *iam-group* est appelé en passant comme paramètre la variable groupes chargée dans l'étape 4, pour sa création.

#### iam_policies

Dans le script [/config/iam_policies.tf](../config/iam_policies.tf), les données des *policies* à créer dans la structure des données (*Map*) requises comme paramètre pour le module *iam-policy* sont chargées. Ensuite, avec ce paramètre, le module *iam-policy* est appelé pour faire la création des *policies*.

La logique détaillée de ce script est la suivante :

1. les différentes permissions requises pour chaque groupe sont définies, regroupées dans un *array* et assignées à une variable locale. Le nom du groupe auquel s'applique la permission est obtenu à partir du fichier *[locals.tf](../config/locals.tf)*.

Les groupes d'autorisations définis sont:

iam_root_permissions, iam_enccmp_permissions, security_root_permissions, cybersecurity_root_permissions, cybersecurity_permissions, network_permissions, database_permissions, database_nonprod_permissions, database_permissions_on_exainfra_cmp, sys_permissions, sys_nonprod_permissions, appdev_permissions, et exainfra_permissions.

ci-dessous un exemple de définition d'autorisations pour un groupe spécifique :

      security_root_permissions = [
         "Allow group ${local.security_admin_group_name} to read all-resources in tenancy",
         "Allow group ${local.security_admin_group_name} to use cloud-shell in tenancy"
      ]

2. Des stratégies (*policies*) sont définies pour chaque groupe. La définition de chaque *policy* consiste à créer un objet avec le nom de la *policy*. Le nom de la *policy* est obtenu à partir de *locals.tf*. Chaque objet (policy) associe un groupe de permissions parmi celles créées à l'étape 1, l'identifiant du compartiment parent *parent_compartment_id* et une description qui inclut le nom du groupe auquel il s'applique.

Voici un exemple de la définition d'une *policy* :

      (local.cybersecurity_admin_root_policy_name) = {
         compartment_id = var.tenancy_ocid
         description    = "Landing Zone ${local.cybersecurity_admin_group_name}'s root compartment policy."
         statements     = local.cybersecurity_root_permissions
      }
  
Dans *statements*, le groupe d'autorisations requis parmi ceux créés à l'étape 1 est assigné.

3. Tous les objets *policy* créés à l'étape 2 sont regroupés dans la *Map* *default_policies*. Dans la *Map* *exainfra_policy* la policy pour le compartiment *exadata* est assignée au cas où une serait requise.

4. La fusion des *policies* définies dans *default_policies* et la *policy* définie dans *exainfra_policy* est effectuée et assignée à la variable *policies*.

5. Le module *iam-policy* est appelé en passant comme paramètre la *Map* stratégies (*policies*) chargée dans l'étape 4, pour sa création.

#### net_drg

Dans le script [/config/net_drg.tf](../config/net_drg.tf), les données de *drg* à créer dans la structure des données (*Map*) requises comme paramètre pour le module *drg* sont chargées. Ensuite, avec ce paramètre, le module */modules/network/drg* est appelé pour faire la création du *drg*.

La logique détaillée de ce script est la suivante :

1. La ressource *null_resource.slow_down_drg* est appelée pour s'assurer que le *module module.lz_compartments* chargé de créer les compartiments est déjà exécuté.

      depends_on     = [ null_resource.slow_down_drg ]

2. Un *sleep* du nombre de secondes défini dans la variable d'entrée *local.delay_in_secs* est effectué. Ce *sleep* est destiné à laisser suffisamment de temps pour que les compartiments créés soient disponibles.

   provisioner "local-exec" {
      command = "sleep ${local.delay_in_secs}" # Wait for compartments to be available.
   }

3. Une fois le *sleep* de l'étape 2 est terminé, l'id du compartiment network est recherché dans les compartiments créés par *module.lz_compartments.compartments* à l'aide de la variable locale *local.network_compartment.key*.

      compartment_id = module.lz_compartments.compartments[local.network_compartment.key].id

4. L'attribut *service_label* du module *drg* est défini comme *cmp-conne-cam1-001*.

      service_label  = "cmp-conne-cam1-001"

5. L'attribut *is_create_drg* est défini pour déterminer s'il faut ou non créer une *drg* en fonction de l'évaluation de la condition *(var.is_vcn_onprem_connected == true || var.hub_spoke_architecture) && var.existing_drg_id == ""*

Dans cette condition, si le paramètre d'entrée *is_vcn_onprem_connected* est vrai, cela indique que le *vcn* est connecté au réseau du client ou le paramètre d'entrée *var.hub_spoke_architecture* est vrai, indiquant qu'il s'agit d'un type de déploiement *spoke* et le paramètre d'entrée *var.existing_drg_id* n'est pas défini, donc l'attribut *is_create_drg* est défini comme true. S'il ne s'agit pas d'un *vcn* connecté au client ou d'une architecture *spoke*, l'attribut *is_create_drg* sera défini sur false.

Si la variable d'entrée *var.existing_drg_id* est déjà définie, l'attribut *is_create_drg* sera défini sur false quelle que soit la valeur des autres variables d'entrée.

6- Le module */network/drg* est appelé avec les attributs définis dans les étapes précédentes, pour la création du *drg* requis.

#### net_dmz

Dans le script [/config/net_dmz.tf](../config/net_dmz.tf), les données des *vcns* et des *route_tables* à créer sont chargées dans la structure des données (*Map*) requises comme paramètre pour les modules *modules/network/vcn-basic* et */modules/network/vcn-routing*. Ensuite, avec ces paramètres, les modules *vcn-basic* et *vcn-routing* sont appelés pour faire la création du *vcns* et *route_tables*.

La logique détaillée de ce script est la suivante :

1. la condition var.hub_spoke_architecture && length(var.dmz_vcn_cidr) > 0 est évaluée pour déterminer si un dmz_vcn doit être créé. Pour que la création de dmz_vcn continue, le paramètre d'entrée hub_spoke_architecture doit être vrai et le paramètre d'entrée var.dmz_vcn_cidr doit être défini. Si l'un de ces paramètres n'est pas vrai, une *Map* vide est retournée, indiquant qu'il n'est pas nécessaire de créer de dmz_vcn.

2. étant la condition de l'étape 1. réussie. Les attributs de base du *dmz_vcn* sont chargés à l'aide des paramètres d'entrée. L'attibut *id du compartiment* est recherché dans les compartiments créés par *module.lz_compartments.compartments* à l'aide de la variable locale *local.network_compartment.key*. L'attribut *is_create_igw* est défini comme true si un accès Internet est requis et l'attribut *is_attach_drg* est défini comme true si un *firewall dmz* n'est pas requis. Les autres attributs sont *hard-coded* comme se présenté dans l'extrait de code suivant:

   compartment_id    = module.lz_compartments.compartments[local.network_compartment.key].id
   cidr              = var.dmz_vcn_cidr
   dns_label         = "dmz"
   is_create_igw     = !var.no_internet_access
   is_attach_drg     = var.dmz_for_firewall == true ? false : true
   block_nat_traffic = false
   defined_tags      = null

3. les subnets du *dmz_vcn* sont chargés. Pour cela, le paramètre d'entrée *var.dmz_number_of_subnets* est traversé dans une boucle FOR à partir de laquelle les attributs de chacun des *subnets* sont obtenus et regroupés dans un objet avec le nom du *subnet*. Ensuite, chaque objet *subnet* est chargé dans l'attribut *subnets* du dms_vcn.

      subnets = {
         for s in range(var.dmz_number_of_subnets) : "${local.dmz_subnet_names[s]}" => {
            compartment_id  = null
            name            = "${local.dmz_subnet_names[s]}"
            cidr            = cidrsubnet(var.dmz_vcn_cidr, var.dmz_subnet_size, s)
            dns_label       = local.dmz_subnet_dns[s]
            private         = var.no_internet_access ? true : s == 0 || (local.is_mgmt_subnet_public && s == 2) ? false : true
            dhcp_options_id = null
            defined_tags    = null
            security_lists = { "security-list" : {
              compartment_id : null
              is_create : true
              ingress_rules : [{
                  is_create : s < 2
                  protocol : "all"
                  stateless : false
                  description : "Allows all protocols from anywhere."
                  src : "0.0.0.0/0"
                  src_type : "CIDR_BLOCK"
                  icmp_type : null
                  icmp_code : null
                  src_port_min : null
                  src_port_max : null
                  dst_port_min : null
                  dst_port_max : null
               },
               {
                  is_create : s == 2
                  protocol : "1"
                  stateless : false
                  description : "Allows ICMP protocols from anywhere. "
                  src : "0.0.0.0/0"
                  src_type : "CIDR_BLOCK"
                  icmp_type : null
                  icmp_code : null
                  src_port_min : null
                  src_port_max : null
                  dst_port_min : null
                  dst_port_max : null
               },
               {
                  is_create : s == 2
                  protocol : "6"
                  stateless : false
                  description : "Allows SSH protocols from anywhere. "
                  src : "0.0.0.0/0"
                  src_type : "CIDR_BLOCK"
                  icmp_type : null
                  icmp_code : null
                  src_port_min : null
                  src_port_max : null
                  dst_port_min : "22"
                  dst_port_max : "22"
               },
               {
                  is_create : s == 2
                  protocol : "6"
                  stateless : false
                  description : "Allows HTTP protocols from anywhere. "
                  src : "0.0.0.0/0"
                  src_type : "CIDR_BLOCK"
                  icmp_type : null
                  icmp_code : null
                  src_port_min : null
                  src_port_max : null
                  dst_port_min : "80"
                  dst_port_max : "80"
               },
               {
                  is_create : s == 2
                  protocol : "6"
                  stateless : false
                  description : "Allows HTTPS protocols from anywhere. "
                  src : "0.0.0.0/0"
                  src_type : "CIDR_BLOCK"
                  icmp_type : null
                  icmp_code : null
                  src_port_min : null
                  src_port_max : null
                  dst_port_min : "443"
                  dst_port_max : "443"
               },
               {
                  is_create : s == 3
                  protocol : "all"
                  stateless : false
                  description : "Allows all protocols from hosts in ${cidrsubnet(var.dmz_vcn_cidr, var.dmz_subnet_size, s)} CIDR range."
                  src : cidrsubnet(var.dmz_vcn_cidr, var.dmz_subnet_size, s)
                  src_type : "CIDR_BLOCK"
                  icmp_type : null
                  icmp_code : null
                  src_port_min : null
                  src_port_max : null
                  dst_port_min : null
                  dst_port_max : null
               }]
               egress_rules : [{
                  is_create : s < 3
                  protocol : "all"
                  stateless : false
                  description : "Allows all protocols from anywhere."
                  dst : "0.0.0.0/0"
                  dst_type : "CIDR_BLOCK"
                  icmp_type : null
                  icmp_code : null
                  src_port_min : null
                  src_port_max : null
                  dst_port_min : null
                  dst_port_max : null
               },
               {
                  is_create : s == 3
                  protocol : "all"
                  stateless : false
                  description : "Allows all protocols from hosts in ${cidrsubnet(var.dmz_vcn_cidr, var.dmz_subnet_size, s)} CIDR range."
                  dst : cidrsubnet(var.dmz_vcn_cidr, var.dmz_subnet_size, s)
                  dst_type : "CIDR_BLOCK"
                  icmp_type : null
                  icmp_code : null
                  src_port_min : null
                  src_port_max : null
                  dst_port_min : null
                  dst_port_max : null
               }]
              defined_tags  = null
              freeform_tags = null
            }
         }
      }
   }

A noter que pour définir le *cidr* du *subnet*, on utilise la fonction *cidrsubnet* pour calculer une adresse de sous-réseau dans un préfixe d'adresse réseau IP donné.

4- Les *route_tables* sont chargées pour chacun des *subnets* créés via le module *module.lz_vcn_dmz.subnets*. Pour cela, chacun des *subnet* créés est parcouru par une boucle FOR.

   dmz_route_tables = { for key, subnet in module.lz_vcn_dmz.subnets : replace("rtable-${key}", "vcn-", "") => {
   compartment_id = subnet.compartment_id
   vcn_id         = subnet.vcn_id
   subnet_id      = subnet.id
   defined_tags   = null

Pour chaque *subnet*, l'attribut *route_rules* est défini avec un *array* d'objets de type *route_rules*. Le premier objet *route_rules* est la configuration de la table de routage pour le Service Gateway avec ou sans accès Internet.

    route_rules = concat([{
      is_create         = var.no_internet_access
      destination       = local.valid_service_gateway_cidrs[0]
      destination_type  = "SERVICE_CIDR_BLOCK"
      network_entity_id = module.lz_vcn_dmz.service_gateways[subnet.vcn_id].id
      description       = "Traffic destined to ${local.valid_service_gateway_cidrs[0]} goes to Service Gateway."
      },
      {
        is_create         = !var.no_internet_access
        destination       = local.valid_service_gateway_cidrs[1]
        destination_type  = "SERVICE_CIDR_BLOCK"
        network_entity_id = module.lz_vcn_dmz.service_gateways[subnet.vcn_id].id
        description       = "Traffic destined to ${local.valid_service_gateway_cidrs[1]} goes to Service Gateway."
      },

Le second est l'objet *route_rules* pour la configuration route_table de *internet gateway*.

      {
        is_create         = !var.no_internet_access
        destination       = local.anywhere
        destination_type  = "CIDR_BLOCK"
        network_entity_id = !var.no_internet_access ? module.lz_vcn_dmz.internet_gateways[subnet.vcn_id].id : null
        description       = "Traffic destined to ${local.anywhere} CIDR range goes to Internet Gateway."

      }

Ensuite, les *route_rules* pour *vcn_spokes* .

      [for vcn_name, vcn in local.all_lz_vcn_spokes : {
        is_create         = var.hub_spoke_architecture
        destination       = vcn.cidr_block
        destination_type  = "CIDR_BLOCK"
        network_entity_id = var.existing_drg_id != "" ? var.existing_drg_id : (module.lz_drg.drg != null ? module.lz_drg.drg.id : null)
        description       = "Traffic destined to ${vcn_name} VCN (${vcn.cidr_block} CIDR range) goes to DRG."
        }
      ],

et les *route_rules* pour *on-premises* sont chargées. C'est-à-dire, la liste des *on-premises* *cidr*  blocs autorisés à se connecter au réseau Landing Zone via un *DRG*.

      [for cidr in var.onprem_cidrs : {
        is_create         = true
        destination       = cidr
        destination_type  = "CIDR_BLOCK"
        network_entity_id = var.existing_drg_id != "" ? var.existing_drg_id : (module.lz_drg.drg != null ? module.lz_drg.drg.id : null)
        description       = "Traffic destined to on-premises ${cidr} CIDR range goes to DRG."
        }
      ],

Finalement, les *route_rules* pour le *vcn_exadata* sont chargées. C'est-à-dire,  la liste des *CIDR* blocs pour *Exadata Cloud Service*

      [for cidr in var.exacs_vcn_cidrs : {
        is_create         = var.hub_spoke_architecture
        destination       = cidr
        destination_type  = "CIDR_BLOCK"
        network_entity_id = var.existing_drg_id != "" ? var.existing_drg_id : (module.lz_drg.drg != null ? module.lz_drg.drg.id : null)
        description       = "Traffic destined to Exadata VCN (${cidr} CIDR range) goes to DRG."
        }
      ]

5- Le module */modules/network/vcn-basic* est appelé en passant comme paramètre la variable *local.dmz_vcn* chargée dans l'étape 2 et 3, pour sa création.

6- Le module */modules/network/vcn-routing* est appelé en passant comme paramètre la variable *local.dmz_route_tables* chargée dans l'étape 4, pour sa création.

#### net_dmz_nsgs

Dans le script [/config/net_dmz_nsgs.tf](../config/net_dmz_nsgs.tf), les données de *Security Groups* à créer sont chargées dans la structure des données (*Map*) requises comme paramètre pour le module */network/security*. Ensuite, avec ce paramètre, le module */modules/network/security* est appelé pour faire la création du *Network Security Groups*.

La logique détaillée de ce script est la suivante :

1- Les noms *Network Security Groups* (nsg) sont déterminés à partir de la variable locale *local.dmz_vcn_name.name* et en ajoutant un préfixe unique pour identifier chaque *nsg*. Exemple :

      dmz_services_nsg_name   = length(var.dmz_vcn_cidr) > 0 ? "nsg-servi-${local.dmz_vcn_name.name}" : null

où "nsg-serv-" est le préfixe pour identifier ce *nsg*.

2- Créer une *Map* regroupant les *egress_rules* pour autoriser les connexions *ssh* à chacun des *vcn spokes*.

      ssh_dmz_to_spokes_nsg_egress_rules = { 
         for k, v in local.all_lz_vcn_spokes : "${k}-dmz-ssh-egress-rule" => {
            is_create : true,
            description : "Allows SSH connections to hosts in ${k} VCN (${v.cidr_block} CIDR range).",
            protocol : "6",
            stateless : false,
            dst : v.cidr_block,
            dst_type : "CIDR_BLOCK",
            dst_port_min : 22,
            dst_port_max : 22,
            src_port_min : null,
            src_port_max : null,
            icmp_type : null,
            icmp_code : null
         }
      }

3- Créer une *Map* regroupant les egress_rules pour autoriser les connexions *ssh* pour chaque *vcn Exadata*.

      ssh_dmz_to_exacs_nsg_egress_rules = { 
         for k, v in module.lz_exacs_vcns.vcns : "ssh-exacs-${k}-egress-rule" => {
            is_create : true,
            description : "Allows SSH connections to hosts in Exadata ${k} VCN (${v.cidr_block} CIDR range).",
            protocol : "6",
            stateless : false,
            dst : v.cidr_block,
            dst_type : "CIDR_BLOCK",
            dst_port_min : 22,
            dst_port_max : 22,
            src_port_min : null,
            src_port_max : null,
            icmp_type : null,
            icmp_code : null
         } 
      }

4- Les egress_rules continuent d'être regroupés de la même manière pour *autorise la communication vcns ONS avec les hosts dans Exadata*, *autorise les connexions SQLNet aux hosts dans Exadata* et *autorise les connexions HTTP aux vcns*.

5- *nsg* est défini pour autoriser les connexions HTTPS à un host dans le spectrum du CIDR.

      public_dst_cidrs_nsg = length(var.public_dst_cidrs) > 0 && length(var.dmz_vcn_cidr) > 0 ? { 
         (local.dmz_public_dst_nsg_name) : {
            vcn_id = module.lz_vcn_dmz.vcns[local.dmz_vcn_name.name].id
            ingress_rules : {},
            egress_rules : { 
               for cidr in var.public_dst_cidrs : "https-public-dst-egress-rule-${index(var.public_dst_cidrs, cidr)}" => {
                  is_create : length(var.public_dst_cidrs) > 0 && !var.no_internet_access && length(var.dmz_vcn_cidr) > 0,
                  description : "Allos HTTPS connections to hosts in ${cidr} CIDR range.",
                  stateless : false,
                  protocol : "6",
                  dst      = cidr,
                  dst_type = "CIDR_BLOCK",
                  src_port_min : null,
                  src_port_max : null,
                  dst_port_min : 443,
                  dst_port_max : 443,
                  icmp_code : null,
                  icmp_type : null
               }
            }
         } 
      }

6- Bastion *nsg* est défini. Pour cela, le nom défini à l'étape 1 est repris pour nommer l'objet qui regroupe tous les attributs de ce *nsg*. L'attribut *vcn_id* est obtenu à partir de la réponse *module.lz_vcn_dmz.vcns*.

6.1 Pour définir les *ingress_rules* de ce *nsg*, il faut d'abord qu'une boucle FOR traverse le paramètre d'entrée *public_src_bastion_cidrs* et pour chaque bloc cidr, un objet ingress_rule est créé, ce qui autorise la connexion SSH depuis un host dans le spectrum du *cidr*.

      { 
            for cidr in var.public_src_bastion_cidrs : "ssh-public-ingress-rule-${index(var.public_src_bastion_cidrs, cidr)}" => {
               is_create : (!var.no_internet_access && length(var.onprem_cidrs) == 0 && length(var.public_src_bastion_cidrs) > 0),
               description : "Allows SSH connections from hosts in ${cidr} CIDR range.",
               protocol : "6",
               stateless : false,
               src : cidr,
               src_type : "CIDR_BLOCK",
               dst_port_min : 22,
               dst_port_max : 22,
               src_port_min : null,
               src_port_max : null,
               icmp_type : null,
               icmp_code : null
            }
      }

et deuxièmement, une boucle FOR traverse le paramètre d'entrée *onprem_src_ssh_cidrs* et pour chaque bloc *cidr* un objet *ingress_rule* est créé qui autorise la connexion *SSH* à partir d'un host défini dans le spectrum *cidr* de *on-premises*.

      { 
         for cidr in var.onprem_src_ssh_cidrs : "ssh-onprem-ingress-rule-${index(var.onprem_src_ssh_cidrs, cidr)}" => {
            is_create : length(var.onprem_src_ssh_cidrs) > 0,
            description : "Allows SSH connections from hosts in on-premises ${cidr} CIDR range.",
            protocol : "6",
            stateless : false,
            src : cidr,
            src_type : "CIDR_BLOCK",
            dst_port_min : 22,
            dst_port_max : 22,
            src_port_min : null,
            src_port_max : null,
            icmp_type : null,
            icmp_code : null
         }
      }

Finalement, les objets *bastion ingress rules* sont fusionnés avec les *on-premises ingress rules* et assignés à l'attribut *ingress_rules* du *nsg*.

6.2 Pour définir les *egress_rules* de ce *nsg*, d'abord un objet *egress_rule* est créé qui autorise la connexion *SSH* à un *host* dans le vcn..

      { 
         dmz-services-egress-rule : 
         {
            is_create : true,
            description : "Allows SSH connections to hosts in ${local.dmz_services_nsg_name} NSG.",
            protocol : "6",
            stateless : false,
            dst      = local.dmz_services_nsg_name,
            dst_type = "NSG_NAME",
            dst_port_min : 22,
            dst_port_max : 22,
            src_port_min : null,
            src_port_max : null,
            icmp_type : null,
            icmp_code : null
         }
      }

et deuxièmement un objet *egress_rule* est créé qui autorise la connexion *SSH* à un host dans le spectrum du *cidr*.

      {
         osn-services-egress-rule : 
         {
            is_create : true,
            description : "Allows HTTPS connections to hosts in ${local.valid_service_gateway_cidrs[0]}.",
            protocol : "6",
            stateless : false,
            dst      = local.valid_service_gateway_cidrs[0],
            dst_type = "SERVICE_CIDR_BLOCK",
            dst_port_min : 443,
            dst_port_max : 443,
            src_port_min : null,
            src_port_max : null,
            icmp_type : null,
            icmp_code : null
         } 
      }

Finalement, les objets *services-egress-rule* sont fusionnés avec les *osn-services-egress-rule* et assignés à l'attribut *egress_rules* du *nsg*.

7- *lb_nsg*  est défini. Pour cela, le nom défini à l'étape 1 est repris pour nommer l'objet qui regroupe tous les attributs de ce *nsg*. L'attribut *vcn_id* est obtenu à partir de la réponse *module.lz_vcn_dmz.vcns*.

      vcn_id = module.lz_vcn_dmz.vcns[local.dmz_vcn_name.name].id

pour définir les *ingress_rules* de ce *nsg*:

7.1 Une boucle FOR traverse le paramètre d'entrée *public_src_bastion_cidrs* et pour chaque bloc cidr, un objet ingress_rule est créé, ce qui autorise la connexion *SSH* depuis un host dans le spectrum du *cidr*.

      { 
         for cidr in var.public_src_bastion_cidrs : "ssh-public-ingress-rule-${index(var.public_src_bastion_cidrs, cidr)}" => {
            is_create : (!var.no_internet_access && length(var.onprem_cidrs) == 0 && length(var.public_src_bastion_cidrs) > 0),
            description : "Allows HTTP connections from hosts in ${cidr} CIDR range.",
            protocol : "6",
            stateless : false,
            src : cidr,
            src_type : "CIDR_BLOCK",
            dst_port_min : 80,
            dst_port_max : 80,
            src_port_min : null,
            src_port_max : null,
            icmp_type : null,
            icmp_code : null
         }
      }

7.2 Une boucle FOR traverse le paramètre d'entrée *onprem_src_ssh_cidrs* et pour chaque bloc cidr, un objet ingress_rule est créé, ce qui autorise la connexion *SSH* depuis un host dans le *on-premises* spectrum du *cidr*.

      {
         for cidr in var.onprem_src_ssh_cidrs : "ssh-onprem-ingress-rule-${index(var.onprem_src_ssh_cidrs, cidr)}" => {
            is_create : length(var.onprem_src_ssh_cidrs) > 0,
            description : "Allows HTTP connections from hosts in on-premises ${cidr} CIDR range.",
            protocol : "6",
            stateless : false,
            src : cidr,
            src_type : "CIDR_BLOCK",
            dst_port_min : 80,
            dst_port_max : 80,
            src_port_min : null,
            src_port_max : null,
            icmp_type : null,
            icmp_code : null
         }
      }

7.3 Une boucle FOR traverse le paramètre d'entrée *public_src_bastion_cidrs* et pour chaque bloc cidr, un objet ingress_rule est créé, ce qui autorise la connexion *HTTP* depuis un host dans le spectrum du *cidr*.

      {
         for cidr in var.public_src_bastion_cidrs : "ssh-public-ingress-rule-${index(var.public_src_bastion_cidrs, cidr)}" => {
            is_create : (!var.no_internet_access && length(var.onprem_cidrs) == 0 && length(var.public_src_bastion_cidrs) > 0),
            description : "Allows HTTP connections from hosts in ${cidr} CIDR range.",
            protocol : "6",
            stateless : false,
            src : cidr,
            src_type : "CIDR_BLOCK",
            dst_port_min : 443,
            dst_port_max : 443,
            src_port_min : null,
            src_port_max : null,
            icmp_type : null,
            icmp_code : null
         }
      }

7.4 Une boucle FOR traverse le paramètre d'entrée *onprem_src_ssh_cidrs* et pour chaque bloc cidr, un objet ingress_rule est créé, ce qui autorise la connexion *HTTP* depuis un host dans le *on-premises* spectre du *cidr*.

      {
         for cidr in var.onprem_src_ssh_cidrs : "ssh-onprem-ingress-rule-${index(var.onprem_src_ssh_cidrs, cidr)}" => {
            is_create : length(var.onprem_src_ssh_cidrs) > 0,
            description : "Allows HTTP connections from hosts in on-premises ${cidr} CIDR range.",
            protocol : "6",
            stateless : false,
            src : cidr,
            src_type : "CIDR_BLOCK",
            dst_port_min : 443,
            dst_port_max : 443,
            src_port_min : null,
            src_port_max : null,
            icmp_type : null,
            icmp_code : null
         }
      }

7.5 Finalement, les objets *ingress-rule* sont fusionnés et assignés à l'attribut *ingress_rules* du *nsg*.

pour définir les *egress-rule* de ce *nsg*:

7.6 Un objet *egress_rule* est créé qui autorise la connexion *SSH* à un host dans le spectre du *cidr*.

      { 
         osn-services-egress-rule : {
            is_create : true,
            description : "Allows HTTPS connections to hosts in ${local.valid_service_gateway_cidrs[0]}.",
            protocol : "6",
            stateless : false,
            dst      = local.valid_service_gateway_cidrs[0],
            dst_type = "SERVICE_CIDR_BLOCK",
            dst_port_min : 443,
            dst_port_max : 443,
            src_port_min : null,
            src_port_max : null,
            icmp_type : null,
            icmp_code : null
         }
      }

7.7 Finalement, les objets *egress-rule* sont fusionnés et assignés à l'attribut *egress_rules* du *nsg*.

8- *services_nsg* est défini. Pour cela, le nom défini à l'étape 1 est repris pour nommer l'objet qui regroupe tous les attributs de ce *nsg*. L'attribut *vcn_id* est obtenu à partir de la réponse *module.lz_vcn_dmz.vcns*.

pour définir les *ingress_rules* de ce *nsg*:

8.1 Une boucle FOR traverse le paramètre d'entrée *onprem_cidrs* et pour chaque bloc cidr, un objet ingress_rule est créé, ce qui autorise la connexion *SSH* depuis un host dans le *on-premises* spectre du *cidr*.

      { 
         for cidr in var.onprem_cidrs : "http-onprem-ingress-rule-${index(var.onprem_cidrs, cidr)}" => {
            is_create : length(var.onprem_cidrs) > 0,
            description : "Allows HTTPS connections from hosts in on-premises ${cidr} CIDR range.",
            protocol : "6",
            stateless : false,
            src : cidr,
            src_type : "CIDR_BLOCK",
            dst_port_min : 443,
            dst_port_max : 443,
            src_port_min : null,
            src_port_max : null,
            icmp_type : null,
            icmp_code : null
         }
      }

8.2 Une boucle FOR traverse le paramètre d'entrée *public_src_lbr_cidrs* et pour chaque bloc cidr, un objet ingress_rule est créé, ce qui autorise la connexion *HTTPS* depuis un host dans le spectre du *cidr*.

      { 
         for cidr in var.public_src_lbr_cidrs : "http-public-ingress-rule--${index(var.public_src_lbr_cidrs, cidr)}" => {
            is_create : !var.no_internet_access && length(var.public_src_lbr_cidrs) > 0,
            description : "Allows HTTPS connections from hosts in ${cidr} CIDR range.",
            protocol : "6",
            stateless : false,
            src : cidr,
            src_type : "CIDR_BLOCK",
            dst_port_min : 443,
            dst_port_max : 443,
            src_port_min : null,
            src_port_max : null,
            icmp_type : null,
            icmp_code : null
         }
      }

8.3 Finalement, les objets *ingress-rule* sont fusionnés et assignés à l'attribut *ingress_rules* du *nsg*.

pour définir les *egress-rule* de ce *nsg*:

8.4 Un objet *egress_rule* est créé qui autorise la connexion *HTTPS* à un host dans le spectre du *cidr*.

      {
         osn-services-egress-rule : {
            is_create : true,
            description : "Allows HTTPS connections to ${local.valid_service_gateway_cidrs[0]}.",
            protocol : "6",
            stateless : false,
            dst      = local.valid_service_gateway_cidrs[0],
            dst_type = "SERVICE_CIDR_BLOCK",
            dst_port_min : 443,
            dst_port_max : 443,
            src_port_min : null,
            src_port_max : null,
            icmp_type : null,
            icmp_code : null
         }
      }

#### net_nsgs

Dans le script [/config/net_nsgs.tf](../config/net_nsgs.tf), les données de *Security Groups* à créer sont chargées dans la structure des données (*Map*) requises comme paramètre pour le module *[/network/security](../../modules/network/security)*. Ensuite, avec ce paramètre, le module *[/modules/network/security](../../modules/network/security)* est appelé pour faire la création du *Network Security Groups*.

La logique détaillée de ce script est la suivante :

1 Un bastion *nsg* est défini. Pour cela, une boucle FOR traverse le résultat du  *module.lz_vcn_sandbox.vcns* et pour chaque *vcn*, un objet *nsg-bastion* est créé

1.1 Pour définir les *ingress_rules* de ce *nsg*, une boucle FOR traverse le paramètre d'entrée *public_src_bastion_cidrs* et pour chaque bloc cidr, un objet ingress_rule est créé, ce qui autorise la connexion SSH depuis un host dans le spectre du *cidr* .

      ingress_rules : merge( 
         { for cidr in var.public_src_bastion_cidrs : "ssh-public-ingress-rule-${index(var.public_src_bastion_cidrs, cidr)}" => {
            is_create : !var.no_internet_access && length(var.public_src_bastion_cidrs) > 0,
            description : "Allows SSH connections from hosts in ${cidr} CIDR range.",
            protocol : "6",
            stateless : false,
            src : cidr,
            src_type : "CIDR_BLOCK",
            dst_port_min : 22,
            dst_port_max : 22,
            src_port_min : null,
            src_port_max : null,
            icmp_type : null,
            icmp_code : null
            }
         })

1.2 Créer une *Map* *app-egress_rule* pour autoriser les connexions *ssh* à un *host* dans *nsg-app*.

      app-egress_rule : {
        is_create : true,
        description : "Allows SSH connections to hosts in nsg-app-${k} NSG.",
        stateless : false,
        protocol : "6",
        dst      = "nsg-app-${k}",
        dst_type = "NSG_NAME",
        dst_port_min : 22,
        dst_port_max : 22,
        src_port_min : null,
        src_port_max : null,
        icmp_type : null,
        icmp_code : null
      }

1.3 Créer une *Map* *db-egress_rule* pour autoriser les connexions *ssh* à un *host* dans *nsg-db*.

      db-egress_rule : {
        is_create : true,
        description : "Allows SSH connection to hosts in nsg-db-${k} NSG.",
        stateless : false,
        protocol : "6",
        dst      = "nsg-db-${k}",
        dst_type = "NSG_NAME",
        dst_port_min : 22,
        dst_port_max : 22,
        src_port_min : null,
        src_port_max : null,
        icmp_type : null,
        icmp_code : null
      }

1.4 Créer une *Map* *lbr-egress_rule* pour autoriser les connexions *ssh* à un *host* dans *nsg-lbr*.

      lbr-egress_rule : {
        is_create : true,
        description : "Allows SSH connection to hosts in nsg-lbr-${k} NSG.",
        stateless : false,
        protocol : "6",
        dst      = "nsg-lbr-${k}",
        dst_type = "NSG_NAME",
        dst_port_min : 22,
        dst_port_max : 22,
        src_port_min : null,
        src_port_max : null,
        icmp_type : null,
        icmp_code : null
      }

1.5 Créer une *Map* *osn-services-egress-rule* pour autoriser les connexions *ssh* à un *valid_service_gateway*.

      osn-services-egress-rule : {
         is_create : true,
         description : "Allows HTTPS connections to ${local.valid_service_gateway_cidrs[0]}.",
         stateless : false,
         protocol : "6",
         dst      = local.valid_service_gateway_cidrs[0],
         dst_type = "SERVICE_CIDR_BLOCK",
         dst_port_min : 443,
         dst_port_max : 443,
         src_port_min : null,
         src_port_max : null,
         icmp_type : null,
         icmp_code : null
      }

2  La liste des *lbr_nsg* est défini. Pour cela, une boucle for_each traverse le résultat du  *module.lz_vcn_sandbox.vcns* et pour chaque *vcn*, un objet *nsg-lbr* est créé

2.1 Créer une *Map* *ingress_rules* pour autoriser les connexions *ssh* depuis un host dans *nsg-lbr*.

      {
      ssh-ingress-rule : {
        is_create : true,
        description : "Allows SSH connections from hosts in nsg-bastion-${k} NSG.",
        stateless : false,
        protocol : "6",
        src : "nsg-bastion-${k}",
        src_type : "NSG_NAME",
        dst_port_min : 22,
        dst_port_max : 22,
        src_port_min : null,
        src_port_max : null,
        icmp_type : null,
        icmp_code : null
      }}

2.2 Pour définir les *ingress_rules* de ce *nsg*, une boucle FOR traverse le paramètre d'entrée *public_src_lbr_cidrs* et pour chaque bloc cidr, un objet ingress_rule est créé, ce qui autorise la connexion *HTTPS* depuis un host dans le spectre du *cidr*.

      { for cidr in var.public_src_lbr_cidrs : "http-public-ingress-rule-${index(var.public_src_lbr_cidrs, cidr)}" => {
        is_create : !var.no_internet_access && length(var.public_src_lbr_cidrs) > 0,
        description : "Allows HTTPS connections from hosts in ${cidr} CIDR range.",
        stateless : false,
        protocol : "6",
        src : cidr,
        src_type : "CIDR_BLOCK",
        dst_port_min : 443,
        dst_port_max : 443,
        src_port_min : null,
        src_port_max : null,
        icmp_type : null,
        icmp_code : null
        }
    }

2.3 Créer une *Map* *app-egress_rule* pour autoriser les connexions *ssh* à un *host* dans *nsg-app*.

      app-egress_rule : {
        is_create : true,
        description : "Allows HTTP connections to hosts in nsg-app-${k} NSG.",
        stateless : false,
        protocol : "6",
        dst      = "nsg-app-${k}",
        dst_type = "NSG_NAME",
        dst_port_min : 80,
        dst_port_max : 80,
        src_port_min : null,
        src_port_max : null,
        icmp_type : null,
        icmp_code : null
      }

2.4 Créer une *Map* *osn-services-egress-rule* pour autoriser les connexions *HTTPS* à un *valid_service_gateway*.

      osn-services-egress-rule : {
         is_create : true,
         description : "Allows HTTPS connections to ${local.valid_service_gateway_cidrs[0]}.",
         stateless : false,
         protocol : "6",
         dst      = local.valid_service_gateway_cidrs[0],
         dst_type = "SERVICE_CIDR_BLOCK",
         dst_port_min : 443,
         dst_port_max : 443,
         src_port_min : null,
         src_port_max : null,
         icmp_type : null,
         icmp_code : null
      }

3 La liste *app_nsgs* est définie. Pour cela, une boucle FOR traverse le résultat du  *module.lz_vcn_sandbox.vcns* et pour chaque *vcn*, un objet *nsg-app* est créé

3.1 Créer une *Map* *ssh-ingress-rule* pour autoriser les connexions *ssh* depuis un host dans *nsg-bastion*.

      ssh-ingress-rule : {
        is_create : true,
        description : "Allows SSH connections from hosts in nsg-bastion-${k} NSG.",
        stateless : false,
        protocol : "6",
        src : "nsg-bastion-${k}",
        src_type : "NSG_NAME",
        dst_port_min : 22,
        dst_port_max : 22,
        src_port_min : null,
        src_port_max : null,
        icmp_type : null,
        icmp_code : null
      }

3.2 Créer une *Map* *http-ingress-rule* pour autoriser les connexions *HTTP* à un host dans *nsg-lbr*.

      http-ingress-rule : {
        is_create : true,
        description : "Allows HTTP connections to hosts in nsg-lbr-${k} NSG.",
        stateless : false,
        protocol : "6",
        src : "nsg-lbr-${k}",
        src_type : "NSG_NAME",
        dst_port_min : 80,
        dst_port_max : 80,
        src_port_min : null,
        src_port_max : null,
        icmp_type : null,
        icmp_code : null
      }

3.3 Créer une *Map* *db-egress-rule* pour autoriser les connexions *SQLNet* à un *host* dans *nsg-db*.

      db-egress-rule : {
        is_create : true,
        description : "Allows SQLNet connections to hosts in nsg-db-${k} NSG.",
        stateless : false,
        protocol : "6",
        dst      = "nsg-db-${k}",
        dst_type = "NSG_NAME",
        src_port_min : null,
        src_port_max : null,
        dst_port_min : 1521,
        dst_port_max : 1522,
        icmp_code : null,
        icmp_type : null
      }

3.4 Créer une *Map* *osn-services-egress-rule* pour autoriser les connexions *HTTPS* à un *valid_service_gateway*.

      osn-services-egress-rule : {
         is_create : true,
         description : "Allows HTTPS connections to ${local.valid_service_gateway_cidrs[0]}.",
         stateless : false,
         protocol : "6",
         dst      = local.valid_service_gateway_cidrs[0],
         dst_type = "SERVICE_CIDR_BLOCK",
         src_port_min : null,
         src_port_max : null,
         dst_port_min : 443,
         dst_port_max : 443,
         icmp_code : null,
         icmp_type : null
      }

4 La liste *db_nsgs* est définie. Pour cela, une boucle FOR traverse le résultat du  *module.lz_vcn_sandbox.vcns* et pour chaque *vcn*, un objet *nsg-db* est créé.

4.1 Créer une *Map* *ssh-ingress-rule* pour autoriser les connexions *ssh* depuis un host dans *nsg-bastion*.

      ssh-ingress-rule : {
        is_create : true,
        description : "Allows SSH connections from hosts in nsg-bastion-${k} NSG.",
        stateless : false,
        protocol : "6",
        src : "nsg-bastion-${k}",
        src_type : "NSG_NAME",
        dst_port_min : 22,
        dst_port_max : 22,
        src_port_min : null,
        src_port_max : null,
        icmp_type : null,
        icmp_code : null
      }

4.2 Créer une *Map* *app-ingress-rule* pour autoriser les connexions *SQLNet* depuis un host dans *nsg-app*.

       app-ingress-rule : {
        is_create : true,
        description : "Allows SQLNet connections from hosts in nsg-app-${k} NSG.",
        stateless : false,
        protocol : "6",
        src : "nsg-app-${k}",
        src_type : "NSG_NAME",
        src_port_min : null,
        src_port_max : null,
        dst_port_min : 1521,
        dst_port_max : 1522,
        icmp_code : null,
        icmp_type : null
      }

4.3 Créer une *Map* *osn-services-egress-rule* pour autoriser les connexions *HTTPS* à un *valid_service_gateway*.

      osn-services-egress-rule : {
         is_create : true,
         description : "Allows HTTPS connections to ${local.valid_service_gateway_cidrs[0]}.",
         stateless : false,
         protocol : "6",
         dst      = local.valid_service_gateway_cidrs[0],
         dst_type = "SERVICE_CIDR_BLOCK",
         src_port_min : null,
         src_port_max : null,
         dst_port_min : 443,
         dst_port_max : 443,
         icmp_code : null,
         icmp_type : null
      }

5 La liste *public_dst_nsgs* est définie. Pour cela, une boucle FOR traverse le résultat du  *module.lz_vcn_sandbox.vcns* et pour chaque *vcn*, un objet *public-dst-nsg* est créé

5.1. Une boucle FOR traverse le paramètre d'entrée *public_dst_cidrs* et pour chaque bloc cidr, un objet egress_rule (https-public-dst-egress-rule) est créé, ce qui autorise la connexion *HTTPS* à un hôte dans le spectrum du *cidr*.

      {
         for cidr in var.public_dst_cidrs : "https-public-dst-egress-rule-${index(var.public_dst_cidrs, cidr)}" => {
            is_create : var.public_dst_cidrs != null && !var.no_internet_access,
            description : "Allows HTTPS connections to ${cidr} CIDR range.",
            stateless : false,
            protocol : "6",
            dst      = cidr,
            dst_type = "CIDR_BLOCK",
            src_port_min : null,
            src_port_max : null,
            dst_port_min : 443,
            dst_port_max : 443,
            icmp_code : null,
            icmp_type : null
         } 
      }

6 Les objets *bastions_nsgs*, *lbr_nsgs*, *app_nsgs*, *db_nsgs* et *public_dst_nsgs* sont fusionnés  et assignés à l'attribut *nsg*.

      nsgs = merge(local.bastions_nsgs, local.lbr_nsgs, local.app_nsgs, local.db_nsgs, local.public_dst_nsgs)

7 Finalement, la ressource */modules/network/security* est appelée en passant comme paramètre *nsgs* de l'étape précédente pour la création des *nsgs*.

      module "lz_nsgs_sandbox" {
         depends_on     = [module.lz_vcn_sandbox]
         source         = "../modules/network/security"
         compartment_id = module.lz_compartments.compartments[local.sandbox_compartment.key].id
         nsgs           = merge(local.bastions_nsgs, local.lbr_nsgs, local.app_nsgs, local.db_nsgs, local.public_dst_nsgs)
      }

#### net_vcn

Dans le script [/config/net_vcn.tf](../config/net_vcn.tf), les données de *VCNs* à créer sont chargées dans la structure des données (*Map*) requises comme paramètre pour le module */network/vcn-basic*. Ensuite, avec ce paramètre, le module *vcn-basic* est appelé pour faire la création des *vcns*.

La logique détaillée de ce script est la suivante :

1- Les noms de sous-réseau sont définis.  

      spoke_subnet_names = ["subnet"]
      sandbox_subnet_names = ["snetr-vcn-cmp-casae-tecae-cam1-001"]
      unclassified_subnet_names = ["snetr-vcn-cmp-nocla-tenoa-cam1-001"]

2-  Créer une *Map* d'objets de type *vcn* où chaque objet regroupe les attributs *name*, *cidr* et *dns*. Pour cela, le paramètre d'entrée *var.sandbox_vcn_cidrs* est traversé dans une boucle FOR à laquelle le *cidr* est défini et avec l'index il est associé au paramètre d'entrée *var.sandbox_vcn_names* pour définir le *nom* et le *DNS*. Cette même logique est utilisée pour créer les objets *vcn unclassified_vcns*, *prod_vcns* et *nonprod_vcns*.

      sandbox_vcns_map = { 
         for v in var.sandbox_vcn_cidrs : "vcn${index(var.sandbox_vcn_cidrs, v)}" => {
            name = length(var.sandbox_vcn_names) > 0 ? (length(regexall("[a-zA-Z0-9-]+", var.sandbox_vcn_names[index(var.sandbox_vcn_cidrs, v)])) > 0 ? join("", regexall("[a-zA-Z0-9-]+", "vcn-cmp-case-tecae-cam1-${var.sandbox_vcn_names[index(var.sandbox_vcn_cidrs, v)]}")) : "vcn-cmp-case-tecae-cam1-${var.sandbox_vcn_names[index(var.sandbox_vcn_cidrs, v)]}") : "vcn-cmp-case-tecae-cam1-00${index(var.sandbox_vcn_cidrs, v)+1}"
            cidr = v
            dns = length(var.sandbox_vcn_names) > 0 ? (length(regexall("[a-zA-Z0-9]+", var.sandbox_vcn_names[index(var.sandbox_vcn_cidrs, v)])) > 0 ? join("", regexall("[a-zA-Z0-9]+", "vcn-cmp-case-tecae-cam1-${var.sandbox_vcn_names[index(var.sandbox_vcn_cidrs, v)]}")) : "vcncompcasetecaecam1${var.sandbox_vcn_names[index(var.sandbox_vcn_cidrs, v)]}") : "vcncompcasetecaecam100${index(var.sandbox_vcn_cidrs, v)+1}"
         }
      }

3- Les *sandbox_vcns* sont chargés. Pour cela, la variable *local* definie dans le pas 2 *local.sandbox_vcns_map* est traversé dans une boucle FOR à partir de laquelle les attributs de chacun des *vcns* sont obtenus et regroupés dans un objet avec le nom du *sandbox_vcns*. Ensuite, chaque objet *subnet* est chargé dans l'attribut *subnets* du *vcn*. Cette même logique est utilisée pour créer les objets *vcn unclassified_vcns*, *prod_vcns* et *nonprod_vcns*.

      sandbox_vcns = { 
         for key, vcn in local.sandbox_vcns_map : vcn.name => {
            compartment_id    = module.lz_compartments.compartments[local.sandbox_compartment.key].id
            cidr              = vcn.cidr
            dns_label         = vcn.dns
            is_create_igw     = true
            is_attach_drg     = false
            block_nat_traffic = false
            defined_tags      = null
            subnets = { 
               for s in local.sandbox_subnet_names : replace("${vcn.name}-${s}-subnet", "-vcn", "") => {
                  compartment_id  = null
                  name            = s
                  defined_tags    = null
                  cidr            = cidrsubnet(vcn.cidr, 4, index(local.sandbox_subnet_names, s))
                  dns_label       =  join("", regexall("[a-zA-Z0-9]+",s))
                  private         = var.no_internet_access ? true : (index(local.sandbox_subnet_names, s) == 0 ? false : true)
                  dhcp_options_id = null
                  security_lists = { "security-list" : {
                     compartment_id : null
                     is_create : true
                     ingress_rules : [{
                        is_create : s == "app" && length(var.onprem_cidrs) == 0
                        protocol : "6"
                        stateless : false
                        description : "Allows SSH connections from hosts in ${vcn.cidr} CIDR range."
                        src : vcn.cidr
                        src_type : "CIDR_BLOCK"
                        icmp_type : null
                        icmp_code : null
                        src_port_min : null
                        src_port_max : null
                        dst_port_min : "22"
                        dst_port_max : "22"
                     }]
                     egress_rules : [{
                        is_create : s == "app" && length(var.onprem_cidrs) == 0
                        protocol : "6"
                        stateless : false
                        description : "Allows SSH connections to hosts in ${vcn.cidr} CIDR range."
                        dst : vcn.cidr
                        dst_type : "CIDR_BLOCK"
                        icmp_type : null
                        icmp_code : null
                        src_port_min : null
                        src_port_max : null
                        dst_port_min : "22"
                        dst_port_max : "22"
                     }]
                     defined_tags  = null
                     freeform_tags = null
                  }
               }
            }
         }
      }

4- Le module */modules/network/vcn-basic* est appelé avec les attributs définis dans l'étape précédente, pour la création des *vcns* requis. Cette même logique est utilisée pour créer les objets *vcn unclassified_vcns*, *prod_vcns* et *nonprod_vcns*.

      module "lz_vcn_sandbox" {
         source               = "../modules/network/vcn-basic"
         depends_on           = [null_resource.slow_down_vcn]
         compartment_id       = module.lz_compartments.compartments[local.sandbox_compartment.key].id
         service_label        = var.service_label
         service_gateway_cidr = local.valid_service_gateway_cidrs[0]
         drg_id               = ""
         vcns                 = local.sandbox_vcns
      }

#### bastion

Dans ce script, les données des *bastion* à créer sont chargées dans la structure des données (*Map*) requises comme paramètre pour le module */security/bastion*. Ensuite, avec ce paramètre, le module *bastion* est appelé pour faire la création des *bastions*.

La logique détaillée de ce script est la suivante :

1- Les *Subnets* du *VCN* *sandbox* sont parcourus et pour chaque *Subnet* obtenu, il est vérifié s'il porte le nom qui se trouve en deuxième position de la variable *local.sandbox_subnet_names[1]*. Si le nom correspond à celui du *Subnet* obtenu, l'*ocid* de ce *subnet* est pris pour définir l'attribut *target_subnet_id* de la ressource *bastion*.  

2- Définit les autres attributs de la ressource *bastion* du *VCN* *sand_box* à l'aide des variables d'entrée *var.public_src_bastion_cidrs* et de la variable locale *local.bastion_max_session_ttl_in_seconds*. Pour résoudre l'attribut *compartment_id*, la variable *local.sandbox_compartment.key* permet de le rechercher dans le résultat de la création des compartiments.

      sandbox_bastion = {for subnet in module.lz_vcn_sandbox.subnets : subnet.display_name => {
         name = "${replace(subnet.display_name,"/[^a-zA-Z0-9]/","")}Bastion"
         compartment_id = module.lz_compartments.compartments[local.sandbox_compartment.key].id
         target_subnet_id = subnet.id
         client_cidr_block_allow_list = var.public_src_bastion_cidrs
         max_session_ttl_in_seconds = local.bastion_max_session_ttl_in_seconds
      } if length(var.sandbox_vcn_cidrs) == 1 && (length(regexall(".*${local.sandbox_subnet_n

3- Les *Subnets* du *VCN* *unclassified* sont parcourus et pour chaque *Subnet* obtenu, il est vérifié s'il porte le nom qui se trouve en deuxième position de la variable *local.unclassified_subnet_names[1]*. Si le nom correspond à celui du *Subnet* obtenu, l'*ocid* de ce *subnet* est pris pour définir l'attribut *target_subnet_id* de la ressource *bastion*.  

4- Les autres attributs de la ressource *bastion* du *VCN* *unclassified* sont définis à l'aide des variables d'entrée *var.public_src_bastion_cidrs* et de la variable locale *local.bastion_max_session_ttl_in_seconds*. Pour résoudre l'attribut *compartment_id*, la variable *local.unclassified_compartment.key* permet de le rechercher dans le résultat de la création des compartiments.

      unclassified_bastion = {for subnet in module.lz_vcn_unclassified.subnets : subnet.display_name => {
         name = "${replace(subnet.disy_planame,"/[^a-zA-Z0-9]/","")}Bastion"
         compartment_id = module.lz_compartments.compartments[local.unclassified_compartment.key].id
         target_subnet_id = subnet.id
         client_cidr_block_allow_list = var.public_src_bastion_cidrs
         max_session_ttl_in_seconds = local.bastion_max_session_ttl_in_seconds
      } if length(var.unclassified_vcn_cidrs) == 1 && (length(regexall(".*${local.unclassified_subnet_names[1]}*", subnet.display_name)) > 0)}

5- Les objets dans *sandbox_bastion* (pas 1) et *unclassified_bastion* (pas 2) sont fusionnés et assignés à la variable *all_bastions*.

      all_bastions = merge(local.unclassified_bastion,local.sandbox_bastion)

6- Le module */modules/security/bastion* est appelé avec les attribut définis dans l'étape précédente *all_bastions*, pour la création des *bastions* requis.

#### mon_cloud_guard

Dans ce script, les données de *cloud-guard* à créer sont chargées dans la structure des données (*Map*) requises comme paramètre pour le module */monitoring/cloud-guard*. Ensuite, avec ce paramètre, le module *monitoring/cloud-guard* est appelé pour faire la création du *cloud-guard*.

La logique détaillée de ce script est la suivante :

1. Le paramètre d'entrée *var.cloud_guard_configuration_status* est vérifié. Si c'est *ENABLE*, on vérifie alors que le service n'existe pas déjà et qu'il n'est pas dans l'état *Enable*, et on procède ensuite à la création de ce service. S'il existe déjà et que son statut est *Enable*, zéro est retourné afin qu'un autre service *cloud-guard* ne soit pas créé puisqu'il existe déjà et est actif.
Dans le cas où le paramètre d'entrée *var.cloud_guard_configuration_status* est différent de *ENABLE*, zéro est retourné afin que la création d'un service *cloud guard* ne soit pas effectuée puisque sa création n'est pas requise.

      count = var.cloud_guard_configuration_status == "ENABLE" ?
         (data.oci_cloud_guard_cloud_guard_configuration.this != null ?
            (data.oci_cloud_guard_cloud_guard_configuration.this.status != "ENABLED" ?
               1
               : 0)
         :  1)
      : 0

2. Vérification que le module *lz_services_policy* chargé de créer les stratégies (*policies*) ait déjà terminé et un délai déterminé par la variable locale *local.delay_in_secs* est ajouté pour s'assurer que les politiques créées sont déjà disponibles avant de créer le service *cloud-guard*.

      depends_on = [null_resource.slow_down_cloud_guard]
      resource "null_resource" "slow_down_cloud_guard" {
         depends_on = [module.lz_services_policy]
         provisioner "local-exec" {
            command = "sleep ${local.delay_in_secs}" # Wait for policies to be available.
         }
      }

3. Les autres attributs du service de création de service *cloud-guard* sont chargés à l'aide des variables locales *local.home_region_key* et *local.cg_target_name*, des paramètres d'entrée *var.tenancy_ocid*, *var.cloud_guard_configuration_status* et *var.tenancy_ocid*.

      compartment_id        = var.tenancy_ocid
      reporting_region      = local.regions_map[local.home_region_key]
      status                = var.cloud_guard_configuration_status == "ENABLE" ? "ENABLED" : "DISABLED"
      self_manage_resources = false
      default_target        = { name : local.cg_target_name, type : "COMPARTMENT", id : var.tenancy_ocid

4. Le module */modules/monitoring/cloud-guard* est appelé, pour la création du *cloud-guard* requis.

      source                = "../modules/monitoring/cloud-guard"
      providers             = { oci = oci.home }

#### mon_flow_logs

Dans ce script, les données des *flow-logs* à créer sont chargées dans la structure des données (*Map*) requises comme paramètre pour le module */modules/monitoring/logs*. Ensuite, avec ce paramètre, le module *monitoring/logs* est appelé pour faire la création des *flow-logs*.

La logique détaillée de ce script est la suivante :

1. Tous les subnets des *VCNs* dans *lz* sont fusionnés dans la variable *all_lz_subnets*

      all_lz_subnets = merge(local.all_lz_vcn_subnets, module.lz_vcn_dmz.subnets, module.lz_exacs_vcns.subnets)  

2. Tous les *subnets* sont traversés et pour chaque *subnet* son *id* est extrait pour définir les attributs du *flow-log* pour ce *subnet*. Chaque objet *flow-log* crée est regroupé dans la variable (*Map*) *flow_logs*.

      flow_logs = { for k, v in local.all_lz_subnets : k =>
         {
            log_display_name              = "${k}-flow-log",
            log_type                      = "SERVICE",
            log_config_source_resource    = v.id,
            log_config_source_category    = "all",
            log_config_source_service     = "flowlogs",
            log_config_source_source_type = "OCISERVICE",
            log_config_compartment        = module.lz_compartments.compartments[local.security_compartment.key].id,
            log_is_enabled                = true,
            log_retention_duration        = 30,
            defined_tags                  = null,
            freeform_tags                 = null
         }
      }

3. Le module */modules/monitoring/logs* est appelé avec l'attribut défini dans l'étape précédente *flow_logs*, pour la création des *flow_logs* requis.

      module "lz_flow_logs" {
         depends_on             = [module.lz_vcn_sandbox, module.lz_vcn_unclassified, module.lz_vcn_prod, module.lz_vcn_nonprod, module.lz_vcn_dmz, module.lz_exacs_vcns]
         source                 = "../modules/monitoring/logs"
         compartment_id         = module.lz_compartments.compartments[local.security_compartment.key].id
         log_group_display_name = "${var.service_label}-flow-logs-group"
         log_group_description  = "Landing Zone ${var.service_label} flow logs group."
         target_resources       = local.flow_logs
      }

#### mon_notifications

Dans ce script, les données des *rules* à créer sont chargées dans la structure des données requises comme paramètre pour le module */modules/monitoring/notifications*. Ensuite, le module *monitoring/notifications* est appelé pour faire la création des *rules* de notification dans Oracle Cloud Infrastructure Events service.

La logique détaillée de ce script est la suivante :

1. Vérification que le module *module.lz_compartments* chargé de créer les *compartments* ait déjà terminé et un délai déterminé par la variable locale *local.delay_in_secs* est ajouté pour s'assurer que les compartiments créées sont déjà disponibles avant de créer les *rules* de notification.

   depends_on = [null_resource.slow_down_notifications]

   resource "null_resource" "slow_down_notifications" {
      depends_on = [module.lz_compartments]
      provisioner "local-exec" {
   command = "sleep ${local.delay_in_secs}" # Wait for compartments to be available.
   }

2. Définit la règle de notification associée à la ressource *IAM*, en spécifiant les événements qui déclencheront l'action de notification, le type de notification et le *topic* où la notification sera publiée.

      ("${var.service_label}-notify-on-iam-changes-rule") = {
         compartment_id      = var.tenancy_ocid
         description         = "Landing Zone events rule to detect when IAM resources are created, updated or deleted."
         is_enabled          = true
         condition           = <
            {"eventType":
               ["com.oraclecloud.identitycontrolplane.createidentityprovider",
               "com.oraclecloud.identitycontrolplane.deleteidentityprovider",
               "com.oraclecloud.identitycontrolplane.updateidentityprovider",
               "com.oraclecloud.identitycontrolplane.createidpgroupmapping",
               "com.oraclecloud.identitycontrolplane.deleteidpgroupmapping",
               "com.oraclecloud.identitycontrolplane.updateidpgroupmapping",
               "com.oraclecloud.identitycontrolplane.addusertogroup",
               "com.oraclecloud.identitycontrolplane.creategroup",
               "com.oraclecloud.identitycontrolplane.deletegroup",
               "com.oraclecloud.identitycontrolplane.removeuserfromgroup",
               "com.oraclecloud.identitycontrolplane.updategroup",
               "com.oraclecloud.identitycontrolplane.createpolicy",
               "com.oraclecloud.identitycontrolplane.deletepolicy",
               "com.oraclecloud.identitycontrolplane.updatepolicy",
               "com.oraclecloud.identitycontrolplane.createuser",
               "com.oraclecloud.identitycontrolplane.deleteuser",
               "com.oraclecloud.identitycontrolplane.updateuser",
               "com.oraclecloud.identitycontrolplane.updateusercapabilities",
               "com.oraclecloud.identitycontrolplane.updateuserstate"]
            }
         EOT
         actions_action_type = "ONS"
         actions_is_enabled  = true
         actions_description = "Sends notification via ONS"
         topic_id            = module.lz_security_topic.topic.id
         defined_tags        = null
      }

3. Définit la règle de notification associée à la ressource *networking*, en spécifiant les événements qui déclencheront l'action de notification, le type de notification et le *topic* où la notification sera publiée.

      ("${var.service_label}-notify-on-network-changes-rule") = {
         compartment_id      = local.parent_compartment_id
         description         = "Landing Zone events rule to detect when networking resources are created, updated or deleted."
         is_enabled          = true
         condition           = <<
         {"eventType":
            ["com.oraclecloud.virtualnetwork.createvcn",
            "com.oraclecloud.virtualnetwork.deletevcn",
            "com.oraclecloud.virtualnetwork.updatevcn",
            "com.oraclecloud.virtualnetwork.createroutetable",
            "com.oraclecloud.virtualnetwork.deleteroutetable",
            "com.oraclecloud.virtualnetwork.updateroutetable",
            "com.oraclecloud.virtualnetwork.changeroutetablecompartment",
            "com.oraclecloud.virtualnetwork.createsecuritylist",
            "com.oraclecloud.virtualnetwork.deletesecuritylist",
            "com.oraclecloud.virtualnetwork.updatesecuritylist",
            "com.oraclecloud.virtualnetwork.changesecuritylistcompartment",
            "com.oraclecloud.virtualnetwork.createnetworksecuritygroup",
            "com.oraclecloud.virtualnetwork.deletenetworksecuritygroup",
            "com.oraclecloud.virtualnetwork.updatenetworksecuritygroup",
            "com.oraclecloud.virtualnetwork.updatenetworksecuritygroupsecurityrules",
            "com.oraclecloud.virtualnetwork.changenetworksecuritygroupcompartment",
            "com.oraclecloud.virtualnetwork.createdrg",
            "com.oraclecloud.virtualnetwork.deletedrg",
            "com.oraclecloud.virtualnetwork.updatedrg",
            "com.oraclecloud.virtualnetwork.createdrgattachment",
            "com.oraclecloud.virtualnetwork.deletedrgattachment",
            "com.oraclecloud.virtualnetwork.updatedrgattachment",
            "com.oraclecloud.virtualnetwork.createinternetgateway",
            "com.oraclecloud.virtualnetwork.deleteinternetgateway",
            "com.oraclecloud.virtualnetwork.updateinternetgateway",
            "com.oraclecloud.virtualnetwork.changeinternetgatewaycompartment",
            "com.oraclecloud.virtualnetwork.createlocalpeeringgateway",
            "com.oraclecloud.virtualnetwork.deletelocalpeeringgateway",
            "com.oraclecloud.virtualnetwork.updatelocalpeeringgateway",
            "com.oraclecloud.virtualnetwork.changelocalpeeringgatewaycompartment",
            "com.oraclecloud.natgateway.createnatgateway",
            "com.oraclecloud.natgateway.deletenatgateway",
            "com.oraclecloud.natgateway.updatenatgateway",
            "com.oraclecloud.natgateway.changenatgatewaycompartment",
            "com.oraclecloud.servicegateway.createservicegateway",
            "com.oraclecloud.servicegateway.deleteservicegateway.begin",
            "com.oraclecloud.servicegateway.deleteservicegateway.end",
            "com.oraclecloud.servicegateway.attachserviceid",
            "com.oraclecloud.servicegateway.detachserviceid",
            "com.oraclecloud.servicegateway.updateservicegateway",
            "com.oraclecloud.servicegateway.changeservicegatewaycompartment"]
         }
         EOT
         actions_action_type = "ONS"
         actions_is_enabled  = true
         actions_description = "Sends notification via ONS"
         topic_id            = module.lz_network_topic.topic.id
         defined_tags        = null
      }  

4. Le module */modules/monitoring/notifications* est appelé avec les attributs définis dans l'étape précédente, pour la création des *rules* requises dans le Oracle Notification Service (ONS).

#### mon_oss_logs

Dans ce script, les données des *object storage bucket logs* à créer sont chargées dans la structure des données *oss_bucket_logs* (*Map*) requises comme paramètre pour le module */modules/monitoring/logs*. Ensuite, avec ce paramètre, le module *monitoring/logs* est appelé pour faire la création des *object-storage-logs*.

La logique détaillée de ce script est la suivante :

1. Une boucle FOR traverse le résultat du *module.lz_buckets.oci_objectstorage_buckets* (création de object-storages) et pour chaque object-storage, un objet *object-storage-log* est créé. Ensuite, chaque *object-storage-log* est chargé dans la variable *oss_bucket_logs*.

      oss_bucket_logs = {for bkt in module.lz_buckets.oci_objectstorage_buckets : bkt.name => {
         log_display_name              = "${bkt.name}-object-storage-log",
         log_type                      = "SERVICE",
         log_config_source_resource    = bkt.name,
         log_config_source_category    = "write",
         log_config_source_service     = "objectstorage",
         log_config_source_source_type = "OCISERVICE",
         log_config_compartment        = module.lz_compartments.compartments[local.security_compartment.key].id,
         log_is_enabled                = true,
         log_retention_duration        = 30,
         defined_tags                  = null,
         freeform_tags                 = null
         }
      }  
2. Le module */modules/monitoring/logs* est appelé avec la variable *oss_bucket_logs* définie dans l'étape précédente, pour la création des  *oss_bucket_logs* requis.

      module "lz_oss_logs" {
         depends_on             = [ module.lz_buckets ]
         source                 = "../modules/monitoring/logs"
         compartment_id         = module.lz_compartments.compartments[local.security_compartment.key].id
         log_group_display_name = "${var.service_label}-object-storage-log-group"
         log_group_description  = "Landing Zone ${var.service_label} Object Storage log group."
         target_resources       = local.oss_bucket_logs
      }

[Page d'accueil](../../README.md)
