# 30-cloudinternetsvcs

## Aperçu

Cette extension déploie [Cloud Internet Services](https://cloud.ibm.com/docs/cis?topic=cis-getting-started) dans votre zone d'atterrissage.

Cloud Internet Services peut être utilisé pour assurer une protection en périphérie des applications Internet.

![Cloud Internet Services](../../docs/images/vsi-cloudinternetsvcs.png)

## Variables d'entrée

Ces variables d'entrée seront consultées dans la sortie de [00-landing-zone](../00-landing-zone/patterns/vsi). Ou vous pouvez les remplacer et les transmettre.  Ce composant est conçu pour être exécuté après `00-landing-zone`.

| Nom | Description | Type | Par défaut/Exemple | Obligatoire |
| ---- | ----------- | ---- | ------- | -------- |
| ibmcloud_api_key | Clé d'interface API utilisée pour fournir les ressources.  Votre clé doit être autorisée à effectuer les actions dans ce script. | chaîne | sans objet |oui |
| region |  Répertoriez toutes les régions disponibles avec : "ibmcloud regions". | chaîne | Par défaut : "ca-tor" | oui |
| prefix | Courte chaîne qui sera utilisée pour préfixer tous les noms de ressources | chaîne | sans objet | oui |
| resource_group_id | L'ID du groupe de ressources dans lequel il faut fournir les composants d'observabilité. | chaîne | `<prefix>-slz-service-rg`| Utilisez celle par défaut ou fournissez la vôtre |

## Pour exécuter ce script

1. Run `terraform init`
1. Run `terraform plan`
1. Run `terraform apply`

Vous pouvez exécuter `terraform destroy` pour détruire ces composants.  Assurez-vous de procéder à cette exécution avant de détruire `00-landing-zone`.

