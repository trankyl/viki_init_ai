# Utilisation et exploitation de script de validation de la zone d’accueil fournie par Oracle

## Table des matières

1. [Création de bucket  Object Storage où les rapports seront copiés](#création-de-bucket-object-storage-où-les-rapports-seront-copiés)
1. [Exécution du script](#exécution-du-script-dans-oracle-cloud-shell)
1. [Génération du rapport CSV](#génération-du-rapport-csv)
1. [Faire correspondre les recommandations CIS aux noms des problèmes Cloud Guard](#faire-correspondre-les-noms-des-problèmes-cloud-guard-aux-recommandations-cis)

## Introduction

  Cette documentation vise à faciliter l’utilisation et l'exploitation de script de validation de la zone d’accueil fourni par Oracle.
Ce script génère un rapport synthèse en format CSV ainsi qu'un rapport de résultats individuel, également en format CSV, pour les problèmes de configuration découverts dans un dossier (emplacement par défaut). Celui-ci comporte la date du jour, par exemple 2022-05-25.

## Création de bucket Object Storage où les rapports seront copiés

Création d'un compartiment (*bucket*) “demo”  où les rapports synthèses seront copiés.

![Cration Bucket](../images/CreateBucket.png)

![List Bucket](../images/ListBucket.png)

## Exécution du script dans Oracle Cloud Shell

1. [Accéder au Github du script de vérification](https://github.com/oracle-quickstart/oci-cis-landingzone-quickstart/blob/main/compliance-script.md).

![Github](../images/Github.png)

2. Télécharger le script avec le [présent lien](https://raw.githubusercontent.com/oracle-quickstart/oci-cis-landingzone-quickstart/main/scripts/cis_reports.py).

3. Définir les privilèges de sécurité nécessaire à l’exécution pour un groupe d'auditeurs, par exemple.

![Stratégie](../images/Strategie.png)

4. Lancer le Cloud Shell d’OCI.

![Icone shell](../images/shell.png)

Le Cloud Shell peut prendre quelques secondes avant d’être prêt à l’utilisation.

![shell](../images/CloudShell.png)

5. Méthodes pour téléverser ou télécharger le script python cis_reports.  

5.1 Téléverser le script python cis_reports.

![File Download](../images/FileDownload.png)

![File Transfer](../images/FileTransfer.png)

5.2 Télécharger le script à partir du Cloud Shell.

Cette étape remplace l'étape 2.

Taper la commande suivante :

```Bash
wget https://raw.githubusercontent.com/oracle-quickstart/oci-cis-landingzone-quickstart/main/scripts/cis_reports.py
```

![Script](../images/wget_cis_reports.jpg)

L’indicateur de téléchargement doit indiquer 100 % et le rapport doit avoir été sauvegardé (*saved*).

6. Exécuter le script en tapant les commandes suivantes :

+ **python3 -m venv python**
+ **pip3 install oci**
+ **python3 cis_reports.py -dt --output-to-bucket  ‘demo’**

![Script Execution](../images/ExecutionScript.png)

## Génération du rapport CSV

Le téléchargement de document peut se faire à partir du compartiment défini en « demo ».

![Lister Bucket Demo](../images/ListDocBucketDemo.png)

**Extraction du fichier Excel** :

Extraire le fichier CSV pour analyse et identification de la conformité de la location par rapport à la référence CIS.

![File Output](../images/ListeFileOutput.png)

Chaque ligne de rapport correspond à une recommandation de l'OCI Foundations Benchmark et identifie si la location est conforme ainsi que le nombre des écarts détectés. Le rapport est composé de :

**Recommandation** : le numéro de recommandation dans le document CIS Benchmark

**Section** : les sections de la recommandation sont séparées comme suit : gestion des accès et des identités, réseau, journalisation et surveillance, stockage des objets et gestion des actifs.

**Niveau** : le niveau de recommandation, à savoir que les recommandations de niveau 1 sont moins restrictives que celles de niveau 2.

**Conforme** : si la location est conforme à la recommandation.

**Écart** : le nombre de conclusions incriminées pour la recommandation

**Titre** : la description de la recommandation

**Date d’extraction** : la date de l’extraction

Dans l'exemple ci-dessous, nous remarquons que la location n'est pas conforme à quatorze recommandations. Parmi celles-ci se trouve l'élément 1.7 qui montre que l'authentification multifacteur (MFA) pour accéder à la console OCI n'est pas activé pour cinq utilisateurs.

![Finding MFA](../images/ExcelResult.png)

Un rapport CSV dédié pour chaque écart remonté est généré au niveau de la console. Par exemple, pour l’élément 1.7, le rapport donne plus de détails sur les cinq utilisateurs.

![Finding MFA](../images/Ecart1.7.png)

## Faire correspondre les noms des problèmes Cloud Guard aux recommandations CIS

Le tableau ci-dessus mappe les noms des problèmes Cloud Guard aux recommandations CIS.

### Gestion des identités et des accès

![IAM](../images/IAM.png)

### Réseau

![Réseau](../images/Reseau.png)

### Journalisation et surveillance

Partie 1 :
![Jounalisation](../images/JournalisationSurveillance.png)

Partie 2 :
![Jounalisation](../images/JournalisationSurveillance2.png)
Partie 3 :

![Jounalisation](../images/JournalisationSurveillance3.png)

### Stockage des objets

![Obkectstorage](../images/StockageObjet.png)

### Gestion des actifs

![Managment actif](../images/gestionActif.png)  

[Retour à la Page d'accueil](../../ReadMe.md)
