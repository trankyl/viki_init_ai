[CmdletBinding()]
param (
    [Parameter(Mandatory = $true, Position = 1)]
    [string] $subscriptions
)

$subArray = $subscriptions.Split(",")

foreach($sub in $subArray)
{
  if (![string]::IsNullOrEmpty($sub))
  {
    az account set --subscription $sub
    $subName = az account show --query name | ConvertFrom-Json
    Write-Host "##[group]Wiping policiy assignments and role assignments linked to subscription $subName"

    $subAssignmentNames = az policy assignment list --scope "/subscriptions/$sub" --disable-scope-strict-match | ConvertFrom-Json

    Write-Host ("##[section]Found " + $subAssignmentNames.Count + " policy assignments")
    
    foreach($assignment in $subAssignmentNames)
    {
      $aScope = $assignment.scope
      $aName = $assignment.name

      Write-Host ("##[section]Policy Assignment $aName on scope $aScope")

      if ($null -ne $assignment.identity) {
        $identityFound = $assignment.identity.principalId
        $roleAssignments = az role assignment list --assignee $identityFound  --include-inherited --scope $aScope | ConvertFrom-Json
        $roleFound = $roleAssignments.Count
      }
      else {
        $roleFound = 0
        $identityFound = "(no identity)"
      }

      Write-Host ("Found $roleFound role assignments for identity $identityFound ...")
      if ($roleFound -gt 0) {
        Write-Host ("##[command]az role assignment delete --assignee $identityFound --include-inherited --scope $aScope")
        az role assignment delete --assignee $identityFound --include-inherited --scope $aScope
      }
      
      Write-Host ("##[command]az policy assignment delete --name $aName --scope $aScope")
      az policy assignment delete --name $aName --scope $aScope
    }

    Write-Host "##[endgroup]"
  }
}