import json
import subprocess
import time

servicelabel = input("Rentrez le servicelabel (ex CEISDEL): ")
ocid_compartiment_racine = input("Saisir OCID du compartiment racine (ex ocid1.tenancy.xxx) : ")
logfile = input("Saisir le nom ou chemin du fichier journal (ex : log.txt) : ")


def log(pinformation , pfile):
    print(CurrentTimeString() + " : " + pinformation + "\n\n")
    f = open(pfile , 'a')
    if (f is None):
        return
    f.write(CurrentTimeString() + " : " + pinformation + "\n\n")
    f.close()

def CurrentTimeString():
    return time.strftime("%D %H:%M:%S", time.localtime())

# ocid1.tenancy.oc1..aaaaaaaaevng5cb7yve3myznrz3lyehvioucls4yt2mx2bku7wtextnevupq
log("Chargement des stratégies dans le compartiment " + ocid_compartiment_racine , logfile)

oci_command = "oci iam policy list -c " + ocid_compartiment_racine + " > policiestodel.json"
subprocess.run(oci_command, shell=True)
lbuffer = ""

f = open('policiestodel.json', 'r')
if (f is None):
    log("Aucune stratégie à supprimer" , logfile)
    exit()
else:
    lbuffer = f.read()
    if (lbuffer != ""):
        f.close()
    else:
        log("Aucune stratégie à supprimer" , logfile)
        print("Aucune stratégie à supprimer")
        f.close()
        exit()
    
    
with open('policiestodel.json', 'r') as file:
    data = json.load(file)

id_list = []

log("Filtrage stratégie IAM ayant étiquette " + servicelabel + "..." , logfile)

for item in data['data']:
    if item['name'].startswith(servicelabel):
        id_list.append(item['id'])

for id_value in id_list:
    log("Suppression stratégie IAM  " + id_value + " ..." , logfile)
    command = f"oci iam policy delete --policy-id {id_value}"

    subprocess.run(command, shell=True)
    log("Stratégie IAM " + id_value + " supprimée" , logfile)
    
