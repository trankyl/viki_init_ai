#### Retour en arrière

* [Architecture des zones d'accueil](architecture_za.md)
* [Page d'accueil](../Readme.md)

# L'architecture des zones d'accueil

Le script V2.2 offre la possibilité de déployer des architectures prédéfinies de zone d'accueil, ainsi que de personnaliser les déploiements selon les besoins spécifiques des organismes publics (OP).

## 1. Scénarios prédéfinis - architecture de solution

À ce jour, le scénario pris en charge et prédéfini ("base") offre une configuration simplifiée, afin de répondre d'une manière efficace aux besoins de la plupart des OP et des établissements du REES et du RSSS. Pour ce scénario, le paramétrage nécessaire est simplifié :


| Scénario | Abonnements Plateforme                         | Zones de charge production                 | Zones de charge non-prod | Autres non-prod  |
| ----------- | ------------------------------------------------ | :------------------------------------------- | -------------------------- | ------------------ |
| Base      | Connectivité, Identité, Gestion, Périmètre | Données sensibles, Données non sensibles | Non-Production            | Carrés de sable |

Un autre scénario ("complexe") est fourni pour des déploiements plus élaborés :


| Scénario | Abonnements Plateforme                         | Zones de charge production               | Zones de charge Développement et Acceptation | Autres non-prod                      |
| ----------- | ------------------------------------------------ | :----------------------------------------- | ----------------------------------------------- | -------------------------------------- |
| Complexe  | Connectivité, Identité, Gestion, Périmètre | Intranet, Services en ligne, Bureautique | Intranet, Services en ligne, Bureautique      | Carrés de sable, Preuves de concept |

---

## 2. Scénario Base

Le scénario "base" déploie les ressources et services dans les abonnements "plateforme" et les zones d'accueil pour les environnements Production et Non-production.
![Architecture des zones d'accueil pour scénario base](images/architecture_zones_daccueil_base_50pct.png)

Les Zones d'Accueil suivantes sont déployées par le script V2 avec configuration pour le scénario "base":


| Zone d'accueil         | Type     | Chemin groupe d'administration       | Commentaires                                                                                      |
| ------------------------ | ---------- | -------------------------------------- | --------------------------------------------------------------------------------------------------- |
| Données sensibles     | Prod     | Org/Charges/Production/Sensibles     | Déployer ici des charges de travail qui traitent des données sensibles adéquates dans le nuage. |
| Données non sensibles | Prod     | Org/Charges/Production/Non Sensibles | Déployer ici des charges de travail qui traitent des données non sensibles.                      |
| Non Prod               | Non-prod | Org/Charges/Non Production           | Déployer ici des charges de travail de développement, test et acceptation.                       |
| Carrés de sable       | Non-prod | Org/Expérimentation                 | Déployer ici des charges de travail pour POC.                                                     |

Le scénario "base" offre une configuration simplifiée, facile à déployer afin de répondre d'une manière efficace aux besoins de la plupart des OP et des établissements du REES et du RSSS.

## 3. Scénario Complexe

Le scénario "complexe" qui est inclus avec le script (voir le sous-répertoire scenario-complexe en dessous de azure-pipeline/config/variables) permet de déployer une architecture de zones d'accueil, similaire d'un point de vue hiérarchique, à l'architecture des déploiements faits avec la version v1.1 du script. Malgré les apparences, ça vient avec les mêmes améliorations majeures, tant sur les plans de la flexibilité de paramétrage, de la sécurité et du routage, présentes dans le scénario de base. La seule différence est en effet la structure hiérarchique des groupes d'administration.

![Architecture des zones d'accueil pour scénario complexe](images/Architecture-Landing-zones-complexe.jpg)
