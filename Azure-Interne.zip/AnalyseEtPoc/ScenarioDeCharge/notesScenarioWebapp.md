# Scénario de Web App dans les services en ligne avec Application Gateway

## But : 
Le but de ce scénario est de 
- Tester l'automatisation d'un déployment d'une application web dans l'abonnement de services en ligne.
- Tester le fonctionnement d'un Web Application Firewall à l'aide d'un Application Gateway setté dans le Virtual Network de la zone d'accueil

## Fonctionnement :
Un fichier YAML permet de créer un resource group qui pourra déployer l'application web. 

Ensuite, à l'aide d'un template Bicep, on crée l'application web à partir d'un lien docker mis en paramètre.

Pour le application Gateway,