


## Azure Budgets
- On peut envoyer des alertes
- On peut mettre des Threshold
- Automation possible pour chaque Threshold
- Menu de création sur Dashboard > Subscriptions > *Budget* > Create budget
- On peut choisir la période pour les spendings
- On choisit les pourcentages où on veut avoir des alertes de spendings. Un action group peut être lié à l'alerte et s'activer au pourcentage.
  - C'est la valeur **action** du action group qui va permettre d'automatiser des actions. L'action d'un action group peut être un Azure Automation runbook, un Azure Function, un Azure Logic Apps Workflow, un webook, etc.

- Pour plusieurs abonnements, on peut automatiser avec des requests au API de Azure avec le REST API
  - https://learn.microsoft.com/en-us/azure/cost-management-billing/costs/manage-automation#automate-alerts-and-actions-with-budgets
  - https://learn.microsoft.com/en-us/rest/api/consumption/budgets

- On peut aussi faire un ARM template (peut-être plus proche de ce que l'on voudrait faire ici?)
    - https://learn.microsoft.com/en-us/azure/cost-management-billing/costs/quick-create-budget-template?tabs=one-filter%2CCLI
- Dans le template ARM, les données modifiables sont :
	- Nom du budget (string)
	- Montant (int)
	Temps (Monthly, Quarterly, Annually)
	Date de debut
	Date de fin
	Première et deuxième limite en pourcentage
	Adresses e-mail des contacts
	etc.

## Azure off-hours script

- On pourrait aussi, en plus d'implémenter les budgets, potentiellement Stopper un groupe de VMs quand ils sont "off-hours" pour être surs que si il y a un oubli, on aura pas de problèmes ? 
	https://learn.microsoft.com/en-us/azure/azure-functions/start-stop-vms/overview
	
	

## FinOps - Optimisation des finances dans Azure
---

Comment sauver de l'argent ? (Vidéo pt 1)
- Réduire le gaspillage
  - Supprimer les *unattached disks* 
    - https://learn.microsoft.com/en-us/azure/virtual-machines/windows/find-unattached-disks
  - Utiliser le *Advisor* pour avoir des recommandations qui optimisent les machines et leurs ressources
    - On peut aussi avoir des recommandations pour un type de *Reserved Instance* qui permettrait de sauver des bons montants d'argent
    - Les *Reserved Instances* sont des machines virutelles sous contrat de 1 ou 3 ans qui permettent d'avoir un rabais jusqu'à 75% environ, mais non-scalable.
- Utiliser un outil comme Azure Cost Management, une application en PowerBI qui permet de récolter de l'information sur les différents abonnements
  - Permet de voir avec des graphiques la consommation d'énergie

(Vidéo pt 2)
- On peut utiliser des *Direct API Calls* dans le but de télécharger les rapports qui seraient vus dans la plateforme Azure Cost Management
  - Liste des calls qui peuvent être faits
  - ![APICalls](apiCallsBudget.png)
  - [Lien pour les commandes](https://learn.microsoft.com/en-us/rest/api/consumption/)
  - RI *(Reserved instance)* Recommendations
    - On peut choisir la période pour laquelle on veut évaluer les recommendations (lookBackPeriod)
    - On a le meter, sku et terme pour lequel on pourrait avoir un *Reserved Instance* qui sauverait de l'argent.
- Solutions d'architecture
  - ![solutionArchitecture](architectureSolution.png)

## Saving plans
Les *saving plans* d'Azure sont des contrats d'un ou trois ans permettant d'avoir des réductions de coûts selon l'utilisation moyenne des ressources par heure.
- Si il y a un dépassement, le reste serait chargé sans le rabais (avec le *pay-as-you-go rate*).
- Seulement les ressources de calculs (*compute ressources*) peuvent être éligibles pour ce rabais.
- Si une reservation et un saving plan est selectionné pour la même machine, ce sera la reservation qui prendra le dessus.
- Les raisons de prendre un saving plan plutôt qu'une réservation seraient si 
  - On change souvent de région
  - On change souvent de VM en dehors du *flexibility group*
  - etc.
- Les saving plans ne peuvent pas être échangées, retournées ou cancellées (contrairement aux reservations).

