# Clonage du document

## Table des matières

1. [Préface](#préface)
2. [Instructions](#instructions)
3. [Conclusion](#conclusion)

## Préface

Ce guide vise à soutenir les futurs utilisateurs souhaitant cloner le dépôt de fichiers sur leur poste local.

[Retourner en haut](#table-des-matières)

## Instructions

### Prérequis

1. Tout d'abord, assurez-vous d'avoir accès au dépôt créé par le CEI.

2. Vous devez également installer l'application Visual Studio Code à partir du lien suivant en fonction de votre système d'opération (OS) : [Vscode](https://code.visualstudio.com/download).

### Cloner le dépôt

1. À la suite de ces prérequis, vous serez en mesure d'accéder au lien suivant : [CEI-IBM-ZONE-ACCUEIL](https://dev.azure.com/ccticei/Migration/_git/CEI-IBM-ZONE-ACCUEIL).

    ![Image](images/1-initial.png)

2. Cliquez sur le bouton **Clone**.

    ![Image](images/2-boutonClone.png)

3. Vous pourrez ensuite cloner sur Visual Studio Code le dépôt en cliquant sur le bouton **"Clone in VS Code"**.

    ![Image](images/3-clonerDansVscode.png)

[Retourner en haut](#table-des-matières)

## Conclusion

Maintenant que vous avez cloné le dépôt, vous pouvez accèder localement au fichier développé par le CEI.

Le bouton suivant à gauche, pointé avec une flèche, permettra de prévisualiser les fichiers Markdowns.

![Image](images/4-previsualisation.png)

[Retourner en haut](#table-des-matières)
 
 
 
 
 
 
 
  
 
  
   
    
     
      