# 10-Observability

## Aperçu

Cette extension déploie les composants d'observabilité suivants dans votre zone d'atterrissage.

1. [Activity Tracker](https://cloud.ibm.com/docs/activity-tracker?topic=activity-tracker-getting-started) pour collecter les événements de vérification, notamment les événements de connexion
ou les changements apportés à n'importe quelle configuration de ressources.
    - Route et cible créées afin que les événements globaux, comme les événements de gestion des identités et des accès, soient envoyés à l'instance régionale d'Activity Tracker.
1. [IBM Log Analysis](https://cloud.ibm.com/docs/log-analysis?topic=log-analysis-getting-started) pour la surveillance des journaux des systèmes, des applications et des plateformes.
1. [IBM Cloud Monitoring](https://cloud.ibm.com/docs/monitoring) pour une visibilité opérationnelle des performances et de l'état de vos applications, services et plateformes.


**IMPORTANT** : Vous devez configurer cette variable d'environnement de la manière suivante :  `export IBMCLOUD_ATRACKER_API_ENDPOINT="https://us-east.atracker.cloud.ibm.com"`

![Composants d'observabilité](../../docs/images/vsi-observability.png)

## Variables d'entrée

Ces variables d'entrée seront consultées dans la sortie de [00-landing-zone](../00-landing-zone/patterns/vsi). Ou vous pouvez les remplacer et les transmettre.  Ce composant est conçu pour être exécuté après `00-landing-zone`.


| Nom | Description | Type | Par défaut/Exemple  | Obligatoire  |
| ---- | ----------- | ---- | ------- | -------- |
| ibmcloud_api_key | Clé d'interface API utilisée pour fournir les ressources.  Votre clé doit être autorisée à effectuer les actions dans ce script.  | chaîne  | sans objet  | oui |
| region | région multizone pour fournir les paires actives-passives haute disponibilité FortiGate. Répertoriez toutes les régions disponibles avec : "ibmcloud regions".  | chaîne | Par défaut : "ca-tor"  | oui |
| prefix | Courte chaîne qui sera utilisée pour préfixer tous les noms de ressources  | chaîne | sans objet  | oui |
| resource_group_id | L'ID du groupe de ressources dans lequel il faut fournir les composants d'observabilité. | chaîne | `<prefix>-slz-service-rg` | Utilisez celle par défaut ou fournissez la vôtre  |

## Pour exécuter ce script

1. Exécutez  `terraform init`
1. Exécutez  `terraform plan`
1. Exécutez  `terraform apply`

Vous pouvez exécuter `terraform destroy` pour détruire ces composants.  Assurez-vous de procéder à cette exécution avant de détruire `00-landing-zone`.

