
import traceback
import netaddr
from plan_adressage import PlanAdressage


def test_incrementation_prefixe_avec_portee_adresse_ip_depart_par_sous_reseau() :
    
    global gliste_sous_reseau    
    
    lalgorithme = 'incrementation_prefixe_reseau'

    lliste_portee_adressage_depart = []
    #lliste_portee_adressage_depart.append({ladresse_ip_depart : "zoneaccueil"})
    l = {}
    l['adresseip'] = '10.84.0.0'
    l['prefixe_reseau'] = 17
    l['portee'] = ['connectivite']
    lliste_portee_adressage_depart.append(l)

    l = {}
    l['adresseip'] = '10.85.0.0'
    l['prefixe_reseau'] = 16
    l['portee'] = ['Gateway' , 'Azure Firewall']
    lliste_portee_adressage_depart.append(l)

    lparametres_algorithme = {}
    lparametres_algorithme['pas'] = 1
    schema_adressage = PlanAdressage.generer(gliste_sous_reseau , lalgorithme 
                                             , lparametres_algorithme , lliste_portee_adressage_depart)
    
    print("test_incrementation_prefixe_avec_portee_adresse_ip_depart_sur_tous_les_sous_reseaux sucess")
    print(schema_adressage)

def test_incrementation_prefixe_avec_portee_adresse_ip_depart_sur_tous_les_sous_reseaux() :
    
    global gliste_sous_reseau    
    
    lalgorithme = 'incrementation_prefixe_reseau'

    ladresse_ip_depart = '10.84.0.0'

    lliste_portee_adressage_depart = []
    
    l = {}
    l['adresseip'] = '10.85.0.0'
    l['prefixe_reseau'] = 15
    l['portee'] = 'zoneaccueil'
    lliste_portee_adressage_depart.append(l)


    lparametres_algorithme = {}
    lparametres_algorithme['pas'] = 1
    schema_adressage = PlanAdressage.generer( gliste_sous_reseau , lalgorithme 
                                             , lparametres_algorithme , lliste_portee_adressage_depart)
    
    print("test_incrementation_prefixe_avec_portee_adresse_ip_depart_sur_tous_les_sous_reseaux sucess")
    print(schema_adressage)

def test_liste_sous_reseau_is_null() :
    PlanAdressage.generer('' , 17 , None)

def test_liste_vide_sous_reseau() :
    PlanAdressage.generer('' , 17 , [])

def test_liste_avec_un_sous_reseau() :
    schema_adressage = PlanAdressage.generer('10.84.0.0' , 16 , ['connectivite'] , 'incrementaion_prefixe_reseau')
    print("test_liste_avec_un_sous_reseau sucess")
    print(schema_adressage)

def test_incrementation_prefixe_reseau_liste_avec_plusieurs_sous_reseaux() :
    lliste_sous_reseau = ['connectivite','ASSIGNÉ','Gateway','Azure Firewall', 'NVA Subnet - externe']
    lliste_sous_reseau.append('NVA Subnet - interne')
    lliste_sous_reseau.append('NVA Subnet - HASync')
    lliste_sous_reseau.append('NVA Subnet - Gestion')
    lliste_sous_reseau.append('Desserte Subnet')    
    lliste_sous_reseau.append('Application Gateway')    
    lliste_sous_reseau.append('ÉVOLUTION')
    lliste_sous_reseau.append('VNET PÉRIMÈTRE')
    lliste_sous_reseau.append('VNET CONNECTIVITÉ')

    lalgorithme = 'incrementation_prefixe_reseau'
    lparametres_algorithme = {}
    lparametres_algorithme['pas'] = 1
    schema_adressage = PlanAdressage.generer('10.84.0.0' , 16 , lliste_sous_reseau , lalgorithme , lparametres_algorithme)
    print("test_incrementation_prefixe_reseau_liste_avec_plusieurs_sous_reseaux sucess")
    print(schema_adressage)


def test_decrementation_prefixe_reseau_liste_avec_plusieurs_sous_reseaux() :
    lliste_sous_reseau = ['connectivite','ASSIGNÉ','AppGateway','Azure Firewall','Azure Firewall' , 'NVA Subnet - externe']
    lalgorithme = 'incrementation_prefixe_reseau'
    lparametres_algorithme = {}
    lparametres_algorithme['pas'] = -1
    schema_adressage = PlanAdressage.generer('10.84.0.0' , 26 , lliste_sous_reseau , lalgorithme , lparametres_algorithme)
    print("test_decrementation_prefixe_reseau_liste_avec_plusieurs_sous_reseaux sucess")
    print(schema_adressage)


liste_espace_adressage_a_exclure = ['224.0.0.0/4' , '255.255.255.255/32' , '127.0.0.0/8' ,'169.254.0.0/16' , '168.63.129.16/32']
ladresse_depart = '10.84.0.1'
lprefixe_reseau_cidr_de_depart = 16
liste_type_adresse_ip = ['IPv4' , 'IPv6']
ltype_adresse_ip = liste_type_adresse_ip[0]
lliste_sous_reseau = []

try:

    gliste_sous_reseau = ['connectivite','ASSIGNÉ','Gateway','Azure Firewall', 'NVA Subnet - externe']
    gliste_sous_reseau.append('NVA Subnet - interne')
    gliste_sous_reseau.append('NVA Subnet - HASync')
    gliste_sous_reseau.append('NVA Subnet - Gestion')
    gliste_sous_reseau.append('Desserte Subnet')    
    gliste_sous_reseau.append('Application Gateway')    
    gliste_sous_reseau.append('ÉVOLUTION')
    gliste_sous_reseau.append('VNET PÉRIMÈTRE')
    gliste_sous_reseau.append('VNET CONNECTIVITÉ')


    test_incrementation_prefixe_avec_portee_adresse_ip_depart_sur_tous_les_sous_reseaux()

    test_incrementation_prefixe_avec_portee_adresse_ip_depart_par_sous_reseau()

    test_decrementation_prefixe_reseau_liste_avec_plusieurs_sous_reseaux()

    test_liste_avec_un_sous_reseau()
   

    test_liste_sous_reseau_is_null()
    print("test_liste_sous_reseau_is_null sucess")

    test_liste_vide_sous_reseau()
    print("test_liste_vide_sous_reseau sucess")

    
   
    #plan_adressage = generation_plan_adressage( ladresse_depart , lprefixe_reseau_cidr_de_depart , lliste_sous_reseau , ltype_adresse_ip)
    #print("Plan adressage par sous-réseau ====")
    #print(plan_adressage)

except :
    # printing stack trace
    traceback.print_exc()

