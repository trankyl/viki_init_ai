# Aperçu des étapes pour le déploiement des zones d'accueil

**Sommaire**

* [Configurations nécessaires dans Azure DevOps](#ConfigurationsNecessairesDansAzureDevops "Configurations nécessaires dans Azure Devops")  
* [Paramétrage du script pour le scénario « base »](#ParametrageScenarioBase "Paramétrage du script pour le scénario base")  
* [Procédure pour la création et l'exécution des pipelines](#ProcedurePourLaCreationEtExecutionDesPipelines "Procédure pour la création et execution des pipelines")
* [Vérification du déploiement](#VerificationDuDeploiement "Vérification du déploiement")  
* [Accueil](../README.md "Retour à la page d'accueil")  

Le déploiement des zones d'accueil par les script V2.2 se fait par l'entremise de l'exécution des pipelines, un pour chaque catégorie de ressources. Pour exécuter ces pipelines, certains prérequis de configuration Azure DevOps doivent être respectés.

Pour les étapes de déploiement des zones d'accueil avec le script, veuillez visiter les liens ci-dessous :

1. [Configuration dans Azure DevOps](clonage_et_apercu_script.md) et [clonage du répertoire CEI](clonage_et_apercu_script.md)
2. [Paramétrage du script](parametrage_deploiements.md)
3. [Créer et exécuter les pipelines](deployment_pipelines_structure.md)

Ces étapes sont aussi illustrées par le diagramme ci-dessous pour le scénario de base :
![etapes_deploiement](images/etapes_deploiement_800px.png "Étapes du déploiement du script")

Pour le scénario complexe, le paramétrage est similaire, mais dans le fichier cei-complexe-param.yml.

---

## <a id="ConfigurationsNecessairesDansAzureDevops"></a>1. Configurations nécessaires dans Azure DevOps

Pour les configurations nécessaires dans Azure DevOps voir les liens suivants :

* [Configuration dans Azure DevOps](clonage_et_apercu_script.md)
  * Création d'une [nouvelle connexion de service](https://docs.microsoft.com/fr-ca/azure/devops/pipelines/library/service-endpoints) (*Service Connection* en anglais)
  * Création d'un [environnement d'exécution des pipelines](https://docs.microsoft.com/fr-ca/azure/devops/pipelines/process/environments)
* [Clonage du répertoire CEI](clonage_et_apercu_script.md)

---

## <a id="ParametrageScenarioBase"></a>2. Paramétrage du script (pour le scénario « base »)

Les [procédures de paramétrage](parametrage_deploiements.md) du script visent deux catégories principales :

* Procédures de paramétrage obligatoire
* Procédures de paramétrage avancé ou optionnel
  (pour personnaliser le scénario de déploiement choisi)

Avant de sélectionner un [scénario de déploiement](scenarios_deploiement.md) et d'en faire le [paramétrage](parametrage.md), assurez-vous de bien comprendre :

* Les [scénarios de déploiement](scenarios_deploiement.md)
* Les [zones d'accueil](apercu_za.md)
* Le [paramétrage](parametrage.md) de la [plateforme](parametrage_plateforme.md) et des [zones d'accueil](parametrage_za_charge.md)

Pour le scénario « base », à part le fichier cei-base-param.yml, veuillez prendre connaissance des fichiers suivants, comme décrits en détail dans les documents de [paramétrage des déploiements](parametrage_deploiements.md).
C'est très similaire pour le scénario complexe, à l'exception du préfixe des fichiers de configuration "par scénario" qui serait "cei-complexe" à la place de "cei-base" dans le répertoire correspondant.


| Pipeline                | Fichiers de paramétrage                                                                                                                                                        | Commentaires                                                                                                                                                                                                                                      |
| ---------------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| management-groups.yml   | cei-base-hierarchie.yml                                                                                                                                                         | Création de groupes d'administration                                                                                                                                                                                                             |
| assign-subscriptions.yml | cei-base-subscriptions.yml                                                                                                                                                      | Assignation des abonnements aux groupes d'administration                                                                                                                                                                                          |
| platform.yml            | cei-tags.yml - cei-perimetre.yml                                                                                                                                                | Le pipeline déploie les ressources et services dans les abonnements « plateforme » y compris le « périmètre » et les tables de routage pour les VNet dans les abonnements-plateforme « gestion » et « identité ».                      |
| rbac.yml                | cei-rbac.yml                                                                                                                                                                    | Assigne des « rôles » (définis dans Azure AD) aux groupes de sécurité (définis toujours dans Azure AD). Les rôles et les groupes d'utilisateurs doivent être définis d'avance par un administrateur.                                    |
| policy.yml                 | parameters.assignbuiltin.yml<br />parameters.custompolicies.yml<br />parameters.custompolicyset.yml<br />parameters.assigncustompolicy.yml<br />parameters.assigncustompolicyset.yml | Les définitions et assignation des stratégies et initiatives intégrées ou personnalisées sont sous le répertoire scenario-base/policy.                                                                                                        |
| landingzones.yml        | cei-base-lz.yml,<br />cei-base-routage.yml                                                                                                                                      | Déploiement des zones d'accueil (abonnements de type « charge de travail »). Le paramétrage définit, entre autres, les préfixes réseau pour les sous-réseaux dans chaque zone d'accueil, le routage et les groupes de sécurité réseau. |

---

## <a id="ProcedurePourLaCreationEtExecutionDesPipelines"></a>3. Procédure pour la création et l'exécution des pipelines

Une fois que la [configuration DevOps](clonage_et_apercu_script.md), le [clonage du référentiel CEI](clonage_et_apercu_script.md) et le [paramétrage du déploiement](parametrage_deploiements.md) sont achevés, les pipelines doivent être exécutés dans l'ordre suivant :

* Déploiement des groupes d'administration - rouler pipeline « [/azure-pipeline/management-groups.yml](../azure-pipeline/management-groups.yml) ».
* Assignation des abonnements aux groupes d'administration - rouler pipeline « [/azure-pipeline/assign-subscriptions.yml](../azure-pipeline/assign-subscriptions.yml) ».
* Déploiement de la plateforme - rouler pipeline « [/azure-pipeline/platform.yml](../azure-pipeline/platform.yml) ».
  Avertissement : le déploiement de la plateforme pourrait prendre plus d'une heure.
* Déploiement des zones d'accueil pour les charges de travail - rouler pipeline « [/azure-pipeline/landingzones.yml](../azure-pipeline/landingzones.yml) ».
* Déploiement des stratégies et initiatives (*policies*) - rouler pipeline « [/azure-pipeline/policy.yml](../azure-pipeline/policy.yml) ».
* Déploiement des contrôles d’accès - rouler pipeline « [/azure-pipeline/rbac.yml](../azure-pipeline/rbac.yml) ».

### 3.1 Créer le pipeline pour déployer les groupes d'administration (*Management Groups*)

1. Dans Azure DevOps, aller dans **Pipelines -> Pipelines**.
2. Cliquer sur **Create Pipeline**.
3. Cliquer sur **Azure Repos Git**.
   ![Sélectionner Azure Repos Git](images/PipelineWhereIsCode.png)
4. Sélectionner le répertoire (repos).
   ![Sélectionner le repos](images/PipelineSelectRepo.png).
5. Cliquer sur **Existing Azure Pipelines YAML file**.
   ![Configurer le pipeline](images/PipelineConfigurePipeline.png).
6. Sélectionner la **branche** et **/azure-pipeline/management-groups.yml** pour le **Path** et cliquer sur **Continue**.
   ![Sélectionner le fichier YAML](images/PipelineSelectYAML.png).
7. Cliquer sur la flèche à côté de **Run** et cliquer sur **Save**.
   ![Sauvegarder le pipeline](images/PipelineSave.png).
8. Cliquer sur **Pipelines** dans le menu, puis sur l'ellipse à droite du nouveau pipeline et sélectionner **Rename/move**.
   ![Sauvegarder le pipeline](images/PipelineRename.png).
9. Changer le nom pour « management-groups-ci » et cliquer sur **Save**.
10. Cliquer sur l'ellipse à droite du pipeline « management-groups-ci », puis sélectionner **Run pipeline**, sélectionner la branche et cliquer sur **Run**.
    ![Exécuter le pipeline](images/PipelineRun.png).
11. Quelques secondes après l'exécution, un message indique que des permissions doivent être accordées pour continuer, cliquer sur **View**.
    ![Demande pour les permissions](images/PipelinePermissions1.png).
12. Les permissions requises sont affichées, cliquer sur **Permit** pour chacune d'elles.
    ![Valider les permissions](images/PipelineGrantPermissions.png).
13. Le déploiement va prendre plusieurs minutes, vous pouvez cliquer sur **Job** pour en suivre le statut.
14. Une fois le déploiement complété, vous pouvez voir l'arborescence des *Management Groups* dans le portail Azure.
    ![Management Groups déployés](images/ManagementGroupsCreated.png).

</br>

### 3.2 Assigner les abonnements

Si vous souhaitez assigner les abonnements pour les groupes d'administration (*Management Groups*) suivants par le biais d'un pipeline :

-Connectivité
-Gestion
-Identité

1. Dans Azure DevOps, aller dans **Pipelines -> Pipelines**.
2. Cliquer sur le bouton **New Pipeline** en haut à droite.
3. Cliquer sur **Azure Repos Git**.
4. Sélectionner le répertoire (repos).
5. Cliquer sur **Existing Azure Pipelines YAML file**.
6. Sélectionner la **branche** et **/azure-pipeline/assign-subscriptions.yml** pour le **Path** et cliquer sur **Continue**.
7. Cliquer sur la flèche à côté de **Run** et cliquer sur **Save**.
8. Cliquer sur l'ellipse (trois points à la verticale) en haut à droite du bouton **Run pipeline** et sélectionner **Rename/move**.
9. Changer le nom pour « assign-subscription-ci » et cliquer sur **Save**.
10. Cliquer sur **Run pipeline**, sélectionner la branche et cliquer sur **Run**.
11. Quelques secondes après l'exécution, un message indique que des permissions doivent être accordées pour continuer, cliquer sur **View**.
12. Les permissions requises sont affichées, cliquer sur **Permit** pour chacune d'elles.
13. Le déploiement va prendre plusieurs minutes, vous pouvez cliquer sur **Job** pour en suivre le statut.

### 3.3 Déployer les plateformes de connectivité, gestion et identité

1. Dans Azure DevOps, aller dans **Pipelines -> Pipelines**.
2. Cliquer sur le bouton **New Pipeline** en haut à droite.
3. Cliquer sur **Azure Repos Git**.
4. Sélectionner le répertoire (repos).
5. Cliquer sur **Existing Azure Pipelines YAML file**.
6. Sélectionner la **branche** et **/azure-pipeline/platform.yml** pour le **Path** et cliquer sur **Continue**.
7. Cliquer sur la flèche à côté de **Run** et cliquer sur **Save**.
8. Cliquer sur l'ellipse (trois points à la verticale) en haut à droite du bouton **Run pipeline** et sélectionner **Rename/move**.
9. Changer le nom pour « deploy-platforms-ci » et cliquer **Save**.
10. Cliquer sur **Run pipeline**, sélectionner la branche et cliquer sur **Run**.
11. Quelques secondes après l'exécution, un message indique que des permissions doivent être accordées pour continuer, cliquer sur **View**.
12. Les permissions requises sont affichées, cliquer sur **Permit** pour chacune d'elles.
13. Le déploiement peut prendre plus d'une heure selon les ressources à déployer, vous pouvez cliquer sur **Job** pour en suivre l'état.

### 3.4 Assigner les rôles RBAC

1. Dans Azure DevOps, aller dans **Pipelines -> Pipelines**.
2. Cliquer sur le bouton **New Pipeline** en haut à droite.
3. Cliquer sur **Azure Repos Git**.
4. Sélectionner le répertoire (repos).
5. Cliquer sur **Existing Azure Pipelines YAML file**.
6. Sélectionner la **branche** et **/azure-pipeline/rbac.yml** pour le **Path** et cliquer sur **Continue**.
7. Cliquer sur la flèche à côté de **Run** et cliquer sur **Save**.
8. Cliquer sur l'ellipse (trois points à la verticale) en haut à droite du bouton **Run pipeline** et sélectionner **Rename/move**.
9. Changer le nom pour « assign-rbac-ci » et cliquer sur **Save**.
10. Cliquer sur **Run pipeline**, sélectionner la branche et cliquer sur **Run**.
11. Quelques secondes après l'exécution, un message indique que des permissions doivent être accordées pour continuer, cliquer sur **View**.
12. Les permissions requises sont affichées, cliquer sur **Permit** pour chacune d'elles.
13. Le déploiement va prendre plusieurs minutes, vous pouvez cliquer sur **Job** pour en suivre l'état.

</br>
### 3.5 Assigner les stratégies et initiatives

1. Dans Azure DevOps, aller dans **Pipelines -> Pipelines**.
2. Cliquer sur le bouton **New Pipeline** en haut à droite.
3. Cliquer sur **Azure Repos Git**.
4. Sélectionner le répertoire (repos).
5. Cliquer sur **Existing Azure Pipelines YAML file**.
6. Sélectionner la **branche** et **/azure-pipeline/policy.yml** pour le **Path** et cliquer sur **Continue**.
7. Cliquer sur la flèche à côté de **Run** et cliquer sur **Save**.
8. Cliquer sur l'ellipse (trois points à la verticale) en haut à droite du bouton **Run pipeline** et sélectionner **Rename/move**.
9. Changer le nom pour « assign-policies-ci » et cliquer sur **Save**.
10. Cliquer sur **Run pipeline**, sélectionner la branche et cliquer sur **Run**.
11. Quelques secondes après l'exécution, un message indique que des permissions doivent être accordées pour continuer, cliquer sur **View**.
12. Les permissions requises sont affichées, cliquer sur **Permit** pour chacune d'elles.
13. Le déploiement va prendre plusieurs minutes, vous pouvez cliquer sur **Job** pour en suivre l'état.

### 3.6 Déployer les zones d'accueil

1. Dans Azure DevOps, aller dans **Pipelines -> Pipelines**.
2. Cliquer sur le bouton **New Pipeline** en haut à droite.
3. Cliquer sur **Azure Repos Git**.
4. Sélectionner le répertoire (repos).
5. Cliquer sur **Existing Azure Pipelines YAML file**.
6. Sélectionner la **branche** et **/azure-pipeline/landingzones.yml** pour le **Path** et cliquer sur **Continue**.
7. Cliquer sur la flèche à côté de **Run** et cliquer sur **Save**.
8. Cliquer sur l'ellipse (trois points à la verticale) en haut à droite du bouton **Run pipeline** et sélectionner **Rename/move**.
9. Changer le nom pour « landingzones-ci » et cliquer sur **Save**.
10. Cliquer sur **Run pipeline**, sélectionner la branche et cliquer sur **Run**.
11. Quelques secondes après l'exécution, un message indique que des permissions doivent être accordées pour continuer, cliquer sur **View**.
12. Les permissions requises sont affichées, cliquer sur **Permit** pour chacune d'elles.
13. Le déploiement peut prendre plus d'une heure selon les ressources à déployer, vous pouvez cliquer sur **Job** pour en suivre le statut.

---

## <a id="VerificationDuDeploiement"></a>4. Vérification du déploiement

Après avoir roulé chaque pipeline, vous devez vérifier l'exactitude du déploiement des ressources et services. Pour ce faire, aller dans le portail Azure :

| Vérification                             | Ressources               | Commentaires                                                                                                                                                                                                                                                                                                                          |
| -------------------------------------------- | -------------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Déploiement des groupes d'administration      | Groupes d'administration | Sélectionner « Groupes d'administration » et naviguer la hiérarchie en s'assurant de la présence des groupes.                                                                                                                                                                                                                        |
| Assignation des abonnements                | Abonnements              | Sélectionner « Groupes d'administration » et naviguer la hiérarchie en s'assurant de l'assignation des abonnements.                                                                                                                                                                                                                   |
| Assignation des stratégies et initiatives | Policies                 | Sélectionner « Groupes d'administration » et naviguer la hiérarchie en sélectionnant *policies* à gauche et en s'assurant de l'assignation des stratégies.                                                                                                                                                                       |
| Assignation des RBAC                       | IAM                      | Sélectionner « Groupes d'administration » et naviguer la hiérarchie, en sélectionnant à gauche « Contrôle d'accès (GIA) » et en s'assurant de l'assignation des droits d'accès par groupe.                                                                                                                                        |
| Plateforme                                 | Abonnements              | Sélectionner un par un les groupes d'administration Plateforme (Connectivité, Périmètre, Gestion, Identité) et, pour chacun d'eux, sélectionner l'abonnement en dessous. Pour chaque abonnement dans le menu à gauche, sélectionner « Toutes les ressources » en vérifiant pour chacun d'eux que les bonnes ressources ont été provisionnées. |
| Zones d'accueil                            | Abonnements              | Sélectionner un par un les groupes d'administration de dernier niveau en dessous de « Charges » et, pour chacun d'eux, sélectionner l'abonnement en dessous. Pour chaque abonnement dans le menu à gauche, sélectionner « Toutes les ressources » en vérifiant pour chacun d'eux que les bonnes ressources ont été provisionnées.     
| Azure Defender for Cloud                    | Abonnements              | Sélectionner un par un les abonnements dans Azure Defender for Cloud. Pour chaque abonnement, vérifier que les plans Azure Defender dans [cei-base-hierarchie.yml](../azure-pipeline/config/variables/scenario-base/cei-base-hierarchie.yml) ou [cei-complexe-hierarchie.yml](../azure-pipeline/config/variables/scenario-complexe/cei-complexe-hierarchie.yml) sont appliqués. La configuration par défaut est la suivante : [P2](https://learn.microsoft.com/fr-ca/azure/defender-for-cloud/defender-for-servers-introduction) pour les abonnements ayant des données sensibles et [P1](https://learn.microsoft.com/fr-ca/azure/defender-for-cloud/defender-for-servers-introduction) pour les autres abonnements.
| pare-feu Fortigate                    | Abonnements Hub ou Périmètre  | Pour chaque abonnement, vérifier qu'on y trouve le déploiement de deux machines virtuelles (**nva-XXX-FGT-A** et **nva-XXX-FGT-B**). Vérifier ensuite que chaque machine virtuelle a trois interfaces réseau. Par exemple, pour la machine virtuelle nva-hub-FGT-A, on aura les interfaces réseau **nva-hub-FGT-A-ext-Nic1**, **nva-hub-FGT-A-ext-Nic2** et **nva-hub-FGT-A-int-Nic1**.

---

Pour plus d'information, suivre les liens ci-dessous :

* [Aperçu des zones d'accueil](apercu_za.md)
* [Procédure de clonage du dépôt source CEI](clonage_et_apercu_script.md)
* [Configuration nécessaire en Azure DevOps](clonage_et_apercu_script.md)
* [Aperçu de l'abonnement Plateforme Connectivité](connectivite.md)
* [Déploiement et structure des pipelines](deployment_pipelines_structure.md)
* [Paramétrage et déploiement pare-feu FortiGate](parametrage_fortigate.md)
* [Page d'accueil](../Readme.md)
