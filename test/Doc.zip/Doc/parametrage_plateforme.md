#### Retour en arrière

* [Aperçu de l'abonnement Plateforme Connectivité](connectivite.md)
* [Étapes du déploiement](etapes_deploiement.md)
* [Aperçu des procédures de paramétrage](parametrage.md)
* [Procédures de paramétrage des déploiements](parametrage_deploiements.md)
* [Page d'accueil](../Readme.md)

# Aperçu du paramétrage pour la Plateforme

La "Plateforme" fournit des services communs utilisés par les charges de travail déployées dans les zones d'accueil. Il y a quatre abonnements, dont deux sont optionnels (même s'ils sont fortement recommandés).

## 1. Les abonnements Plateforme


| Abonnement                                                  | Déploiement | Type  | Commentaire                                                                                                                                                                                                                                                                                                                  |
| ------------------------------------------------------------- | -------------- | ------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| [Connectivité](connectivite.md)                            | Obligatoire  | Hub   | Fournit les services de connectivité "privée" sur site (*on-prem*) ou vers d'autres déploiements en nuage par le biais des passerelles VPN ou ExpressRoute.                                                                                                          |
| [Perimetre](#parametrageperimetre)     | Optionnel    | Hub   | Fournit les services de connectivité publique vers Internet, protégés par un pare-feu (par défaut fourni par le service Azure Firewall). Ce pare-feu fournit des protections contre des attaques DDoS et inspecte aussi les flux applicatifs (WAF). Il y a également d'autres méthodes (par exemple via FortiGate dans le *hub*). |
| [Gestion](#parametragegestion)         | Optionnel    | Spoke | Fournit les services de gestion, y compris pour l'accès sécuritaire aux ressources et aux charges de travail dans les zones d'accueil par le biais du service Azure Bastion; les instances VM "Jump-point" y sont déployées.                                     |
| [Identité](#parametrageidentite) | Optionnel    | Spoke | Est recommandée pour le déploiement "hybride" des solutions de gestion d'identité et des accès (GIA) tels que pour étendre dans le nuage une grappe Active Directory sur site.                                                                |

### <a id="parametrageperimetre"> **1.1 Paramétrage des abonnements "plateforme"**

Le paramétrage des abonnements "plateforme" comporte deux volets :

* Choisir les abonnements à déployer
* Choisir les services à déployer dans l'abonnement "connectivité'

Les organismes ont le choix de déployer les abonnements "identité" et/ou "gestion" en fonction de leurs besoins en utilisant un paramétrage "vanille".


| Abonnement                                                                 | Paramètre                     | Valeur défaut | Description                                                                                                                                                  |
| ---------------------------------------------------------------------------- | -------------------------------- | ---------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| [Identité](#parametrageidentite)                | var-deploy-platform-identity   | true           | Dans le cas où on ne veut pas déployer cette zone d'accueil, mettre le paramètre à false et éliminer l'association dans var-platform-identite-subscriptionId. |
| [Gestion](#parametragegestion) | var-deploy-platform-management | true           | Dans le cas où on ne veut pas déployer cette zone d'accueil, mettre le paramètre à false et éliminer l'association dans var-platform-gestion-subscriptionId.   |

### 1.2 Notes importantes

* Déployer "Gestion" pour avoir un accès distant sécurisé aux autres abonnements par le service Azure Bastion.
* Déployer "Identité" si on veut étendre la grappe Active Directory sur site vers le nuage. Par exemple, si on a des applications dans les zones de charges dépendantes sur l'Active Directory sur site (*on-prem*).
* Dans le fichier de paramétrage (cei-base-param.yml pour le scénario "base", cei-complexe-param.yml pour scénario "complexe") utiliser toujours les mots **true** et **false** sans les inclure dans des guillemets.

### 1.3 Plan d'adressage

Les préfixes réseau des VNET dans les abonnements Connectivité et Périmètre sont définis par les variables suivantes dans le fichier de paramétrage (pour scénario "base" : cei-base-param.yml, pour le scénario "complexe" : cei-complexe-param.yml). Pour plus de détails, voir le document "[Plan d'adressage](plan_adressage.md)".


| Variable                                        | Défaut | Plage IP  | Commentaire        |
| ------------------------------------------------- | --------- | ----------- | -------------------- |
| var-platform-hub-virtualNetwork-ip-prefix       | 10.84   | .0.0/17   | Pour Connectivité |
| var-platform-perimetre-virtualNetwork-ip-prefix | 10.84   | .128.0/17 | Pour Périmètre    |
| var-platform-identite-virtualNetwork-ip-prefix  | 10.73   | .0.0/17   | Pour Identité     |
| var-platform-gestion-virtualNetwork-ip-prefix   | 10.73   | .128.0/17 | Pour Gestion       |

Les suffixes des sous-réseaux dans chacun de VNet de ces abonnements sont définis dans le fichier cei-platform.yml dans le répertoire /azure-pipeline/config/variables, dans les variables de définition de ressources en format json :

* Sous-réseaux Connectivité : var-platform-hub-virtualNetwork
* Sous-réseaux Identité : var-platform-identite-virtualNetwork
* Sous-réseaux Gestion : var-platform-gestion-virtualNetwork

---

## 2. Configuration des abonnements

Les abonnements **doivent être créés indépendamment et avant exécution des scripts**. Même si, techniquement, il est possible d'automatiser la création de ces abonnements par des modules incorporés dans les scripts, la meilleure pratique recommandée par les fournisseurs infonuagiques est de créer ces abonnements manuellement, par un usager avec des privilèges élevés, dont on assigné un rôle de type "Billing administrator".

Une fois créés, les identificateurs des abonnements de type **Plateforme** doivent être entrés dans des paramètres spécifiques :


| Abonnement plateforme    | Paramètre                            |
| -------------------------- | --------------------------------------- |
| Plateforme/Connectivité | var-platform-hub-subscriptionId       |
| Plateforme/Gestion       | var-platform-gestion-subscriptionId   |
| Plateforme/Identité     | var-platform-identite-subscriptionId  |
| Plateforme/Périmetre    | var-platform-perimetre-subscriptionId |

### 2.1 Notes importantes

* Si un ID d'abonnement est une chaîne de caractères vide (c'est-à-dire '' en convention Azure), il n'y aura pas de déploiement même si la variable correspondante était "true".
* Les abonnements utilisés doivent avoir des limites de ressources suffisantes pour les déploiements des ressources et services.
* Le routage pour les VNet Gestion permet le trafic (par le "next-hop" de la passerelle VPN dans Connectivité) vers :

  * Tous les sous-réseaux dans le VNET de l'abonnement Identité
  * Tous les sous-réseaux dans les VNET des abonnements des Zones d'accueil
* Le routage pour les VNet Identité permet le trafic (par le "next-hop" de la passerelle VPN dans Connectivité) vers :

  * Tous les sous-réseaux dans le VNET de l'abonnement Gestion
  * Tous les sous-réseaux dans les VNET des abonnements des Zones d'accueil

---

## 3. Paramétrage des abonnements Plateforme

Le paramétrage de l'abonnement Connectivité est décrit en détail dans un [document à part](connectivité.md).

Pour les abonnements Périmètre, Gestion et Identité, lire ce qui suit.

### 3.1 Paramétrage de l'abonnement Périmètre

Le paramétrage de l'abonnement Périmètre consiste des étapes suivantes :


| Paramétrage                                          | Variable                                        | Défaut | Commentaire                                                                                                                                                                                                                                                                                                                                 |
| ------------------------------------------------------- | ------------------------------------------------- | --------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Assigner un abonnement existant                       | var-platform-perimetre-subscriptionId           | S/O     | Si la valeur est vide, l'abonnement Périmètre ne sera pas déployé.                                                                                                                                                                                                                                                                         |
| Valider / assigner un préfixe IP                        | var-platform-perimetre-virtualNetwork-ip-prefix | 10.84   | À modifier si en conflit avec d'autres plages d'adresse. Par défaut, le périmètre utilise le même préfixe que Connectivité, mais une plage différente dans l'espace disponible.                                                                                                                                                          |
| Choisir de déployer ou non le pare-feu Azure         | var-platform-perimetre-deploy-AzureFW           | True    | Le pare-feu est nécessaire si la communication vers Internet se fait par le périmètre. Alternativement, en modifiant le routage, on peut acheminer tout le trafic Internet par le tunnel VPN dans l'abonnement Connectivité et le pare-feu sur site (*0n-prem*).                                                                                 |
| Choisir de déployer ou non la passerelle applicative | var-platform-perimetre-deploy-appGateway        | False   | <br />Une passerelle applicative serait indiquée si on décide d'exposer sur Internet des charges de travail (dans les zones d'Accueil) offrant des interfaces externes Web. La passerelle applicative avec l'option WAF permet la protection contre les attaques DDoS et de niveau 7 (par exemple, par injection SQL ou code Javascript malveillant). |

Voici les groupes de ressources déployées par défaut dans l'abonnement Périmètre:


| Nom groupe de ressource      | Utilisation                                                                       |
| ------------------------------ | ----------------------------------------------------------------------------------- |
| NetworkWatcher_canadacentral | Le service Network Watcher est y déployé.                                         |
| rg-agw-per-prod-cac-001      | La passerelle applicative y est déployée.                                        |
| rg-network-per-prod-cac-001  | Le VNet vnet-per-prod-cac-001 y est déployé.                                     |
| rg-nva-per-prod-cac-001      | Des applications virtuelles peuvent être déployées dans ce groupe de ressources. |

Le VNet de l'abonnement Périmètre est apparié (*peering* en langage Azure) aux VNet dans les autres abonnements périphériques (*spoke*), soit Gestion, Identité et Charges (pour le scénario "base" Données sensibles, Données non sensibles et Non-prod).

### <a id="parametrageidentite"> 3.2 Paramétrage de l'abonnement Identité

Le paramétrage de l'abonnement Identité consiste des étapes suivantes :


| Paramétrage                    | Variable                                       | Défaut | Commentaire                                                                                                                                                                   |
| --------------------------------- | ------------------------------------------------ | --------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| Assigner un abonnement existant | var-platform-identite-subscriptionId           | S/O     | Si la valeur est vide, l'abonnement Identité ne sera pas déployé.                                                                                                           |
| Valider / assigner préfixe IP  | var-platform-identite-virtualNetwork-ip-prefix | 10.73   | À modifier si en conflit avec d'autres plages d'adresse. Par défaut, le périmètre utilise le même préfixe que Gestion, mais une plage différente dans l'espace disponible. |

Il n'y a pas de groupes de ressources déployées par défaut dans l'abonnement Identité.

Le VNet de l'abonnement Identité est apparié (*peering* en langage Azure) aux VNet *hub*, soient l'abonnement Connectivité et Périmètre.

### <a id="parametragegestion"> 3.3 Paramétrage de l'abonnement Gestion

Le paramétrage de l'abonnement Identité consiste des étapes suivantes :


| Paramétrage                    | Variable                                      | Défaut | Commentaire                                                                                                                                                                     |
| --------------------------------- | ----------------------------------------------- | --------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Assigner un abonnement existant | var-platform-gestion-subscriptionId           | S/O     | Si la valeur est vide, l'abonnement Gestion ne sera pas déployé.                                                                                                               |
| Valider / assigner préfixe IP  | var-platform-gestion-virtualNetwork-ip-prefix | 10.73   | À modifier si en conflit avec d'autres plages d'adresse. Par défaut, le périmètre utilise le même préfixe que Identité, mais une plage différente dans l'espace disponible. |

Pour le scénario "base", les groupes de ressources déployées par défaut dans l'abonnement Gestion sont les suivants:


| Nom groupe de ressource         | Utilisation                                                                                                |
| --------------------------------- | ----------------------------------------------------------------------------------------------------------- |
| NetworkWatcherRG                | Le service Network Watcher y est déployé.                                                                 |
| rg-alaw-gestion-prod-cac-001    | Le service Log Analytics Workspace y est déployé.                                                       |
| rg-bastion-gestion-prod-cac-001 | Le service Azure Bastion y est déployé.                                                                   |
| rg-kv-gestion-prod-cac-001      | Le service Azure Keyvault y est déployé.                                                                  |
| rg-network-gestion-prod-cac-001 | Le VNet de l'abonnement ainsi que la table de routage et le groupe de sécurité réseau y sont déployés. |
| rg-rsv-gestion-prod-cac-001     | Lae service de coffre-fort de recouvrement (Azure Recovery Service) y est déployé.                                |

Le VNet de l'abonnement Gestion est apparié (*peering* en langage Azure) aux VNet *hub*, soient l'abonnement Connectivité et Périmètre.
