# terraform-google-folders

Ce module aide à créer plusieurs dossiers sous le même parent.

<!-- BEGINNING OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
## Exigences

Pas d'exigences

## Fournisseurs

| Nom                                                        | Version |
|------------------------------------------------------------|---------|
| <a name="provider_google"></a> [google](#provider\_google) | n/a |

## Modules

| Nom                                                                        | Source | Version |
|----------------------------------------------------------------------------|--------|---------|
| <a name="module_folder_names"></a> [folder\_names](#module\_folder\_names) | ../naming-standard//modules/gcp/folder | 1.0.0 |

## Ressources

| Nom                                                                                                            | Type |
|----------------------------------------------------------------------------------------------------------------|------|
| [google_folder.folders](https://registry.terraform.io/providers/hashicorp/google/latest/docs/resources/folder) | resource |

## Entrées

| Nom                                                  | Description                                                                                                    | Type | Défaut | Requis |
|------------------------------------------------------|----------------------------------------------------------------------------------------------------------------|------|--------|:------:|
| <a name="input_names"></a> [names](#input\_names)    | Noms de dossier                                                                                                | `list(string)` | `[]`   |  non   |
| <a name="input_owner"></a> [owner](#input\_owner)    | Division ou groupe responsable pour la sécurité et l'engagement financier                                      | `string` | `""`   |  non   |
| <a name="input_parent"></a> [parent](#input\_parent) | Le nom de ressource du dossier parent ou de. Doit être de la forme folders/folder\_id ou organizations/org\_id | `string` | n/a    |  oui   |

## Sorties

| Nom                                                                     | Description                                  |
|-------------------------------------------------------------------------|----------------------------------------------|
| <a name="output_folders"></a> [folders](#output\_folders)               | Ressources de dossier en tant que liste      |
| <a name="output_folders_map"></a> [folders\_map](#output\_folders\_map) | Ressources de dossier par nom                |
| <a name="output_ids"></a> [ids](#output\_ids)                           | IDs de dossier                               |
| <a name="output_ids_list"></a> [ids\_list](#output\_ids\_list)          | Liste des ids de dossier                     |
| <a name="output_names"></a> [names](#output\_names)                     | Noms de dossier                              |
| <a name="output_names_list"></a> [names\_list](#output\_names\_list)    | List de noms de dossier |
<!-- END OF PRE-COMMIT-TERRAFORM DOCS HOOK -->

