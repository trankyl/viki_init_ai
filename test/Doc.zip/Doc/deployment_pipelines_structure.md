#### Retour en arrière

* [Étapes du déploiement](etapes_deploiement.md)
* [Page d'accueil](../Readme.md)

# Deployment pipelines

structure

## Commun

### templates

- variables

  - common.yml
  - **cei-main.yml**

## Management groups

### management-groups.yml

- templates

  - variables

    - common.yml
    - **cei-main.yml**
  - steps

    - load-variables.yml
    - show-variables.yml
    - deploy-management-groups.yml

      - modules\management-groups\structure-v2.bicep

### assign-subscriptions.yml

- templates

  - variables

    - common.yml
    - **cei-main.yml**

## RBAC

### rbac.yml

- templates

  - variables

    - common.yml
    - **cei-main.yml**
- customrbacdefinition.bicep

  - parameters

    - parameters.customrbacdefinition.json
- assignecustomrbac.bicep
- assignbuiltinrbac.bicep

## Policies

### policy.yml

- templates

  - variables

    - common.yml
- custompolicies.bicep
- custompolicyset.bicep
- assignbuiltin.bicep
- assigncustompolicy.bicep
- assigncustompolicyset.bicep

## Platform

### platform.yml

- templates

  - variables

    - common.yml
    - **cei-main.yml**
  - steps

    - deploy-platform.yml

      - hub-and-spokes\hub\hubconnectivite.bicep
      - hub-and-spokes\spokes\spoke.bicep

## Landing zones

### landingzones.yml

- templates

  - variables

    - common.yml
    - **cei-main.yml**
    - lz<name>.yml
  - steps

    - deploy-landingzone.yml

      - hub-and-spokes\spokes\spoke.bicep

### Spécialisés

- PDM
- AVS
- SAP
- AVD
- ...
