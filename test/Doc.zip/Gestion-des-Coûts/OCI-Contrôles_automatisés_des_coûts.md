# Contrôles automatisés des coûts

## Table des matières

- [Paramètres de contrôles de coût](#paramètres-de-controles-de-coût)
  - [Seuil d'alerte](#seuil-dalerte)
  - [Compartiments adaptés à votre organisation](#compartiments-adaptés-à-votre-organisation)
  - [Un budget](#un-budget)
  - [Implémentation d'un budget](#implémentation-du-budget)
- [Outils de surveillance des coûts](#outils-de-surveillance-des-coûts)


## Paramètres de contrôles de coût

Il s'agit ici d'identifier les différents concepts et options qui vont permettre à une organisation publique (OP) de définir de manière efficace les coûts liés à une infrastructure déployée dans Oracle Cloud Infrastructure (OCI).

### Seuil d'alerte

- seuils afin de déclencher des alertes liées à l’augmentation des dépenses
- seuils afin de déclencher des alertes liées aux ressources sous-utilisées.
- seuils afin de déclencher des alertes liées aux ressources sous-utilisées.
- seuils afin de déclencher des alertes liées au nombre d’instances exécutées à un moment  donné .
- seuils afin de déclencher des alertes sur l’utilisation de ressources spécifiques.
- etc.


### Compartiments adaptés à votre organisation

Les compartiments sont un composant fondamental d'Oracle Cloud Infrastructure (OCI) pour l'organisation et l'isolement de vos ressources cloud. Un compartiment est un conteneur logique pour héberger différentes ressources cloud OCI. Utilisez des compartiments pour séparer clairement les ressources dans le but de mesurer l'utilisation et la facturation, l'accès (par le biais de stratégies) et l'isolement (en séparant les ressources d'un projet ou d'une unité métier des autres).

Il est recommandé de configurer la location pour prendre en charge le fonctionnement de votre entreprise. Vous pouvez ainsi consulter et filtrer les données de coût et d'utilisation en fonction des dimensions adaptées à votre organisation. En général, cela implique l'utilisation de compartiments en tant que conteneurs logiques pour héberger différents services OCI. Vous pouvez mettre en correspondance des compartiments avec des unités organisationnelles, des unités opérationnelles ou même des propriétaires individuels de service et de solution, en fonction de la façon dont votre entreprise est exécutée.


### Balises de suivi des coûts

En associant des balises de suivi des coûts aux différentes ressources utilisées, vous pouvez interroger les données de coût en utilisant des balises comme filtres plutôt que comme compartiments. Vous bénéficiez ainsi d'une plus grande souplesse dans l'emplacement des ressources et dans la manière d'interroger les données de coûts, mais elle impose également une stratégie de balisage robuste. Vous ne souhaitez pas modifier les espaces de noms de balisage, souvent les noms de clé de balise, car cela causera plus de complexité lors de la recherche et de l'agrégation de données.

### Implémentation des balises de suivi des coûts

L'association de balises aux différentes ressources comme :
- Finance.CostCenter:xyz
- Environment.Type:Production
- Project.Owner:xyz,
- Application.Name:xyz

 sont des exemples.  Ainsi, OCI ajoute les balises aux données d'utilisation et de coût générées et autorise les recherches basées sur ces balises.

Les espaces de noms balisés doivent être protégés par les stratégies IAM pour garantir que seuls les administrateurs de balise apportent des modifications.

### Un budget

Un budget peut être utilisé afin de définir des limites ajustables pour vos dépenses réelles d'Oracle Cloud Infrastructure (OCI) ou pour vos prévisions de dépenses. Lorsque les seuils sont atteints, la plate-forme peut déclencher des alertes et envoyer des e-mails aux contacts désignés ou déclencher des événements susceptibles de déclencher des actions supplémentaires au sein de la plate-forme OCI.

#### Implémentation du budget

Les budgets sont définis sur des balises de suivi des coûts ou sur des compartiments (y compris le compartiment racine) afin de suivre toutes les dépenses associées à cette balise de suivi des coûts, ou pour ce compartiment et ses enfants.

## Outils de surveillance des coûts

Dans cette section , nous allons décrire les outils de surveillance pour suivre ces paramètres de contrôle des coûts. Il peut s’agir d’outils de  fournisseur de cloud natifs  ou de services tiers.

### Comment choisir le meilleur outil de gestion des coûts cloud ?

Voici quelques caractéristiques des solutions de gestion des coûts du cloud qui simplifieraient le processus :

- Plateforme d'automatisation et d'IA
- Identifiez les ressources Cloud inutilisées et inutilisées
- Capable de prédire l'utilisation du Cloud en fonction de niveaux granulaires
- Adaptez les services à la bonne taille
- Reporting complet
- Visibilité et analyse approfondie des dépenses
- Utiliser des instances réservées et tirer parti des instances ponctuelles
- Surveiller les anomalies de coût
- Utiliser les options de stockage appropriées
- Capable de fournir une analyse des coûts à chaque étape de la SDLC
- Identifiez et minimisez les coûts de licence logicielle
- Notifications sur le dépassement des seuils de coût
- Créer et gérer plusieurs budgets de coûts
- Alertes en cas de dépassement de l'utilisation des ressources

### Quelques outils de surveillances des coûts

- [Datadog]()
- [Harnais](https://www.harness.io/products/cloud-cost)

https://docs.oracle.com/fr/solutions/oci-best-practices/track-and-manage-usage-and-cost1.html#GUID-A1D356C3-A262-4114-B7A5-119D60774E15

[Début de la page](#table-des-matières)