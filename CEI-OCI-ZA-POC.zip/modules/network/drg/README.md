## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| oci | n/a |

## Modules

No Modules.

## Resources

| Name |
|------|
| [oci_core_drg](https://registry.terraform.io/providers/hashicorp/oci/latest/docs/resources/core_drg) |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| compartment\_id | Identifiant OCID du compartiment où sera créé le réseau virtuel infonuagique ( VCN ) | `any` | n/a | yes |
| is\_create\_drg | Whether a DRG is to be created. | `bool` | `false` | no |
| service\_label | Étiquette pour préfixer les noms des ressources déployées. | `any` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| drg | DRG information. |
