# Plan de test haut niveau pour la release v.2.2.1

## Policies
- [ ] Validation de la conformité de la zone d'accueil selon des prédéfinies acceptable
- [ ] Remédiation des *resource tags*
  - [ ] Les tags par rapport à l'organisation sont bien mis et définis dans le code
  - [ ] Les tags par rapport aux abonnements sont bien mis et définis dans le code
  - [ ] L'héritage suite à la remédiation se fait bien des abonnements vers les groupes de ressources
  - [ ] Les tags sont bel et bien obligatoires lors de la création ou modification d'un *resource group*.
  - [ ] Remédiation de public endpoint sur storage account et keyvault
  - [ ] La remédiation de *public endpoint* est appliquée sur le *storage account* et le *keyvault*
  - [ ] Il n'y a pas de *builtin* qui sont obsolète dans les initiatives utilisées
- [ ] *Resource Lock*
    - [ ] La remédiation applique les verrouillages sur les groupes de ressources de production
## Wipe Tenant
- [ ] Le nettoyage se fait même avec le *Resource Lock*
## BGP Propagation
- [ ] On peut configurer le paramètre BGP visuellement à la valeur *true* ou *false*
## Register resource provider
- [ ] La liste des fournisseurs de ressources est bien installée **avant** la fin du pipeline d'assignation des abonnements
## Service en lignes
- [ ] Les conflits d'addressages sont gérés
- [OK] Le *peering* est fait entre service en ligne non production et avec le hub
- [OK] Le *peering* est fait entre service en ligne production et avec le hub
- [OK] Le routage NSG est fonctionnel
- [ ] Les services en lignes sont fonctionnels avec le *jumpbox* aussi.
## AVD
- [ECHEC] Les ressources sont déployées pour le pipeline Commun - **Diagnostic settings does not support retention for new diagnostic settings**  
- [ECHEC] Les ressources sont déployées pour le pipeline Instance - **Diagnostic settings does not support retention for new diagnostic settings**
- [ ] Éventuellement peut être, Domain Controller dans Identité. Valider que les regle permette que AVD s'enregistre dans DC
- [ ] Lorsqu'un Domain Controller est déployé dans l'abonnement Identité, AVD peut communiquer avec ce Domain Controller.
## NSG / ASG / DNS Resolver
- [ ] On peut personnaliser facilement des NSG en injectant des règles a l'aide de templates
- [ ] On peut personnaliser facilement des ASG en injectant des règles a l'aide de templates
- [ ] On peut personnaliser facilement des DNS Resolver en injectant des règles a l'aide de templates
## Groupes de variable
- [OK] Les groupes de variables sont bien fonctionnels pour tous les pipelines
  - [ ] Pour le pipeline 1 - Azure - ManagementGroups
    - [ ] Pour le scénario de base
      - [OK] Le management group ServicesEnLigneNonProd existe dans le cadre du scénario de base
      - [OK] Le management group ServicesEnLigneProd existe dans le cadre du scénario de base
    - [OK] Pour le scénario complexe
    - [ ] Avec "None" comme organisation
    - [OK] Avec "what-if" comme paramètre
  - [ ] Pour le pipeline 2 - Azure - AssignSubscriptions
    - [ ] Avec "None" comme organisation
    - [OK] Pour le scénario de base
    - [ ] Pour le scénario complexe
  - [ ] Pour le pipeline 3 - Azure - Platform
    - [OK] Pour le scénario de base
    - [ ] Pour le scénario complexe
  - [ ] Pour le pipeline 4 - Azure - LandingZone
    - [ ] Pour le scénario de base
    - [ ] Pour le scénario complexe
  - [ ] Pour le pipeline 5 - Azure - Policy
    - [OK] Pour le scénario de base , sans Wipe Tenant   
    - [ECHEC] Pour le scénario de base , avec Wipe Tenant 
    - [ ] Pour le scénario complexe
  - [ ] Pour le pipeline 6 - Azure - RBAC
    - [ECHEC] Pour le scénario de base
    - [ ] Pour le scénario complexe
  - [ ] Pour le pipeline Azure - Wipe Tenant
- [ ] Le mot de clé None fait que le groupe de variables n'est pas utilisé pour les pipelines visés
- [ ] Toutes les valeurs des variables présentes dans le code ont priorité sur les valeurs du groupe de variables


## Checkbox et pipeline adhoc pour Wipe Policies
- [OK] Les anciennes *policies* sont bien nettoyées avant de procéder à l'assignation des nouvelles *policies*

## Autres
  - [OK] Valeur par défaut du nom de l'organisation : Dans les fichiers de pipeline on va suggerer par default le NomOrganisation comme "Default" ; c'est au client d'aller dans Devops et changer le nom pour un autre via le portail ou de le clôner aussi via le portail pour en créer plusieurs sous d'autre noms
  - [OK] Ajout du script de création des groupes de variables en Powershell sous `scripts/create-var-groups.ps1`
