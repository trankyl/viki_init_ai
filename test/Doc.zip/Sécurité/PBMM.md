# Contrôles de sécurité liés aux 12 exigences minimales
## Suivi de l'implémentation des contrôles de sécurité reliés aux 12 exigences minimales dans le cadre du PCCTI

Le MCN en accord avec le Secrétariat du Conseil du Trésor (SCT) et le Centre Gouvernemental de Cyberdéfense (CGC), à publier [les douze exigences minimales de sécurité](https://ccti.isec.gouv.qc.ca/SitePages/Exigences-minimales-de-s%C3%A9curit%C3%A9-dans-le-nuage(1).aspx) qui doivent être respecter par les organismes et établissements pour héberger les données du gouvernement du Québec (Profil A ou B) dans le nuage.

Le présent document comprend la liste des contrôles et sous-contrôles de sécurité correspondant aux 12 exigences minimales de sécurité du profil B. Ces exigences doivent être mis en place avant le déploiement des charges de travail dans le nuage.
 
Les fournisseurs infonuagiques sont appelés à répondre aux questions dans la colonne I des différents onglets (colonne  C pour l'exigence 05). L'objectif est de savoir quels contrôles et sous-contrôles de sécurité sont mis en place nativement avec les scripts de zone d’accueil, et ceux qui ne le sont pas. Le fournisseur doit expliquer comment mettre en place les contrôles non déployés par défaut, et fournir les procédures (documents, lien Internet, capture d'écran, etc.) nécessaires pour ce faire.  Cela aidera les organismes publics (OP) à mettre en place les contrôles dont ils sont responsables. 

## Liste des exigences avec quelques explications 

1. [Protéger les comptes racines](PBMM_EX1234.md)
2. [Gérer les comptes ayant le privilège administrateur idem](PBMM_EX1234.md)
3. [Limiter les accès à la console du nuage](PBMM_EX1234.md)
4. [Définir les comptes de surveillance d’entreprise](PBMM_EX1234.md)
5. [Déterminer la localisation des données](PBMM_EX5.md)
6. [Protéger les données au repos](PBMM_EX6.md)
7. [Protéger les données en transit](PBMM_EX7.md)
8. [Segmenter et séparer les données selon leur sensibilité](PBMM_EX8.md)
9. [Implémenter des services de sécurité réseau](PBMM_EX9.md)
10. [Mettre en place des services de cyberdéfense](PBMM_EX10.md)
11. [Implémenter la journalisation et la surveillance](PBMM_EX11.md)
12. [Restreindre les accès aux produits de la place de marché infonuagique](PBMM_EX12.md)


 [Retour à la Page d'Accueil](../../ReadMe.md)




 
 

