######################
# remove-policy #
######################
# ----------------------------------------------------------------------------------
#  Ce code est la propriété du MCN. S.V.P. vous référer au fichier Licence.md  pour les clauses légales 
# ----------------------------------------------------------------------------------

<#
.SYNOPSIS
Nettoie un tenant AAD après déploiement d'un Enterprise Scale (Azure Landing Zone Accelerator) de manière à ce qu'il puisse être redéployé.
ATTENTION: TOUTES VOS RESSOURCES AZURE SERONT SUPPRIMEES.
A UTILISER AVEC EXTREME PRUDENCE ET UNIQUEMENT LORSQUE LA FONCTIONALITE EST BIEN COMPRISE

.DESCRIPTION
Nettoie un tenant AAD après déploiement d'un Enterprise Scale (Azure Landing Zone Accelerator) de manière à ce qu'il puisse être redéployé.
.EXAMPLE
# Sans suppression du SPN
.\Wipe-ESLZAzTenant.ps1 -tenantRootGroupID "f73a2b89-6c0e-4382-899f-ea227cd6b68f" -intermediateRootGroupID "Contoso"
# Avec suppression du SPN
.\Wipe-ESLZAzTenant.ps1 -tenantRootGroupID "f73a2b89-6c0e-4382-899f-ea227cd6b68f" -intermediateRootGroupID "Contoso" -eslzAADSPNName "Contoso-ESLZ-SPN"
.NOTES
Pour en apprendre plus sur l'Enterprise-scale here (attention documentation en anglais uniquement):
https://github.com/Azure/Enterprise-Scale
https://aka.ms/es/guides
# Modules PowerShell requis:
- https://docs.microsoft.com/en-us/powershell/azure/install-az-ps?view=azps-6.4.0
- Install-Module -Name Az
- Spécifiquement 'Az.Accounts', 'Az.Resources' & 'Az.ResourceGraph' si vous devez limiter ce qui doit être installé
# Notes de release du 14/09/2021 - V1.0:
- Release initiale.
- Utilise Azure Resource Graph pour énumérer les abonnements contenus dans la hiérarchie du groupe de gestion ciblé, c'est pourquoi le rafraîchissement des données d'Azure Graph peut prendre 5-10 minutes, surtout si ils ont été déplacées récemment d'un groupe de gestion à un autre
# Notes de release du 29/09/2021 - V1.1:
- Ajout de la vérification de la présence des modules d'Azure PowerShell requis: 'Az' or 'Az.Accounts', 'Az.Resources' & 'Az.ResourceGraph'
# Notes de release du 30/09/2021 - V1.2:
- Ajout de la validation d'exécution dans l'environnement PowerShell Core et non Desktop - https://docs.microsoft.com/en-us/powershell/scripting/install/installing-powershell?view=powershell-7.1
# Notes de release du 01/10/2021 - V1.3:
- Modification de la manière dont la validation de la présence des modules Azure Powershell est faite
# Notes de release du 11/23/2021 - V1.4:
- Suppression de la validation par l'usager vu que nous exécutons ce script via Pipeline et non en mode interactif. Si vous souhaitez examiner le script original vous pourrez le trouver là:
    https://github.com/jtracey93/PublicScripts/blob/master/Azure/PowerShell/Enterprise-scale/Wipe-ESLZAzTenant.ps1
#>

[CmdletBinding()]
param (
    # Ajout d'un paramètre pour gérer le fait que le contexte pourrait avoir accès à plusieurs tenant AAD
    [Parameter(Mandatory = $true, Position = 1, HelpMessage = "Please the Insert Tenant ID (GUID) of your Azure AD tenant e.g.'f73a2b89-6c0e-4382-899f-ea227cd6b68f'")]
    [string] $tenantRootGroupID,

    [Parameter(Mandatory = $true, Position = 2, HelpMessage = "Insert the name of your intermediate root Management Group e.g. 'Contoso'")]
    [string] $intermediateRootGroupID,

    [Parameter(Mandatory = $false, Position = 3, HelpMessage = "(Optional) Please enter the display name of your Enterprise-scale app registration in Azure AD. If left blank, no app registration is deleted.")]
    [string] $eslzAADSPNName
)

$ConfirmPreference = "None"

# Instantiation des modules Azure Powershell requis
Install-Module Az.ResourceGraph -Scope CurrentUser -Force
Import-Module Az.ResourceGraph -Force
Import-Module Az.Accounts -Force
Import-Module Az.Resources -Force


Write-Output $tenantRootGroupID
Write-Output $intermediateRootGroupID

#Suppression des messages informatifs concernant DisplayName et DisplayId
Set-Item Env:\SuppressAzurePowerShellBreakingChangeWarnings "true"

# Démarrage du chronomètre des tâches
$StopWatch = New-Object -TypeName System.Diagnostics.Stopwatch
$StopWatch.Start()

#Enumération des abonnements qui se trouvent sous la hiérarchie du group de gestion à supprimer
$intermediateRootGroupChildSubscriptions = Search-AzGraph -Query "resourcecontainers | where type =~ 'microsoft.resources/subscriptions' | mv-expand mgmtGroups=properties.managementGroupAncestorsChain | where mgmtGroups.name =~ '$intermediateRootGroupID' | project subName=name, subID=subscriptionId, subState=properties.state, aadTenantID=tenantId, mgID=mgmtGroups.name, mgDisplayName=mgmtGroups.displayName"
$userConfirmationMGsToDelete = Get-AzManagementGroup -GroupID $intermediateRootGroupID -Expand -Recurse | Select-Object Id, DisplayName, Name, TenantId, ParentId, ParentDisplayName, ParentName, Children
$userConfirmationSubsToMove = $intermediateRootGroupChildSubscriptions | Select-Object subName, subID, subState, aadTenantID

# Liste des groupes de gestions qui vont être supprimés
Write-Output "Les groupes de gestion suivants vont être supprimés (l'information sur le groupe parent est là à des fins de visibilité, il ne sera PAS supprimé):"
$userConfirmationMGsToDelete

Write-Output "La hiérarchie du groupe de gestion ciblé contient les abonnements suivants qui seront déplacés au niveau du Tenant Root Management Group:"
Write-Output ""
if ($null -ne $intermediateRootGroupChildSubscriptions) {
    $userConfirmationSubsToMove
} else {
    Write-Output "Nous n'avons pas trouvé d'abonnements dans la hiérarchie ciblée"
    Write-Output ""
}

# Enumération des all PolicyDefinition du tenantRootGroupID
Write-Host ""
$listeStrategie = Get-AzPolicyDefinition
Write-Host "Liste des akk PolicyDefinition" -ForegroundColor Cyan
ForEach ($PolicyDefinition in $listeStrategie) {
    Write-Host "Nom : '$($PolicyDefinition.Name)'" -ForegroundColor Cyan
    Write-Host "ResourceId : '$($PolicyDefinition.ResourceId)'" -ForegroundColor Cyan
    Remove-AzPolicyDefinition -Id $PolicyDefinition.ResourceId -Force
}


# Get all policy assignments assigned to a management group intermediateRootGroupID
#Write-Host ""
#$mgId = $intermediateRootGroupID
#$listePolicyAssignment = Get-AzPolicyAssignment -Scope '/providers/Microsoft.Management/managementgroups/$mgId'
#Write-Host "Liste des PolicyAssignment du mg intermediateRootGroupID '$intermediateRootGroupID'" -ForegroundColor Cyan
#ForEach ($PolicyAssignment in $listePolicyAssignment) {
#    Write-Host "Nom : '$($PolicyAssignment.Name)'" -ForegroundColor Cyan
#    Write-Host "ResourceId : '$($PolicyAssignment.ResourceId)'" -ForegroundColor Cyan
#}

# Enumération des PolicyDefinition -Builtin du tenantRootGroupID
#Write-Host ""
#$listeStrategie = Get-AzPolicyDefinition -ManagementGroupName $tenantRootGroupID -Builtin
#Write-Host "Liste des PolicyDefinition du mg tenantRootGroupID '$tenantRootGroupID'" -ForegroundColor Cyan
#ForEach ($PolicyDefinition in $listeStrategie) {
#    Write-Host "Nom : '$($PolicyDefinition.Name)'" -ForegroundColor Cyan
#    Write-Host "ResourceId : '$($PolicyDefinition.ResourceId)'" -ForegroundColor Cyan
#}

# Afficher et supprimer chacunes des policy definitions trouvées
#Write-Host "Liste des PolicyDefinition du souscription '$($subscription.subID)'" -ForegroundColor Cyan

#ForEach ($PolicyDefinition in $listeStrategie) {
#    Write-Host "Nom : '$($PolicyDefinition.Name)'" -ForegroundColor Cyan
#    Write-Host "ResourceId : '$($PolicyDefinition.ResourceId)'" -ForegroundColor Cyan
#    
    #Remove-AzPolicyDefinition -Id $PolicyDefinition.ResourceId -Force
#}


ForEach ($subscription in $intermediateRootGroupChildSubscriptions) {
    Write-Host "Met le contexte sur la souscription: '$($subscription.subName)'" -ForegroundColor Cyan
    Set-AzContext -Subscription $subscription.subID | Out-Null
    Write-Host ""

    # Enumération des PolicyDefinition -Builtin d un abonnement
    $listeStrategie = Get-AzPolicyDefinition -SubscriptionId $subscription.subID -Builtin

    # Afficher et supprimer chacunes des policy definitions trouvées
    Write-Host "Liste des PolicyDefinition du souscription '$($subscription.subID)'" -ForegroundColor Cyan

    ForEach ($PolicyDefinition in $listeStrategie) {
        Write-Host "Nom : '$($PolicyDefinition.Name)'" -ForegroundColor Cyan
        Write-Host "ResourceId : '$($PolicyDefinition.ResourceId)'" -ForegroundColor Cyan
        
        #Remove-AzPolicyDefinition -Id $PolicyDefinition.ResourceId -Force
    }

    # Enumération des groupes de ressources de l'abonnement
    #$resources = Get-AzResourceGroup
    #Write-Output "Parcourir les groupes de ressources de l'abonnement '$($subscription.subName)'"
    #ForEach ($rg in $resources) {
    #    
    #}
}


# Arrêt du chromométrage
$StopWatch.Stop()

# Affichage du chronométrage des diverses étapes
Write-Output "Temps passé à exécuter les tâches:"
$StopWatch.Elapsed | Format-Table