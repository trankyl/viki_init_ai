# terraform-dns-zone
Ce module crée et gérer des zone DNS dans GCP

<!-- BEGINNING OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
## Exigences

Pas d'exigences

## Fournisseurs

| Nom                                                        | Version |
|------------------------------------------------------------|---------|
| <a name="provider_google"></a> [google](#provider\_google) | n/a |

## Module

Pas de module

## Resources

| Nom                                                                                                                                         | Type |
|---------------------------------------------------------------------------------------------------------------------------------------------|------|
| [google_dns_managed_zone.forwarding](https://registry.terraform.io/providers/hashicorp/google/latest/docs/resources/dns_managed_zone)       | resource |
| [google_dns_managed_zone.peering](https://registry.terraform.io/providers/hashicorp/google/latest/docs/resources/dns_managed_zone)          | resource |
| [google_dns_managed_zone.private](https://registry.terraform.io/providers/hashicorp/google/latest/docs/resources/dns_managed_zone)          | resource |
| [google_dns_managed_zone.public](https://registry.terraform.io/providers/hashicorp/google/latest/docs/resources/dns_managed_zone)           | resource |
| [google_dns_record_set.cloud-static-records](https://registry.terraform.io/providers/hashicorp/google/latest/docs/resources/dns_record_set) | resource |

## Entrées

| Nom                                                                                                                                            | Description                                                                                                                                                                         | Type | Défaut      | Requis |
|------------------------------------------------------------------------------------------------------------------------------------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|------|-------------|:------:|
| <a name="input_default_key_specs_key"></a> [default\_key\_specs\_key](#input\_default\_key\_specs\_key)                                        | Objet de signature de clé: algorithm, key\_length, key\_type, kind. [Voir](https://cloud.google.com/dns/docs/reference/v1/managedZones) pour les valeurs valides pour chaque champ  | `any` | `{}`        |  non   |
| <a name="input_default_key_specs_zone"></a> [default\_key\_specs\_zone](#input\_default\_key\_specs\_zone)                                     | Objet de signature de Zone: algorithm, key\_length, key\_type, kind. [Voir](https://cloud.google.com/dns/docs/reference/v1/managedZones) pour les valeurs valides pour chaque champ | `any` | `{}`        |  non   |
| <a name="input_description"></a> [description](#input\_description)                                                                            | Description de zone gérée                                                                                                                                                           | `string` | n/a         |  oui   |
| <a name="input_dnssec_config"></a> [dnssec\_config](#input\_dnssec\_config)                                                                    | Object contenant: kind, non\_existence, state. [Voir](https://cloud.google.com/dns/docs/reference/v1/managedZones) pour les valeurs de "kind", "non\_existence" et "state" valides  | `any` | `{}`        |  non   |
| <a name="input_domain"></a> [domain](#input\_domain)                                                                                           | Domaine du zone, doit se terminer par un point                                                                                                                                      | `string` | n/a         |  oui   |
| <a name="input_force_destroy"></a> [force\_destroy](#input\_force\_destroy)                                                                    | Vrai pour supprimer tous les enregistrements dans cette zone                                                                                                                        | `bool` | `false`     |  non   |
| <a name="input_labels"></a> [labels](#input\_labels)                                                                                           | Combinaison clé-valeur pour les étiquettes de la zone gérée                                                                                                                         | `map(any)` | `{}`        |  non   |
| <a name="input_name"></a> [name](#input\_name)                                                                                                 | Nom de la zone, doit être unique dans un projet                                                                                                                                     | `string` | n/a         |  oui   |
| <a name="input_private_visibility_config_networks"></a> [private\_visibility\_config\_networks](#input\_private\_visibility\_config\_networks) | Liste de "self-links" de VPC qui sont visible dans cette zone                                                                                                                       | `list(string)` | `[]`        |  non   |
| <a name="input_project_id"></a> [project\_id](#input\_project\_id)                                                                             | ID de projet pour cette zone                                                                                                                                                        | `string` | n/a         |  oui   |
| <a name="input_recordsets"></a> [recordsets](#input\_recordsets)                                                                               | Liste d'objets d'enregistrement de DNS à gérer, dans la structure standarde de Terraform                                                                                            | <pre>list(object({<br>    name    = string<br>    type    = string<br>    ttl     = number<br>    records = list(string)<br>  }))</pre> | `[]`        |  non   |
| <a name="input_target_name_server_addresses"></a> [target\_name\_server\_addresses](#input\_target\_name\_server\_addresses)                   | Liste de serveurs de nom ciblés pour la zone de transfert                                                                                                                           | `list(map(any))` | `[]`        |  non   |
| <a name="input_target_network"></a> [target\_network](#input\_target\_network)                                                                 | Réseau de peering                                                                                                                                                                   | `string` | `""`        |  non   |
| <a name="input_type"></a> [type](#input\_type)                                                                                                 | Public, privé, acheminement ou peering                                                                                                       | `string` | `"private"` |  non   |

## Sorties

| Nom                                                                        | Description                    |
|----------------------------------------------------------------------------|--------------------------------|
| <a name="output_domain"></a> [domain](#output\_domain)                     | Domaine de la zone DNS         |
| <a name="output_name"></a> [name](#output\_name)                           | Nom de la zone DNS             |
| <a name="output_name_servers"></a> [name\_servers](#output\_name\_servers) | Serveurs de nom de la zone DNS |
| <a name="output_type"></a> [type](#output\_type)                           | Type de la zone DNS        |
<!-- END OF PRE-COMMIT-TERRAFORM DOCS HOOK -->