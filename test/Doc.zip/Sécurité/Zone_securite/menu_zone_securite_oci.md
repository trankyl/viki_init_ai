# Service Zone de Sécurité de Oracle Cloud Infrastructure   

1. [Présentation du service Zone de Sécurité de OCI](../Zone_securite/Zone_Securite.md)  

2. [Configuration de base du service Zone de Sécurité dans une zone d'accueil OCI](../Zone_securite/Configuration_de_base_zone_securite.md)  


[Retour à la Page d'accueil](../../../README.md)   


