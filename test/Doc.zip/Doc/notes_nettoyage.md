# Nettoyage de l'environnement avant de redéployer

Parfois, il est nécessaire de redéployer le script, soit à cause d'un besoin de paramétrage différent, soit à cause d'une erreur de déploiement. Le nettoyage peut se faire aux niveaux suivants :

1. Effaçage des assignations des stratégies et initiatives ainsi que des assignations de rôle, réalisées lors d'un déploiement précédent au niveau des groupes d'administration, à la suite de l'exécution des pipelines policy.yml et/ou rbac.yml
2. Suppression de toutes les ressources déployées y compris celles déployées manuellement dans les abonnements provisionnés par le script
3. Suppression des instances NetworkWatcher dans les abonnements

Le premier cas arrive lors d'une deuxième exécution des pipelines policy.yml et/ou rbac.yml. Si des affectations et définitions précédentes de stratégies, initiatives et/ou rôles personnalisés persistent à la suite d'un déploiement précédent, les pipelines vont échouer avec des erreurs visibles dans les journaux disant qu'une mise à jour n'est pas permise, par exemple : "RoleAssignmentNotPermitted".

![RoleAssignmentUpdateNotPermitted](images\Nettoyage\RoleUpdateNotPermitted.PNG )

## Nettoyage des affectations des stratégies et initiatives

Pour effacer les stratégies et initiatives, on débute avec le groupe d'administration racine en descendant vers charges et/ou production, et possiblement plus bas en fonction de la personnalisation qui a été réalisée.

On commence donc avec l'effacement des affectations des initiatives et, par la suite, avec l'effacement (similaire) des stratégies non construites qui restent en utilisant la boîte de filtrage "Définition type" située en haut.

![Effacement assignations initiatives](images\Nettoyage\EffacerAffectationssInitiativesCustom.png)

## Nettoyage des définitions des stratégies et initiatives

On continue avec le nettoyage des définitions et des initiatives personnalisées (*custom*) et intégrées (*builtin*) créées par le script. On poursuit par la suite avec la suppression similaire des définitions des stratégies personnalisées (*custom*) qui restent, au niveau de chaque groupe d'administration où ces définitions ont été réalisées.

![Effacement définitions initiatives](images\Nettoyage\EffacerDefinitionsInitiativesCustom.png )

Pour avoir une meilleure idée des groupes d'administration où des définitions, affectations de stratégies et initiatives ont été réalisées, il suffit de regarder les configurations yml en dessous du répertoire "policy" pour le scénario que l'on déploie, par exemple :

![Paramétrage stratégies et initiatives](images\Nettoyage\ParametrageStrategiesInitiatives.PNG)

## Nettoyage des affectations des rôles

On arrive au nettoyage des affectations de rôles réalisées par le pipeline policy.yml ainsi que par le pipeline rbac.yml.

Pour chaque groupe d'administration sur lequel on a fait des assignations, des initiatives et des stratégies, on vérifie l'affectation des rôles dans le menu IAM pour chaque groupe :

![Vérification affectation des rôles](images\Nettoyage\VerificationAffectationRoles.png)

On verra possiblement des affectations qui commencent par "tag-", "logging-" ou "asc-" qu'il faut supprimer en les cochant et en utilisant la fonction *Remove* dans le menu en haut.

![Supprimer affectation des rôles par stratégies initiatives](images\Nettoyage\SupprimerAffectationRoles1.png)

Pour la suppression des affectations des rôles assignés par les stratégies et/ou initiatives, il y a aussi un script PowerShell inclus dans le répertoire scripts : Wipe-ESLZRolesAssignments.ps1.

On peut le rouler dans le Cloud Shell Azure avec deux paramètres : les ID du groupe *tenant* et celui du groupe racine. Le script ne supprime pas les affectations de rôle RBAC.

Puis, il faut aussi supprimer les affectations des rôles réalisées par le pipeline rbac.yml. Dans l'exemple plus bas, elles sont facilement identifiables par leurs noms (il faut donc suivre la convention de nom lors de l'assignation).

![Supprimer les affectations des rôles par rbac](images\Nettoyage\SupprimerAffectationRoles2.png)

## Nettoyage des ressources et des groupes d'administration

Il est parfois nécessaire de faire un nettoyage complet des ressources et des groupes de ressources en retournant les abonnements en dessous du groupe "tenant"; le pipeline qui fait cela est wipe-tenant.yml qui demande deux paramètres pour le rouler.

* l'identificateur du groupe *tenant*
* l'identificateur du groupe racine en dessous duquel le nettoyage se fait

C'est un pipeline "dangereux" pour deux raisons :

* Si on met le mauvais ID de groupe racine, on risque d'effacer des choses en dehors de la zone d'accueil déployée. Il faut donc vérifier deux fois.
* Si on avait manuellement déployé des ressources dans les abonnements de la zone d'accueil, ces ressources seront également supprimées. Il est donc recommandé de prendre des sauvegardes de ces ressources en dehors des abonnements de la zone d'accueil si on veut les restaurer après le nettoyage et le redéploiement.

Pour que le pipeline wipe-tenant puisse également effacer les groupes d'administration en dessous du groupe racine, il faut donner des permissions de propriétaire (*owner*) au compte de service ("service principal") associé avec la connexion de service dans DevOps. Pour cela, faire rouler les commandes suivantes dans le Cloud Shell Azure avec un compte de service ayant les droits nécessaires (*owner* du groupe "tenant") :

```
$spndisplayname = "nom du compte de service"
$spn = (Get-AzADServicePrincipal -DisplayName $spndisplayname).id
New-AzRoleAssignment -Scope '/' -RoleDefinitionName 'Owner' -ObjectId $spn**
```

Si le compte de service est *owner* juste au niveau du groupe racine, il faudra manuellement supprimer les groupes d'administration créés par le script de déploiement management-groups.yml.
