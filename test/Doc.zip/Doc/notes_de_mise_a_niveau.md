# Notes de mise à niveau des déploiements faits avec le script déploiement zone d'accueil Azure v2.0

version 2.2

---

Mises en garde

* La mise à niveau des déploiements de la zone d'accueil Azure réalisés avec le script v1.x ou V2 (pre-août 2022) n'est pas prise en charge.
* La mise à niveau des déploiements réalisés avec le scénario "complet" (et non "complexe") n'est pas prise en charge.

---

La nomenclature des ressources n'a pas changé dans la v2.2, il est donc possible de faire une mise à niveau d'un déploiement précédent, fait avec la version 2.0 (août 2022) du script. Noter qu’aucun changement majeur n’a été fait manuellement concernant des éléments de configuration (comme le changement de nom ou le rajout d'entités). La procédure est simple :

* S'assurer de prendre en note les NSG, règles dedans et/ou routes rajoutées manuellement puisqu'il faudra les appliquer de nouveau une fois la mise à niveau réalisée.
* Créer un nouveau groupe racine selon la nouvelle convention de nom : var-organisation-id: \'\$(var-prefixe-env-org)-\$(var-organisation-name)\'. Par défaut, var-prefixe-env-org est 'EnvironnementOrganisationnel' , mais il est préférable de le raccourcir, car il y a des limite de longueur de nom, par exemple 68 caractères pour déploiements.
* Déplacer la hiérarchie des groupes d'administration en dessous de l'ancien groupe racine ('EnvironnementOrganisationnel') en dessous du nouveau groupe d'administration.
* S'assurer que le paramétrage "commun" du script v2.2 à déployer est identique au déploiement v2.0 à mettre à jour, y compris les abonnements.
* S'assurer que les quelques corrections de code v2.0 sont réalisées, surtout en ce qui concerne les noms des VNet *hub* et du périmètre.
* Effacer les appairages (*peerings*) des VNet.
* Effacer les routes existantes en les déliant d'abord des sous-réseaux.
* Effacer les NSG avec les noms nsg-shred-* et nsg-name-*.
* Effacer l'ancien groupe d'administration 'EnvironnementOrganisationnel'.
* Effacer les stratégies et les initiatives personnalisées (*custom*).
* Effacer les instances NetworkWatcher déployées dans les abonnements.
* Déployer le script v2.2 par-dessus le déploiement existant. Les ressources existantes ne seront pas touchées, les nouvelles ressources et configurations seront déployées.
