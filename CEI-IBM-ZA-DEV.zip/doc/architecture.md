# Architecture

## Table des matières

1. [Architecture choisie](#architecture-choisie)
2. [Fondation de la zone d'accueil](#fondation-de-la-zone-d'accueil)
3. [Services d'observabilité](#services-d'observabilité)
4. [FortiGate](#fortigate)
5. [Services Internet infonuagiques ](#services-internet-infonuagiques)

## Architecture choisie

![image](images/architecture.png)


[Retour vers le haut](#table-des-matières)

## Fondation de la zone d'accueil

Vous pouvez consulter la documentation détaillée intitulée [`zone-acceuil.md`](module_docs/zone-acceuil.md).

### Zone d'accueil 

![vsi](images/module_doc_imgs/vsi.png)

[Retour vers le haut](#table-des-matières)

### Services infonuagiques

![services](images/module_doc_imgs/resources.png)

[Retour vers le haut](#table-des-matières)

### Infrastructures de nuage privé virtuel (VPC)

![network](images/module_doc_imgs/network.png)

[Retour vers le haut](#table-des-matières)

### Journaux de bord (*Flow Logs*)

![flow logs](images/module_doc_imgs/flowlogs.png)

[Retour vers le haut](#table-des-matières)

### Les points de fin privés virtuels

![vpe](images/module_doc_imgs/vpe.png)

[Retour vers le haut](#table-des-matières)

## Services d'observabilité

Vous pouvez consulter la documentation détaillée intitulée [`observabilite.md`](module_docs/obersvabilite.md).

![Observability Components](images/module_doc_imgs/vsi-observability.png)

[Retour vers le haut](#table-des-matières)

## FortiGate

Vous pouvez consulter la documentation détaillée intitulée [`FortiGate.md`](module_docs/FortiGate.md).

![Fortigate HA Pairs](images/module_doc_imgs/vsi-fortinet.png)

[Retour vers le haut](#table-des-matières)

## Services Internet infonuagiques

Vous pouvez consulter la documentation détaillée intitulée [`SrvInternetsInfo.md`](module_docs/SrvInternetsInfo.md).

![Cloud Internet Services](images/module_doc_imgs/vsi-cloudinternetsvcs.png)

[Retour vers le haut](#table-des-matières)
