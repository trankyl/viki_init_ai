#############################
# Wipe-ESLZRolesAssignments #
#############################
# Version: 1.1
# Création: 01/31/2023 
# Author: JP Gutton


<#
.SYNOPSIS

.DESCRIPTION

.EXAMPLE

.NOTES

#>


#.\Wipe-ESLZRolesAssignments.ps1 -tenantRootGroupID "xxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxx" -intermediateRootGroupID "EnvironnementOrganisationnel-JPMSFT" 

[CmdletBinding()]
param (
    # Ajout d'un paramètre pour gérer le fait que le contexte pourrait avoir accès à plusieurs tenant AAD
    [Parameter(Mandatory = $true, Position = 1, HelpMessage = "Please the Insert Tenant ID (GUID) of your Azure AD tenant e.g.'f73a2b89-6c0e-4382-899f-ea227cd6b68f'")]
    [string] $tenantRootGroupID,

    [Parameter(Mandatory = $true, Position = 2, HelpMessage = "Insert the name of your intermediate root Management Group e.g. 'Contoso'")]
    [string] $intermediateRootGroupID
)

# Instantiation des modules Azure Powershell requis
Install-Module Az.ResourceGraph -Scope CurrentUser -Force
Install-Module Az.Accounts -Scope CurrentUser -Force
Import-Module Az.ResourceGraph -Force
Import-Module Az.Accounts -Force
Import-Module Az.Resources -Force

Connect-AzureAD

# Démarrage du chronomètre des tâches
$StopWatch = New-Object -TypeName System.Diagnostics.Stopwatch
$StopWatch.Start()

$spnall = Get-AzureADServicePrincipal -Filter "startswith(DisplayName,'tags-')"
$spnall += Get-AzureADServicePrincipal -Filter "startswith(DisplayName,'logging-')"
$spnall += Get-AzureADServicePrincipal -Filter "startswith(DisplayName,'asc-')"
     
$rootscope = '/providers/Microsoft.Management/managementGroups/' + $intermediateRootGroupID

foreach ($spn in $spnall) {
    $allroles = Get-AzRoleAssignment -Scope $rootscope -ObjectId $spn.objectid
    foreach ($role in $allroles) {
        Remove-AzRoleAssignment -ObjectId $role.objectid -RoleDefinitionId $role.RoleDefinitionId -Scope $rootscope
    }
}

$allMG = Search-AzGraph -Query "ResourceContainers | where type =~ 'Microsoft.Management/managementGroups' | project id, name" -ManagementGroup $intermediateRootGroupID
    
$parent = Get-AzManagementGroup -GroupId $tenantRootGroupID
$assignments = Get-AzPolicyAssignment -Scope $parent.Id
foreach ($assignment in $assignments) {
    Remove-AzPolicyAssignment -Scope $parent.Id -Name $assignment.Name
}
foreach ($mg in $allMG) {
    $childAssgnt = Get-AzPolicyAssignment -Scope $mg.Id
    foreach ($child in $childAssgnt) {
        Remove-AzPolicyAssignment -Scope $mg.Id -Name $child.Name
    }
}

$StopWatch.Stop()

# Affichage du chronométrage des diverses étapes
Write-Output "Temps passé à exécuter les tâches:"
$StopWatch.Elapsed | Format-Table

