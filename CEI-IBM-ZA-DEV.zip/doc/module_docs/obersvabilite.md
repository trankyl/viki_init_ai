# 10-Observability

## Overview

This extension deploys the following Observability components into your landing zone.

1. [Activity Tracker](https://cloud.ibm.com/docs/activity-tracker?topic=activity-tracker-getting-started) for collecting audit events, including login events
or changes to any resource configuration.

- Route and target created so that global events, such as IAM events, are sent to the regional instance of Activity Tracker.

1. [IBM LogAnalysis](https://cloud.ibm.com/docs/log-analysis?topic=log-analysis-getting-started) for monitoring system, application and platform logs.

1. [IBM Cloud Monitoring](https://cloud.ibm.com/docs/monitoring) for operational visibility into performance and health of your applications, services and platforms.

**IMPORTANT**: You must set this environment variable as follows.  `export IBMCLOUD_ATRACKER_API_ENDPOINT="https://us-east.atracker.cloud.ibm.com"`

![Observability Components](../images/module_doc_imgs/vsi-observability.png)

## Input Variables

These input variables will be looked up in the output of [00-landing-zone](../../terraform/00-landing-zone/patterns/vsi) or you can override and pass them in.  This component is designed to be run after `00-landing-zone`.

| Name | Description | Type | Default/Example | Required |
| ---- | ----------- | ---- | ------- | -------- |
| ibmcloud_api_key | API Key used to provision resources.  Your key must be authorized to perform the actions in this script. | string | N/A | yes |
| region | MZR to provision the Fortigate AP HA pairs. List all available regions with: "ibmcloud regions". | string | Default: "ca-tor" | yes |
| prefix | Short string that will be used to prefix all resource names | list(string) | N/A | yes |
| resource_group_id | The id of the resource group in which to provision the observability components. | string | `<prefix>-slz-service-rg`| Use default or provide your own |
