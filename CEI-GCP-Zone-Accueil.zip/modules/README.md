
# Modules

## Table des matières

1. [Introduction](#introduction)
1. [audit-bunker](#audit-bunker)
2. [cloudbuild](#cloudbuild)
3. [dns-zone](#dns-zone)
4. [firewall](#firewall)
5. [folder](#folder)
6. [fortigate-appliance](#fortigate-appliance)
7. [guardrails](#guardrails)
8. [iam](#iam)
9. [landing-zone-bootstrap](#landing-zone-bootstrap)
10. [naming-standard](#naming-standard)
11. [network](#network)
12. [network-host-project](#network-host-project)
13. [org-custom-roles](#org-custom-roles)
14. [organization-policy](#organization-policy)
15. [project](#project)
16. [virtual-machine](#virtual-machine)
17. [vpc-service-controls](#vpc-service-controls)

### Introduction

Les modules Terraform développés par GCP (Google Cloud Platform) sont présents dans le lien suivant [Modules](https://registry.terraform.io/providers/hashicorp/google/latest/docs). 

Les services suivants sont inclus dans le lien terraform :
- API Gateway
- Access Approval
- Access Context Manager (VPC Service Controls)
- Apigee
- Apikeys
- App Engine
- Artifact Registry
- AssuredWorkloads
- BigQuery  
    - Connection
    - Data Transfer
    - Reservation
- Binary Authorization
- Certificate Authority Service
- Certificate Manager
- Cloud (Stackdriver)
    - Logging
    - Monitoring
- Cloud AI Notebooks
- Cloud Asset Inventory
- Cloud Bigtable
- Cloud Billing
- Cloud Build
- Cloud Composer
- Cloud DNS
- Cloud Data Fusion
- Cloud Deploy
- Cloud Deployment Manager
- Cloud Endpoints
- Cloud Functions
    - 1st gen
    - 2nd gen
- Cloud Healthcare
- Cloud IAM
- Cloud Identity
- Cloud IoT Core
- Cloud Key Management Service
- Cloud Platform
- Cloud Pub/Sub
- Cloud Run
- Cloud SQL
- Cloud Scheduler
- Cloud Security Scanner
- Cloud Source Repositories
- Cloud Spanner
- Cloud Storage
- Cloud TPU
- Cloud Tasks
- Compute Engine
- Container Registry
- ContainerAWS
- ContainerAzure
- Data Catalog
- Data Loss Prevention
- Dataflow
- Dataplex
- Dataproc
- Dataproc Metastore
- Datastore
- Dialogflow CX
- Essential Contacts
- Eventarc
- Filestore
- Firebase
- Firebaserules
- Firestore
- GKEHub
- Game Servers
- Identity Platform
- Identity-Aware Proxy
- Kubernetes (Container) Engine
- Logging
- ML Engine
- Managed Microsoft Active Directory
- Memcache
- Memorystore (Redis)
- Network Services
- NetworkConnectivity
- NetworkManagement
- OS Config
- OS Login
- OrgPolicy
- OsConfig
- RecaptchaEnterprise
- Resource Manager
- Runtime Configurator
- Secret Manager
- Security Command Center (SCC)
- Serverless VPC Access
- Service Directory
- Service Networking 
- Service Usage 
- Storage Transfer Service
- Tags
- Vertex AI
- Workflows

### audit-bunker

Lien vers la documentation Google : [audit-bunker_README.md](/modules/audit-bunker/README.md)

[Retour à la table des matières](#table-des-matières)
### cloudbuild

Lien vers la documentation Google : [cloudbuild_README.md](/modules/cloudbuild/README.md)

[Retour à la table des matières](#table-des-matières)
### dns-zone

Lien vers la documentation Google : [dns-zone_README.md](/modules/dns-zone/README.md)

[Retour à la table des matières](#table-des-matières)
### firewall

Lien vers la documentation Google : [firewall_README.md](/modules/firewall/README.md)

[Retour à la table des matières](#table-des-matières)
### folder

Lien vers la documentation Google : [folder_README.md](/modules/folder/README.md)

[Retour à la table des matières](#table-des-matières)
### fortigate-appliance

Lien vers la documentation Google : [fortigate-appliance_README.md](/modules/fortigate-appliance/README.md)

[Retour à la table des matières](#table-des-matières)
### guardrails

Lien vers la documentation Google : [guardrails_README.md](/modules/guardrails/README.md)

[Retour à la table des matières](#table-des-matières)
### iam

Lien vers la documentation Google : [iam_README.md](/modules/iam/README.md)

[Retour à la table des matières](#table-des-matières)
### landing-zone-bootstrap

Lien vers la documentation Google : [landing-zone-bootstrap_README.md](/modules/landing-zone-bootstrap/README.md)

[Retour à la table des matières](#table-des-matières)
### naming-standard

Lien vers la documentation Google : [naming-standard_README.md](/modules/naming-standard/README.md)

[Retour à la table des matières](#table-des-matières)
### network

Lien vers la documentation Google : [network_README.md](/modules/network/README.md)

[Retour à la table des matières](#table-des-matières)
### network-host-project

Lien vers la documentation Google : [network-host-project_README.md](/modules/network-host-project/README.md)

[Retour à la table des matières](#table-des-matières)
### org-custom-roles

Lien vers la documentation Google : [org-custom-roles_README.md](/modules/org-custom-roles/README.md)

[Retour à la table des matières](#table-des-matières)
### organization-policy

Lien vers la documentation Google : [organization-policy_README.md](/modules/organization-policy/README.md)

[Retour à la table des matières](#table-des-matières)
### project

Lien vers la documentation Google : [project_README.md](/modules/project/README.md)

[Retour à la table des matières](#table-des-matières)
### virtual-machine

Lien vers la documentation Google : [virtual-machine_README.md](/modules/virtual-machine/README.md)

[Retour à la table des matières](#table-des-matières)
### vpc-service-controls

Lien vers la documentation Google : [vpc-service-controls_README.md](/modules/vpc-service-controls/README.md)

[Retour à la table des matières](#table-des-matières)
