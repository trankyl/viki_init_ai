param([string]$filtersString)

# Fonction permettant de voir si un string contient au moins une valeur dans une liste
function containsArrayValue{
    param([string]$sentence,[array]$values)

    foreach($value in $values){
        if($sentence -like ("*$value*")){
            return $true;
        }
    }
    return $false;
}


$countOuvertes = 0
echo "Ouverture des ressources pour tous les abonnements"
$filters = $filtersString.Split(" ")
$allSubscriptions = Get-AzSubscription | where{containsArrayValue $_.Name $filters -and $_.State -ne 'Disabled'}
foreach($sub in $allSubscriptions){
    Set-AzContext -Subscription $($sub.id) | Out-Null
    $rgNames = Get-AzResourceGroup | % {$_.ResourceGroupName}
    foreach($rgName in $rgNames){
        echo "Ouverture des ressources dans $($sub.name) pour $($rgName)"
        #VMs
        $vms = Get-AzVm -ResourceGroupName $rgName -WarningAction:SilentlyContinue | Start-AzVM
        #Application Gateway
        $agws = Get-AzApplicationGateway -ResourceGroupName $rgName | Start-AzApplicationGateway
        $countOuvertes = $countOuvertes + $vms.count + $agws.count
        $fws = Get-AzFirewall -ResourceGroupName $rgName
        if($fws.count -eq 1){
            $fw = $fws | Select -First 1
            $vnet = Get-AzVirtualNetwork -ResourceGroupName $rgName | Select -First 1
            $pip = Get-AzVirtualNetwork -ResourceGroupName $rgName | Select -First 1
            $fw.Allocate($vnet, $pip)
            $fw | Set-AzFirewall

            $countOuvertes = $countOuvertes + 1
        }
    }
}

echo "$countOuvertes ressources ouvertes (VMs, Firewalls ou Application Gateways)"
