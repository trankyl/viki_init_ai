#### Retour en arrière

* [Aperçu du script](apercu_script.md)
* [Aperçu des Zones d'accueil](apercu_za.md)
* [Architecture des Zones d'accueil](architecture_za.md)
* [Page d'accueil](../Readme.md)

# Mise en contexte par rapport aux zones d'accueil

Le présent projet est réalisé dans le cadre du Décret 596-2020 visant la transposition infonuagique des infrastructures informatiques des organismes publics (OP) et des établissements du réseau de la santé et des services sociaux (RSSS), ainsi que celui de l’éducation et de l’enseignement supérieur (REES).

À cet égard, le Centre d’expertise en infonuagique (CEI) du ministère de la Cybersécurité et du Numérique (MCN), en collaboration avec Microsoft, a produit un script qui permet de provisionner de manière automatisée une [zone d’accueil (*Landing Zone* en anglais)](https://docs.microsoft.com/fr-fr/azure/cloud-adoption-framework/ready/landing-zone/) dans la plateforme infonuagique Azure.

Il est à noter que le script utilise des pipelines Azure DevOps, en format Yaml, qui appellent des modules dans le langage Bicep, permettant  de déployer de manière déclarative des ressources dans la plateforme infonuagique Azure.

Il est recommandé que tous les changements dans les environnements soient faits par le biais du script, c'est-à-dire par des modifications au niveau du paramétrage du script. Autrement, si des changements sont réalisés manuellement, ils risquent d'être écrasés lors de la prochaine exécution du script ou peuvent nuire à l'exécution du script.

## 1. Version v2.2

Cette version 2.2 est majeure et inclut tous les correctifs et toutes les améliorations antérieures.

Pour consulter l’historique des améliorations et des versions, cliquez [ICI](ReadmeHistoversion.md).

## 2. Note importante

Les recommandations et les exemples dans la documentation sont présentés à titre indicatif seulement.
Les OP et les établissements ont la responsabilité de définir et de personnaliser les différents paramètres du script en fonction de leurs besoins.

**IMPORTANT** : VEUILLEZ LIRE ATTENTIVEMENT CETTE [LICENCE AVANT D’UTILISER CE SCRIPT ET SES COMPOSANTS](../Licence.md).

## 3. Pour continuer

La documentation est organisée de manière modulaire pour permettre aux usagers une navigation rapide et efficace.

Les liens ci-dessous vous permettent de naviguer dans la documentation selon vos intérêts et vos besoins :

* [Aperçu des zones d'accueil](apercu_za.md)
* [Architecture des zones d'accueil](architecture_za.md)
* [Aperçu du script v2.2](apercu_script.md)
* [Aperçu du paramétrage du script](parametrage.md)
* [Les scénarios de déploiement prédéfinis](scenarios_deploiement.md)
