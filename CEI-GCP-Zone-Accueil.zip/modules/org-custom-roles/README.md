# Aperçu

Ce module est conçu pour utiliser avec la Zone d'Accueil de GCP. Il crée des rôles personnalisés au niveau d'organisation qui peuvent être attribué au niveau d'organisation, de dosser et de projet.

## Limitations

## Problèmes Connus

Aucun

## Exemple

Voir le dossier [examples](examples/main.tf)

<!-- BEGINNING OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
## Exigences

Pas d'exigences

## Fournisseurs

| Nom                                                        | Version |
|------------------------------------------------------------|---------|
| <a name="provider_google"></a> [google](#provider\_google) | 3.62.0 |
| <a name="provider_random"></a> [random](#provider\_random) | n/a |

## Modules

| Nom                                                                                         | Source | Version |
|---------------------------------------------------------------------------------------------|--------|---------|
| <a name="module_custom_role_names"></a> [custom\_role\_names](#module\_custom\_role\_names) | ../naming-standard//modules/gcp/custom_role | 2.2.0 |

## Resources

| Nom                                                                                                                                                                | Type |
|--------------------------------------------------------------------------------------------------------------------------------------------------------------------|------|
| [google_organization_iam_custom_role.org_custom_role](https://registry.terraform.io/providers/hashicorp/google/latest/docs/resources/organization_iam_custom_role) | resource |
| [random_id.random_id](https://registry.terraform.io/providers/hashicorp/random/latest/docs/resources/id)                                                           | resource |

## Entrées

| Nom                                                                                             | Description                                               | Type | Défaut                      | Requis |
|-------------------------------------------------------------------------------------------------|-----------------------------------------------------------|------|-----------------------------|:------:|
| <a name="input_custom_roles"></a> [custom\_roles](#input\_custom\_roles)                        | Dictionnaire de rôles à créer                             | <pre>map(<br>    object({<br>      title       = string<br>      description = string<br>      role_id     = string<br>      permissions = list(string)<br>    })<br>  )</pre> | n/a                         |  oui   |
| <a name="input_department_code"></a> [department\_code](#input\_department\_code)               | Code pour département, partie du module de nommage        | `string` | n/a                         |  oui   |
| <a name="input_environment"></a> [environment](#input\_environment)                             | S-Sandbox P-Production Q-Quality D-development            | `string` | n/a                         |  oui   |
| <a name="input_location"></a> [location](#input\_location)                                      | Endroit pour le placement de nommage et de ressource      | `string` | `"northamerica-northeast1"` |   non   |
| <a name="input_org_id"></a> [org\_id](#input\_org\_id)                                          | Organisation dans laquelle sera créé le rôle personnalisé | `string` | n/a                         |  oui   |
| <a name="input_user_defined_string"></a> [user\_defined\_string](#input\_user\_defined\_string) | String défini par l'usager            | `string` | n/a                         |  oui   |

## Sorties

| Nom                                                            | Description |
|----------------------------------------------------------------|-------------|
| <a name="output_role_ids"></a> [role\_ids](#output\_role\_ids) | n/a |
<!-- END OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
