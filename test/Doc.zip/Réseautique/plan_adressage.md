# Plan d'adressage

## Sommaire

1. [Planification réseautique](#planification-réseautique)
1. [Réseautique](#réseautique)
1. [Réseaux et sous-réseaux](#réseaux-et-sous-réseaux)


## Planification réseautique

Dans le cadre de la stratégie élaborée par le Programme de consolidation des centres de traitement informatique (PCCTI), en collaboration avec le Centre d’expertise en infonuagique (CEI), et afin de limiter les impacts de la migration infonuagique sur l’espace d’adressage IP du RITM, les plages d’adresses suivantes ont été réservées. Elles peuvent être utilisées par tous les OP sans crainte de conflits d’adresses avec les autres OP.

10.73.0.0/16    
10.77.0.0/16     
10.79.0.0/16     
10.84.0.0/16  (non utilisée)       
10.86.0.0/16  (non utilisée)      

Dans le cadre de notre déploiement, nous avons utilisé uniquement les trois premiers blocs d'adresses.  
Voyez ci-dessous le découpage par réseau (VCN) et sous-réseaux.  
À noter : chaque installation est unique et ce découpage réseau est à titre indicatif. Son but vise à tester la fonctionnalité de la solution sans tenir compte du nombre ou du type de charges de travail.   


## Réseautique

   Le diagramme suivant est le résultat du déploiement de la zone d'accueil quand elle est déployée en utilisant les paramètres par défaut, voir [Déploiement du script](../Déploiement/Deploi_Script.md).

   En plus des six compartiments présentés dans la section précédente, le script déploie neuf réseaux répertoriés par compartiment comme suit :

- Compartiment de connectivité
  - 1 VCN pour la connectivité
- Compartiment de production
  - 1 VCN Web (web)
  - 1 VCN application (app)
  - 1 VCN base de données (bd)
- Compartiment de non-production
  - 1 VCN Web (web)
  - 1 VCN application (app)
  - 1 VCN base de données (bd)
- Compartiment de non classifié
  - 1 VCN non classifié  
- Compartiment de carré de sable
  - 1 VCN carré de sable


**Réseautique**  

![Arc_CMP_VCN_SReseaux](../images/Arc_Reseautique.png)   


Pour plus d'information concernant le découpage réseau, veuillez consulter la section [Planification réseautique](#planification-réseautique).   


### Réseaux et sous-réseaux   

>| Compartiment     | Réseaux                      | Blocs attribués      | Sous-réseaux                         | Blocs attribué      |
>|------------------|------------------------------|-----------------------|--------------------------------------|----------------------|
>| cmp-conne-001    | VCN Concentrateur            | 10.73.0.0/23 (512)    | Public subnet                        | 10.73.0.00/27 (32)   |
>|                  |                              |                       | Priv subnet                          | 10.73.0.32/27 (32)   |
>|                  |                              |                       | Mgmt subnet                          | 10.73.0.64/27 (32)   |
>|                  |                              |                       | HA subnet                            | 10.73.0.96/27 (32)   |
>| Compartiment     | Réseaux                      | Blocs attribués      | Sous-réseaux                         | Blocs attribués      |
>|------------------|------------------------------|-----------------------|--------------------------------------|-----------------------|
>| cmp-prod-001     | vcn-cmp-nonprod-web-cam1-001 | 10.77.00.0/18 (16384) | snetr-vcn-cmp-nonprod-web-cam1-001   | 10.77.0.0/19 (8192)   |
>|                  | vcn-cmp-prod-app-cam1-001    | 10.77.64.0/18 (16384) | snetr-vcn-cmp-prod-app-cam1-001      | 10.77.64.0/19 (8192)  |
>|                  | vcn-cmp-prod-bd-cazm1-001    | 10.77.128.0/18 (16384)| snetr-vcn-cmp-prod-db-cam1-001       | 10.77.128.0/19 (8192) |
>| Compartiment     | Réseaux                      | Blocs attribués      | Sous-réseaux                         | Blocs attribués      |
>|------------------|------------------------------|-----------------------|--------------------------------------|-----------------------|
>| cmp-nonprod-001  | vcn-cmp-nonprod-web-cam1-001 | 10.79.0.0/18 (16384)  | snetr-vcn-cmp-nonprod-web-cam1-001   | 10.79.0.0/19 (8192)   |
>|                  | vcn-cmp-nonprod-app-cam1-001 | 10.79.64.0/18 (16384) | snetr-vcn-cmp-nonprod-app-cam1-001   | 10.79.64.0/19 (8192)  |
>|                  | vcn-cmp-nonprod-bd-cam1-001  | 10.79.128.0/18 (16384)| snetr-vcn-cmp-nonprod-db-cam1-001    | 10.79.128.0/19 (8192) |
>| Compartiment     | Réseaux                      | Blocs attribués      | Sous-réseaux                         | Blocs attribués      |
>|------------------|------------------------------|-----------------------|--------------------------------------|-----------------------|
>| cmp-casae-001    | vcn-cmp-case-tecae-cam1-001 | 10.73.128.0/18 (16384)| snetr-vcn-cmp-casae-tecae-cam1-001   | 10.73.128.0/22 (1024) |
>| Compartiment     | Réseaux                      | Blocs attribués      | Sous-réseaux                         | Blocs attribués      |
>|------------------|------------------------------|-----------------------|--------------------------------------|-----------------------|
>| cmp-nocla-001    | vcn-cmp-nocla-tenoa-cam1-001| 10.73.64.0/18 (16384) | snetr-vcn-cmp-casae-tecae-cam1-001   | 10.73.64.0/22 (1024)  |
    
Pour plus de détails , voir le [diagramme d'architecture](../images/Arc_CMP_VCN_SReseaux.PNG) de la solution   

[Retour à la page d'accueil](../../README.md)
