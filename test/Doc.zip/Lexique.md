# Lexique

Travailler dans l'infrastructure revient à adopter un certain langage technique qui n'est pas toujours facile à traduire ou à remplacer. Cette liste, même si elle n'est pas exhaustive, vise à donner un complément d'information en ce qui concerne ces mots ou certains acronymes qui sont utilisés. Les liens peuvent être en français ou en anglais selon le fournisseur.

- [Cloud Guard](https://docs.oracle.com/fr-ca/iaas/cloud-guard/home.htm)

- DMZ (Voir **Zone démilitarisée** en français)

- Domaine de disponibilité

  Dans votre région géographique, centre de données Oracle Cloud Infrastructure qui héberge les ressources dans le nuage. Un pare-feu existe dans un seul domaine de disponibilité d'une région.

- Domaines de pannes (**Fault domains** en anglais)

  Un domaine de panne est un regroupement de matériel et d'infrastructure dans un domaine de disponibilité. Chaque domaine de disponibilité dispose de trois domaines de pannes dotés d'une alimentation et d'un matériel indépendants. Lorsque vous distribuez des ressources dans plusieurs domaines de pannes, vos applications peuvent tolérer la panne de serveur physique, la maintenance du système et les pannes de courant dans un domaine de panne.

- [DRG (*Dynamic routing gateway*)](https://docs.oracle.com/fr-ca/iaas/Content/Network/Tasks/managingDRGs.htm) (Voir **Passerelle de routage dynamique** en français )

- [*Events*](https://docs.oracle.com/fr-ca/iaas/Content/Events/Concepts/eventsoverview.htm)

- [FastConnect](https://docs.oracle.com/fr-fr/iaas/Content/Network/Concepts/fastconnect.htm)

  Connexion privée dédiée entre votre centre de données et Oracle Cloud Infrastructure. FastConnect offre des options de bande passante plus élevée et une expérience réseau plus fiable par rapport aux connexions Internet.

- Forme de calcul

  La forme d'une instance de calcul indique le nombre d'unités de consommation (UC) et la quantité de mémoire allouée à l'instance. La forme de calcul détermine également le nombre de cartes VNIC et la bande passante maximale disponible pour l'instance de calcul.

- [IGW Internet gateway](https://docs.oracle.com/fr-ca/iaas/Content/Network/Tasks/managingIGs.htm) (Voir **Passerelle Internet** en français )

- Liste de sécurité

  Pour chaque sous-réseau, vous pouvez créer des règles de sécurité qui spécifient la source, la destination et le type de trafic qui doivent être autorisés dans et hors du sous-réseau.

- [Logs](https://docs.oracle.com/fr-ca/iaas/Content/Logging/Concepts/loggingoverview.htm)

- [NAT gateway](https://docs.oracle.com/fr-ca/iaas/Content/Network/Tasks/NATgateway.htm)

  Voir la définition de **Passerelle NAT**

- [NSG (Network Security Group)](https://docs.oracle.com/en/solutions/hub-spoke-network-drg/index.html#GUID-FB5990CB-A23B-482D-80F4-AE4A548DEC9C)

- [Notifications](https://docs.oracle.com/fr-ca/iaas/Content/Notification/Concepts/notificationoverview.htm)

- [*Object storage*](https://docs.oracle.com/fr-ca/iaas/Content/Object/Concepts/objectstorageoverview.htm)

- [OCI (Oracle Cloud Infrastructure)](https://docs.oracle.com/fr-ca/iaas/Content/GSG/Concepts/baremetalintro.htm)

- [*On-premises network*](https://en.wikipedia.org/wiki/On-premises_software)
Réseau sur site

- Pare-feu (*Firewall* en anglais) :

   Ressource de sécurité qui existe dans un sous-réseau de votre choix et qui contrôle le trafic réseau entrant et sortant en fonction d'un jeu de règles de sécurité. Chaque pare-feu est associé à une politique. Le trafic est acheminé vers et depuis le pare-feu à partir de ressources telles que les passerelles Internet et les passerelles de routage dynamique (DRG).

- Passerelle Internet

  La passerelle Internet permet le trafic entre les sous-réseaux publics dans un VCN et Internet public.

- Passerelle NAT

  La passerelle NAT permet aux ressources privées d'un VCN d'accéder aux hôtes sur Internet, sans exposer ces ressources à des connexions Internet entrantes.

- Passerelle de routage dynamique

  La passerelle de routage dynamique est un routeur virtuel qui fournit un chemin pour le trafic réseau privé entre le VCN et un réseau en dehors de la région, tel qu'un VCN dans une autre région Oracle Cloud Infrastructure, un réseau sur site ou un réseau dans un autre fournisseur infonuagique.

- Passerelle de service

  La passerelle de service fournit l'accès d'un VCN à d'autres services, tels qu'Oracle Cloud Infrastructure Object Storage. Le trafic entre le VCN et le service Oracle traverse le tissu réseau Oracle et ne traverse jamais Internet.

- Politique (*Policy* en anglais)

  Une politique contient toute la configuration utilisée par un pare-feu pour traiter le trafic réseau. Une politique peut être associée à un ou plusieurs pare-feux.

- [*Regions and Availability Domains*](https://docs.oracle.com/fr-ca/iaas/Content/General/Concepts/regions.htm))
  - Région et zones de disponibilités
  - Une région Oracle Cloud Infrastructure est une zone géographique localisée qui contient un ou plusieurs centres de données, appelés domaines de disponibilité.

- [RT (*Route table*)](https://docs.oracle.com/fr-ca/iaas/Content/Network/Tasks/managingroutetables.htm)
  - Table de routage
  - Un VCN utilise des tables de routage pour envoyer le trafic hors du VCN. Ces tables de routage ont des règles qui ressemblent et agissent comme des règles de routage réseau traditionnelles.

- [Service Connectors](https://docs.oracle.com/fr-ca/iaas/Content/service-connector-hub/overview.htm)

- [Service Gateway](https://docs.oracle.com/fr-ca/iaas/Content/Network/Tasks/servicegateway.htm)

- *Shape of a compute instance* (Voir **Forme de calcul** en français)

- [*Site-to-Site VPN*](https://docs.oracle.com/fr-fr/iaas/Content/Network/Tasks/overviewIPsec.htm#:~:text=Site%2Dto%2DSite%20VPN%20provides,the%20traffic%20when%20it%20arrives.)
  - Fournit une connectivité VPN IPSec entre votre réseau sur site et les VCN dans Oracle Cloud Infrastructure.

- [SL (*Security list*)](https://docs.oracle.com/fr-ca/iaas/Content/Network/Concepts/securitylists.htm)
  - Liste de sécurité
  - Les listes de sécurité agissent comme des pare-feux virtuels pour vos instances de calcul et d'autres ressources.

- Table de routage

  Les tables de routage virtuelles contiennent des règles pour acheminer le trafic de sous-réseaux vers des destinations en dehors d'un VCN, généralement par des passerelles.

- Trafic réseau est-ouest

  Trafic circulant entre les charges de travail et les sous-réseaux dans un réseau en nuage virtuel.

- Trafic réseau nord-sud

  Trafic entrant dans votre réseau à partir d'une source externe.

- [*Vault*](https://docs.oracle.com/fr-ca/iaas/Content/KeyManagement/Concepts/keyoverview.htm)

- [VCN (*Virtual cloud network*)](https://docs.oracle.com/fr-ca/iaas/Content/Network/Tasks/managingVCNs_topic-Overview_of_VCNs_and_Subnets.htm#Overview)
  - Réseau virtuel infonuagique
  - Un VCN est un réseau privé virtuel que vous configurez dans les centres de données Oracle. Il ressemble beaucoup à un
réseau traditionnel, avec des règles de pare-feu et des types de passerelles de communication spécifiques.
- [Vulnerability Scanning Service](https://www.oracle.com/ca-fr/security/cloud-security/vulnerability-scanning-service/)

- Zone démilitarisée (DMZ en anglais)

  Sous-réseau qui contient un pare-feu et qui ajoute une couche de sécurité au réseau.
