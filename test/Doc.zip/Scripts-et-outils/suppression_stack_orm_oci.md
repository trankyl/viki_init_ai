# RAPPORT À LA SUITE DE LA DESTRUCTION DE RESSOURCES PAR LA PILE (*STACK*) ORM DANS ORACLE CLOUD INFRASTRUCTURE

## Table des matières

1. [Introduction](#introduction)
2. [Intrant](#intrant)
3. [Destruction de la pile](#destruction-de-la-pile)
4. [État après destruction](#état-après-destruction)
5. [Autres résultats après destruction](#autres-résultats-après-destruction)
6. [Conclusion](#conclusion)

## Introduction  

  Rapport à la suite de la destruction d'une infrastructure déployée dans Oracle Cloud Infrastructure

## Intrant  

Les intrants à cette activité de destruction sont les suivants :

1. Une (1) pile (*stack*) ORM qui a été utilisée pour déployer une infrastructure de ressources dans Oracle. Cette pile, nommée ```CEI-OCI-Zone-Accueil-20220622```, a été exécutée le ```22 juin 2022```.
2. Un (1) compartiment qui englobe ```cmp-ceiza-03``` et qui contient l'infrastructure de ressources déployées par la pile ORM.  

## Destruction de la pile  

Nous avons supprimé la pile de ressources en lançant un travail Terraform de destruction de la pile ORM ```CEI-OCI-Zone-Accueil-20220622```.  

Voici la procédure de suppression de la pile  ```CEI-OCI-Zone-Accueil-20220622``` :  

1. Ouvrez un navigateur Web et, si vous n'êtes pas encore connecté à la console Oracle Cloud Infrastructure, connectez-vous.
2. Lancez l'URL suivante dans le navigateur Web : [https://cloud.oracle.com/resourcemanager/stacks?region=ca-montreal-1](https://cloud.oracle.com/resourcemanager/stacks?region=ca-montreal-1).  

### Écran 1

![pile_dans_compartiment](../images/pile_dans_compartiment.jpg)
3. À l'extrême gauche, dans la liste déroulante ```Compartiment``` , sélectionner le compartiment que vous désirez supprimer. Dans notre cas ce sera ```cmp-ceiza-01```  

Dans la partie centrale de la page Web, la liste des piles du compartiment sélectionné s'actualise.  
4. Dans la liste de piles, cliquer sur la pile ```CEI-OCI-ZA-Nov-2023```.  

Une nouvelle page Web s'affiche.

### Écran 2


![pile_pour_cmp_ceiza_01.png](../images/bouton_detruire_pile.jpg)



5. Cliquer sur le bouton ```Détruire```.

Une fenêtre modale ```Détruire``` s'affiche avec le nom du prochain travail de destruction.  

### Écran 3

![boite_dialogue_destroy.png](../images/DS_Ecran3.png)

5. Cliquer sur le bouton ```Destroy``` dans la fenêtre modale.  

Une nouvelle page Web, comportant les informations sur le travail de destruction, s'affiche.


### Écran 4

![travail_destruction_accepte.png](../images/DS_Ecran4.png)

Par défaut, le travail s'affiche avec le statut : ```Accepted```.

Attendre quelques secondes que le système démarre le travail.

Une fois le travail démarré, le système actualisera le statut du travail.

### Écran 5

![travail_destruction_en_progression.png](../images/DS_Ecran5.png)

Attendre la progression du travail de destruction jusqu'à la fin.

Une fois le travail de destruction terminé, le statut du travail va passer à : ![state_destroy_job_succeeded.png](../images/DS_Ecran51.png)  

## État après destruction  

À la suite du travail de destruction, il est possible d'obtenir un état du compartiment après destruction.  

Pour ce faire, nous avons exécuté la requête suivante dans Oracle Search Service :

  ```query all resources sorted by timeCreated desc```

, afin d'avoir la liste de toutes les ressources déployées le 22 juin 2022.  

### Écran 6

![liste_ressource_apres_destruction.png](../images/DS_Ecran6.png)

Pour les ressources non supprimées, on y trouve deux clés et un coffre à secrets.  

## Autres résultats après destruction  

En réalisant d’autres recherches manuelles, on trouve les ressources suivantes après suppression.  

- DRG

La passerelle de routage dynamique (*Dynamic Routing Gateway, DRG*) suivante, dans cmp-ceiza-03, n'a pas été supprimée.

### Écran 7

![drg.png](../images/DS_Ecran7.png)

- Tables de routage autogénérées

Les tables de routages suivantes n'ont pas été supprimées.

### Écran 8

![table_routage_autogenere.png](../images/DS_Ecran8.JPG)

- Compartiment cmp-sejou-001

Le sous-compartiment suivant, dans cmp-ceiza-03, n'a pas été supprimé.

### Écran 9

![cmp_sejou_001.png](../images/DS_Ecran9.png)

## Conclusion  

Après suppression :

- Des ressources dans le compartiment cmp-ceiza-03 et root (des *policies*) ont été supprimées immédiatement.  

À l’exception de :

- 1 passerelle de routage dynamique (DRG)
- Des tables de routage autogénérées
- 1 coffre à secrets (planifié pour suppression le 04 août 2022, par le système)
- 2 clés (planifiées pour suppression ultérieure par le système)
- 1 sous-compartiment cmp-sejou-001
