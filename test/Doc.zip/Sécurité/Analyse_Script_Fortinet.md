# Analyse du script Fortigate

Le script de déploiement et configuration du pare-feu Fortigate est défini dans le module network/fortigate et se compose des fichiers suivants : 
-   compute.tf
-   data_sources.tf
-   locals.tf
-   marketplace.tf
-   network.tf
-   output.tf
-   variables.tf

## compute.tf :
Le script fonctionne de la manière suivante :

- 1.    Création des deux instances de pare-feu 'oci_core_instance' dans la ressource 'firewall-vms' en déterminant le nombre d'instances à travers la valeur de 'count'. Les instances sont crées dans le compartiment spécifié par 'compartment_id'.
- 2.    Création du VNIC (Virtual Network Interface Card) pour chaque instance du pare-feu dans la section create_vnic_details. La VNIC est associée à un sous-réseau spécifié par subnet_id, et diverses adresses IP privées sont configurées pour différentes interfaces du pare-feu.
- 3.    Les détails de la source de l'image utilisée pour l'instance de pare-feu sont spécifiés dans 'source_details'.
- 4.    Les options de lancement de l'instance ainsi que le type de réseau sont définies dans 'launch_options'.
- 5.    Les métadonnées de l'instance de pare-feu sont fournies sous forme de paires clé-valeur (Clés SSH autorisées, Fichiers de licence, les adresses IP, etc.)
- 6.    Les ressources oci_core_vnic_attachment font en sorte d'attacher des VNIC aux instances de pare-feu les VNIC sont attachées aux sous-réseaux définis et aux instances de pare-feu correspondantes.
- 7.    Des adresses IP publiques et privées sont ajoutés aux interfaces privées et publiques du pare-feu via 'oci_core_private_ip' et 'oci_core_public_ip'.

## data_sources.tf :

Ce script récupère des informations sur les domaines de disponibilité, les domaines de défaillance, les compartiments de réseau, les sous-réseaux, les attachements VNIC et les VCN à l'aide de diverses sources de données OCI, en préparation du provisionnement des ressources avec Terraform.

1. Get availability domains : 

```
   data "oci_identity_availability_domains" "ads" {
     compartment_id = var.tenancy_ocid
   }
```
Cette section récupère les domaines de disponibilité (AD) dans le compartiment spécifié. Elle utilise la source de données `oci_identity_availability_domains` et affecte le résultat à la variable `ads`.

2. Get Fault Domains :

```
   data "oci_identity_fault_domains" "fd" {
     compartment_id      = var.tenancy_ocid
     availability_domain = data.oci_identity_availability_domains.ads.availability_domains[0].name
   }
```
Cette section récupère les domaines de défaillance (FD) dans le compartiment et le domaine de disponibilité spécifiés. Elle utilise la source de données `oci_identity_fault_domains` et spécifie l'ID du compartiment et le domaine de disponibilité obtenus à l'étape précédente.

3. Nom du compartiment réseau

```
   data "oci_identity_compartment" "network_compartment" {
     id = var.network_compartment
   }
```

Cette section récupère le nom du compartiment du réseau. Elle utilise la source de données `oci_identity_compartment` et spécifie l'identifiant du compartiment obtenu à partir de la variable `var.network_compartment`.

4. Données du sous-réseau DMZ

```
   data "oci_core_subnets" "dmz_vcn_subnets_mgmt" {
     compartment_id = var.network_compartment
     filter {
       name   = "display_name"
       values = ["${local.dmz_subnet_names[2]}"]
     }
   }
```
Cette section récupère les données du sous-réseau de gestion dans le VCN (Virtual Cloud Network) de la DMZ. Elle utilise la source de données `oci_core_subnets`, spécifie l'ID du compartiment et filtre les sous-réseaux en fonction de leur display name.

Des sections similaires existent pour les sous-réseaux outdoor, indoor et HA (High Availability), chacune récupérant les données de son sous-réseau respectif.

4. Attachments VNIC :

```
   data "oci_core_vnic_attachments" "outdoor_attachments" {
     compartment_id = var.network_compartment
     instance_id    = oci_core_instance.firewall-vms.0.id
     filter {
       name   = "subnet_id"
       values = [data.oci_core_subnets.dmz_vcn_subnets_outdoor.subnets.0.id]
     }
     depends_on = [
       oci_core_vnic_attachment.outdoor_vnic_attachment,
     ]
   }
```

Cette section récupère les "attachments" VNIC (Virtual Network Interface Card) en fonction du sous-réseau extérieur. Elle utilise la source de données `oci_core_vnic_attachments`, spécifie l'ID du compartiment, l'ID de l'instance, et filtre en fonction de l'ID du sous-réseau.

Une section similaire existe pour le sous-réseau indoor.

5. VCN Data

```
   data "oci_core_vcn" "spokes" {
     for_each = var.spoke_vcns
     vcn_id   = each.value
     depends_on = [
       oci_core_drg_attachment.spoke_drg_attachments
     ]
   }
```
Cette section récupère les données pour les VCNS (Virtual Cloud Networks). Elle utilise la source de données `oci_core_vcn`, boucle sur la variable `var.spoke_vcns` (qui contient les ID des VCN), et récupère les données pour chaque VCN.

## locals.tf :

Ce script définit des variables locales à l'aide du bloc locals de Terraform.

1. Nom du VCN DMZ et noms des sous-réseaux :

```
   dmz_subnet_names = ["snetr-vcn-cmp-conne-publ-cam1-001", "snetr-vcn-cmp-conne-prive-cam1-001", "snetr-vcn-cmp-conne-mgmt-cam1-001", "snetr-vcn-cmp-conne-ha-cam1-001", "snetr-vcn-cmp-conne-diag-cam1-001"]
   dmz_vcn_name = "vcn-cmp-conne-conce-cam1-001"
```
Cette section définit les noms du VCN DMZ et de ses sous-réseaux associés. La liste `dmz_subnet_names` contient les noms de cinq sous-réseaux : outdoor, indoor, mgmt (gestion), ha (haute disponibilité), et diag (diagnostics). La variable `dmz_vcn_name` représente le nom du VCN de la DMZ.

2. Utilisation d'un réseau existant : 

```
   use_existing_network = true
```

Cette section définit une variable booléenne use_existing_network qui vaut true. Elle est utilisée pour indiquer si un réseau existant sera utilisé.

3. Marketplace :

```
   mp_subscription_enabled  = var.mp_subscription_enabled ? 1 : 0
   listing_id               = var.mp_listing_id
   listing_resource_id      = var.mp_listing_resource_id
   listing_resource_version = var.mp_listing_resource_version
   is_flex_shape            = var.vm_compute_shape == "VM.Standard.E3.Flex" ? [var.vm_flex_shape_ocpus] : []
```

Cette section définit les variables relatives au marketplace. 
   - `mp_subscription_enabled` est un flag qui vaut `1` si `var.mp_subscription_enabled` est `true`, et `0` sinon.
   - `listing_id`, `listing_resource_id`, et `listing_resource_version` représentent les ID et les versions de la liste de la place de marché et de ses ressources associées.
   - `is_flex_shape` est une liste vide si `var.vm_compute_shape` n'est pas "VM.Standard.E3.Flex". Si elle correspond, elle contient un seul élément `var.vm_flex_shape_ocpus`.


## marketplace.tf :
Ce script implique d'interagir avec l'Oracle Cloud Infrastructure (OCI) marketplace pour s'abonner et récupérer des abonnements d'images. 

1. Image Agreement

```
   resource "oci_core_app_catalog_listing_resource_version_agreement" "mp_image_agreement" {
     count                      = local.mp_subscription_enabled
     listing_id                 = local.listing_id
     listing_resource_version   = local.listing_resource_version
   }
```
Cette section crée une ressource de type `oci_core_app_catalog_listing_resource_version_agreement` pour obtenir l'image agreement. Elle sera exécutée si `local.mp_subscription_enabled` est vrai. Les variables `listing_id` et `listing_resource_version` sont définies en utilisant des variables locales.

2. Accepter les conditions et s'abonner à l'image

```
   resource "oci_core_app_catalog_subscription" "mp_image_subscription" {
     count                      = local.mp_subscription_enabled
     compartment_id             = var.network_compartment
     eula_link                  = oci_core_app_catalog_listing_resource_version_agreement.mp_image_agreement[0].eula_link
     listing_id                 = oci_core_app_catalog_listing_resource_version_agreement.mp_image_agreement[0].listing_id
     listing_resource_version   = oci_core_app_catalog_listing_resource_version_agreement.mp_image_agreement[0].listing_resource_version
     oracle_terms_of_use_link   = oci_core_app_catalog_listing_resource_version_agreement.mp_image_agreement[0].oracle_terms_of_use_link
     signature                  = oci_core_app_catalog_listing_resource_version_agreement.mp_image_agreement[0].signature
     time_retrieved             = oci_core_app_catalog_listing_resource_version_agreement.mp_image_agreement[0].time_retrieved

     timeouts {
       create = "20m"
     }
   }
   ```

Cette section crée une ressource de type `oci_core_app_catalog_subscription` pour accepter les termes et s'abonner à l'image. Elle sera exécutée si `local.mp_subscription_enabled` est vrai. Elle spécifie l'ID du compartiment, les détails de l'agreement récupéré depuis `oci_core_app_catalog_listing_resource_version_agreement`, et définit un timeout pour la création de la ressource.

3. Abonnement aux images "Partner"

```
   data "oci_core_app_catalog_subscriptions" "mp_image_subscription" {
     count                      = local.mp_subscription_enabled
     compartment_id             = var.network_compartment
     listing_id                 = local.listing_id

     filter {
       name   = "listing_resource_version"
       values = [local.listing_resource_version]
     }
   }
```

 Cette section récupère les données en utilisant la source de données `oci_core_app_catalog_subscriptions`. Elle sera exécutée si `local.mp_subscription_enabled` est vrai. Elle spécifie l'ID du compartiment, l'ID de la liste et applique un filtre pour récupérer l'abonnement à l'image spécifique basé sur la version de la ressource de la liste.

## network.tf :

1. **Créer la table de routage ingress du VCN sur le Hub VCN:**
   - Cette section crée une table de routage dans le compartiment et le réseau virtuel en nuage (VCN) spécifiés pour gérer le trafic entrant.
   - Elle inclut une règle de routage qui achemine tout le trafic (0.0.0.0/0) vers une entité réseau spécifique (IP privée OCI) au sein du VCN.

2. **Attacher la DRG au VCN du hub:**
   - Cette section attache une passerelle de routage dynamique (DRG) au VCN du hub.
   - Elle spécifie l'ID de la DRG, un display name et l'ID de la table de routage du DRG pour l'attachement.
   - Le bloc `network_details` définit l'ID du VCN, le type ("VCN"), et l'ID de la table de routage d'entrée du VCN créée précédemment.

3. **Attacher DRG aux VCNs Spoke :** (Attacher un DRG à des VCNs parlés)
   - Cette section attache le même DRG à plusieurs VCNs spoke.
   - Elle utilise une boucle (`for_each`) pour itérer sur la variable `var.spoke_vcns`, qui contient un mapping d'ID des VCNs des spokes.
   - L'ID du DRG, l'ID du VCN, le display name et l'ID de la table de routage du DRG sont spécifiés pour chaque attachement.

4. **Créer une table de routage du pare-feu vers le DRG:**
   - Cette section crée une table de routage DRG pour acheminer le trafic du pare-feu vers le DRG.
   - Elle spécifie l'ID du DRG et un nom d'affichage pour la table de routage.
   - La propriété `import_drg_route_distribution_id` fait référence à une distribution de route DRG qui sera définie plus tard dans le script.

5. **Créer une table de routage à partir de la DRG vers le pare-feu :**
   - Cette section crée une table de routage DRG pour acheminer le trafic vers le pare-feu à partir de la DRG.
   - Elle spécifie l'ID de la DRG et un display name pour la table de routage.

6. **Mise à jour de la table de route To Firewall pointant vers le VCN du hub:**
   - Cette section met à jour la table de route DRG "To Firewall" pour diriger tout le trafic (0.0.0.0/0) vers le VCN hub.
   - La propriété `next_hop_drg_attachment_id` spécifie l'ID de l'attachement du DRG du VCN concentrateur.

Globalement, ce script configure le routage du réseau entre le VCN du hub, les VCN des spokes et le DRG dans Oracle Cloud Infrastructure. Il définit les tables de routage, attache le DRG aux VCN et configure les règles de routage pour le flux de trafic.

## Output.tf :

Ce script définit plusieurs valeurs de sortie qui fournissent des informations sur les instances de pare-feu créées.

1. **firewallA_instance_public_ips:**
   - Cette sortie fournit une liste d'adresses IP publiques pour la première instance de firewall (`firewall-vms[0]`).
   - Elle utilise l'attribut `public_ip` de la ressource `oci_core_instance` pour extraire les adresses IP publiques.

2. **firewallA_instance_private_ips:**
   - Cette sortie fournit une liste d'adresses IP privées pour la première instance de firewall (`firewall-vms[0]`).
   - Elle utilise l'attribut `private_ip` de la ressource `oci_core_instance` pour extraire les adresses IP privées.

3. **firewallB_instance_public_ips:**
   - Cette sortie fournit une liste d'adresses IP publiques pour la seconde instance de firewall (`firewall-vms[1]`).
   - Elle utilise l'attribut `public_ip` de la ressource `oci_core_instance` pour extraire les adresses IP publiques.

4. **firewallB_instance_private_ips:**
   - Cette sortie fournit une liste d'adresses IP privées pour la seconde instance de firewall (`firewall-vms[1]`).
   - Elle utilise l'attribut `private_ip` de la ressource `oci_core_instance` pour extraire les adresses IP privées.

5. **firewall_instance_ids:**
   - Cette sortie fournit une liste des identifiants des instances des deux pare-feux.
   - Elle utilise l'attribut `id` de la ressource `oci_core_instance` pour extraire les IDs des instances.
   - Les identifiants d'instance sont spécifiés sous forme de chaînes de caractères dans la liste `value`.

6. **instance_https_urls:**
   - Cette sortie fournit une liste d'URL HTTPS pour accéder à chaque instance de firewall.
   - Elle utilise l'attribut `public_ip` de la ressource `oci_core_instance` pour extraire les adresses IP publiques.
   - La fonction `formatlist` est utilisée pour ajouter "https://" à chaque adresse IP publique de la liste.

7. **instruction_initiale:**
   - Cette sortie fournit les instructions initiales pour la mise en place et la configuration des instances du pare-feu.
   - Elle utilise une multi-line string (heredoc) pour définir les instructions.
   - Les espaces réservés `${oci_core_instance.firewall-vms.0.public_ip}` et `${oci_core_instance.firewall-vms.1.public_ip}` sont remplacés par les adresses IP publiques des instances de pare-feu.

## userdata.tpl

Script de configuration pour le pare-feu FortiGate, il met en place diverses configurations système, interfaces, routage, paramètres du connecteur SDN, paramètres de haute disponibilité (HA), et inclut un fichier de licence s'il est fourni.

1. **Content-Type et MIME-Version:**
   - Ces en-têtes spécifient le type de contenu et la version MIME du message multipartite.

```
Content-Type: text/x-shellscript; charset="us-ascii"
MIME-Version: 1.0
```


2. **config system global:**
   - Cette section définit les configurations globales du système pour le pare-feu, telles que le délai d'attente de l'administrateur, le nom d'hôte, le fuseau horaire et le thème de l'interface graphique.

```
config system global
    set admintimeout 120
    set hostname "${fgt_vm_name}"
    set timezone 12
    set gui-theme mariner
end
```

3. **config system interface:**
   - Cette section définit la configuration de chaque interface du pare-feu.
   - L'exemple montre les configurations pour quatre interfaces : port1 (Management), port2 (Untrust), port3 (Trust), et port4 (HA).
   - Chaque interface est configurée avec des paramètres spécifiques tels que le mode (dhcp/static), les adresses IP, les descriptions, les alias, la taille du MTU et l'accès autorisé.

```
config system interface
    edit port1
        set mode dhcp     
        set allowaccess ping https ssh http fgfm
        set alias mgmt
        set description "Management"
        set mtu-override enable
        set mtu 9000
    next
end
```

4. **config router static:**
   - Cette section définit les configurations de routage statique pour le pare-feu.
   - Elle configure les routes par défaut pour les interfaces port2 (Untrust) et port3 (Trust), ainsi que des routes supplémentaires pour spoke_vcns.
   - Les VCNs et leurs blocs CIDR sont itérés en utilisant l'interpolation de modèle (`%{ for vcnname, vcn in spoke_vcns ~}`) pour configurer dynamiquement les routes.

```
config router static
    edit 1        
        set gateway ${fgt_untrust_gw}
        set device port2
    next
    edit 2
        set dst 134.70.0.0 255.255.0.0
        set gateway ${fgt_trust_gw}
        set device "port3"
    next
%{ for vcnname, vcn in spoke_vcns ~}
    edit 0
        set dst ${vcn.cidr_block}
        set gateway ${fgt_trust_gw}
        set device port3
    next
%{ endfor ~}
end
```

5. **config system sdn-connector:**
   - Cette section configure le connecteur SDN (Software-Defined Networking) pour le pare-feu.
   - Elle spécifie le type comme OCI (Oracle Cloud Infrastructure) et définit divers paramètres tels que l'ID du locataire, l'ID du compartiment, l'utilisation des métadonnées IAM et l'intervalle de mise à jour.à

```
config system sdn-connector
    edit "oci-sdn"
        set type oci
        set status enable
        set ha-status enable
        set tenant-id ${tenancy-ocid}
        set compartment-id ${compute-compartment-ocid}
        set use-metadata-iam enable
        set update-interval 60
    next
end
```

6. **config system ha:**
   - Cette section définit les paramètres de haute disponibilité (HA) pour le pare-feu.
   - Elle configure le cluster HA avec un ID et un nom de groupe, un mode (actif-passif), un dispositif de battement de cœur (port4), un ramassage de session, un état de gestion HA et des paramètres d'interface de gestion.
   - Les paramètres comprennent également la priorité HA, le heartbeat unicast et l'adresse IP de l'homologue HA.

```
config system ha
    set group-id 30
    set group-name "ha-cluster"
    set mode a-p
    set hbdev "port4" 50
    set session-pickup enable
    set session-pickup-connectionless enable
    set ha-mgmt-status enable
    config ha-mgmt-interfaces
        edit 1
            set interface "port1"
            set gateway ${fgt_mgmt_ip_gw}  
        next
    end
    set override disable
    set priority ${fgt_ha_priority}    
    set unicast-hb enable
    set unicast-hb-peerip ${fgt_ha_peer_ip}
end
```

7. **Fichier de licence:**
   - Si un fichier de licence est fourni (`%{ if license_file != "" }`), il est inclus en tant que pièce jointe dans le message multipart.
   - Le contenu du fichier de licence est interpolé avec `${fichier_licence}`.

```
%{ if license_file != "" }
--==OCI==
Content-Type: text/plain; charset="us-ascii"
MIME-Version: 1.0
Content-Transfer-Encoding: 7bit
Content-Disposition: attachment; filename="license"

${license_file}

%{ endif }
```
