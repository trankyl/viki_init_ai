# Historique des améliorations et des versions


| Version | Date    | Description                                        |
|:--------|:--------|:---------------------------------------------------|
| v2.0    | 12-2022 | Version stable actuelle, changement d'architecture |
| v1.0    | 08-2022 | Version initiale                                   |
