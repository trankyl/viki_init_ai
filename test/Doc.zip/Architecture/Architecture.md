# Architecture

## Sommaire

- [Compartiments réseaux et sous-réseaux](#compartiments-vcns-et-sous-réseaux)
- [Réseautique](#réseautique)
- [Routage](#routage)
- [Périmètre et pare-feux](#périmètre-et-pare-feux)

## Description de l'architecture

   La solution de notre zone d'accueil est basée sur une topologie en étoile (*Hub and Spoke*). Cette architecture utilise une DRG, [Passerelle de routage dynamique](https://docs.oracle.com/fr-fr/iaas/Content/Network/Tasks/managingDRGs.htm), comme un routeur virtuel pour permettre de relier des réseaux dans le nuage, des réseaux dans différentes régions et des réseaux sur site (*on-premise*) au réseau du nuage.

### Diagramme typique d'une architecture en étoile avec une DRG (1)

   ![ARC_HP_DRG](../images/ARC_HP_DRG.png)

   (1) Source : site Web d'Oracle

### Compartiments VCNs et sous réseaux

   Le diagramme [ci-dessous](#compartiments-réseaux-et-sous-réseaux) illustre comment les différents réseaux sont connectés à la DRG pour produire une topologie en étoile. Cette architecture est représentée par trois sections logiques composées de compartiments.

- Section **Plateforme**
  - Cette section est composée de deux compartiments
    - Compartiment de connectivité
    - Compartiment de sécurité et de journalisation
- Section **Corporative**
  - Cette section est composée de deux compartiments
    - Compartiment de production
    - Compartiment de non-production
- Sections **Carrés de sable** et **Zone non classifiée**
  - Ces sections sont composées de deux compartiments
    - Compartiment de non classifié
    - Compartiment de carrés de sable

   En résumé, la zone d'accueil est composée de six compartiments et de neuf [réseaux](#routage) reliés par des attaches à une DRG qui route le trafic.

### Compartiments réseaux et sous-réseaux

   ![Arc_CMP_VCN_SReseaux](../images/Arc_CMP_VCN_SReseaux.png)

## Réseautique

Dans le cadre de la stratégie élaborée par le Programme de consolidation des centres de traitement informatique (PCCTI), en collaboration avec le Centre d’expertise en infonuagique (CEI), et afin de limiter les impacts de la migration infonuagique sur l’espace d’adressage IP du RITM, des plages d’adresses ont été réservées.

Dans le document [Plan adressage](../Réseautique/plan_adressage.md) , vous trouverez la liste des [plages d'adresses réservées](../Réseautique/plan_adressage.md#planification-réseautique) , le [plan d'adressage par réseau/sous-réseau](../Réseautique/plan_adressage.md#réseaux-et-sous-réseaux) ainsi que la vue globale réseautique ci-dessous , suite à un [déploiement](../Déploiement/Deploi_Script.md) en utilisant les paramètres par défaut.


![Arc_CMP_VCN_SReseaux](../images/Arc_Reseautique.png)


## Routage

   Dans cette architecture en étoile, la DRG centralise la communication entre les réseaux inter VCN ainsi que la communication entre les VCN et le site sur place (*on-premise*).

  ![Arc_Routage](../images/Arc_Routage.png)

   Voir le document [Routage](../Réseautique/routage.md) pour plus de détails.

## Périmètre et pare-feux

  Pour la configuration des pare-feux, Oracle prend en charge plusieurs partenaires, dont le FortiGate de Fortinet. Lors de l'installation de la zone d'accueil, le script vous donne le choix de configurer ou non un pare-feu, voir le document [Déploiement du script](../Déploiement/Deploi_Script.md). Par conséquent, le choix du partenaire de pare-feux peut se faire ultérieurement.

  À noter que le script ne déploie que les instances de FortiGate par défaut; pour le reste des partenaires, une configuration additionnelle est nécessaire.

  Les deux instances de FortiGate sont configurées en haute disponibilité en mode actif-passif (*Active-Passive*).

  Si vous choisissez de configurer le pare-feu lors de l'installation, le script déploie deux instances *Fortinet* et crée quatre sous-réseaux dans la VCN de connectivité (DMZ).

  Chaque partenaire déploie un nombre de sous-réseaux.

  | Partenaire sécurité | Nombre de sous-réseaux |
  |---------------------|------------------------|
  | Check Point         |          2             |
  | Cisco               |          5             |
  | Fortinet            |          4             |
  | Palo Alto Networks  |          4             |

  Pour les pare-feux de FortiGate, le script déploie les quatre sous-réseaux suivants :

- Sous-réseaux de gestion (management) (port 1)
- Sous-réseaux publics (public) (port 2)
- Sous-réseaux privés (port 3)
- Sous-réseaux HA (port 4)

   ![Arc_Perimetre_PareFeux](../images/Arc_Perimetre_PareFeux.png)

[Retour à la page d'accueil](../../ReadMe.md)
