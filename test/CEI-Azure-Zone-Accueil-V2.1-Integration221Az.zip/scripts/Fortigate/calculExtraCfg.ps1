# ----------------------------------------------------------------------------------
#  Ce code est la propriété du MCN. S.V.P. vous référer au fichier Licence.md  pour les clauses légales 
# ----------------------------------------------------------------------------------
# dans config.ini
# platform-hub-virtualNetwork=10.84.0.0/16
# platform-gestion-virtualNetwork=10.73.128.0/17
# platform-identite-virtualNetwork=10.73.0.0/17
# charges-virtualNetwork=10.77.0.0/16
# les commentaires plus bas font la correspondance avec les calcule équivalents dans cei-platform.yml (var-platform-hub-fortigate) et fortigate.bicep


Function calculExtraCfg($cfg)
{
    # param vnetAddressPrefix  <= "vnetAddressPrefix": "$(var-platform-hub-virtualNetwork-ip-prefix)$(var-platform-hub-virtualNetwork-ip-suffix)",
    $vnetAddressPrefix=$cfg."platform-hub-virtualNetwork"

    # var-platform-hub-subnet-nva-ip-prefix: '$(var-platform-hub-virtualNetwork-ip-prefix).4'
    $platform_hub_subnet_nva = ($vnetAddressPrefix.split('.')[0..1] -join '.')+'.4'


    # param subnetExtPrefix <= "subnetExtPrefix": "$(var-platform-hub-subnet-nva-ip-prefix).0/26",
    $subnetExtPrefix = $platform_hub_subnet_nva + '.0/26' 

    # param subnetExtStartAddress <= "$(var-platform-hub-subnet-nva-ip-prefix).4",
    $subnetExtStartAddress = $platform_hub_subnet_nva  + '.4'

    # param subnetIntPrefix <= "$(var-platform-hub-subnet-nva-ip-prefix).64/26",
    $subnetIntPrefix = $platform_hub_subnet_nva + '.64/26'

    # param subnetIntStartAddress string <= "subnetIntStartAddress": "$(var-platform-hub-subnet-nva-ip-prefix).68",
    $subnetIntStartAddress = $platform_hub_subnet_nva + '.68'

    # param subnetMgmtPrefix <= "$(var-platform-hub-subnet-nva-ip-prefix).192/27",
    $subnetMgmtPrefix = $platform_hub_subnet_nva + '.192/27'

    # param subnetMgmtStartAddress <= "subnetMgmtStartAddress": "$(var-platform-hub-subnet-nva-ip-prefix).196",
    $subnetMgmtStartAddress = $platform_hub_subnet_nva + '.196'

    # param subnetHASyncPrefix string <= "subnetHASyncPrefix": "$(var-platform-hub-subnet-nva-ip-prefix).128/26",
    $subnetHASyncPrefix = $platform_hub_subnet_nva + '.128/26'

    # param subnetHASyncStartAddress <= "subnetHASyncStartAddress": "$(var-platform-hub-subnet-nva-ip-prefix).132",
    $subnetHASyncStartAddress =  $platform_hub_subnet_nva + '.132'

    # param vnetAddressSpokeGestPrefix <= "vnetAddressSpokeGestPrefix": "$(var-platform-gestion-virtualNetwork-ip-prefix)$(var-platform-gestion-virtualNetwork-ip-suffix)",
    $vnetAddressSpokeGestPrefix = $cfg.'platform-gestion-virtualNetwork'

    # param vnetAddressSpokeIdentPrefix <= "vnetAddressSpokeIdentPrefix": "$(var-platform-identite-virtualNetwork-ip-prefix)$(var-platform-identite-virtualNetwork-ip-suffix)",
    $vnetAddressSpokeIdentPrefix = $cfg.'platform-identite-virtualNetwork'

    # param vnetAddressLzSpokesPrefix <= "vnetAddressLzSpokesPrefix": "$(var-charges-virtualNetwork-ip-prefix)$(var-charges-virtualNetwork-ip-suffix)",
    $vnetAddressLzSpokesPrefix = $cfg.'charges-virtualNetwork'

    # var snExtIPArray = split(subnetExtPrefix, '.')
    # var snExtIPArray2ndString = string(snExtIPArray[3])
    # var snExtIPArray2nd = split(snExtIPArray2ndString, '/')
    # var snExtIPArray3 = string((int(snExtIPArray2nd[0]) + 1))
    # var snExtIPArray2 = string(int(snExtIPArray[2]))
    # var snExtIPArray1 = string(int(snExtIPArray[1]))
    # var snExtIPArray0 = string(int(snExtIPArray[0]))
    # var snExtIPStartAddress = split(subnetExtStartAddress, '.')
    # =>
    # var snExtGatewayIP = '${snExtIPArray0}.${snExtIPArray1}.${snExtIPArray2}.${snExtIPArray3}'
    # var snExtCIDRmask = string(int(snExtIPArray2nd[1]))
    # var snExtIPfga = '${snExtIPArray0}.${snExtIPArray1}.${snExtIPArray2}.${int(snExtIPStartAddress[3])}'
    # var snExtIPfgb = '${snExtIPArray0}.${snExtIPArray1}.${snExtIPArray2}.${(int(snExtIPStartAddress[3]) + 1)}'

    $snExtGatewayIP = ($subnetExtPrefix.split('.')[0..2] -join('.')) + '.' + [string]([int](($subnetExtPrefix.split('.')[3]).split('/')[0])+1)
    $snExtCIDRmask = ($subnetExtPrefix.split('.')[3]).split('/')[1]
    $snExtIPfga = ($subnetExtStartAddress.split('.')[0..2] -join('.')) + '.' + [string]([int]($subnetExtStartAddress.split('.')[3])+0)
    $snExtIPfgb = ($subnetExtStartAddress.split('.')[0..2] -join('.')) + '.' + [string]([int]($subnetExtStartAddress.split('.')[3])+1)

    # var snIntIPArray = split(subnetIntPrefix, '.')
    # var snIntIPArray2ndString = string(snIntIPArray[3])
    # var snIntIPArray2nd = split(snIntIPArray2ndString, '/')
    # var snIntIPArray3 = string((int(snIntIPArray2nd[0]) + 1))
    # var snIntIPArray2 = string(int(snIntIPArray[2]))
    # var snIntIPArray1 = string(int(snIntIPArray[1]))
    # var snIntIPArray0 = string(int(snIntIPArray[0]))
    # var snIntIPStartAddress = split(subnetIntStartAddress, '.')
    # var snIntIPlb = '${snIntIPArray0}.${snIntIPArray1}.${snIntIPArray2}.${int(snIntIPStartAddress[3])}'
    # =>
    # var snIntGatewayIP = '${snIntIPArray0}.${snIntIPArray1}.${snIntIPArray2}.${snIntIPArray3}'
    # var snIntCIDRmask = string(int(snIntIPArray2nd[1]))
    # var snIntIPfga = '${snIntIPArray0}.${snIntIPArray1}.${snIntIPArray2}.${(int(snIntIPStartAddress[3]) + 1)}'
    # var snIntIPfgb = '${snIntIPArray0}.${snIntIPArray1}.${snIntIPArray2}.${(int(snIntIPStartAddress[3]) + 2)}'

    $snIntGatewayIP = ($subnetIntPrefix.split('.')[0..2] -join('.')) + '.' + [string]([int](($subnetIntPrefix.split('.')[3]).split('/')[0])+1)
    $snIntCIDRmask = ($subnetIntPrefix.split('.')[3]).split('/')[1]
    $snIntIPfga = ($subnetIntStartAddress.split('.')[0..2] -join('.')) + '.' + [string]([int]($subnetIntStartAddress.split('.')[3])+1)
    $snIntIPfgb = ($subnetIntStartAddress.split('.')[0..2] -join('.')) + '.' + [string]([int]($subnetIntStartAddress.split('.')[3])+2)

    # var snMgmtIPArray = split(subnetMgmtPrefix, '.')
    # var snMgmtIPArray2ndString = string(snMgmtIPArray[3])
    # var snMgmtIPArray2nd = split(snMgmtIPArray2ndString, '/')
    # var snMgmtIPArray3 = string((int(snMgmtIPArray2nd[0]) + 1))
    # var snMgmtIPArray2 = string(int(snMgmtIPArray[2]))
    # var snMgmtIPArray1 = string(int(snMgmtIPArray[1]))
    # var snMgmtIPArray0 = string(int(snMgmtIPArray[0]))
    # var snMgmtIPStartAddress = split(subnetMgmtStartAddress, '.')
    # =>
    # var snMgmtGatewayIP = '${snMgmtIPArray0}.${snMgmtIPArray1}.${snMgmtIPArray2}.${snMgmtIPArray3}'
    # var snMgmtCIDRmask = string(int(snMgmtIPArray2nd[1]))
    # var snMgmtIPfga = '${snMgmtIPArray0}.${snMgmtIPArray1}.${snMgmtIPArray2}.${int(snMgmtIPStartAddress[3])}'
    # var snMgmtIPfgb = '${snMgmtIPArray0}.${snMgmtIPArray1}.${snMgmtIPArray2}.${(int(snMgmtIPStartAddress[3]) + 1)}'

    $snMgmtGatewayIP = ($subnetMgmtPrefix.split('.')[0..2] -join('.')) + '.' + [string]([int](($subnetMgmtPrefix.split('.')[3]).split('/')[0])+1)
    $snMgmtCIDRmask = ($subnetMgmtPrefix.split('.')[3]).split('/')[1]
    $snMgmtIPfga = ($subnetMgmtStartAddress.split('.')[0..2] -join('.')) + '.' + [string]([int]($subnetMgmtStartAddress.split('.')[3])+0)
    $snMgmtIPfgb = ($subnetMgmtStartAddress.split('.')[0..2] -join('.')) + '.' + [string]([int]($subnetMgmtStartAddress.split('.')[3])+1)

    # var snHASyncIPArray = split(subnetHASyncPrefix, '.')
    # var snHASyncIPArray2ndString = string(snHASyncIPArray[3])
    # var snHASyncIPArray2nd = split(snHASyncIPArray2ndString, '/')
    # var snHASyncIPArray2 = string(int(snHASyncIPArray[2]))
    # var snHASyncIPArray1 = string(int(snHASyncIPArray[1]))
    # var snHASyncIPArray0 = string(int(snHASyncIPArray[0]))
    # var snHASyncIPStartAddress = split(subnetHASyncStartAddress, '.')
    # =>
    # var snHASyncIPfga = '${snHASyncIPArray0}.${snHASyncIPArray1}.${snHASyncIPArray2}.${int(snHASyncIPStartAddress[3])}'
    # var snHASyncIPfgb = '${snHASyncIPArray0}.${snHASyncIPArray1}.${snHASyncIPArray2}.${(int(snHASyncIPStartAddress[3]) + 1)}'
    # var snHASyncCIDRmask = string(int(snHASyncIPArray2nd[1]))

    $snHASyncIPfga = ($subnetHASyncStartAddress.split('.')[0..2] -join('.')) + '.' + [string]([int]($subnetHASyncStartAddress.split('.')[3])+0)
    $snHASyncIPfgb = ($subnetHASyncStartAddress.split('.')[0..2] -join('.')) + '.' + [string]([int]($subnetHASyncStartAddress.split('.')[3])+1)
    $snHASyncCIDRmask = ($subnetHASyncPrefix.split('.')[3]).split('/')[1]

    $extraCfg=@{
        'vnetAddressPrefix' = $vnetAddressPrefix
        'vnetAddressSpokeGestPrefix' = $vnetAddressSpokeGestPrefix
        'vnetAddressSpokeIdentPrefix' =  $vnetAddressSpokeIdentPrefix
        'vnetAddressLzSpokesPrefix' = $vnetAddressLzSpokesPrefix
        'snExtGatewayIP' = $snExtGatewayIP
        'snExtCIDRmask' = $snExtCIDRmask
        'snExtIPfga' = $snExtIPfga
        'snExtIPfgb' = $snExtIPfgb
        'snIntGatewayIP' = $snIntGatewayIP
        'snIntIPfga' = $snIntIPfga
        'snIntIPfgb' = $snIntIPfgb
        'snIntCIDRmask' = $snIntCIDRmask
        'snMgmtGatewayIP' = $snMgmtGatewayIP
        'snMgmtIPfga' = $snMgmtIPfga
        'snMgmtIPfgb' = $snMgmtIPfgb
        'snMgmtCIDRmask' = $snMgmtCIDRmask
        'snHASyncIPfga' = $snHASyncIPfga
        'snHASyncIPfgb' = $snHASyncIPfgb
        'snHASyncCIDRmask' = $snHASyncCIDRmask
        'fmgCustomData' = ''
        'fortiGateAdditionalCustomData' = ''
    }
    return $extraCfg
}

