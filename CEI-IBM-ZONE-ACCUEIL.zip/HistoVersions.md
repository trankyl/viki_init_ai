# Historique des améliorations et des versions

| Version | Date       | Description                                           |
|---------|------------|-------------------------------------------------------|
| v1.0    | 31-08-2022 | Version initiale                                      |
| v2.0    | 13-01-2023 | Version stable actuelle, Améliorations d’architecture |
