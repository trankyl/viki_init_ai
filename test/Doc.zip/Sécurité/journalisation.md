# JOURNALISATION

## Table des matières

- Aperçu général sur la journalisation dans Oracle Cloud Infrastructure

  - [Aperçu sur la journalisation dans Oracle Cloud Infrastructure](#aperçu-sur-la-journalisation-dans-oracle-cloud-infrastructure)
  - [Introduction](#introduction)
  - [Étapes du processus de la journalisation OCI](#étapes-du-processus-de-la-journalisation-oci)
  - [Collecter et gérer](#collecter-et-gérer)
  - [Rechercher et analyser](#rechercher-et-analyser)
  - [Prendre action](#prendre-action)
  - [Flux de données](#flux-de-données)
  - [Sources des données](#sources-des-données)  
  - [Types de données](#types-de-données)
  - [Manipulation des données](#manipulation-des-données)

- Description sommaire du module journalisation dans l'OCI à travers la console

  - [Le menu Observation et gestion](#le-menu-observation-et-gestion)
  - [Recherche](#recherche)  
  - [Journaux](#journaux)  
  - [Groupe de journaux](#groupes-de-journaux)
  - [Agent de configuration](#agent-de-configuration)
  - [Connecteurs de service](#connecteurs-de-service)

- La journalisation et la zone d'accueil

  - [Sélectionner le "connecteur de service"](#sélectionner-le-connecteur-de-service)
  - [Vérification des connecteurs de service](#vérification-des-connecteurs-de-service)
  - [Vérification des groupes de journaux](#vérification-des-groupes-de-journaux)  
  
- Activation des services connecteurs et les journaux analytiques

  - [Activer le journal analytique pour le locataire dans la région](#activer-le-journal-analytique-pour-le-locataire-dans-la-région)
  - [Créer des groupes de journaux dans Analytics Cloud](#créer-des-groupes-de-journaux-dans-analytics-cloud)
  - [Activer les connecteurs de service](#activer-les-connecteurs-de-service)  
  - [Arrimer les groupes de journaux de OCI Logging et ceux de Logging Analytics](#arrimer-les-groupes-de-journaux-de-oci-logging-et-ceux-de-logging-analytics)  
  - [Veiller à ce que tous les journaux des sous-réseaux soient activés et utilisent le même groupe de journaux](#veiller-à-ce-que-tous-les-journaux-des-sous-réseaux-soient-activés-et-utilisent-le-même-groupe-de-journaux)
  - [Accéder aux tableaux de bord de Logging Analytics](#accéder-aux-tableaux-de-bord-de-logging-analytics)
  - [Effectuer des analystes avec les fonctions en IA du Log Explorer](#effectuer-des-analystes-avec-les-fonctions-en-ia-du-log-explorer)
  - [Voir les problèmes potentiels et les tendances](#voir-les-problèmes-potentiels-et-les-tendances)

## Aperçu sur la journalisation dans Oracle Cloud Infrastructure

## Introduction

  La zone d'accueil pour Oracle active automatiquement les journaux de flux VCN pour tous les sous-réseaux provisionnés. Les journaux de flux sont utiles pour détecter les problèmes de flux de paquets sur le réseau. La zone d'accueil Oracle active également la journalisation du stockage d'objets (*Object Storage*) pour les opérations d'écriture.

  Une autre source de journal importante est le journal d'audit OCI, car il enregistre toutes les demandes adressées aux API du plan de contrôle des services OCI. Le journal d'audit est automatiquement activé par OCI.

  La zone d'accueil canalise les journaux de flux VCN et les journaux d'audit par le « Service Connector Hub (SCH) » vers *Object Storage* (par défaut), fournissant ainsi une vue consolidée des données de journalisation et les rendant plus facilement consommables par les systèmes des clients.

   « OCI Logging » d'Oracle est une plateforme entièrement gérée et native du nuage. Elle simplifie l'ingestion, la gestion et l'analyse des journaux, tels que l'audit, l'infrastructure, la base de données et les applications, qui sont nécessaires pour la conformité de la sécurité. Le service rassemble tous vos journaux dans une seule vue. Il vous permet d'ingérer et de gérer de manière transparente les journaux générés par vos ressources et vos applications.
  
  Vous pouvez utiliser le puissant moteur de [recherche de journaux](#recherche) pour les explorer, rendre chaque ligne de journal exploitable en temps quasi réel et exporter ou archiver vos journaux pour une conservation indéfinie avec la prise en charge de [Service Connector Hub](https://www.oracle.com/devops/).

## Étapes du processus de la journalisation OCI  

Il y a trois étapes dans le processus de journalisation

- Collecter et gérer
- Rechercher et analyser
- Prendre action

   ![Journ_Etapes](../images/Journal/Journ_Etapes.PNG)

## Collecter et gérer

      - Utiliser le logiciel de collecte de données en code source libre ou installer le module d'extension de sortie OCI Logging Analytics pour acheminer les données de journal collectées vers Oracle [Cloud Logging Analytics](https://www.oracle.com/ca-en/manageability/logging-analytics/).
      - Gérer les [journaux avec les groupes de journaux](https://docs.oracle.com/fr-fr/iaas/Content/Logging/Task/managinglogs.htm) pour faciliter la gestion des accès. 
      - Configurer les journaux par un simple clic. 

## Rechercher et analyser

Les groupes de journaux sont des récipients logiques utilisés pour centraliser et gérer les journaux. Les changements aux permissions ainsi que les accès aux groupes de journaux sont audités. Le module de [recherche de journaux](#recherche) vous permet de faire des recherches et d'analyser vos données. Vous pouvez aussi :  

- Définir des autorisations à l'échelle du compartiment et à celle des groupes de journaux.
- Interroger les journaux en utilisant [l'écran de recherche](#recherche).

## Prendre action

On se basant sur des règles, vous pouvez prendre plusieurs actions, par exemple :  

- Intégration de fonctions  
- Notification par plusieurs outils tels que le courriel  

## Flux de données

  ***Écran : Flux de données***

  ![Journ_FluxDonnees](../images/Journal/Journ_FluxDonnees.PNG)

## Sources des données

Il y a deux types de ressources qui produisent des journaux :  

- Services OCI
- Applications personnalisées

## Types de données

Les données des journaux sont de quatre types :

- Audit (lecture, écriture, changements à la configuration, etc.)  
- États des ressources (arrêt, démarrage, suppression, etc.)  
- Journaux (VCN, applications, etc.)  
- Métriques (CPU, latence, etc.)  

## Manipulation des données

  Pour manipuler les données produites par les journaux et obtenir des informations plus approfondies, nous avons besoin d'un [Service Connector Hub ou SCH](https://docs.oracle.com/fr-ca/iaas/Content/connector-hub/overview.htm) pour orchestrer le déplacement de données entre les services OCI ou entre les services OCI et des services tiers.  

## Description sommaire du module journalisation dans l'OCI

### Le menu Observation et gestion

   Le menu "Observation et gestion" dans la console de l'OCI donne accès au module de gestion des journaux.
  
  ***Écran : Menu de journalisation***

![Journ_Menu](../images/Journal/Journ_Menu.PNG)

  Nous allons décrire d’une façon sommaire le contenu des sections de ce module et donner quelques exemples pour illustrer les possibilités pour gérer les journaux. Le but ici n'est pas de former l'utilisateur, mais plutôt de donner un aperçu de ce qui existe avant de montrer, dans la section suivante, ce qui est configuré et ce qui existe dans le script de la zone d'accueil d'Oracle.

  Pour plus d'information, consultez [la documentation d'Oracle pour le service OCI Logging](https://www.oracle.com/ca-fr/devops/logging/).  
  
### Recherche

   Cette section donne accès à la page d'accueil de recherche et permet de rechercher, d'analyser et de visualiser les journaux d'une façon centralisée.
   Elle vous permet de créer des filtres personnalisés : par compartiments, par groupes ou par journaux. Elle vous permet aussi de personnaliser l'affichage selon plusieurs types et de grouper vos données selon plusieurs critères. Pour explorer toutes les possibilités offertes, vous pouvez vous référer à la [documentation d'Oracle](https://www.oracle.com/ca-fr/devops/logging/#rc30p2).

   ![Recherche et analyse](../images/Journal/Journ_RechAnalyse.PNG)

### Journaux

   Cette section vous permet de visualiser tous les journaux par [compartiment](https://docs.oracle.com/fr-fr/iaas/Content/Identity/Tasks/managingcompartments.htm) ou par groupe de journaux.

  Vous pouvez activer votre premier journal de deux façons :

- À partir de « Central management page »;  
- À partir de la page de la ressource elle-même.  

#### Création à partir de la Page centrale de gestion  

   À partir de la page centrale, en choisissant la section "Journaux", vous avez la possibilité de créer un journal de service ou un journal personnalisé.

   ***Écran : Création d'un journal***

  ![Creation_Journal](../images/Journal/Journ_Creation.PNG)

##### Activation d'un journal

En choisissant d'activer un journal de service par exemple, vous avez la possibilité de :  

- Choisir la ressource qui génère le journal  
- Configurer le journal  
- Choisir l'emplacement du journal  
- Définir la rétention du journal  

   ***Écran : Activation d'un journal***

  ![Journ_Activer](../images/Journal/Journ_Activer.PNG)

   ***Écran : Résultat d'activation d'un journal***

   Après l'activation d'un journal, un résumé des informations du journal actif est affiché pour validation.

  ![Journal](../images/Journal/Journ_Journal.PNG)

#### Création à partir de la page de la ressource elle-même

  La deuxième façon d'activer un journal est à partir de la page de la ressource. Sur la page, en choisissant l'option "Journaux" dans le menu de la ressource, une liste de journaux activés et non activés sera affichée au bas de la page. Il suffit de sélectionner le journal et de l'activer avec le bouton "activé", voir l'écran ci-dessous.

##### Écran : Activation d'un journal à partir de la page Ressource

   ![Activer_journal_ressource](../images/Journal/Journ_ActiverRsce.PNG)

   En sélectionnant l'activation, un second écran, voir ci-dessous, vous invite à compléter le reste de l'information.  

##### Écran : Saisir des données de l'activation d'un journal à partir de la page Ressource

   ![Activer_journal_ressource-saisir](../images/Journal/Journ_ActiverRsce01.PNG)

### Groupes de journaux

  Cette section permet de créer les [groupes de journaux](https://docs.oracle.com/fr-fr/iaas/Content/Logging/Task/managinglogs.htm#managinglogs) et de les visualiser par compartiment.  

### Agent de configuration
  
Cette section permet de définir de quelle machine nous collectons les journaux et de spécifier les journaux à collecter.
  
Elle se fait en trois étapes :  

- De quels hôtes souhaitez-vous collecter?  
- Quel journal exact voulez-vous traiter?  
- Quel sera l’emplacement de ces journaux?  

À partir du menu, choisir :  

- "Configuration agent"  
- Créer une configuration d'agent"  

#### Écran : Configuration d'agent

   ![Configuration agent](../images/Journal/Journ_AgentCfg.PNG)

   En cliquant sur 'Créer une configuration d'agent", l'écran suivant s'affiche :

   ***Écran : Saisie des données de la configuration d'agent***

   ![Configuration_agent_Saisir](../images/Journal/Journ_AgentCfg01.PNG)

### Connecteurs de service

Cette section permet de configurer, en temps réel si nécessaire, les actions à entreprendre sur les journaux et leurs entrées. Elle offre une vue globale sur tous les événements et permet d'utiliser des filtres pour trouver des événements particuliers.  

## La journalisation et la zone d'accueil

Cette section décrit comment la journalisation est activée dans la zone d'accueil d'Oracle, comment vérifier la configuration à la fin du déploiement et comment s'assurer que les connecteurs de service sont inactifs.
  
### Sélectionner le connecteur de service

S’assurer que l’option « Service Connector » a été sélectionnée lors de l’exécution du script de la zone d'accueil.
La zone d'accueil crée deux "connecteurs de service" : le premier est dédié à l'audit, le second aux réseaux virtuels infonuagiques (VCN).
À noter : pour éviter de générer des coûts à l'installation, les connecteurs sont installés, mais ne sont pas activés.

  ![ZA Activation de connecteur](../images/Journal/Jour_ZA_Act_Connector.PNG)

### Vérification des connecteurs de service

 Pour s'assurer que les connecteurs de service sont créés, revoir la section "Connecteurs de service" dans le module "Journalisation", voir l'écran ci-dessous.

  ![ZA Vérification des connecteurs](../images/Journal/Journ_ZA_Conn_Verif.PNG)

### Vérification des groupes de journaux

 La section des groupes de journaux listera deux groupes : le premier pour les journaux du flux des VCN, le deuxième pour l'activité en écriture (*Write Access Events*) sur le "stockage d'objets" (*Object Storage*).

 ![ZA Vérification groupe journaux](../images/Journal/Journ_ZA_LogGroupes.PNG)

## Activation des services connecteurs et les journaux analytiques

Attention, la configuration de ces deux services engendrera des coûts puisque ce sont des services payants. Pour obtenir un estimé du coût à défrayer à ce jour, veuillez consulter l'[Estimateur de coût](https://www.oracle.com/ca-fr/cloud/costestimator.html).

 Pour connaître les étapes à suivre à haut niveau en vue d'activer les services connecteurs avec les journaux analytiques, consultez la [création d'un analyseur](https://docs.oracle.com/fr-fr/iaas/logging-analytics/doc/create-parser.html).

### Activer le journal analytique pour le locataire dans la région  

À partir du menu 'Observation et Gestion'

- Cliquer sur "Logging Analytics";  
- Cliquer ensuite sur le bouton "Commencer à utiliser Logging Analytics".  

### Créer des groupes de journaux dans Analytics Cloud

  ![Créer Log groupe de log analytique ](../images/Journal/Journ_LogGroup_LogAnalytique.PNG)

### Activer les connecteurs de service

   ![Activer les services connecteur](../images/Journal/Journ_Active_serviceConnecteur.PNG)
  
### Arrimer les groupes de journaux de OCI Logging et ceux de Logging Analytics  

  ![Arrimer Log Analytique et Log OCI logging](../images/Journal/Journ_Arrimer_LogAnalytique_Logging.PNG)
  
### Veiller à ce que tous les journaux des sous-réseaux soient activés et utilisent le même groupe de journaux

  ![Vérification log des sous réseaux actif](../images/Journal/Journ_Verif_Log_Subnet_Actif.PNG)
  ![Vérification log des sous réseaux actif](../images/Journal/Journ_Verif_Log_Subnet_Actif01.PNG)

### Accéder aux tableaux de bord de Logging Analytics

  ![Vérification log des sous réseaux actif](../images/Journal/Journ_Acceder_Tableau_LogAnalytique.PNG)

### Effectuer des analystes avec les fonctions en IA du Log Explorer  

  ![Vérification log des sous réseaux actif](../images/Journal/Journ_Analyse_LofAnalytique.PNG)  

### Voir les problèmes potentiels et les tendances  

   ![Vérification log des sous réseaux actif](../images/Journal/Journ_Pbme_LogAnalytique.PNG)

## Documentation et ressources

- [OCI Logging](https://www.oracle.com/ca-fr/devops/logging/)
- [Manageability](https://www.oracle.com/manageability/)
- [Oracle Service Connector Hub](https://www.oracle.com/ca-fr/devops/service-connector-hub/)
- [Estimateur de coût](https://www.oracle.com/ca-fr/cloud/costestimator.html)
- [Stockage d'objets (*Object Storage*)](https://www.oracle.com/ca-fr/cloud/storage/object-storage/)

[Retour à la Page d'accueil](../../ReadMe.md)
