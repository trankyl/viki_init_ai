# Les Prérequis

## Sommaire

- [Faire partie du groupe Administrators dans le compte tenant](#faire-partie-du-groupe-administrators-dans-le-compte-tenant)
- [Une paire de clées SSH doit être générée au préalable pour la création des VMs Fortinet](#une-paire-de-clés-ssh-doit-être-générée-au-préalable-pour-la-création-des-vms-fortinet)
- [Un compartiment doit être créé au préalable pour contenir les ressources infonuagiques qui seront créées](#un-compartiment-doit-être-créé-au-préalable-pour-contenir-les-ressources-infonuagiques-qui-seront-créées)
- [Un DRG doit être créé au préalable pour pouvoir établir une communication avec votre infrastructure sur site (on-premise)](#un-drg-doit-être-créé-au-préalable-pour-pouvoir-établir-une-communication-avec-votre-infrastructure-sur-site-on-premise)
- [Planification réseautique](#planification-réseautique)
- [Génération du jeton pour accéder au dépôt de configurations des pare-feux Fortigate](#génération-du-jeton-pour-accéder-au-dépôt-de-configurations-des-pare-feux-fortigate)

Avant de commencer l'installation et la configuration de la zone d'accueil, il y a certains prérequis qui devraient être configurés au préalable.

## Faire partie du groupe Administrators dans le compte tenant

Le groupe 'Administrators' donne accès à l’ensemble des privilèges de gestion du compte OCI (*tenant*). Il peut être préférable de créer un sous-administrateur ayant moins de privilèges.

![alt text](../images/PR_Ecran1.PNG)

## Une paire de clés SSH doit être générée au préalable pour la création des VMs Fortinet

Vous pouvez utiliser [PuTTY Key Generator pour Windows](https://www.oracle.com/webfolder/technetwork/tutorials/obe/cloud/javaservice/JCS/JCS_SSH/create_sshkey.html) pour créer cette paire de clés SSH.   

![administrator](../images/PR_Ecran2.png)   
   

Vous pouvez revoir la [documentation d'Oracle](https://docs.oracle.com/en/cloud/cloud-at-customer/occ-get-started/generate-ssh-key-pair.html) si la génération de clés est pour UNIX ou Linux.   
   
  
      ssh-keygen -t rsa




## Sélection région de déploiement   


Il faudra définir la région dans laquelle seront déployées les ressources qui vont suivre.

![selection_region_deploiement](../images/deploiement/selection_region_deploiement.JPG)   

Dans ce document , nous avons choisi le centre de données de Montréal (ca-montreal-1)

*Nota Bene* : La région ici doit être la même que la région de déploiement de la zone d'accueil.   


## Un compartiment doit être créé au préalable pour contenir les ressources infonuagiques qui seront créées

Pour plus de détails sur la création d'un compartiment, consultez la documentation d'Oracle en anglais [Creating an Oracle Cloud Infrastructure Compartment](https://docs.oracle.com/en/cloud/paas/integration-cloud/oracle-integration-oci/creating-oci-compartment.html).

![Compartiment](../images/PR_Ecran3.png)

## Un DRG doit être créé au préalable pour pouvoir établir une communication avec votre infrastructure sur site on-premise

![DRG](../images/PR_Ecran4.0.png)   

![creation DRG](../images/PR_Ecran4.png)

## Planification réseautique

Dans le cadre de la stratégie élaborée par le Programme de consolidation des centres de traitement informatique (PCCTI), en collaboration avec le Centre d’expertise en infonuagique (CEI), et afin de limiter les impacts de la migration infonuagique sur l’espace d’adressage IP du RITM, les plages d’adresses suivantes ont été réservées. Elles peuvent être utilisées par tous les OP sans crainte de conflits d’adresses avec les autres OP.

10.73.0.0/16    
10.77.0.0/16     
10.79.0.0/16    
10.84.0.0/16  (non utilisée)     
10.86.0.0/16  (non utilisée)     

Dans le cadre de notre déploiement, nous avons utilisé uniquement les trois premiers blocs d'adresses.  
Voyez ci-dessous le découpage par réseau (VCN) et sous-réseaux.  
À noter : chaque installation est unique et ce découpage réseau est à titre indicatif. Son but vise à tester la fonctionnalité de la solution sans tenir compte du nombre ou du type de charges de travail.

### Réseaux et sous-réseaux  (voir le diagramme d'architecture de la solution pour plus de détails)

>| Compartiment     | Réseaux                      | Blocs attribués      | Sous-réseaux                         | Blocs attribué      |
>|------------------|------------------------------|-----------------------|--------------------------------------|----------------------|
>| cmp-conne-001    | VCN Concentrateur            | 10.73.0.0/23 (512)    | Public subnet                        | 10.73.0.00/27 (32)   |
>|                  |                              |                       | Priv subnet                          | 10.73.0.32/27 (32)   |
>|                  |                              |                       | Mgmt subnet                          | 10.73.0.64/27 (32)   |
>|                  |                              |                       | HA subnet                            | 10.73.0.96/27 (32)   |
>| Compartiment     | Réseaux                      | Blocs attribués      | Sous-réseaux                         | Blocs attribués      |
>|------------------|------------------------------|-----------------------|--------------------------------------|-----------------------|
>| cmp-prod-001     | vcn-cmp-nonprod-web-cam1-001 | 10.77.00.0/18 (16384) | snetr-vcn-cmp-nonprod-web-cam1-001   | 10.77.0.0/19 (8192)   |
>|                  | vcn-cmp-prod-app-cam1-001    | 10.77.64.0/18 (16384) | snetr-vcn-cmp-prod-app-cam1-001      | 10.77.64.0/19 (8192)  |
>|                  | vcn-cmp-prod-bd-cazm1-001    | 10.77.128.0/18 (16384)| snetr-vcn-cmp-prod-db-cam1-001       | 10.77.128.0/19 (8192) |
>| Compartiment     | Réseaux                      | Blocs attribués      | Sous-réseaux                         | Blocs attribués      |
>|------------------|------------------------------|-----------------------|--------------------------------------|-----------------------|
>| cmp-nonprod-001  | vcn-cmp-nonprod-web-cam1-001 | 10.79.0.0/18 (16384)  | snetr-vcn-cmp-nonprod-web-cam1-001   | 10.79.0.0/19 (8192)   |
>|                  | vcn-cmp-nonprod-app-cam1-001 | 10.79.64.0/18 (16384) | snetr-vcn-cmp-nonprod-app-cam1-001   | 10.79.64.0/19 (8192)  |
>|                  | vcn-cmp-nonprod-bd-cam1-001  | 10.79.128.0/18 (16384)| snetr-vcn-cmp-nonprod-db-cam1-001    | 10.79.128.0/19 (8192) |
>| Compartiment     | Réseaux                      | Blocs attribués      | Sous-réseaux                         | Blocs attribués      |
>|------------------|------------------------------|-----------------------|--------------------------------------|-----------------------|
>| cmp-casae-001    | vcn-cmp-case-tecae-cam1-001 | 10.73.128.0/18 (16384)| snetr-vcn-cmp-casae-tecae-cam1-001   | 10.73.128.0/22 (1024) |
>| Compartiment     | Réseaux                      | Blocs attribués      | Sous-réseaux                         | Blocs attribués      |
>|------------------|------------------------------|-----------------------|--------------------------------------|-----------------------|
>| cmp-nocla-001    | vcn-cmp-nocla-tenoa-cam1-001| 10.73.64.0/18 (16384) | snetr-vcn-cmp-casae-tecae-cam1-001   | 10.73.64.0/22 (1024)  |
    

## Génération du jeton pour accéder au dépôt de configurations des pare-feux Fortigate

1. Connectez-vous à l'organisation Azure DevOps qui détient le dépôt de configurations des pare-feux Fortigate .   

Exemple de lien d'une organisation Azure DevOps : 

   https://dev.azure.com/{yourorganization} , où {yourorganization} est le nom de votre organisation.    

Dans la configuration par défaut , cette organisation est : ccticei.   

Vous pouvez modifier cette organisation suivant votre besoin d'affaire.

2. À partir de votre page d’accueil, ouvrez les paramètres utilisateur  et sélectionnez Jetons d’accès personnels.

3. Suivre le guide dans le lien suivant :  

https://learn.microsoft.com/fr-ca/azure/devops/organizations/accounts/use-personal-access-tokens-to-authenticate?view=azure-devops&tabs=Windows#create-a-pat   

4. Sur l'interface graphique de la pile de déploiement , vous allez entrer ce jeton dans le champ **Jeton d'accès personnel au dépôt privé de configurations Fortigate**

5. Et lors du déploiement de la Zone Accueil , le script Terraform va utiliser ce jeton comme mot de passe , pour accéder au dépôt [Module-Fortigate](https://ccticei@dev.azure.com/ccticei/Migration/_git/Module-Fortigate) , qui est le dépôt par défaut qui contient les configurations pour des pare-feux Fortigate.


[Retour à la Page d'accueil](../../ReadMe.md)
