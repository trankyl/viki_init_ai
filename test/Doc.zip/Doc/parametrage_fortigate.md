# Paramétrage du pare-feu FortiGate dans la zone d'accueil

## Sommaire

* [Paramétrage](#parametrage)
* [Déploiement](#deploiementautomatique)
* [Configuration](#configurationfortigate)
* [Page d'accueil](../Readme.md)

## <a id="parametrage"> Paramétrage

Le pare-feu FortiGate est instancié sous forme de machine virtuelle avec une image précise de FortiGate.

Les paramètres pour FortiGate sont répartis dans différents fichiers.


| Paramètre                        | Fichier            | Type de données       | Valeur par défaut       | Commentaire                                                                                                                                                                                                                                                                                                                                                                                                        |
| ----------------------------------- | -------------------- | ------------------------ | -------------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| var-platform-hub-deploy-Fortigate | cei-base-param.yml | Booléen               | false                    | Permet ou empêche le déploiement de FortiGate dans le scénario de base.                                                                                                                                                                                                                                                                                                                                         |
| var-platform-hub-nsgList          | cei-platform.yml   | Objet                  |                          | Contient les deux règles de sécurité**allow_fortigate_mgmt_initial_https_inbound** et **allow_fortigate_mgmt_https_inbound** dans le NSG **nsg-name-platform-hub-001**; une pour autoriser HTTPS (port 443) pour la connexion initiale aux FortiGate et la deuxième pour le port 8443, une fois le port de gestion modifié.                                                                                   |
| var-platform-hub-virtualNetwork   | cei-platform.yml   | Objet                  |                          | Contient les quatre sous-réseaux (/26) pour correspondre à l'architecture de référence de Fortinet (extérieur, intérieur, HA sync, gestion). Les quatre sous-réseaux sont : <br />*```snetnva-ext1-$(var-platform-hub-name-suffix)```* , *```snetnva-ext2-$(var-platform-hub-name-suffix)```* , *```snetnva-int-$(var-platform-hub-name-suffix)```* , *```snetnva-mgmt-$(var-platform-hub-name-suffix)```*. |
| var-platform-hub-fortigate-name   | cei-platform.yml   | chaîne de caractères |                          | Nom de la machine virtuelle FortiGate                                                                                                                                                                                                                                                                                                                                                                              |
| var-sku-image-fortigate           | cei-platform.yml   | chaîne de caractères | fortinet_fg-vm           | SKU de l'image de la machine virtuelle FortiGate                                                                                                                                                                                                                                                                                                                                                                   |
| var-version-image-fortigate       | cei-platform.yml   | chaîne de caractères | 7.0.9                    | Version de l'image de la machine virtuelle FortiGate. Si on veut appliquer automatiquement la configuration, on laisse '7.0.9'. Si on veut l'image "à jour" (7.2.x), on choisit 'latest", mais la configuration doit toutefois être appliquée manuellement à cause d'un problème connu avec cette version (voir plus bas).                                                                                    |
| var-offre-image-fortigate         | cei-platform.yml   | chaîne de caractères | fortinet_fortigate-vm_v5 | Offre de l'image FortiGate                                                                                                                                                                                                                                                                                                                                                                                         |
| var-platform-hub-fortigate        | cei-platform.yml   | Objet                  |                          | Liste de configurations FortiGate à appliquer                                                                                                                                                                                                                                                                                                                                                                     |

Afin de les protéger, certains paramètres ne sont pas inscrits dans le script, mais ils sont demandés à la volée à chaque session de déploiement des FortiGate. Il s'agit des paramètres suivants dans le pipeline [azure-pipeline\templates\steps\deploy-platform.yml](../azure-pipeline/templates/steps/deploy-platform.yml) :


| Paramètre        | Type de données      | Commentaire                                                                                                                                                           |
| ------------------- | ----------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| nomUtilAdminFg    | Chaîne de caractère | Nom de l'utilisateur pour administrer la machine FortiGate (obligatoire, à spécifier si FortiGate est déployé).                                                   |
| motDePasseAdminFg | Chaîne de caractère | Mot de passe de l'administrateur de la machine FortiGate (obligatoire, à spécifier si FortiGate est déployé).                                                     |
| licenceFortigateA | Chaîne de caractère | Contenu du fichier de licence pour FG-A y compris les BEGIN et END. Optionnel si on veut activer la licence manuellement plus tard, dans quel cas on tape```Aucun```. |
| licenceFortigateB | Chaîne de caractère | Contenu du fichier de licence pour FG-B y compris les BEGIN et END. Optionnel si on veut activer la licence manuellement plus tard, dans quel cas on tape```Aucun```. |

Il y a possiblement des situations dans lesquelles FortiGate n'est pas déployé (var-platform-hub-deploy-Fortigate = false) ou on veut appliquer les licences manuellement. Dans ces situations, le pipeline platform.yml va quand même toujours demander les quatre paramètres ci-dessus. Taper simplement ```Aucun``` ou ```aucun```, car le pipeline n'accepte pas des paramètres vides.

## <a id="deploiementautomatique"> Déploiement automatique

Afin de lancer le déploiement automatiquement des pare-feux FortiGate, il faut lancer le pipeline [azure-pipeline\templates\steps\deploy-platform.yml](../azure-pipeline/templates/steps/deploy-platform.yml).

## <a id="configurationfortigate"> Configuration FortiGate

Une fois un pare-feu FortiGate déployé, deux situations peuvent se présenter en fonction de la version FortiGate choisie :

* Si on déploie la version par défaut 7.0.9, la configuration est appliquée automatiquement par le script.
* Si la version choisie est 'latest', il y a alors une procédure manuelle pour configurer les deux FortiGate.

### Configuration manuelle des FortiGate

Dans le cas du choix 'latest' pour var-version-image-fortigate, il faut configurer manuellement ses interfaces, la haute disponibilité (HA) et les autres paramètres de routage et règles de coupe-feu. Le même cas existe si on choisit de ne pas déployer la licence par le biais du script.

Deux scripts FortiGate (**fga.cfg** et **fgb.cfg**) sont générés pour chacun des deux pare-feux FortiGate, à partir des paramètres ci-dessus. Ils sont disponibles dans le dossier [scripts/Fortigate](../scripts/Fortigate/) pour le plan d'adressage par défaut. Si on utilise un autre plan d'adressage, il faudra créer ces configurations en roulant un script PowerShell, soit localement, soit dans l'interface "Cloud Shell" d'Azure selon la procédure décrite dans la section [Génération script Fortigate](#Génération-script-Fortigate).

Pour chacun des pare-feux FortiGate, il faudra importer ce script dans la console Web d'administration afin que des configurations soient créées. Ainsi, le pare-feu FortiGate pourra acheminer et contrôler le trafic dans votre zone d'accueil.

Répéter les étapes suivantes pour chacun des pare-feux déployés.

### Activation de la licence FortiGate

* Dans un navigateur Web, connectez-vous à la console Web d'administration du pare-feu FortiGate, et tapez l'adresse suivante :

[https://public_ip](https://public_ip), où public_ip est l'adresse publique de la machine virtuelle FortiGate.

![1_console_web_admin_fortigate](images\fortigate\1_console_web_admin_fortigate.png )

![2_console_web_admin_fortigate](images\fortigate\2_console_web_admin_fortigate.png )

* Saisir l'identifiant et le mot de passe pour accéder à la machine virtuelle FortiGate.

![3_saisie_identifiant_vm_fortigate](images\fortigate\3_saisie_identifiant_vm_fortigate.png )

Une nouvelle page Web s'affiche.

* Sélectionner le type de licence pour l'activation du pare-feu FortiGate.

![4_selection_type_licence](images\fortigate\4_selection_type_licence.png )

Sélectionner **Full license**.

* Importer le fichier de licence à partir de votre poste de travail.

![6_importation_licence_fortigate](images\fortigate\6_importation_licence_fortigate.png )

Le système affiche une boîte de dialogue et demande l'autorisation pour redémarrer la machine virtuelle.

![7_accepter_redemarrage_vm_fortigate](images\fortigate\7_accepter_redemarrage_vm_fortigate.png )

* Cliquer sur le bouton OK pour accepter le redémarrage.

Le machine virtuelle redémarre.

![8_redemarrage](images\fortigate\8_redemarrage.png )

Pendant que la machine virtuelle redémarre quelques minutes, passons à la génération du script FortiGate pour sa configuration.

### Génération du script FortiGate

* Télécharger le répertoire (*repository*) Azure DevOps ayant le script de déploiement de la zone accueil.
* Dans l'explorateur Windows, décompresser le script compressé.
* Lancer la ligne de commande PowerShell et aller dans le dossier scripts/Fortigate.

![9_ouvrir_dossier_fortigate](images\fortigate\9_ouvrir_dossier_fortigate.png )

* Lancer le script PowerShell **Replace-Tokens-fg-cli.ps1** pour lancer la génération.

Taper la commande suivante :

ReplaceTokens -InputFile fga_cfg.tpl  -OutputFile fga.cfg -Config config.ini
Le script fga.cfg sera créé dans le dossier scripts/Fortigate.

### Accès à l'interface de gestion Web FortiGate

Par défaut, l'accès public à l'interface de gestion n'est pas permis, il faut donc accéder l'interface à partir du *jumpbox* dans la zone gestion, via https à son adresse privée, par défaut 10.84.4.196 et 10.84.4.197 pour FG-A et FG-B respectivement.

Pour activer temporairement l'adresse publique, il faut enlever le signe de commentaire, dans cei-platform.yml, pour que la ligne suivante se lise comme suit : var-platform-hub-nva-mgmt-pip-allowed: 'yes'.

![Fortigate interface gestion](images\fortigate\16_FortigateInterface_Gestion.PNG)

### Configuration de FortiGate via la console CLI

* Une fois la machine virtuelle redémarrée, lancer la console Web d'administration et entrer l'identifiant et le mot de passe.

La page Web suivante s'affiche.

![10_page_accueil_console_web](images\fortigate\10_page_accueil_console_web.png )

* Lancer la console CLI dans FortiGate.
* Importer le fichier fga.cfg en copiant-collant son contenu dans la console CLI.

![11_script_importe_dans_console_cli_fortigate](images\fortigate\11_script_importe_dans_console_cli_fortigate.png )

* Lancer le script dans la console CLI.

Le système configure le pare-feu.

Et voici son résultat.

![12_interfaces](images\fortigate\12_interfaces.png "Interfaces")

![13_route_statique](images\fortigate\12_interfaces.png "Route statiques")

![14_adressage](images\fortigate\14_adressage.png "Plan d adressage")

![15_regle_pare_feu_fortigate](images\fortigate\15_regle_pare_feu_fortigate.png "Regles du pare-feu")
