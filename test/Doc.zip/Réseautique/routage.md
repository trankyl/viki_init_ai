
# Routage

   Dans notre architecture en étoile, la DRG centralise la communication entre les réseaux inter VCN ainsi que la communication entre les VCN et le site sur place (*on-premises*). La DRG offre la possibilité de diriger et d'inspecter le trafic des VCN à l'aide de pare-feux. La sécurité de ce trafic est gérée essentiellement à travers le *Hub* qui dispose de pare-feux en redondance. À cet effet, voir la section [Périmètre et pare-feux](../Architecture/Architecture.md#périmètre-et-pare-feux) dans l'[architecture](../Architecture/Architecture.md).

   Pour Oracle, la communication avec le site peut se faire de deux façons :

- [Site-to-Site VPN](https://docs.oracle.com/fr-fr/iaas/Content/Network/Tasks/overviewIPsec.htm#:~:text=Site%2Dto%2DSite%20VPN%20provides,the%20traffic%20when%20it%20arrives.)
       Fournit une connectivité VPN IPSec entre votre réseau sur site et les VCN dans Oracle Cloud Infrastructure.
- [FastConnect](https://docs.oracle.com/fr-fr/iaas/Content/Network/Concepts/fastconnect.htm)
       Connexion privée dédiée entre votre centre de données et Oracle Cloud Infrastructure. FastConnect offre des options de bande passante plus élevée et une expérience réseau plus fiable par rapport aux connexions Internet.

![Arc_Routage](../images/Arc_Routage.png)   

[Retour à la page d'accueil](../../README.md)
