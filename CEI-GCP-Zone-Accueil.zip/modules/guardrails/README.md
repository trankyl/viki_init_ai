# terraform-guardrails
<!-- BEGINNING OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
## Entrées

| Nom                               | Description                                                                                                                  | Type | Défaut                      | Requis |
|-----------------------------------|------------------------------------------------------------------------------------------------------------------------------|------|-----------------------------|:------:|
| additional\_user\_defined\_string | Modifiant d'envirnement à deployer les instances                                                                             | `string` | `""`                        |   non   |
| billing\_account                  | ID de compte de facturation                                                                                                  | `string` | `null`                      |   non   |
| department\_code                  | Code de département utilisé à fin de nommage                                                                                 | `string` | n/a                         |  oui   |
| environment                       | P = Prod, D = Development, Q = QA, S = SandBox, etc.                                                                         | `string` | n/a                         |  oui   |
| org\_client                       | Vrai si c'est une organisation de client. Faux si c'est une organisation de "core"                                           | `bool` | `false`                     |   non   |
| org\_id                           | ID d'organisation dans laquelle se déploiera cette ressource                                                                 | `string` | n/a                         |  oui   |
| org\_id\_scan\_list               | Une liste d'id d'organisation à scanner.                                                                                     | `list(string)` | `[]`                        |   non   |
| owner                             | Propriétaire du projet.                                                                                                      | `string` | `""`                        |   non   |
| parent                            | Dossier parent ou organisation dans le format 'folders/folder\_id' ou 'organizations/org\_id' dans lequel créeront les mesures de sécurité | `string` | `null`                      |   non   |
| region                            | La région par défaut de toutes les ressources                                                                                | `string` | `"northamerica-northeast1"` |   non   |
| user\_defined\_string             | Modifiant d'envirnement à deployer les instances                                                                             | `string` | `""`                        |   non   |

## Sorties

| Nom                                         | Description                                                                                                                                 |
|---------------------------------------------|---------------------------------------------------------------------------------------------------------------------------------------------|
| asset\_inventory\_bucket                    | Bucket GCS conetnant les rapport d'inventaire de ressource                                                                                  |
| cloudbuild\_container\_pipeline\_definition | Le déclencheur de Cloud Build qui crée le conteneur de génération de rapport                                                                |
| cloudbuild\_container\_pipeline\_trigger    | Le déclencheur de Cloud Build qui crée le conteneur de génération de rapport                                                                |
| guardrails\_container\_location             | Le déclencheur de Cloud Build qui crée le conteneur de génération de rapport                                                                |
| guardrails\_policies\_repo\_name            | Le nom du repo contenant les policies rego des mesures de sécurité dans "Cloud Source Repository"                                           |
| project\_id                                 | L'id de projet où se trouvent les ressources de mesures de sécurité                                                                         |
| report\_generation\_schedule                | L'horaire de génération de rapport                                                                                                          |
| reports\_bucket                             | Bucket GCS contenant les rapport de résultat de scan de mesures de sécurité |

<!-- END OF PRE-COMMIT-TERRAFORM DOCS HOOK -->