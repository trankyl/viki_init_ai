#### Retour en arrière

* [Aperçu du paramétrage et du déploiement](parametrage_deploiements.md)
* [Page d'accueil](../Readme.md)

# Déployer les définitions et les assignations de stratégies et d'initiatives

Le pipeline permet de déployer les définitions et les assignations de stratégies personnalisées ainsi que la création d'initiatives personnalisées. Il déploie également les assignations des stratégies intégrées.

Il y a deux types de fichiers : des stratégies individuelles (*policies*) et des initiatives (*policyset*).

* Le pipeline policy.yml exécute les étapes suivantes :
* Déployer les définitions des stratégies (*policies* en anglais) personnalisées
* Déployer les définitions des initiatives (*policyset* en anglais) personnalisées (par exemple : Azure Defender, Log Analytics, Network, Tags)
* Assigner les stratégies intégrées (builtin en anglais)
* Assigner les stratégies personnalisées
* Assigner les initiatives personnalisées

Les fichiers qui définissent les initiatives et stratégies se trouvent en dessous du répertoire *policy* dans le sous-répertoire correspondant d'un scénario. Pour le scénario de base, il est en dessous de azure-pipeline/config/variables/scenario-base/policy.
Chaque stratégie est référencée par son ID qui correspond à la version de l'API déclarée dans le fichier policysetdefinition.json.

Au besoin, et à la suite d'un avis de sécurité, vous pouvez mettre à jour certaines valeurs par défaut des fichiers de paramètres ci-dessous avec les valeurs correspondant à celles de votre environnement infonuagique, mais après en avoir fait des copies de sauvegarde. Toutefois, pour des raisons de conformité et de sécurité, il est fortement déconseillé de modifier ces fichiers.


| Fichier                              | Sous-répertoire             | Personnalisation                                                                                        | Commentaire                                                                                |
| -------------------------------------- | ------------------------------ | --------------------------------------------------------------------------------------------------------- | -------------------------------------------------------------------------------------------- |
| parameters.assignbuiltin.yml         | builtin/policy-assignment    | À ne pas modifier sans un avis de sécurité                                                              | Assigner les stratégies intégrées, par défaut assignées au niveau organisation             |
| parameters.custompolicies.yml        | custom/definitions/policy    | À ne pas modifier sans un avis de sécurité                                                              | Création des stratégies personnalisées                                                  |
| parameters.custompolicyset.yml       | custom/definitions/policyset | À ne pas modifier sans un avis de sécurité                                                              | Création des initiatives personnalisées                                                  |
| parameters.assigncustompolicy.yml    | custom/assignments/policy    | Chercher un avis de sécurité avant de modifier l'état et les niveaux d'assignation (groupes d'administration) | Assignation des stratégies personnalisées dans la hiérarchie des groupes d'administration  |
| parameters.assigncustompolicyset.yml | custom/assignments/policyset | Chercher un avis de sécurité avant de modifier l'état et les niveaux d'assignation (groupes d'administration) | Assignation des initiatives personnalisées dans la hiérarchie des groupes d'administration |

Pour la personnalisation des stratégies et des initiatives, il y a quelques variables dans le fichier de paramétrage par scénario (cei-base-param.yml pour le scénario "base", cei-complexe-param.yml pour le scénario "complexe") :


| Variable                           | Valeur défaut                                                                                                                                                                                                                              | Commentaire                               |
| ------------------------------------ | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------- |
| var-custom_policy-prod-scope      | L'ID du groupe d'administration "Production" de votre organisation, même qui est référencé dans le fichier cei-base-hierarchie.yml (défaut "Production"). Certaines stratégies seront appliquées à ce niveau (voir fichier .yml)   | Chercher un avis de sécurité pour modifier |
| var-custom_policy-charges-scope    | L'ID du groupe d'administration "Charges" de votre organisation, même qui est référencé dans le fichier cei-base-hierarchie.yml (défaut "ZonesDeCharges"). Certaines stratégies seront appliquées à ce niveau (voir fichier .yml) | Chercher un avis de sécurité pour modifier |
| var-custom-policy_security_contact | Entrer ici l'adresse courriel de votre organisation qui recevra les alertes de non-conformité par rapport aux stratégies.                                                                                                                | Modification obligatoire                  |
