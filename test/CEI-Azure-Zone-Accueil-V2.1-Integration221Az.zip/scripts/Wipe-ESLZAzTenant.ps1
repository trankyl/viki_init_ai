######################
# Wipe-ESLZ-AzTenant #
######################
# Version: 1.6
# Dernières modifications: 2022/03/10
# Author: Jack Tracey
# Contributeurs: Liam F. O'Neill, Paul Grimley, Jeff Mitchell
# Modifié par by: jfaurskov, David De Backer


<#
.SYNOPSIS
Nettoie un tenant AAD après déploiement d'un Enterprise Scale (Azure Landing Zone Accelerator) de manière à ce qu'il puisse être redéployé.
ATTENTION: TOUTES VOS RESSOURCES AZURE SERONT SUPPRIMEES.
A UTILISER AVEC EXTREME PRUDENCE ET UNIQUEMENT LORSQUE LA FONCTIONALITE EST BIEN COMPRISE

.DESCRIPTION
Nettoie un tenant AAD après déploiement d'un Enterprise Scale (Azure Landing Zone Accelerator) de manière à ce qu'il puisse être redéployé.
.EXAMPLE
# Sans suppression du SPN
.\Wipe-ESLZAzTenant.ps1 -tenantRootGroupID "f73a2b89-6c0e-4382-899f-ea227cd6b68f" -intermediateRootGroupID "Contoso"
# Avec suppression du SPN
.\Wipe-ESLZAzTenant.ps1 -tenantRootGroupID "f73a2b89-6c0e-4382-899f-ea227cd6b68f" -intermediateRootGroupID "Contoso" -eslzAADSPNName "Contoso-ESLZ-SPN"
.NOTES
Pour en apprendre plus sur l'Enterprise-scale here (attention documentation en anglais uniquement):
https://github.com/Azure/Enterprise-Scale
https://aka.ms/es/guides
# Modules PowerShell requis:
- https://docs.microsoft.com/en-us/powershell/azure/install-az-ps?view=azps-6.4.0
- Install-Module -Name Az
- Spécifiquement 'Az.Accounts', 'Az.Resources' & 'Az.ResourceGraph' si vous devez limiter ce qui doit être installé
# Notes de release du 14/09/2021 - V1.0:
- Release initiale.
- Utilise Azure Resource Graph pour énumérer les abonnements contenus dans la hiérarchie du groupe de gestion ciblé, c'est pourquoi le rafraîchissement des données d'Azure Graph peut prendre 5-10 minutes, surtout si ils ont été déplacées récemment d'un groupe de gestion à un autre
# Notes de release du 29/09/2021 - V1.1:
- Ajout de la vérification de la présence des modules d'Azure PowerShell requis: 'Az' or 'Az.Accounts', 'Az.Resources' & 'Az.ResourceGraph'
# Notes de release du 30/09/2021 - V1.2:
- Ajout de la validation d'exécution dans l'environnement PowerShell Core et non Desktop - https://docs.microsoft.com/en-us/powershell/scripting/install/installing-powershell?view=powershell-7.1
# Notes de release du 01/10/2021 - V1.3:
- Modification de la manière dont la validation de la présence des modules Azure Powershell est faite
# Notes de release du 11/23/2021 - V1.4:
- Suppression de la validation par l'usager vu que nous exécutons ce script via Pipeline et non en mode interactif. Si vous souhaitez examiner le script original vous pourrez le trouver là:
    https://github.com/jtracey93/PublicScripts/blob/master/Azure/PowerShell/Enterprise-scale/Wipe-ESLZAzTenant.ps1
#>

[CmdletBinding()]
param (
    # Ajout d'un paramètre pour gérer le fait que le contexte pourrait avoir accès à plusieurs tenant AAD
    [Parameter(Mandatory = $true, Position = 1, HelpMessage = "Please the Insert Tenant ID (GUID) of your Azure AD tenant e.g.'f73a2b89-6c0e-4382-899f-ea227cd6b68f'")]
    [string] $tenantRootGroupID,

    [Parameter(Mandatory = $true, Position = 2, HelpMessage = "Insert the name of your intermediate root Management Group e.g. 'Contoso'")]
    [string] $intermediateRootGroupID,

    [Parameter(Mandatory = $false, Position = 3, HelpMessage = "(Optional) Please enter the display name of your Enterprise-scale app registration in Azure AD. If left blank, no app registration is deleted.")]
    [string] $eslzAADSPNName
)

$ConfirmPreference = "None"

# Instantiation des modules Azure Powershell requis
Install-Module Az.ResourceGraph -Scope CurrentUser -Force
Install-Module Az.Accounts -Scope CurrentUser -Force
Import-Module Az.ResourceGraph -Force
Import-Module Az.Accounts -Force
Import-Module Az.Resources -Force


Write-Output $tenantRootGroupID
Write-Output $intermediateRootGroupID

#Suppression des messages informatifs concernant DisplayName et DisplayId
Set-Item Env:\SuppressAzurePowerShellBreakingChangeWarnings "true"

# Démarrage du chronomètre des tâches
$StopWatch = New-Object -TypeName System.Diagnostics.Stopwatch
$StopWatch.Start()

#Enumération des abonnements qui se trouvent sous la hiérarchie du group de gestion à supprimer
$intermediateRootGroupChildSubscriptions = Search-AzGraph -Query "resourcecontainers | where type =~ 'microsoft.resources/subscriptions' | mv-expand mgmtGroups=properties.managementGroupAncestorsChain | where mgmtGroups.name =~ '$intermediateRootGroupID' | project subName=name, subID=subscriptionId, subState=properties.state, aadTenantID=tenantId, mgID=mgmtGroups.name, mgDisplayName=mgmtGroups.displayName"
$userConfirmationMGsToDelete = Get-AzManagementGroup -GroupID $intermediateRootGroupID -Expand -Recurse | Select-Object Id, DisplayName, Name, TenantId, ParentId, ParentDisplayName, ParentName, Children
$userConfirmationSubsToMove = $intermediateRootGroupChildSubscriptions | Select-Object subName, subID, subState, aadTenantID

# Liste des groupes de gestions qui vont être supprimés
Write-Output "Les groupes de gestion suivants vont être supprimés (l'information sur le groupe parent est là à des fins de visibilité, il ne sera PAS supprimé):"
$userConfirmationMGsToDelete

Write-Output "La hiérarchie du groupe de gestion ciblé contient les abonnements suivants qui seront déplacés au niveau du Tenant Root Management Group:"
Write-Output ""
if ($null -ne $intermediateRootGroupChildSubscriptions) {
    $userConfirmationSubsToMove
} else {
    Write-Output "Nous n'avons pas trouvé d'abonnements dans la hiérarchie ciblée"
    Write-Output ""
}

Write-Output "Déplacement des abonnements trouvés vers le groupe de gestion: $tenantRootGroupID"

# Pour chacun des abonnements trouvés dans la hiérarchie du groupe de gestion ciblé, déplacement vers le Tenant Root Management Group
$intermediateRootGroupChildSubscriptions | ForEach-Object -Parallel {
    if ($_.subState -ne "Disabled") {
        Write-Output "Déplacement de la souscription: '$($_.subName)' vers le Tenant Root Management Group: '$($using:tenantRootGroupID)'"
        New-AzManagementGroupSubscription -GroupName $($using:tenantRootGroupID) -SubscriptionId $($_.subID) -verbose
           
    }
}

# Suppression des ressources, groupes de ressources et déploiements dans chacune des abonnements de la hiérarchie ciblée
Write-Host "Suppression des ressources, groupes de ressources et déploiements dans chacune des abonnements de la hiérarchie ciblée" -ForegroundColor Yellow

ForEach ($subscription in $intermediateRootGroupChildSubscriptions) {
    Write-Host "Met le contexte sur la souscription: '$($subscription.subName)'" -ForegroundColor Cyan
    Set-AzContext -Subscription $subscription.subID | Out-Null

    # Enumération des groupes de ressources de l'abonnement
    $resources = Get-AzResourceGroup

    <# désactivé car ne fonctionne pas correctement, mieux les enlever manuellement pour l'instant
    # Suppression des policy assignment associé au ressources trouvés
    $resources | ForEach-Object -Parallel {
        # Removes the policy assignment
        Write-Host "Suppression de policy assignment associé au rg" $_.ResourceGroupName "..." -ForegroundColor Red
        Remove-AzPolicyAssignment -Scope "/subscriptions/$($subscription.subID)/resourceGroups/$($_.ResourceGroupName)"
    }
    Write-Host "Suppression des PolicyDefinition Builtin du souscription '$($subscription.subID)'" -ForegroundColor Cyan
    # Obtenir les policy definitions Builtin de l abonnement en cours d'itération
    $listeStrategieBuiltin = Get-AzPolicyDefinition -SubscriptionId "$($subscription.subID)" -Builtin
    # Suppression des policy definitions Builtin de l abonnement en cours d'itération
    ForEach ($PolicyDefinition in $listeStrategieBuiltin) {
        Write-Host "Nom : '$($PolicyDefinition.Name)'" -ForegroundColor Cyan
        Write-Host "ResourceId : '$($PolicyDefinition.ResourceId)'" -ForegroundColor Cyan
        Remove-AzPolicyDefinition -Id $PolicyDefinition.ResourceId -Force
    }

    Write-Host "Suppression de toutes les PolicyDefinition du souscription '$($subscription.subID)'" -ForegroundColor Cyan
    # Obtenir les policy definitions de l abonnement en cours d'itération
    $listePolicyDefinition = Get-AzPolicyDefinition -SubscriptionId "$($subscription.subID)"
    # Suppression des policy definitions de l abonnement en cours d'itération
    ForEach ($PolicyDefinition in $listePolicyDefinition) {
        Write-Host "Nom : '$($PolicyDefinition.Name)'" -ForegroundColor Cyan
        Write-Host "ResourceId : '$($PolicyDefinition.ResourceId)'" -ForegroundColor Cyan
        Remove-AzPolicyDefinition -Id $PolicyDefinition.ResourceId -Force
    }  
    #>
    
    # Suppression des groupes de ressources trouvés
    $resources | ForEach-Object -Parallel {
        Write-Host "Suppression de " $_.ResourceGroupName "..." -ForegroundColor Red
        Remove-AzResourceGroup -Name $_.ResourceGroupName -Force | Out-Null
    }
    
    # Enumération des déploiments de l'abonnement
    $subDeployments = Get-AzSubscriptionDeployment

    Write-Host "Suppression de tous les déploiements pour l'abonnement: $($subscription.subName)" -ForegroundColor Yellow 
    
    # Suppression de tous les déploiements de l'abonnement
    $subDeployments | ForEach-Object -Parallel {
        Write-Host "Suppression du déploiement $($_.DeploymentName) ..." -ForegroundColor Red
        Remove-AzSubscriptionDeployment -Id $_.Id
    }
}

# Enumération des déploiements au niveau du tenant AAD
$tenantDeployments = Get-AzTenantDeployment

Write-Output "Suppression de tous les déploiements du tenant"

# Suppression de tous les déploiements du tenant
$tenantDeployments | ForEach-Object -Parallel {
    Write-Output "Suppression du déploiement $($_.DeploymentName) ..."
    Remove-AzTenantDeployment -Id $_.Id
}

# Suppression du SPN utilisé pour déployer l'ESLZ (si fourni dans les paramètres)
if ($eslzAADSPNName -ne "") {
    Write-Output "Suppression de l'enregistrement applicatif/SPN d'Azure AD:" $eslzAADSPNName
    Remove-AzADApplication -DisplayName $eslzAADSPNName -Force
}
else {
    Write-Output "Aucun ID applicatif fourni, en conséquence il ne sera pas supprimé."
}

# Cette fonction ne supprime que les groupes de gestion dans la hiérarchie du groupe de gestion ciblé, PAS d'autres groupes de gestion non spécifiés
function Remove-Recursively {
    [CmdletBinding(SupportsShouldProcess)]
    param($name)
    # Connexion au parent
    Write-Output "Connexion au groupe de gestion $name"
    $parent = Get-AzManagementGroup -GroupId $name -Expand -Recurse

    # Enumère les enfants si il y en a
    if ($null -ne $parent.Children) {
        Write-Output "Enfants suivants découverts :"
        Write-Output ($parent.Children | Select-Object Name).Name

        foreach ($children in $parent.Children) {
            # 
            if($PSCmdlet.ShouldProcess($children.Name)){
                Remove-Recursively($children.Name)
            }
        }
    }

    # Si aucun enfant n'est découvert sous le scope
    Write-Output "Aucun objet enfant découvert sous le scope $name"
    Write-Output "Suppression du scope $name"

    Remove-AzManagementGroup -InputObject $parent -ErrorAction SilentlyContinue
}

# Suppression de tous les groupes de gestion sous la hiérarchie ciblée ainsi que le groupe de gestion ciblé lui-même
Remove-Recursively($intermediateRootGroupID)

# Arrêt du chromométrage
$StopWatch.Stop()

# Affichage du chronométrage des diverses étapes
Write-Output "Temps passé à exécuter les tâches:"
$StopWatch.Elapsed | Format-Table