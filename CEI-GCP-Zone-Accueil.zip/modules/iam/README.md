# GCP IAM Module

Ce module a but pour créer des comptes de service de projet et leur assigner des permissions. Il est aussi utilisé pour assigner des permissions à des comptes service de non-projets et des usagers à des ressources de projet.

## Pris en charge actuellement
- Création des comptes de service de projet et les attributions de rôles
- Attribution de rôles aux comptes de service, de groupe et d'usager qui n'appartient pas au projet actuel.
- Attribution de rôle `compute.networkUser` dans un projet de réseau spécifié à un sous-réseau spécifié.

## Améliorations en futur
- Jeux de données Big Query
- Ressources Pub/Sub
- Buckets
- Toutes les autres ressources dont les permissions peuvent être attribué à un niveau de ressource.

<!-- BEGINNING OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
## Exigences

Pas d'exigence

## Fournisseurs

Pas de fournisseurs

## Modules

| Nom                                                                                                     | Source | Version |
|---------------------------------------------------------------------------------------------------------|--------|---------|
| <a name="module_compute_network_users"></a> [compute\_network\_users](#module\_compute\_network\_users) | ./modules/compute_network_user | n/a |
| <a name="module_folder_iam"></a> [folder\_iam](#module\_folder\_iam)                                    | ./modules/folder_iam | n/a |
| <a name="module_organization_iam"></a> [organization\_iam](#module\_organization\_iam)                  | ./modules/organization_iam | n/a |
| <a name="module_project_iam"></a> [project\_iam](#module\_project\_iam)                                 | ./modules/project_iam | n/a |
| <a name="module_sa_create_assign"></a> [sa\_create\_assign](#module\_sa\_create\_assign)                | ./modules/sa_create_assign | n/a |

## Resources

Pas de resources

## Entrées

| Nom                                                                                                   | Description                                                                                                                     | Type | Défaut | Requis  |
|-------------------------------------------------------------------------------------------------------|---------------------------------------------------------------------------------------------------------------------------------|------|--------|:-------:|
| <a name="input_compute_network_users"></a> [compute\_network\_users](#input\_compute\_network\_users) | Liste de comptes qui existent dehors le projet dont le rôle sera attribué dans le projet                                        | <pre>list(object({<br>    members    = list(string)<br>    subnetwork = string<br>    region     = string<br>    project    = optional(string)<br>  }))</pre> | `[]`   |   non    |
| <a name="input_folder_iam"></a> [folder\_iam](#input\_folder\_iam)                                    | Liste de compte à attribuer des rôles dans un dossier spécifié                                                                  | <pre>list(object({<br>    member = string<br>    roles  = list(string)<br>    folder = string<br>  }))</pre> | `[]`   |   non    |
| <a name="input_organization"></a> [organization](#input\_organization)                                | Organisation à laquelle appliquent les changements                                                                              | `string` | `null` |   non    |
| <a name="input_organization_iam"></a> [organization\_iam](#input\_organization\_iam)                  | Liste de compte à attribuer des rôles dans l'organisation                                                                       | <pre>list(object({<br>    member       = string<br>    roles        = list(string)<br>    organization = optional(string)<br>  }))</pre> | `[]`   |   non    |
| <a name="input_project"></a> [project](#input\_project)                                               | Projet auquel appliquent les changements                                                                                        | `string` | `null` |   non    |
| <a name="input_project_iam"></a> [project\_iam](#input\_project\_iam)                                 | Liste de comptes qui existent dehors le projet dont le rôle sera attribué dans le projet                                        | <pre>list(object({<br>    member  = string<br>    roles   = list(string)<br>    project = optional(string)<br>  }))</pre> | `[]`   |   non    |
| <a name="input_sa_create_assign"></a> [sa\_create\_assign](#input\_sa\_create\_assign)                | Liste de comptes service à créer et auxquels attribuene les rôles | <pre>list(object({<br>    account_id   = string<br>    display_name = string<br>    roles        = list(string)<br>    project      = optional(string)<br>  }))</pre> | `[]`   |   non    |

## Sorties

| Nom                                                                                                              | Description |
|------------------------------------------------------------------------------------------------------------------|-------------|
| <a name="output_compute_network_users"></a> [compute\_network\_users](#output\_compute\_network\_users)          | n/a |
| <a name="output_folder_iam_members"></a> [folder\_iam\_members](#output\_folder\_iam\_members)                   | n/a |
| <a name="output_organization_iam_members"></a> [organization\_iam\_members](#output\_organization\_iam\_members) | n/a |
| <a name="output_project_iam_members"></a> [project\_iam\_members](#output\_project\_iam\_members)                | n/a |
| <a name="output_service_accounts"></a> [service\_accounts](#output\_service\_accounts)                           | n/a |
<!-- END OF PRE-COMMIT-TERRAFORM DOCS HOOK -->