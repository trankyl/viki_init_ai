# Historique des améliorations et des versions


| Version | Date       | Description                                                                |
| :-------- | :----------- | :--------------------------------------------------------------------------- |
|   v1.0     | 11-12-2021 |  Version stable actuelle                 |
|   V1.1     | 10-03-2022 |  Amélioration du plan d'adressage        |
|   V1.1     | 15-03-2022 |  Suppression des déclencheurs (*triggers*) des pipelines plateforme et zone d'accueil           |
|   V1.1     | 12-04-2022 |  Amélioration du plan d'adressage selon le Guide d’adressage IP infonuagique        |
|   v2.0    | 03-08-2022 | Version 2.0                                                  |
|   v2.0.1  | 20-02-2022 | Version de maintenance 2.0                                    |
|   v2.2    | 28-02-2023 | Version 2.2                                                   |
