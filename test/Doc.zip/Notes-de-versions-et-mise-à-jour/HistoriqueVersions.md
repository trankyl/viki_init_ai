# Historique des améliorations et des versions

| Version    | Date       |  Description                             |
|------------|------------|------------------------------------------|
|   v1.0     | 19-08-2022 |  Version stable actuelle                 |
|            |            |  Déploiement automatique de 2 machines virtuelles Fortigate |
|   v2.0     | 13-01-2023 |  Déploiement zone accueil avec plus d'automatisation sur Fortigate : déploiement automatique , activation automatique licence (optionnelle) et configuration automatique des 2 machines virtuelles Fortigate                                        |
|            |            |  Guide pour activer la journalisation                                        |
|            |            |  Guide pour ajouter manuellement un pare-feu Fortigate dans une zone d'accueil sans pare-feu                                        |
|            |            |  Guide pour ajouter manuellement un pare-feu natif OCI dans une zone d'accueil sans pare-feu                                 |
|            |            |  Guide pour activer et configurer Cloud Guard dans la zone d'accueil                                  |
|   v2.1     | 15-12-2023 |  Personnalisation des noms des réseaux virtuels (VCN) et des compartiments                                        |
|            |            |  Francisation des libellés et commentaires sur l'interface graphique de la pile de déploiement                                        |
|            |            |  Configuration automatique des pares-feux Fortigate à partir d'un dépôt au MCN , de configurations prédéfinies pour des instances Fortigate                                        |
|            |            |  Restructuration sommaire Table des matières (Architecture,Déploiement,Réseautique,Sécurité,Scripts et outils,Notes de versions et mise à jour,Tarification et coûts)                                       |
|            |            |  FinOps : Documentation sur Tarification , coûts et cycle de vie des ressources dans une zone d'accueil                                       |

[Retour à la Page d'accueil](../../README.md)
