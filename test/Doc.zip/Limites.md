# Limites et quotas par service

 Voici quelques exemples des limitations que vous pouvez rencontrer lors de l'installation ou de l'exploitation de votre zone d'accueil. Il est toujours conseillé de valider ces informations sur le site d'Oracle puisque les données peuvent être modifiées entretemps.

Pour consulter la liste complète de ces limitations et vérifier s'il y a une mise à jour des données listées, veuillez consulter le lien suivant [Limites des services](https://docs.oracle.com/fr-ca/iaas/Content/General/Concepts/servicelimits.htm).

| Ressources                 | Portée           | Allouer                                                                     |
|-------------------------|------------------|-----------------------------------------------------------------------------|
| Réseaux virtuels infonuagiques (VCN)                     | Region           | 50                                                                          |
| Sous-réseaux (*Subnets*)                 | VCN              | 300                                                                         |
| Tables de routage (*VCN Route tables*)        | VCN              | 300                                                                         |
| Règles de routage (*Route rules*)             | VCN Route tables | 100 (impossible d'augmenter cette limite)                                   |
| Passerelle Internet (*Internet gateway*)       | VCN              | 1 (impossible d'augmenter cette limite)                                     |
| Passerelle NAT (*NAT gateway*)            | VCN              | 1                                                                           |
| Passerelle de service (Service gateway)        | VCN              | 1                                                                           |
| Groupe de sécurité réseau (*Network security group*) | VNC              | 1000                                                                        |
| Liste de sécurité (*Security lists*)          | VCN              | 300                                                                         |
| Liste de sécurité (*Security lists*)          | Subnet           | 5                                                                           |
| Règle de sécurité (*Security rules*)          | Security list    | 200 règles d'entrée (*ingress rules*) et 200 régles de sortie (*egress rules*) - impossible d'augmenter cette limite |
| Connecteurs de service (*Service connectors*)      | Region           | 5                                                                           |
| Coffre-fort à secrets (*Vaults*)                  | Tenancy          | 10                                                                          |
| Clés (*Keys*)                    | Vault            | 100                                                                         |
| Passerelles de routage dynamique (DRG)                     | Region           | 5 (impossible d'augmenter cette limite)                                     |
| Attachement à un réseau virtuel infonuagique (*VCN attachments*)         | DRG              | 300                                                                         |
| Adresses IP réservées (*Reserved public IP*)     | Region           | 50                                                                          |
| Adresses IP temporaires (*Ephemeral public IP*)    | Instance         | 2 par VM et 16 par bare metal                                               |

[Retour à la Page d'accueil](../../ReadMe.md)
