
# Configuration de base du service Cloud Guard dans une zone d'accueil OCI

## Sommaire   

* [Introduction](#introduction)   
* [Portée surveillance de base Cloud Guard](#portée-surveillance-de-base-cloud-guard)   
* [Recettes de surveillance de base Cloud Guard](#recettes-de-surveillance-de-base-cloud-guard)   
  * [Recette Cloud Guard de détection de mauvaises configurations](#recette-cloud-guard-de-détection-de-mauvaises-configurations)   
  * [Recette Cloud Guard de détection d'activités illicites](#recette-cloud-guard-de-détection-activités-illicites)   
  * [Recette Cloud Guard de détection de menaces](#recette-cloud-guard-de-détection-de-menaces)   
  * [Recette de répondant](#recette-de-répondant)
* [Recommendations pour personnaliser et optimiser la surveillance Cloud Guard sur votre environnement](#recommendations-pour-personnaliser-et-optimiser-la-surveillance-cloud-guard-sur-votre-environnement)
* [Etat de la configuration Cloud Guard actuelle dans la zone d'accueil OCI](#etat-de-la-configuration-cloud-guard-actuelle-dans-la-zone-accueil-oci)   
  * [Le service Cloud Guard est activé dans la zone accueil OCI](#le-service-cloud-guard-est-activé-dans-la-zone-accueil-oci)
  * [Le script Terraform déploie une cible Cloud Guard sur le compartiment racine](#le-script-terraform-déploie-une-cible-cloud-guard-sur-le-compartiment-racine)
  * [Le script Terraform déploie 4 recettes Cloud Guard](#le-script-terraform-déploie-4-recettes-cloud-guard)   
    * [Liste des règles Cloud Guard de détection de configuration déployée par le script Terraform](#liste-des-règles-cloud-guard-de-détection-de-configuration-déployée-par-le-script-terraform) 
    * [Liste des règles Cloud Guard de détection de menace déployée par le script Terraform](#liste-des-règles-cloud-guard-de-détection-de-menace-déployée-par-le-script-terraform)
    * [Liste des règles Cloud Guard de détection d'activités illicites déployée par le script Terraform](#liste-des-règles-cloud-guard-de-détection-activités-illicites-déployée-par-le-script-terraform)
    * [Liste des répondants Cloud Guard déployée par le script Terraform](#liste-des-répondants-cloud-guard-déployée-par-le-script-terraform) 
  * [Détection de 20 mauvaises configurations par la surveillance Cloud Guard](#détection-de-20-mauvaises-configurations-par-la-surveillance-cloud-guard)   
* [Comparaison entre la configuration actuelle et la configuration attendue](#comparaison-entre-la-configuration-actuelle-et-la-configuration-attendue)
* [Perspectives](#perspectives)



## Introduction   

Cloud Guard est un service Oracle Cloud Infrastructure qui fournit un tableau de bord central permettant de surveiller toutes les ressources cloud afin de détecter les failles de sécurité dans la configuration, ainsi que vos opérateurs et utilisateurs à la recherche d'activités à risque. Lorsqu'il détecte un problème, il peut faire des suggestions, proposer une assistance ou effectuer des actions correctives, en fonction de votre configuration Cloud Guard.   

L'objectif de ce papier est de spécifier les paramétres de surveillance Cloud Guard par défaut , prêts à l'emploi , lors de la livraison d'une zone d'accueil OCI.  


## Portée surveillance de base Cloud Guard   

Une cible définit la portée de ce que Cloud Guard doit vérifier. Pour Oracle Cloud Infrastructure, cette portée est liée au compartiment dans lequel la cible est définie et à tous les compartiments enfant jusqu'à ce qu'une autre cible soit rencontrée. La nouvelle cible rencontrée prend le relais à partir de ce point vers les compartiments descendants.

Une zone d'accueil OCI est livrée avec une cible sur le compartiment racine du tenant. A travers cette cible , Cloud Guard va analyser régulièrement les ressources pour détecter des violations de stratégie Cloud Guard.  

Cette surveillance inclut l'ensemble des sous-compartiments du tenant.

Cette surveillance va s'appuyer sur [3 recettes de détecteur](#recettes-de-surveillance-cloud-guard-de-base).   


![liste_regle_detection_configuration_page_1](../../images/cloud_guard_oci/portee_cible_compartiment_racine.png)


|  Propriété | Valeur  |
|------|-------------|
| Nom de la cible | ${var.service_label}-cloud-guard-cible-racine |
| Compartiment associée | Compartiment racine |
| Portée de la cible | Compartiment racine , compartiment englobant de la zone d'accueil et tous les 9 compartiments dans la zone d'accueil |
| Rôle de la cible | Surveiller les stratégies IAM de la zone d'accueil dans compartiment racine |
| Recettes de la cible  | Recette de détection de mauvaises configurations , gérée par OCI |
|           | Recette de détection de menace , gérée par OCI |
|           | Recette de détection d'activités illicites, gérée par OCI |
|           | Recette de répondant , gérée par OCI |



Chaque recette de détecteur définit une liste de problèmes de sécurité potentiels.   


* [Retour au Sommaire](#sommaire)


# Recettes de surveillance de base Cloud Guard   

La surveillance se fait via des recettes qui fournissent les valeurs de référence pour l'examen des ressources et des activités dans le compartiments racine et le compartiment englobant la zone d'accueil OCI.  

Dans OCI , il existe 2 types de recettes : 

* Recette de détecteur gérée par Oracle ; elles sont fournies par Oracle et sont mises à jour uniquement par Oracle et non par un utilisateur de Oracle
* Recette de détecteur gérée par l'utilisateur ; elles sont créées en clonant une recette gérée par Oracle. Utiliser ce type de recette pour désactiver des règles individuelles et modifier le niveau de risque d'une règle gérée par Oracle.

La zone d'accueil OCI est livrée avec des ```recettes utilisateur``` en clonant des recettes gérées par Oracle.   

Voici les recettes de détection dans la configuration de base Cloud Guard.

* [Retour au Sommaire](#sommaire)

## Recette Cloud Guard de détection de mauvaises configurations   


C'est un ensemble de règles conçu spécifiquement pour détecter les paramètres de configuration de ressource susceptibles de poser un problème de sécurité.


Voici la liste des ```43 règles Cloud Guard de détection de configuration``` , qui seront dans la configuration de base d'une zone d'accueil OCI  

|  Règle de détection de configuration | Niveau de risque  |
|------|-------------|
| API key is too old | Moyen |
| Block Volume is encrypted with Oracle-managed key | Mineur |
| Bucket is public | Critique |
| Data Safe is not enabled | Moyen |
| Database System has public IP address | Elevé |   
| Database System is publicly accessible | Critique |
| Database System version is not sanctioned | Critique |
| Database is not backed up automatically | Elevé |
| Database is not registered in Data Safe | Moyen |
| Database patch is not applied | Moyen |
| Database system patch is not applied | Moyen |
| Database version is not sanctioned | Critique |
| IAM Auth token is too old | Moyen |
| IAM Customer secret key is too old | Moyen |
| IAM group has too few members | Faible |
| IAM group has too many members | Moyen |
| Instance has a public IP address | Elevé |
| Instance is publicly accessible | Critique |
| Instance is running without required Tags | Moyen |
| Key has not been rotated | Moyen |
| Load Balancer has public IP address	| Elevé |
| Load balancer SSL certificate expiring soon | Critique |
| Load balancer allows weak SSL communication | Elevé |  
| Load balancer allows weak cipher suite | Moyen |
| Load balancer has no back-end set | Faible |
| Load balancer has no inbound rules or listeners | Mineur |
| NSG egress rule contains disallowed IP/port | Moyen |
| NSG ingress rule contains disallowed IP/port | Elevé |
| Password is too old | Moyen |
| Password policy does not meet complexity requirements | Faible |
| Policy gives too many privileges | Moyen |
| Resource is not tagged appropriately	| Faible |
| Scanned container image has vulnerabilities	| Critique |
| Scanned host has open ports	| Critique |
| Scanned host has vulnerabilities | Critique |
| Tenancy admin privilege granted to group | Moyen |
| User does not have MFA enabled	| Critique |
| User has API keys | Faible |
| VCN Security list allows traffic to non-public port from all sources (0.0.0.0/0)	| Critique |
| VCN Security list allows traffic to restricted port	| Critique |
| VCN has InternetGateway attached	| Faible |
| VCN has Local Peering Gateway attached	| Faible |
| VNIC without associated network security group	| Mineur |


* [Retour au Sommaire](#sommaire)

## Recette Cloud Guard de détection activités illicites     

C'est un ensemble de règles conçu spécifiquement pour détecter les actions sur les ressources susceptibles de poser un problème de sécurité.  


Voici la liste des ```28 règles Cloud Guard de détection d'activités illicites``` , qui seront dans la configuration de base d'une zone d'accueil OCI  

|  Règle de détection d'activité | Niveau de risque  |
|------|-------------|
| VCN deleted	| Moyen |
| VCN created	| Faible |
| VCN Security List ingress rules changed	| Moyen |
| VCN Security List egress rules changed	| Moyen |
|	VCN Security List deleted	| Moyen |
| VCN Security List created	| Faible |
|	VCN Route Table changed	| Moyen |
| VCN Network Security Group ingress rule changed	| Moyen |
| VCN Network Security Group egress rule changed	| Moyen |
|	VCN Network Security Group Deleted	| Elevé |
| VCN Local Peering Gateway changed	| Moyen |
| VCN Internet Gateway terminated	| Faible |
| VCN Internet Gateway created	| Moyen |
| VCN DHCP Option changed	| Moyen |
| User added to group	| Mineur |
| Update Image	| Faible |
| Suspicious Ip Activity	| Critique |
| Subnet deleted | Faible |
| Subnet Changed	 | Faible |
| Security policy modified	| Faible |
| Local user authenticated without MFA	| Elevé |
| Intermediate Certificate Authority (CA) revoked	| Elevé |
| Instance terminated	| Elevé |
| Import Image	| Mineur |
| IAM User capabilities modified	| Faible |
| Export Image | Mineur |
| Database System terminated	| Elevé |
| Certificate Authority (CA) deleted	| Moyen |



* [Retour au Sommaire](#sommaire)

## Recette Cloud Guard de détection de menaces   


C'est un ensemble de règles conçues spécifiquement pour détecter dans votre environnement des modèles d'activité subtils dont l'accumulation est susceptible de poser un problème de sécurité.

Dans la configuration Cloud Guard attendue , aucune règle de détection de menace ne sera déployée.

Un OP pourra activer la détection de menace , suivant la sensibilité de ses affaires.

* [Retour au Sommaire](#sommaire)

## Recette de répondant   

Lorsque l'un des 71 détecteurs ci-dessus identifie un problème , Cloud Guard peut effectuer une action. Les actions disponibles sont propres aux ressources.   

Une recette de répondant définit l'action ou l'ensemble d'actions à entreprendre en réaction à un problème identifié par un détecteur.   


Dans toute zone d'accueil OCI , nous proposons par défaut une action , un déclencheur , qui permet à la surveillance de la sécurité du cloud de s'intégrer aux processus et procédures existants d'un OP. Ainsi , l'équipe InfoSec d'un OP peut intégrer les problèmes Cloud Guard à leurs outils SIEM internes pour relier les problèmes Cloud Guard à leurs processus internes. Ces intégrations peuvent utiliser les API Cloud Guard et/ou les services d'infrastructure OCI existants tels qu'OCI Events, OCI Notifications, et OCI Functions. 

|  Règle de répondeur | Type  |
|------|-------------|
| Cloud Event | Notification |



* [Retour au Sommaire](#sommaire)

## Recommendations pour personnaliser et optimiser la surveillance Cloud Guard sur votre environnement   

Bien que Cloud Guard commence à fonctionner dès son activation dans votre zone d'accueil, vous devez affiner la configuration des détecteurs et des répondeurs pour mieux répondre aux besoins spécifiques de votre environnement.


### En tant que OP , vous pouvez ajouter votre propre cible , sur un compartiment englobant ou sur un sous-compartiment.   

Vos paramètres de surveillance prendront ainsi le relais sur la configuration de base du CEI et Cloud Guard va l'appliquer à partir de votre portée , vers les compartiments descendants.   

### Créer un groupe utilisateurs du service de protection Cloud Guard   

Le service Cloud Guard traite les informations de sécurité globalement et devrait être accessible à un public restreint.

Suivre les étapes suivantes pour créer manuellement ce groupe d'utilisateurs : https://docs.oracle.com/fr-ca/iaas/cloud-guard/using/prerequisites.htm#prereq-user-group 

Puis ajouter dans le groupe créé , les utilisateurs autorisées à utiliser le service Cloud Guard.   

### Pour surveiller les stratégies IAM, le compartiment racine doit être une cible.   


### Faux positif après le déploiement de vos charges de travail   

Après le déploiement de vos charges de travail , lorsque vous examinez les problèmes détectés par Cloud Guard, vous pouvez constater que certains problèmes sont des faux positifs en fonction de votre scénario d'utilisation. Par exemple, les règles de détecteur "L'instance est accessible publiquement" et "L'instance dispose d'une adresse IP publique" détectent les instances de vos cibles (compartiment) accessibles à partir d'Internet et disposant d'une adresse IP publique. Cependant, vous voulez autoriser une instance de calcul de démonstration/de formation à disposer d'une adresse IP publique et à l'avoir accessible à partir d'Internet.

Pour ce faire, vous pouvez configurer des groupes conditionnels dans les règles de détecteur Cloud Guard et le faire pour presque tous les types de règle de détecteur.   

Vous pouvez aussi filtrer et s'attarder sur les problèmes sur votre compartiment de référence uniquement

### Cloner les recettes de base pour les adapter aux besoins spécifiques de votre environnement

Même si vous pouvez utiliser les recettes gérées par Oracle telles quelles, il vous faudra probablement apporter des modifications pour les adapter aux besoins spécifiques de votre environnement. En particulier, vous voudrez peut-être modifier le niveau de risque associé à certaines règles et désactiver complètement d'autres règles.   

Voici quelques raisons pour lesquelles disposer de différentes recettes :

* Traitement différent des charges globales de production et hors production   
* Opérations ou processus de notification distincts pour les ressources de différents compartiments   
* Exigences régionales pour les ressources de certains compartiments   
* Différents types de ressource nécessitant différentes règles pour la configuration ou l'activité   
* Si un testeur aura besoin d'une adresse IP publique pour une instance de calcul pour une raison réelle, mais que l'activité du répondeur Cloud Guard va enlever l'adresse IP publique de l'instance lors de la détection.    

Pour effectuer ces changements, [clonez](https://docs.oracle.com/fr-fr/iaas/cloud-guard/using/detect-recipes-clone.htm) d'abord la recette de base (gérée par Oracle) pour créer une copie gérée par l'utilisateur, puis modifiez cette dernière.   

### Stratégies Cloud Guard 

Par défaut, seuls les utilisateurs du groupe **Administrators** ont accès à toutes les ressources Cloud Guard. Pour tous les autres utilisateurs de Cloud Guard, vous devez créer des stratégies qui leur affectent les droits appropriés sur les ressources Cloud Guard.

Lien Annexe :  https://docs.oracle.com/fr-fr/iaas/cloud-guard/using/policies.htm   

### Configuration des notifications Cloud Guard   

Vous pouvez utilisez les services Events et Notifications pour recevoir des notifications chaque fois que Cloud Guard détecte un problème dont vous souhaitez être averti.

Lien Annexe :  https://docs.oracle.com/fr-fr/iaas/cloud-guard/using/export-notifs-config.htm   

 ### Réviser vos règles Cloud Guard chaque mois   

 Il est recommandé de réviser les recettes , les règles Cloud Guard chaque mois et d'activer de nouvelles règles lorsqu'elles semblent appropriées.   


* [Retour au Sommaire](#sommaire)



## Etat de la configuration Cloud Guard actuelle dans la zone accueil OCI 

Que trouve t-on actuellement dans la configuration Cloud Guard actuelle dans la zone d"accueil OCI v2.1 ?

### Le service Cloud Guard est activé dans la zone accueil OCI

Lors de la configuration de la [posture de sécurité dans la pile de déploiement d'une zone d'accueil OCI](../../Déploiement/Deploi_Script.md#notification-et-posture-de-sécurité) , le service Cloud Guard est activé.  

![Connecter_réseaux](../../images/DP_Ecran14.png)

### Le script Terraform déploie une cible Cloud Guard sur le compartiment racine   

Le script Terraform déploie une cible Cloud Guard sur le compartiment racine   

Cette cible surveille le compartiment racine et tous ses compartiments enfants   


![cible_pour_zone_accueil_oci_deployee](../../images/cloud_guard_oci/scenario2/cible_pour_zone_accueil_oci_deployee.JPG)   

Le nom de cette cible est ceicg02-cloud-guard-root-target , où ceicg02 est l'étiquette ( service label ) utilisé dans la pile déploiement   
 

### Le script Terraform déploie 4 recettes Cloud Guard

4 recettes gérées par OCI sont déployées et ajoutées dans le mode de surveillance et de réaction

* **1 recette de détecteur** (de problèmes de type Menace) avec **1 règle**. Ce type de règle est conçue spécifiquement pour détecter dans votre zone d'accueil des modèles d'activité subtils dont l'accumulation est susceptible de poser un problème de sécurité.   
* **1 recette de détecteur** (de problèmes de type Configuration) avec **50 règles**. Ces règles sont conçues spécifiquement pour détecter les paramètres de configuration de ressource susceptibles de poser un problème de sécurité dans votre zone d'accueil.   
* **1 recette de détecteur** (de problèmes de type Activité) avec **28 règles**. Ces règles sont conçues spécifiquement pour détecter les actions sur les ressources susceptibles de poser un problème de sécurité de votre zone d'accueil.    
* **1 recette de répondeur** avec **10 résolutions** qui vont corriger les problèmes de sécurité en fonction d'un problème identifié    

![detail_cible_recette_detecteur_za_oci](../../images/cloud_guard_oci/scenario2/detail_cible_recette_detecteur_za_oci.JPG)      

#### Liste des répondants Cloud Guard déployée par le script Terraform 

Voici la liste des ```10 actions Cloud Guard``` , livrées dans la configuration actuelle d'une zone d'accueil OCI 

![liste_action_en_reponse_a_un_probleme](../../images/cloud_guard_oci/liste_regle_repondeur.JPG)


```Dans la liste se trouve une action , Cloud Event , qui permettra à Cloud Guard de notifier un système tiers ( votre SIEM par exemple ) , de tout problème détectée.```  

* [Retour au Sommaire](#sommaire)   


#### Liste des règles Cloud Guard de détection de menace déployée par le script Terraform

Voici la ```règle Cloud Guard de détection de menace``` , livrée dans la configuration de base d'une zone d'accueil OCI

![liste_regle_detection_menace](../../images/cloud_guard_oci/liste_regle_detection_menace.JPG)

#### Liste des règles Cloud Guard de détection de configuration déployée par le script Terraform


Voici la liste des ```50 règles Cloud Guard de détection de mauvaises configurations``` , livrée dans une zone d'accueil OCI 

![liste_regle_detection_configuration_page_1](../../images/cloud_guard_oci/liste_regle_detection_configuration_page_1.JPG)


![liste_regle_detection_configuration_page_2](../../images/cloud_guard_oci/liste_regle_detection_configuration_page_2.JPG)


![liste_regle_detection_configuration_page_3](../../images/cloud_guard_oci/liste_regle_detection_configuration_page_3.JPG)


* [Retour au Sommaire](#sommaire)   


#### Liste des règles Cloud Guard de détection activités illicites déployée par le script Terraform


Voici la liste des ```48 règles Cloud Guard de détection d'activités illicites``` , livrée dans une zone d'accueil OCI  

![liste_regle_detection_activite_page_1](../../images/cloud_guard_oci/liste_regle_detection_activite_page_1.JPG)


![liste_regle_detection_activite_page_2](../../images/cloud_guard_oci/liste_regle_detection_activite_page_2.JPG)


![liste_regle_detection_activite_page_3](../../images/cloud_guard_oci/liste_regle_detection_activite_page_3.JPG)


* [Retour au Sommaire](#sommaire)   


### Détection de 20 mauvaises configurations par la surveillance Cloud Guard

Une fois la zone d'accueil activée , la surveillance Cloud Guard détecte 20 mauvaises configurations dans la la zone d'accueil OCI

![problemes_cloud_guard_dans_une_za_oci](../../images/cloud_guard_oci/problemes_cloud_guard_dans_une_za_oci.png)   
   


* [Retour au Sommaire](#sommaire)


## Comparaison entre la configuration actuelle et la configuration attendue   


|  Critère d'évaluation | Configuration actuelle  | Configuration attendue  |
|------|-------------|-------------|
| Nombre de stratégies Cloud Guard dans la recette de détection de menace | [1](#liste-des-règles-cloud-guard-de-détection-de-menace-déployée-par-le-script-terraform) | [0](#recette-cloud-guard-de-détection-de-menaces) |
| Nombre de stratégies Cloud Guard dans la recette de détection de mauvaises configurations | [50](#liste-des-règles-cloud-guard-de-détection-de-configuration-déployée-par-le-script-terraform) | [43](#recette-cloud-guard-de-détection-de-mauvaises-configurations) |
| Nombre de stratégies Cloud Guard dans la recette de détection d'activités illicites | [48](#recette-cloud-guard-de-détection-activités-illicites) | [20](#recette-cloud-guard-de-détection-activités-illicites) |
| Nombre de stratégies Cloud Guard dans la recette de répondant | [10](#liste-des-répondants-cloud-guard-déployée-par-le-script-terraform) | [1](#recette-de-répondant) |
| Présence d'une cible Cloud Guard sur le compartiment racine | OUI | OUI |
| Présence d'une cible Cloud Guard sur le compartiment englobant | NON | NON |
| Préfixe du déploiement dans le nom de la cible Cloud Guard | NON | OUI |
| Présence d'une Recette de détection de menace ? | OUI | OUI |
| Type de Recette de détection de menace | OCI | Utilisateur |
| Présence d'une Recette de détection d'activités illicites ? | OUI | OUI |
| Type de recette de détection d'activités illicites | OCI | Utilisateur |
| Présence d'une Recette de détection de mauvaises configurations | OUI | OUI |
| Type de recette de détection de mauvaises configurations | OCI | Utilisateur |
| Présence d'une Recette de répondant ? | OUI | OUI |
| Type de recette de répondant | OCI | Utilisateur |
| Préfixe du déploiement dans le nom de la recette Cloud Guard | NON | OUI |

Il ressort du tableau comparatif ci-dessus que : 

- 1 stratégie Cloud Guard dans la recette de détection de menace sera retirée du maximum de stratégies   
- 50 - 43 = 7 stratégie Cloud Guard dans la recette de détection de mauvaises configurations sera retirée du maximum de stratégies   
- 48 - 20 = 28 stratégies Cloud Guard dans la recette de détection d'activités illicites seront retirées du maximum de stratégies   
- 10 - 1 = 9 stratégies Cloud Guard dans la recette de répondant seront retirées du maximum de stratégies   


Voici les stratégies Cloud Guard retirées :   


|  Nom de la stratégie Cloud Guard | Type de recette  |
|------|-------------|
| Rogue User | Détection de menace |
| Block Volume is not attached | Détection de configuration |
| Instance is not running an Oracle public image | Détection de configuration |
| Instance is running an Oracle public image | Détection de configuration |
| Object Storage bucket is encrypted with Oracle-managed key | Détection de configuration |
| Read Log access disabled for bucket	| Détection de configuration |
| VCN has no inbound Security List	| Détection de configuration |
| Write Log access disabled for bucket	| Détection de configuration |
| User removed from group	| Détection d'activité |
| IAM User created	| Détection d'activité |
| IAM User UI password created or reset	| Détection d'activité |
| IAM OAuth 2.0 credentials deleted	| Détection d'activité |
| IAM OAuth 2.0 credentials created	| Détection d'activité |
| IAM Group deleted	| Détection d'activité |
| IAM Group created | Détection d'activité |
|	IAM Customer keys deleted	| Détection d'activité |
| IAM Customer keys created	| Détection d'activité |
| IAM Auth token deleted	| Détection d'activité |
| IAM Auth token created	| Détection d'activité |
| IAM API keys deleted	| Détection d'activité |
| IAM API keys created	| Détection d'activité |
| DRG detached from a VCN	| Détection d'activité |
| DRG deleted	| Détection d'activité |
| DRG created	| Détection d'activité |
| DRG attached to a VCN	| Détection d'activité |
| CA bundle updated	| Détection d'activité |
| Bastion session created	| Détection d'activité |
| Bastion created	| Détection d'activité |
| Delete IAM Policy	| REMEDIATION |  
| Delete Internet Gateway	| REMEDIATION	|
|	Delete Public IP(s)	| REMEDIATION	|
|	Disable IAM User	| REMEDIATION	|
|	Enable DB Backup	| REMEDIATION	|
|	Make Bucket Private	| REMEDIATION	|
|	Rotate Vault Key	| REMEDIATION	|
|	Stop Compute Instance	| REMEDIATION	|
|	Terminate Compute Instance	| REMEDIATION |


## Perspectives

Nous voyons dans l'étude comparative des différences entre la configuration Cloud Guard actuelle et la configuration de base attendue.   

De plus la surveillance Cloud Guard signale 20 mauvaises configurations dans ladite Zone d'accueil.

Pour compléter nos spécifications , il faudrait pour la suite analyser chacun de ces 20 problèmes...   

1 - Est-ce des faux positifis ? Si oui , il faudrait identifier les règles Cloud Guard à désactiver afin que ces positifs n'apparaissent pas à la livraison de la zone d'accueil OCI .    

- Étant donné que dans OCI , il est impossible de créer une nouvelle règle Cloud Guard   
- Étant donné que dans OCI , pour surcharger une règle il faut d'abord la cloner 

Pour implémenter les nouvelles règles , il faudra reprendre le script Terraform afin de rendre effectif le clonage de règles Cloud Guard

2 - Si les problèmes sont réels , il faut les analyser en détails et proposer des pistes de résolutions. Faut-il revoir l'architecture Hub & Spoke ? Faut-il diviser certaines stratégies IAM en plusieurs autres stratégies IAM ? Faut-il retirer certaines instances , certaines passerelles Internet , certaines ressources OCI dans la zone d'accueil OCI ? 

* [Retour au Sommaire](#sommaire)  
* [Retour à la Page d'accueil](../../../README.md)   

