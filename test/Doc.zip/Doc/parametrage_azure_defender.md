**Sommaire**

- [Paramétrage général de Microsoft Azure Defender](#paramétrage-général-de-microsoft-azure-defender)
- [ Paramétrage de Microsoft Azure Defender par abonnement plateforme](#-paramétrage-de-microsoft-azure-defender-par-abonnement-plateforme)
- [ Paramétrage de Microsoft Azure Defender par abonnement zone accueil](#-paramétrage-de-microsoft-azure-defender-par-abonnement-zone-accueil)

## <a id="parametragegeneral"></a>Paramétrage général de Microsoft Azure Defender

Suivant le scénario de déploiement (de base OU complexe), voici les paramètres à modifier pour la configuration de Microsoft Defender dans un abonnement plateforme.


| Variable                                                   | Description                                                                                                                                                                                                                 | Valeur par défaut                                                  | Fichier                                                                                                                                                                                                        |
| ------------------------------------------------------------ | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | --------------------------------------------------------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| ```var-custom-policy_security_contact```                   | Adresse électronique de la liste de diffusion pour Microsoft Defender                                                                                                                                                      | Aucune                                                              | [cei-base-param.yml](../azure-pipeline/config/variables/scenario-base/cei-base-param.yml)   OU [cei-complexe-param.yml](../azure-pipeline/config/variables/scenario-complexe/cei-complexe-param.yml)           |
| ```var-azure-defender-param-notification-email```          | Liste des configurations pour la section "Notification par e-mail" dans Microsoft Defender                                                                                                                                  | Aucune                                                              | [cei-base-defender.yml](../azure-pipeline/config/variables/scenario-base/cei-base-defender.yml) OU [cei-complexe-defender.yml](../azure-pipeline/config/variables/scenario-complexe/cei-complexe-defender.yml) |
| ```var-azure-defender-param-provisionnement-automatique``` | Liste des extensions de la section "Provisionnement automatique" à activer dans Microsoft Defender                                                                                                                         | {"agentLogAnalyticsPourVM":"On", "evaluationVulnerabiliteVM": "On"} | [cei-base-defender.yml](../azure-pipeline/config/variables/scenario-base/cei-base-defender.yml) OU [cei-complexe-defender.yml](../azure-pipeline/config/variables/scenario-complexe/cei-complexe-defender.yml) |
| ```var-azure-defender-param-espace-travail-logAnalytics``` | Configuration de l'espace de travail Log Analytics dans Microsoft Defender dédié aux événements de sécurité                                                                                                           | Aucune                                                              | [cei-base-defender.yml](../azure-pipeline/config/variables/scenario-base/cei-base-defender.yml) OU [cei-complexe-defender.yml](../azure-pipeline/config/variables/scenario-complexe/cei-complexe-defender.yml) |
| ```var-azure-defender-param-free```                        | Configuration de Microsoft Defender, pour le plan gratuit                                                                                                                                                                   | Aucune                                                              | [cei-base-defender.yml](../azure-pipeline/config/variables/scenario-base/cei-base-defender.yml)                                                                                                                |
| ```var-azure-defender-param-P1```                          | Configuration de Microsoft Defender, pour le plan[P1](https://learn.microsoft.com/fr-ca/azure/defender-for-cloud/defender-for-servers-introduction). Ce sera la configuration pour tous les abonnements sauf Prod-Sensible. | Aucune                                                              | [cei-base-defender.yml](../azure-pipeline/config/variables/scenario-base/cei-base-defender.yml) OU [cei-complexe-defender.yml](../azure-pipeline/config/variables/scenario-complexe/cei-complexe-defender.yml) |
| ```var-azure-defender-param-P2```                          | Configuration de Microsoft Defender, pour le plan[P2](https://learn.microsoft.com/fr-ca/azure/defender-for-cloud/defender-for-servers-introduction). Ce sera la configuration pour l'abonnement Prod-Sensible.              | Aucune                                                              | [cei-base-defender.yml](../azure-pipeline/config/variables/scenario-base/cei-base-defender.yml) OU [cei-complexe-defender.yml](../azure-pipeline/config/variables/scenario-complexe/cei-complexe-defender.yml) |

## <a id="parametrageparabonnementplateforme"></a> Paramétrage de Microsoft Azure Defender par abonnement plateforme

L'assignation d'un plan Microsoft Defender sur un abonnement plateforme (connectivité, gestion et identité) se fait dans le fichier [cei-base-hierarchie.yml](../azure-pipeline/config/variables/scenario-base/cei-base-hierarchie.yml) OU [cei-complexe-hierarchie.yml](../azure-pipeline/config/variables/scenario-complexe/cei-complexe-hierarchie.yml), qui contient la hiérarchie des groupes d'administration. Assigner un plan Microsoft Defender à un groupe d'administration et tous les abonnements de ce groupe hériteront dudit plan.

Si aucun plan n'est défini sur un groupe d'administration, le [script](../hub-and-spokes/spokes/azure_defender_gpeadmin.bicep) ne fera aucun déploiement Microsoft Defender for Cloud dans tous les abonnements dudit groupe.

Exemple de plan par abonnement plateforme :

```

var-managementgroup-subscription-identite: >
{
"subscriptions": ["'$(var-platform-identite-subscriptionId)'"],
"managementgroup": "Identite",
"azDefenderParam": $(var-azure-defender-param-P1)
}

var-managementgroup-subscription-gestion: >
{
"subscriptions": ["'$(var-platform-gestion-subscriptionId)'"],
"managementgroup": "Gestion",
"azDefenderParam": $(var-azure-defender-param-P1)
}

var-managementgroup-subscription-hub: >
{
"subscriptions": ["'$(var-platform-hub-subscriptionId)'"],
"managementgroup": "Connectivite",
"azDefenderParam": $(var-azure-defender-param-P1)
}

```

Puis, dans le paramètre *```var-managementgroup-subscriptions```* , définir la liste des groupes d'administration (par ricochet, la liste des abonnements plateforme) sur lesquels on veut effectivement configurer Microsoft Azure Defender.

La configuration effective de Microsoft Defender par abonnement plateforme (connectivité, gestion et identité) se fera lors du lancement du pipeline [```platform.yml```](etapes_deploiement.md).

## <a id="parametrageparabonnementzoneaccueil"></a> Paramétrage de Microsoft Azure Defender par abonnement zone accueil

Suivant le scénario de déploiement, la configuration de Microsoft Defender par abonnement zone d'accueil se fait dans le fichier [azure-pipeline/config/variables/scenario-base/cei-base-lz.yml](../azure-pipeline/config/variables/scenario-base/cei-base-lz.yml) OU [azure-pipeline/config/variables/scenario-complexe/cei-complexe-lz.yml](../azure-pipeline/config/variables/scenario-complexe/cei-complexe-lz.yml).

Dans ce fichier, pour chaque objet représentant la configuration d'une zone d'accueil, ajouter la propriété ```*azDefenderParam*``` et définir le plan (P1 , P2) pour l'activation de Microsoft Defender.

Exemple :

azDefenderParam: $(var-azure-defender-param-P1)

Ensuite, aller dans le fichier [cei-base-hierarchie.yml](../azure-pipeline/config/variables/scenario-base/cei-base-hierarchie.yml) OU [cei-complexe-hierarchie.yml](../azure-pipeline/config/variables/scenario-complexe/cei-complexe-hierarchie.yml), puis définir le plan Microsoft Azure Defender par groupe d'administration (par abonnement zone accueil, par ricochet).

Exemple de plan par abonnement zone accueil :

```

var-managementgroup-subscription-nonsensibles: >
{
"subscriptions":  ["'$(var-charges-nonsensibles-subscriptionId)'"],
"managementgroup": "NonSensibles",
"azDefenderParam": $(var-azure-defender-param-P1)
}

var-managementgroup-subscription-sensibles: >
{
"subscriptions":  ["'$(var-charges-sensibles-subscriptionId)'"],
"managementgroup": "Sensibles",
"azDefenderParam": $(var-azure-defender-param-P2)
}

var-managementgroup-subscription-nonprod: >
{
"subscriptions":  ["'$(var-charges-nonprod-subscriptionId)'"],
"managementgroup": "NonProduction"
}

Si aucun plan n'est défini sur un groupe d'administration, le script ne fera aucun déploiement Microsoft Defender for Cloud dans tous les abonnements dudit groupe.

Rester dans le même fichier et, dans le paramètre *```var-managementgroup-subscription-lz```* , définir la liste des groupes d'administration (par ricochet, la liste des abonnements zone accueil) sur lesquels on veut effectivement configurer Microsoft Azure Defender.

var-managementgroup-subscription-lz: >
[
$(var-managementgroup-subscription-intranet-prod),
$(var-managementgroup-subscription-intranet-uat),
$(var-managementgroup-subscription-intranet-dev),
$(var-managementgroup-subscription-servicesenligne-prod),
$(var-managementgroup-subscription-servicesenligne-uat),
$(var-managementgroup-subscription-servicesenligne-dev),
$(var-managementgroup-subscription-bureautique-prod),
$(var-managementgroup-subscription-bureautique-uat),
$(var-managementgroup-subscription-bureautique-dev)
]

```

La configuration effective de Microsoft Defender par abonnement zone accueil se fera lors du lancement du pipeline [```landingzones.yml```](etapes_deploiement.md).
