# Contrôles de sécurité pour l'exigence minimale 10

10 : Mettre en place des services de cyberdéfense

Contrôles liés à l'exigence 10 :
AU-6, AU-12, AU-12(1), AU-12(2), CM-3, CM-5(2), CM-5(3), CM-6(1), CM-6(2), CM-7(5), CM-8, CM-8(1), CM-8(2), CM-8(3), CM-8(4), CM-8(5), CM-8(6), CM-10, CM-10(1), CP-9, CP-9(1), CP-9(2), CP-9(3), CP-9(5), CP-9(7), CP-10, CP-10(2), CP-10(4), CP-10(6), RA-5(3), RA-5(4), RA-5(5), RA-5(6), RA-5(8), RA-5(10), SA-11, SA-11(1), SA-11(2), SA-11(5), SA-11(6), SA-11(7), SA-11(8), SA-15(4), SI-2, SI-2(1), SI-2(2), SI-2(3), SI-2(6), SI-3, SI-3(1), SI-3(2), SI-3(6), SI-3(7), SI-3(10), SI-4, SI-4(1), SI-4(2), SI-4(4), SI-4(5), SI-4(7), SI-7, SI-7(2), SI-7(3), SI-7(5), SI-7(7). SI-7(14), SI-16

## < --- Contrôle EX10_AU-6--->

![EX10](../images/ex10_AU-6.PNG)

## Validation Contrôle EX10_AU-6

   1. Responsabilité fournisseur : Oui
   2. Commentaire : Le rapport du Protégé B doit être lancé manuellement. Un processus administratif hebdomadaire est à prévoir pour le lancer et le vérifier.
   Les services de Vulnerability Scanning et Data Safe comportent des fonctionnalités pour planifier les rapports. Il faut programmer et vérifier ces rapports une fois par semaine.
   Scanning --> Scan recipes --> Scan recipe details
   Data Safe --> Security Assessment -->Schedules
   Data Safe --> User Assessment -->Schedules
   3. [Lien Document](https://docs.oracle.com/en-us/iaas/scanning/using/host-vulnerabilities-reports.htm)

## < --- Contrôle EX10_AU-12--->

![EX10](../images/ex10_AU-12.PNG)

## Validation Contrôle EX10_AU-12

   1. Responsabilité fournisseur : Oui
   2. Commentaire :
   A) Tous les changements de configuration au locataire (*tenant*) créent automatiquement un enregistrement dans OCI Audit. Par le biais d'OIC Audit, il est
      possible de visualiser et de rechercher ces enregistrements. Des notifications sont également disponibles par OCI Notifications. Il est possible de s'abonner à un ou plusieurs sujets (*'topic'*) du service de notification. Observability & Management--> Audit Developer Services --> Notifications --> Topics
   B) Le script de zone d'accueil crée des groupes et des stratégies (*policies*) pour les principaux rôles TI d'une organisation type. Le script crée également des sujets (*'Topics'*) pour le service de notification pour différentes catégories d'événements. Il faut s'assurer d'associer les sujets aux bons utilisateurs. Identité & Sécurité --> Groups Developer Services --> Notifications --> Topics
   3. [Lien Document](https://docs.oracle.com/en-us/iaas/Content/Notification/Concepts/notificationoverview.htm)

## < --- Contrôle EX10_AU-12(1)--->

![EX10](../images/ex10_AU-12(1).PNG)

## Validation Contrôle EX10_AU-12(1)

   1. Responsabilité fournisseur : Oui
   2. Commentaire : Tous les changements de configuration au locataire (*tenant*) crée automatiquement un enregistrement dans OCI Audit. Par le biais d'OIC Audit, il est possible de visualiser et de rechercher ces enregistrements. Des notifications sont également disponibles par OCI Notification. Il est possible de s'abonner à un ou plusieurs sujets du service de notification.
    Observability & Management--> Audit
    Developer Services --> Notifications --> Topics
   3. [Lien Document](https://docs.oracle.com/en-us/iaas/Content/Notification/Concepts/notificationoverview.htm)

## < --- Contrôle EX10_AU-12(2)--->

![EX10](../images/ex10_AU-12(2).PNG)

## Validation Contrôle EX10_AU-12(2)

   1. Responsabilité fournisseur : Oui
   2. Commentaire : Les enregistrements d'audit peuvent être exportés en format JSON. De plus, il est possible de les exporter par un connecteur de service (*'Service Connector'*) défini par le script de zone d'accueil. Observability & Management-->Audit : (Export log data (JSON)Export Data) Observability & Management--> Service Connectors (CEI01-audit-sch)
   3. [Lien Document](https://docs.oracle.com/en-us/iaas/Content/service-connector-hub/overview.htm)

## < --- Contrôle EX10_CM-3--->

![EX10](../images/ex10_CM-3.PNG)

## Validation Contrôle EX10_CM-3

   1. Responsabilité fournisseur : Oui
   2. Commentaire : Ce contrôle est à la fois administratif et technique. Il s'agit d'identifier qui peut autoriser des
      changements de configuration, de mettre en place un processus d'approbation et d'en faire le suivi. Si les changements de configuration sont effectués uniquement par du script Terraform, il est alors possible d'approuver les changements au niveau d'un outil de contrôle de source comme : GitHub, GitLab ou DevOps. La journalisation des changements de configuration peut être consultée par Oracle Cloud Guard ou OIC Audit. Developer Services--> Resource Manager --> Stacks --> Create stack : Source code control system Identité & Sécurité --> Cloud Guard -->  Filters (Detector type = IAAS - Activity Detector et Detector type = IAAS - Configuration Detector) Observability & Management-->Audit (Request action types= POST, PUT, PATCH)
   3. [Lien Document1](https://docs.oracle.com/en-us/iaas/Content/ResourceManager/Tasks/update-stack-csp.htm)
      [Lien Document2](https://docs.rackspace.com/blog/oracle-cloud-guard-service-overview/)
      [Lien Document3](https://www.ateam-oracle.com/post/oci-observability-and-management-for-networking-part-one-using-the-audit-log-to-find-changes)

## < --- Contrôle EX10_CM-5(2)--->

![EX10](../images/ex10_CM-5(2).PNG)

## Validation Contrôle EX10_CM-5(2)

   1. Responsabilité fournisseur : Oui
   2. Commentaire : La journalisation des changements de configuration peut être consultée par Oracle Cloud Guard ou OIC Audit. Si les
      changements ont été effectués avec Terraform, il est alors possible de consulter les journaux des tâches Terraform et d'utiliser la fonctionnalité 'Drift Detection'. Identité & Sécurité --> Cloud Guard -->  Filters (Detector type = IAAS - Activity Detector et Detector type = IAAS - Configuration Detector) Observability & Management-->Audit (Request action types= POST, PUT, PATCH) Developer Services-->Resource Manager-->Stacks --> Stack details : run drift detection
   3. [Lien Document1](https://docs.oracle.com/en-us/iaas/Content/ResourceManager/Tasks/update-stack-csp.htm)
      [Lien Document2](https://docs.rackspace.com/blog/oracle-cloud-guard-service-overview/)
      [Lien Document3](https://www.ateam-oracle.com/post/oci-observability-and-management-for-networking-part-one-using-the-audit-log-to-find-changes)
       [Lien Document4](https://blogs.oracle.com/cloud-infrastructure/post/drift-detection-for-infrastructure-resources-using-resource-manager)

## < --- Contrôle EX10_CM-5(3)--->

![EX10](../images/ex10_CM-5(3).PNG)

## Validation Contrôle EX10_CM-5(3)

   1. Responsabilité fournisseur : Non
   2. Commentaire
   3. Lien Document

## < --- Contrôle EX10_CM-6(1)--->

![EX10](../images/ex10_CM-6(1).PNG)

## Validation Contrôle EX10_CM-6(1)

   1. Responsabilité fournisseur : Oui
   2. Commentaire : Si un script Terraform est utilisé, il est alors possible d'automatiser les changements de configuration.
   3. Lien Document

## < --- Contrôle EX10_CM-6(2)--->

![EX10](../images/ex10_CM-6(2).PNG)

## Validation Contrôle EX10_CM-6(2)

   1. Responsabilité fournisseur : Oui
   2. Commentaire : Les changements de configuration ne peuvent être effectués que par les utilisateurs OCI associés aux bons groupes et stratégies (*policies*) créés par le script de zone d'accueil. Il est possible de rendre les changements de configuration plus difficiles par l'utilisation de Security Zones.  
      Identity and Security -->Groups
      Identity and Security -->Policies
      Identity and Security -->Security Zones
   3. [Lien Document](https://docs.oracle.com/en-us/iaas/security-zone/using/get-started.htm)

## < --- Contrôle EX10_CM-7(5)--->

![EX10](../images/ex10_CM-7(5).PNG)

## Validation Contrôle EX10_CM-7(5)

   1. Responsabilité fournisseur : 
   2. Commentaire : Oracle OCI permet la création de services IaaS et PaaS. Le script de zone d'accueil met en place des groupes d'utilisateurs et des stratégies (*policies*) pour contrôler les fonctions de gestion associées à ces services. Tous les services IaaS et PaaS ont plusieurs stratégies granulaires concernant leurs fonctions de gestion pour limiter les ajouts et modifications.  Voir
   Identité et sécurité -->Stratégies
   Il est aussi possible de créer des instances 'personnalisées' d'instance de calcul. Ces instances peuvent être préconfigurées avec un ensemble fixe de logiciels et un ensemble limité de fonctions de gestion.
   Compute -->Images personnalisées
   3. [Lien Document1](https://docs.oracle.com/en-us/iaas/Content/Identity/Concepts/commonpolicies.htm)
      [Lien Document2](https://docs.oracle.com/fr-ca/iaas/Content/Compute/Tasks/managingcustomimages.htm)

## < --- Contrôle EX10_CM-8--->

![EX10](../images/ex10_CM-8.PNG)

## Validation Contrôle EX10_CM-8

   1. Responsabilité fournisseur : Oui
   2. Commentaire : OCI fournit le service Tenancy Explorer qui permet de lister toutes les ressources. Au niveau de la zone d'accueil, CEIZA-02 fournit un inventaire sur les compartiments, le gestionnaire de ressources (*Resources Manager*), les stratégies (*policies*), la DRG Route Table, la DRG Route Distribution et la passerelle de routage dynamique (DRG). L'inventaire présenté par le Tenancy Explorer est toujours à jour. Gouvernance et administration -->Explorateur de location
   3. [Lien Document](https://docs.oracle.com/en-us/iaas/Content/General/Concepts/compartmentexplorer.htm)

## < --- Contrôle EX10_CM-8(1)--->

![EX10](../images/ex10_CM-8(1).PNG)

## Validation Contrôle EX10_CM-8(1)

   1. Responsabilité fournisseur : Oui
   2. Commentaire : OCI fournit le service Tenancy Explorer qui permet de lister toutes les ressources. Au niveau de la zone d'accueil, CEIZA-02 fournit un inventaire sur les compartiments, le gestionnaire de ressources (*Resources Manager*), les stratégies (*policies*), la DRG Route Table, la DRG Route Distiubution et la passerelle de routage dynamique (DRG). L'inventaire présenté par le Tenancy Explorer est toujours à jour. Gouvernance et administration -->Explorateur de location
   3. [Lien Document](https://docs.oracle.com/en-us/iaas/Content/General/Concepts/compartmentexplorer.htm)

## < --- Contrôle EX10_CM-8(2)--->

![EX10](../images/ex10_CM-8(2).PNG)

## Validation Contrôle EX10_CM-8(2)

   1. Responsabilité fournisseur : Oui
   2. Commentaire : L'inventaire présenté par le Tenancy Explorer est toujours à jour. La fonctionnalité de 'OS Management' permet la mise à jour de plusieurs VM au niveau des correctifs, des mises à jour et des logiciels.
      Compute-->OS Management
   3. [Lien Document](https://docs.oracle.com/fr-ca/iaas/os-management/home.htm)

## < --- Contrôle EX10_CM-8(3)--->

![EX10](../images/ex10_CM-8(3).PNG)

## Validation Contrôle EX10_CM-8(3)

   1. Responsabilité fournisseur : Oui
   2. Commentaire :
      A) Le service de balayage de vulnérabilité Oracle permet d'améliorer votre posture de sécurité en vérifiant régulièrement les hôtes
      et les images de conteneurs pour les vulnérabilités potentielles.  
      Les sources/base de données suivantes sont utilisées : National Vulnerability Database, Open Vulnerability and Assessment Language et Center for Internet Security. Identité et sécurité-->Rapports de vulnérabilité
      B) Le service de 'Vulnerability Scanning' transmet les informations concernant les vulnérabilités à Cloud Guard qui possède des fonctionnalités pour exécuter des actions correctrices. Identité et sécurité -->Cloud Guard -->Activité du répondeur
      C) Le service de 'Vulnerability Scanning' transmet les informations concernant les vulnérabilités à Cloud Guard qui possède des fonctionnalités pour exécuter des actions correctrices. Identité et sécurité -->Cloud Guard -->Activité du répondeur
   3. [Lien Document](https://docs.oracle.com/en-us/iaas/scanning/using/overview.htm)

## < --- Contrôle EX10_CM8(4)--->

![EX10](../images/ex10_CM-8(4).PNG)

## Validation Contrôle EX10_CM8(4)

   1. Responsabilité fournisseur : Oui
   2. Commentaire : Chaque ressource OCI est contenue dans un compartiment. Les stratégies (*policies*) indiquent pour chaque compartiment quelles sont les responsabilités de gestion.
   Identité et sécurité --> Stratégies
   3. [Lien Document](https://docs.oracle.com/en-us/iaas/Content/Identity/Concepts/policies.htm)

## < --- Contrôle EX10_CM-8(5)--->

![EX10](../images/ex10_CM-8(5).PNG)

## Validation Contrôle EX10_CM-8(5)

   1. Responsabilité fournisseur : Oui
   2. Commentaire : Le 'Tenancy Explorer' ne présente aucune information en double.
   Gouvernance et administration -->Explorateur de location
   3. [Lien Document](https://docs.oracle.com/en-us/iaas/Content/General/Concepts/compartmentexplorer.htm)

## < --- Contrôle EX10_CM-8(6)--->

![EX10](../images/ex10_CM-8(6).PNG)

## Validation Contrôle EX10_CM-8(6)

   1. Responsabilité fournisseur : Oui
   2. Commentaire : Le service 'Cloud Guard' valide en continu les configurations de votre compte infonuagique. Le Service 'Vulnerability Scanning' valide en continu les configurations de vos instances de calcul. Le service 'Data Safe' valide en continu les configurations de vos bases de données Oracle.
   3. [Lien Document](https://docs.oracle.com/en-us/iaas/scanning/using/overview.htm)

## < --- Contrôle EX10_CM-10--->

![EX10](../images/ex10_CM-10.PNG)

## Validation Contrôle EX10_CM-10

   1. Responsabilité fournisseur : Oui
   2. Commentaire : Oracle OCI crée des instances 'personnalisées' d'instance de calcul. Ces instances peuvent être préconfigurées avec un ensemble fixe de logiciels et un ensemble limité de fonctions de gestion.
      Compute --> Images personnalisées
   3. [Lien Document](https://docs.oracle.com/fr-ca/iaas/Content/Compute/Tasks/managingcustomimages.htm)

## < --- Contrôle EX10_CM-10(1)--->

![EX10](../images/ex10_CM-10(1).PNG)

## Validation Contrôle EX10_CM-10(1)

   1. Responsabilité fournisseur : Oui
   2. Commentaire : Oracle OCI crée des instances 'personnalisées' d'instance de calcul. Ces instances peuvent être préconfigurées avec un ensemble fixe de logiciels et un ensemble limité de fonctions de gestion.
      Compute --> Images personnalisées
   3. [Lien Document](https://docs.oracle.com/fr-ca/iaas/Content/Compute/Tasks/managingcustomimages.htm)

## < --- Contrôle EX10_CP-9--->

![EX10](../images/ex10_CP-9.PNG)

## Validation Contrôle EX10_CP-9

   1. Responsabilité fournisseur
   2. Commentaire : Les fonctionnalités de stockage d'Oracle OCI permettent la prise de copie des VM et des volumes de bloc. Il est
      possible de définir un calendrier de prise de copie complète et/ou incrémentale. Il est possible aussi de définir une période de rétention pour ces copies. Le service de base de données comporte également des fonctions de prise de copie. Stockage --> Stratégies de sauvegarde
   3. [Lien Document](https://docs.oracle.com/fr/solutions/oci-best-practices/back-your-data1.html#GUID-42086962-F4B6-497B-939B-12D1A4824BE9)

## < --- Contrôle EX10_CP-9(1)--->

![EX10](../images/ex10_CP-9(1).PNG)

## Validation Contrôle EX10_CP-9(1)

   1. Responsabilité fournisseur : Non
   2. Commentaire : Ceci est un processus administratif.
   3. Lien Document

## < --- Contrôle EX10_CP-9(2)--->

![EX10](../images/ex10_CP-9(2).PNG)

## Validation Contrôle EX10_CP-9(2)

   1. Responsabilité fournisseur : Non
   2. Commentaire : Ceci est un processus administratif.
   3. Lien Document

## < --- Contrôle EX10_CP-9(3)--->

![EX10](../images/ex10_CP-9(3).PNG)
  
## Validation Contrôle EX10_CP-9(3)

   1. Responsabilité fournisseur : Oui
   2. Commentaire : Les services de prise de copie du volume de démarrage (*boot volume() de VM et du stockage de blocs permettent de répliquer les prises de copie automatiquement sur un deuxième site.
   3. [Lien Document](https://docs.oracle.com/fr-ca/iaas/Content/Block/Tasks/schedulingvolumebackups.htm#CrossRegionCopy)

## < --- Contrôle EX10_CP-9(5)--->

![EX10](../images/ex10_CP-9(5).PNG)

## Validation Contrôle EX10_CP-9(5)

   1. Responsabilité fournisseur : Oui
   2. Commentaire : Les services de prise de copie du volume de démarrage (*boot volume*) de VM et de stockage de bloc permettent de répliquer les prises de copie automatiquement sur un deuxième site.
   3. [Lien Document](https://docs.oracle.com/fr-ca/iaas/Content/Block/Tasks/schedulingvolumebackups.htm#CrossRegionCopy)

## < --- Contrôle EX10_CP-9(7)--->

![EX10](../images/ex10_CP-9(7).PNG)
  
## Validation Contrôle EX10_CP-9(7)

   1. Responsabilité fournisseur : Oui
   2. Commentaire : Lorsque les prises de copie sont répliquées sur deux sites, il est possible de définir des autorisations différentes pour chaque site.
   3. [Lien Document](https://docs.oracle.com/fr/solutions/oci-best-practices/back-your-data1.html#GUID-42086962-F4B6-497B-939B-12D1A4824BE9)

## < --- Contrôle EX10_CP-10--->

![EX10](../images/ex10_CP-10.PNG)

## Validation Contrôle EX10_CP-10

   1. Responsabilité fournisseur : Oui
   2. Commentaire : Oracle OCI offre des fonctionnalités de recouvrement, mais un processus administratif est également requis.
   3. [Lien Document](https://docs.oracle.com/en/solutions/design-dr/determine-your-deployment-strategy1.html#GUID-C12D99C4-A027-4395-8D0F-A73179862240)

## < --- Contrôle EX10_CP-10(2)--->

![EX10](../images/ex10_CP-10(2).PNG)
  
## Validation Contrôle EX10_CP-10(2)

   1. Responsabilité fournisseur : Oui
   2. Commentaire : Oracle OCI offre des fonctionnalités de recouvrement, mais un processus administratif est également requis.
   3. [Lien Document](https://docs.oracle.com/en/solutions/design-dr/determine-your-deployment-strategy1.html#GUID-C12D99C4-A027-4395-8D0F-A73179862240)

## < --- Contrôle EX10_CP-10(4)--->

![EX10](../images/ex10_CP-10(4).PNG)

## Validation Contrôle EX10_CP-10(4)

   1. Responsabilité fournisseur : Oui
   2. Commentaire : Oracle OCI offre des fonctionnalités de recouvrement, mais un processus administratif est également requis.
   3. [Lien Document](https://docs.oracle.com/en/solutions/design-dr/determine-your-deployment-strategy1.html#GUID-C12D99C4-A027-4395-8D0F-A73179862240)

## < --- Contrôle EX10_CP-10(6)--->

![EX10](../images/ex10_CP-10(6).PNG)
  
## Validation Contrôle EX10_CP-10(6)

   1. Responsabilité fournisseur : Oui
   2. Commentaire : Oracle OCI offre des fonctionnalités de recouvrement, mais un processus administratif est également requis.
   3. [Lien Document](https://docs.oracle.com/en/solutions/design-dr/determine-your-deployment-strategy1.html#GUID-C12D99C4-A027-4395-8D0F-A73179862240)

## < --- Contrôle EX10_RA-5(3)--->

![EX10](../images/ex10_RA-5(3).PNG)
  
## Validation Contrôle EX10_RA-5(3)

   1. Responsabilité fournisseur
   2. Commentaire : Le service 'Cloud Guard' valide en continu les configurations de votre compte infonuagique.
      Le Service 'Vulnerability Scanning' valide en continu les configurations de vos instances de calcul.
      Le service 'Data Safe' valide en continu les configurations de vos bases de données Oracle.   Identité et sécurité --> 'Cloud Guard' Identité et sécurité --> 'Vulnerability Scanning' Oracle Database-->'Data Safe'
   3. [Lien Document](https://docs.oracle.com/en-us/iaas/scanning/using/overview.htm)

## < --- Contrôle EX10_RA-5(4)--->

![EX10](../images/ex10_RA-5(4).PNG)
  
## Validation Contrôle EX10_RA-5(4)

   1. Responsabilité fournisseur : Oui
   2. Commentaire : Le service 'Cloud Guard' valide en continu les configurations de votre compte infonuagique.
      Le Service 'Vulnerability Scanning' valide en continu les configurations de vos instances de calcul.
      Le service 'Data Safe' valide en continu les configurations de vos bases de données Oracle. Identité et sécurité --> 'Cloud Guard'
      Identité et sécurité --> 'Vulnerability Scanning' Oracle Database-->'Data Safe'
   3. [Lien Document](https://docs.oracle.com/en-us/iaas/data-safe/index.html)

## < --- Contrôle EX10_RA-5(5)--->

![EX10](../images/ex10_RA-5(5).PNG)

## Validation Contrôle EX10_RA-5(5)

   1. Responsabilité fournisseur : Oui
   2. Commentaire : Le service 'Cloud Guard' valide en continu les configurations de votre compte infonuagique.
      Le Service 'Vulnerability Scanning' valide en continu les configurations de vos instances de calcul.
      Le service 'Data Safe' valide en continu les configurations de vos bases de données Oracle. Identité et sécurité --> 'Cloud Guard' Identité et sécurité --> 'Vulnerability Scanning' Oracle Database-->'Data Safe'
   3. [Lien Document](https://docs.oracle.com/en-us/iaas/cloud-guard/using/part-customize.htm)

## < --- Contrôle EX10_RA-5(6)--->

![EX10](../images/ex10_RA-5(6).PNG)

## Validation Contrôle EX10_RA-5(6)

   1. Responsabilité fournisseur : Oui
   2. Commentaire : Oracle Logging Analytics permet de visualiser les tendances au niveau des communications réseau et des audits de
      système. Oracle 'Threat Monitoring' permet de surveiller au fil du temps les différentes menaces pouvant affecter votre compte.
      Identité et sécurité -->Cloud Guard -->Threat monitoring
      Observability & Management --> Logging Analytics
   3. [Lien Document](https://docs.oracle.com/en-us/iaas/cloud-guard/using/threats.htm)

## < --- Contrôle EX10_RA-5(8)--->

![EX10](../images/ex10_RA-5(8).PNG)

## Validation Contrôle EX10_RA-5(8)

   1. Responsabilité fournisseur : Oui
   2. Commentaire : Oracle Logging Analytics et OCI Logging permettent de visualiser les tendances au niveau des communications réseau
      et des audits de système.
      Observability & Management --> Logging Analytics
      Observability & Management --> Logging
   3. [Lien Document](https://docs.oracle.com/fr/learn/oci_logging_analytics_tutorial_sample_logs/index.html#prepare-your-environment)

## < --- Contrôle EX10_RA-5(10)--->

![EX10](../images/ex10_RA-5(10).PNG)

## Validation Contrôle EX10_RA-5(10)

   1. Responsabilité fournisseur : Oui
   2. Commentaire : Oracle Logging Analytics permet de visualiser les tendances au niveau des communications réseau et des audits de système. Oracle 'Threat Monitoring' permet de surveiller au fil du temps les différentes menaces pouvant affecter votre compte.
   3. [Lien Document](https://docs.oracle.com/en-us/iaas/cloud-guard/using/threats.htm)

## < --- Contrôle EX10_SA-11--->

![EX10](../images/ex10_SA-11.PNG)

## Validation Contrôle EX10_SA-11

   1. Responsabilité fournisseur : Oui
   2. Commentaire : OCI DevOps permet de définir des pipelines de livraison qui incluent des étapes de tests et d'approbation en pallier avant la livraison en production.
      Developer Services--> DevOps
   3. [Lien Document](https://docs.oracle.com/fr-ca/iaas/Content/devops/using/home.htm)

## < --- Contrôle EX10_SA-11(1)--->

![EX10](../images/ex10_SA-11(1).PNG)
  
## Validation Contrôle EX10_SA-11(1)

   1. Responsabilité fournisseur : Oui
   2. Commentaire : OCI DevOps permet de définir des pipelines de livraison qui incluent des étapes de tests et d'approbation en
      pallier avant la livraison en production.
      Developer Services--> DevOps
   3. [Lien Document](https://docs.oracle.com/fr-ca/iaas/Content/devops/using/home.htm)

## < --- Contrôle EX10_SA-11(2)--->

![EX10](../images/ex10_SA-11(2).PNG)
  
## Validation Contrôle EX10_SA-11(2)

   1. Responsabilité fournisseur : Oui
   2. Commentaire :  Il s'agit du balayage (*scan*) de vulnérabilité pour les OS et l'état des correctifs pour la base de données.
      Le service fournit aux développeurs, aux équipes d'opérations et aux administrateurs de la sécurité une visibilité complète sur les ressources mal configurées ou vulnérables. Il génère également des rapports avec des mesures et des détails sur ces vulnérabilités, notamment des informations sur les mesures correctives.
      Vulnerability Scanning + test des développeurs
   3. [Lien Document](https://docs.oracle.com/en-us/iaas/scanning/using/overview.htm)

## < --- Contrôle EX10_SA-11(5)--->

![EX10](../images/ex10_SA-11(5).PNG)

## Validation Contrôle EX10_SA-11(5)

   1. Responsabilité fournisseur : Oui
   2. Commentaire : Oracle procède régulièrement à des tests de pénétration pour son infrastructure OCI. Le client peut également procéder à ses tests propres de pénétration, mais cela requiert une coordination avec Oracle.
   3. [Lien Document](https://www.google.com/url?sa=t&rct=j&q=&esrc=s&source=web&cd=&ved=2ahUKEwjq-u3U46b6AhXYkokEHdSRDlMQFnoECBAQAQ&url=https%3A%2F%2Fwww.oracle.com%2Fassets%2Focloud-hosting-delivery-policies-3089853.pdf&usg=AOvVaw1o0Salxy-m0Vs_aWAsvKAL)

## < --- Contrôle EX10_SA-11(6)--->

![EX10](../images/ex10_SA-11(6).PNG)

## Validation Contrôle EX10_SA-11(6)

   1. Responsabilité fournisseur : Oui
   2. Commentaire : OCI DevOps permet de définir des pipelines de livraison qui incluent des étapes de tests et d'approbation en pallier avant la livraison en production.
   3. [Lien Document](https://docs.oracle.com/fr-ca/iaas/Content/devops/using/home.htm)

## < --- Contrôle EX10_SA-11(7)--->

![EX10](../images/ex10_SA-11(7).PNG)

## Validation Contrôle EX10_SA-11(7)

   1. Responsabilité fournisseur : Oui
   2. Commentaire : OCI DevOps permet de définir des pipelines de livraison qui incluent des étapes de tests et d'approbation en pallier avant la livraison en production.
   3. [Lien Document](https://docs.oracle.com/fr-ca/iaas/Content/devops/using/home.htm)
  
## < --- Contrôle EX10_SA-11(8)--->

![EX10](../images/ex10_SA-11(8).PNG)

## Validation Contrôle EX10_SA-11(8)

   1. Responsabilité fournisseur : Oui
   2. Commentaire : OCI DevOps permet de définir des pipelines de livraison qui incluent des étapes de tests et d'approbation en pallier avant la livraison en production.
   3. [Lien Document](https://docs.oracle.com/fr-ca/iaas/Content/devops/using/home.htm)

## < --- Contrôle EX10_SA-15(4)--->

![EX10](../images/ex10_SA-15(4).PNG)
  
## Validation Contrôle EX10_SA-15(4)

   1. Responsabilité fournisseur
   2. Commentaire : OCI DevOps permet de définir des pipelines de livraison qui incluent des étapes de tests et d'approbation en pallier avant la livraison en production.
   3. [Lien Document](https://docs.oracle.com/fr-ca/iaas/Content/devops/using/home.htm)
  
## < --- Contrôle EX10_SI-2--->

![EX10](../images/ex10_SI-2.PNG)

## Validation Contrôle EX10_SI-2

   1. Responsabilité fournisseur : Oui
   2. Commentaire : Le Service 'Vulnerability Scanning' valide en continu les correctifs de vos instances de calcul (OS).
      Le service 'Data Safe' valide en continu les correctifs de vos bases de données Oracle.
      Oracle 'Cloud Guard' valide en continu l'application des correctifs et réévalue votre indice (*score*) de sécurité en conséquence. Identité et sécurité --> 'Cloud Guard' Identité et sécurité --> 'Vulnerability Scanning'
      Oracle Database-->'Data Safe'
   3. [Lien Document](https://docs.oracle.com/en-us/iaas/cloud-guard/using/part-start.htm)

## < --- Contrôle EX10_SI-2(1)--->

![EX10](../images/ex10_SI-2(1).PNG)
  
## Validation Contrôle EX10_SI-2(1)

   1. Responsabilité fournisseur : Oui
   2. Commentaire : Oui par le biais de Cloud Guard
   3. Lien Document
  
## < --- Contrôle EX10_SI-2(2)--->

![EX10](../images/ex10_SI-2(2).PNG)

## Validation Contrôle EX10_SI-2(2)

   1. Responsabilité fournisseur : Oui
   2. Commentaire : Le Service 'Vulnerability Scanning' valide en continu les correctifs de vos instances de calcul (OS).
      Le service 'Data Safe' valide en continu les correctifs de vos bases de données Oracle.
      Oracle 'Cloud Guard' valide en continu l'application des correctifs et réévalue votre indice (*score*) de sécurité en conséquence.
   3. [Lien Document](https://docs.oracle.com/en-us/iaas/cloud-guard/using/part-start.htm)

## < --- Contrôle EX10_SI-2(3)--->

![EX10](../images/ex10_SI-2(3).PNG)

## Validation Contrôle EX10_SI-2(3)

   1. Responsabilité fournisseur : Oui
   2. Commentaire : Cloud Guard conserve la date et l'heure de la première et de la dernière détection d'un problème.
   3. [Lien Document](https://docs.oracle.com/fr-fr/iaas/cloud-guard/using/problems-data-retention.htm)

## < --- Contrôle EX10_SI-2(6)--->

![EX10](../images/ex10_SI-2(6).PNG)

## Validation Contrôle EX10_SI-2(6)

   1. Responsabilité fournisseur : Non
   2. Commentaire
   3. Lien Document

## < --- Contrôle EX10_SI-3--->

![EX10](../images/ex10_SI-3.PNG)

## Validation Contrôle EX10_SI-3

   1. Responsabilité fournisseur : Oui
   2. Commentaire : Le service de balayage de vulnérabilité Oracle permet d'améliorer votre posture de sécurité en vérifiant  
      régulièrement les hôtes et les images de conteneurs pour les vulnérabilités potentielles. Il est possible de balayer des répertoires
      en particulier.
      Les sources/base données suivantes sont utilisées : National Vulnerability Database, Open Vulnerability and Assessment Language et Center for Internet Security.
      Identité et sécurité --> 'Vulnerability Scanning'
   3. [Lien Document](https://docs.oracle.com/fr-ca/iaas/scanning/home.htm)

## < --- Contrôle EX10_SI-3(1)--->

![EX10](../images/ex10_SI-3(1).PNG)
  
## Validation Contrôle EX10_SI-3(1)

   1. Responsabilité fournisseur : Oui
   2. Commentaire : Vulnerabilty Scanning est intégré à Cloud Guard qui permet d'envoyer des alertes.
   Identité et sécurité --> 'Vulnerability Scanning'
   3. [Lien Document](https://docs.oracle.com/fr-ca/iaas/scanning/home.htm)

## < --- Contrôle EX10_SI-3(2)--->

![EX10](../images/ex10_SI-3(2).PNG)

## Validation Contrôle EX10_SI-3(2)

   1. Responsabilité fournisseur : Oui
   2. Commentaire : Vulnerabilty Scanning est intégré à Cloud Guard qui permet d'envoyer des alertes.
   Identité et sécurité --> 'Vulnerability Scanning'
   3. [Lien Document](https://docs.oracle.com/fr-fr/iaas/cloud-guard/using/export-notifs-config.htm)

## < --- Contrôle EX10_SI-3(6)--->

![EX10](../images/ex10_SI-3(6).PNG)

## Validation Contrôle EX10_SI-3(6)

   1. Responsabilité fournisseur : Oui
   2. Commentaire : Vulnerabilty Scanning est intégré à Cloud Guard qui permet d'envoyer des alertes.
   Identité et sécurité --> 'Vulnerability Scanning'
   3. [Lien Document](https://docs.oracle.com/fr-fr/iaas/cloud-guard/usingexport-notifs-config.htm)

## < --- Contrôle EX10_SI-3(7)--->

![EX10](../images/ex10_SI-3(7).PNG)

## Validation Contrôle EX10_SI-3(7)

   1. Responsabilité fournisseur : Oui
   2. Commentaire : Vulnerabilty Scanning est intégré à Cloud Guard qui permet d'envoyer des alertes.
   Identité et sécurité --> 'Vulnerability Scanning'
   3. [Lien Document](https://docs.oracle.com/fr-fr/iaas/cloud-guard/using/export-notifs-config.htm)

## < --- Contrôle EX10_SI-3(10)--->

![EX10](../images/ex10_SI-3(10).PNG)

## Validation Contrôle EX10_SI-3(10)

   1. Responsabilité fournisseur : Oui
   2. Commentaire : Vulnerabilty Scanning est intégré à Cloud Guard qui permet d'envoyer des alertes.
   Identité et sécurité --> 'Vulnerability Scanning'
   3. [Lien Document](https://docs.oracle.com/fr-fr/iaas/cloud-guard/using/export-notifs-config.htm)

## < --- Contrôle EX10_SI-4--->

![EX10](../images/ex10_SI-4.PNG)

## Validation Contrôle EX10_SI-4

   1. Responsabilité fournisseur : Oui
   2. Commentaire : Oracle 'Cloud Guard' surveille en continu la posture de sécurité de votre compte infonuagique dans son ensemble.
      Le Service 'Vulnerability Scanning' surveille en continu la posture de sécurité d'instances de calcul (OS).
      Le service 'Data Safe' surveille en continu la posture de sécurité de vos bases de données Oracle et audite les activités des utilisateurs normaux et privilégiés.
      Le service 'OCI Audit' surveille en continu les actions des administrateurs de votre compte infonuagique.
      Le service 'OCI Logging' journalise toutes les opérations de lecture, création, modification et destruction de vos ressources infonuagiques.
      Identité et sécurité --> 'Cloud Guard'
      Identité et sécurité --> 'Vulnerability Scanning'
      Oracle Database-->'Data Safe'
      Observability & Management --> Logging
      Observability & Management --> Audit
   3. [Lien Document](https://docs.oracle.com/fr-fr/iaas/Content/Audit/Tasks/viewinglogevents.htm)

## < --- Contrôle EX10_SI-4(1)--->

![EX10](../images/ex10_SI-4(1).PNG)

## Validation Contrôle EX10_SI-4(1)

   1. Responsabilité fournisseur : Oui
   2. Commentaire : Oracle procède régulièrement à des tests de pénétration pour son infrastructure OCI. Le client peut également procéder à ses propres tests de pénétration, mais cela requiert une coordination avec Oracle.
      Oracle 'Threat Monitoring' permet de surveiller au fil du temps les différentes menaces pouvant affecter votre compte.
      Identité et sécurité -->Cloud Guard -->Threat monitoring
   3. [Lien Document](https://www.google.com/url?sa=t&rct=j&q=&esrc=s&source=web&cd=&ved=2ahUKEwjq-u3U46b6AhXYkokEHdSRDlMQFnoECBAQAQ&url=https%3A%2F%2Fwww.oracle.com%2Fassets%2Focloud-hosting-delivery-policies-3089853.pdf&usg=AOvVaw1o0Salxy-m0Vs_aWAsvKAL)

## < --- Contrôle EX10_SI-4(2)--->

![EX10](../images/ex10_SI-4(2).PNG)

## Validation Contrôle EX10_SI-4(2)

   1. Responsabilité fournisseur : Oui
   2. Commentaire : Oracle 'Cloud Guard' surveille en continu la posture de sécurité de votre compte infonuagique dans son ensemble.
      Le Service 'Vulnerability Scanning' surveille en continu la posture de sécurité d'instances de calcul (OS).
      Le service 'Data Safe' surveille en continu la posture de sécurité de vos bases de données Oracle et audite les activités des utilisateurs normaux et privilégiés.
      Le service 'OCI Audit' surveille en continu les actions des administrateurs de votre compte infonuagique.
      Le service 'OCI Logging' journalise toutes les opérations de lecture, création, modification et destruction de vos ressources infonuagiques.
      Identité et sécurité --> 'Cloud Guard'
      Identité et sécurité --> 'Vulnerability Scanning'
      Oracle Database-->'Data Safe'
      Observability & Management --> Logging
      Observability & Management --> Audit
   3. [Lien Document](https://www.google.com/url?sa=t&rct=j&q=&esrc=s&source=web&cd=&ved=2ahUKEwjq-u3U46b6AhXYkokEHdSRDlMQFnoECBAQAQ&url=https%3A%2F%2Fwww.oracle.com%2Fassets%2Focloud-hosting-delivery-policies-3089853.pdf&usg=AOvVaw1o0Salxy-m0Vs_aWAsvKAL)

## < --- Contrôle EX10_SI-4(4)--->

![EX10](../images/ex10_SI-4(4).PNG)

## Validation Contrôle EX10_SI-4(4)

   1. Responsabilité fournisseur : Oui
   2. Commentaire : OCI VCN Flow Logs et Oracle Logging Analytics permettent de journaliser tous les flux réseau et de détecter des  
      conditions inhabituelles.
      Observability & Management --> Logging
      Observability & Management --> Logging Analytics
   3. [Lien Document](https://docs.oracle.com/fr-fr/iaas/Content/Network/Concepts/vcn_flow_logs.htm)

## < --- Contrôle EX10_SI-4(5)--->

![EX10](../images/ex10_SI-4(5).PNG)

## Validation Contrôle EX10_SI-4(5)

   1. Responsabilité fournisseur : Oui
   2. Commentaire : Oracle 'Cloud Guard' surveille en continu la posture de sécurité de votre compte infonuagique dans son ensemble.  
      Oracle Cloud Guard permet de centraliser l'information des autres services de surveillance et d'émettre des alertes. Le Service 'Vulnerability Scanning' surveille en continu la posture de sécurité d'instances de calcul (OS).
      Le service 'Data Safe' surveille en continu la posture de sécurité de vos bases de données Oracle et audite les activités de utilisateurs normaux et privilégiés.
      Le service 'OCI Audit' surveille en continu les actions des administrateurs de votre compte infonuagique.
      Le service 'OCI Logging' journalise toutes les opérations de lecture, création, modification et destruction de vos ressources infonuagiques.
   3. [Lien Document](https://www.oracle.com/assets/ocloud-hosting-delivery-policies-3089853.pdf)

## < --- Contrôle EX10_SI-4(7)--->

![EX10](../images/ex10_SI-4(7).PNG)

## Validation Contrôle EX10_SI-4(7)

   1. Responsabilité fournisseur : Oui
   2. Commentaire : Cloud Guard possède des fonctionnalités pour détecter des problèmes (Detector Recipes) et exécuter des actions
      correctrices (*Responder activity*).
      Identité et sécurité --> 'Cloud Guard' --> Detector recipes
   3. [Lien Document](https://docs.oracle.com/fr-fr/iaas/cloud-guard/using/detect-recipes-ref-config.htm)
  
## < --- Contrôle EX10_SI-7--->

![EX10](../images/ex10_SI-7.PNG)

## Validation Contrôle EX10_SI-7

   1. Responsabilité fournisseur : Oui
   2. Commentaire : Cloud Guard possède des fonctionnalités pour détecter des problèmes et exécuter des actions correctrices (*Responder activity*).
   Identité et sécurité --> 'Cloud Guard'
   3. [Lien Document](https://docs.oracle.com/en-us/iaas/cloud-guard/using/respond-dash.htm)

## < --- Contrôle EX10_SI-7(2)--->

![EX10](../images/ex10_SI-7(2).PNG)

## Validation Contrôle EX10_SI-7(2)

   1. Responsabilité fournisseur : Oui
   2. Commentaire : Oracle 'Cloud Guard' surveille en continu la posture de sécurité de votre compte infonuagique dans son ensemble. Oracle Cloud Guard permet de centraliser l'information des autres services de surveillance et d'émettre des alertes.
   Identité et sécurité --> 'Cloud Guard' --> Responder activity
   3. [Lien Document](https://docs.oracle.com/en-us/iaas/cloud-guard/using/respond-dash.htm)

## < --- Contrôle EX10_SI-7(3)--->

![EX10](../images/ex10_SI-7(3).PNG)

## Validation Contrôle EX10_SI-7(3)

   1. Responsabilité fournisseur : Oui
   2. Commentaire : Oracle 'Cloud Guard' surveille en continu la posture de sécurité de votre compte infonuagique dans son ensemble. Oracle Cloud Guard permet de centraliser l'information des autres services de surveillance et d'émettre des alertes.
   Identité et sécurité --> 'Cloud Guard' --> Responder activity
   3. [Lien Document](https://docs.oracle.com/en-us/iaas/cloud-guard/using/respond-dash.htm)

## < --- Contrôle EX10_SI-7(5)--->

![EX10](../images/ex10_SI-7(5).PNG)

## Validation Contrôle EX10_SI-7(5)

   1. Responsabilité fournisseur : Oui
   2. Commentaire : Cloud Guard possède des fonctionnalités pour détecter des problèmes (Detector Recipes) et exécuter des actions correctrices (*Responder activity*).
   Identité et sécurité --> 'Cloud Guard'
   3. [Lien Document](https://www.oracle.com/assets/ocloud-hosting-delivery-policies-3089853.pdf)

## < --- Contrôle EX10_SI-7(7)--->

![EX10](../images/ex10_SI-7(7).PNG)

## Validation Contrôle EX10_SI-7(7)

   1. Responsabilité fournisseur : Oui
   2. Commentaire : Cloud Guard possède des fonctionnalités pour détecter des problèmes (Detector Recipes) et exécuter des actions correctrices (*Responder activity*).
   Identité et sécurité --> 'Cloud Guard'
   3. [Lien Document](https://www.oracle.com/assets/ocloud-hosting-delivery-policies-3089853.pdf)
  
## < --- Contrôle EX10_SI-7(14)--->

![EX10](../images/ex10_SI-7(14).PNG)

## Validation Contrôle EX10_SI-7(14)

   1. Responsabilité fournisseur : Oui
   2. Commentaire : Oracle OCI crée des instances 'personnalisées' d'instance de calcul. Ces instances peuvent être préconfigurées avec un ensemble fixe de logiciels et un ensemble limité de fonctions de gestion.
   3. [Lien Document](https://docs.oracle.com/fr-ca/iaas/Content/Compute/Tasks/managingcustomimages.htm)

## < --- Contrôle EX10_SI-7(16)--->

![EX10](../images/ex10_SI-7(16).PNG)

## Validation Contrôle EX10_SI-7(16)

   1. Responsabilité fournisseur : Oui
   2. Commentaire : Oracle OCI crée des instances 'personnalisées' d'instance de calcul. Ces instances peuvent être préconfigurées avec un ensemble fixe de logiciels et un ensemble limité de fonctions de gestion.
   3. [Lien Document](https://docs.oracle.com/fr-ca/iaas/Content/Compute/Tasks/managingcustomimages.htm)

 [Retour à la liste des exigences](OCI_12_exigences.md)
