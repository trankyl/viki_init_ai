# Zone d'accueil Google

## Table des matières

1. [Aperçu de la zone d'accueil](#aperçu-de-la-zone-daccueil)
   1. [Bootstrap d'environnement](#bootstrap-denvironnement)
   2. [Structure de dossier](#structure-de-dossier)
   3. [Bootstrap de la Zone d'Accueil](#bootstrap-de-la-zone-daccueil)
   4. [Convention de nommage](#convention-de-nommage)
   5. [Police Organisationnelle](#police-organisationnelle)
   6. [Projet](#projet)
   7. [Projet Terraform](#projet-terraform)
2. [Gestion d'identité et d'accès (IAM)](#gestion-didentité-et-daccès-iam)
   1. [Configuration IAM](#configuration-iam)
   2. [Rôles personnalisés organisationnels](#rôles-personnalisés-organisationnels)
3. [Réseautage & Ressources](#réseautage--ressources) 
   1. [DNS](#dns) 
   2. [Pare-feux](#pare-feu) 
   3. [Pare-feu : Fortigate](#pare-feu--fortigate)
   4. [Projet d'hôte de réseau](#projet-dhôte-de-réseau)
   5. [Réseau](#réseau)
   6. [Machines Virtuelles](#machine-virtuelle)
   7. [Contrôles de service de VPC](#contrôles-de-service-de-vpc)
4. [Journalisation](#journalisation)
5. [Automatisation](#automatisation)
   1. [Cloud Build](#cloud-build)
   2. [Mesures de sécurité](#mesures-de-sécurité)
6. [Sécurité](#sécurité)
   1. [Detective Scanning](#detective-scanning)
   2. [Security Command Center](#security-command-center)
   3. [Gestion Secret](#gestion-de-secret)

## Aperçu de la zone d'accueil

Les ressources sont des composantes fondamentales qui composent tous les services de Google Cloud Platform. Les ressources de bas niveau peuvent seulement être adoptées par des projets qui représente le premier mécanisme de groupement hiérarchique de ressources de Google Cloud.

Ressources Google Cloud sont organisés hiérarchiquement. En commençant de bas en haut, **les projets sont le premier niveau** et ils contiennent d'autres ressources.

**La ressource d'organisation est le noeud racine** de la hiérarchie de ressource Google Cloud et toutes les autres ressources qui appartiennent à une organisation sont groupées sous le noeud d'organisation. Cela fournit une visibilité centrale et un contrôle total de chaque ressource qui appartiennent à une organisation.

**Les Dossiers sont un méchanisme de groupement additionnel au-dessus de projets.** Vous êtes obligé d'avoir une ressource d'organisation comme un pré-requis pour utiliser les dossiers. Les dossiers et les projets sont tous mappés sous les ressources d'organisation.

### Bootstrap d'environnement

Le module met en place la structure initiale des permissions contre le noeud d'organisation et active les services de base de GCP tel que Google Cloud Storage pour qu'un repo puisse instancier afin que Terraform valide et exécute le *Plan*.

Il est possible de le trouver dans [`environments/bootstrap`](../environments/bootstrap).

### Structure de dossier

Le module crée un dossier de structure de groupement de référence en utilisant la convention de nommage spécifiée.

Elle se trouve dans [`modules/folder`](../modules/folder).

### Bootstrap de la Zone d'Accueil

Le module fournit une structure initiale pour l'environnement incluant la création du projet bootstrap, storage bucket, compte de service et les rôles utilisés pour déployer divers composantes de la Zone d'Accueil.

Il se trouve dans [`modules/landing-zone-bootstrap`](../modules/landing-zone-bootstrap).

### Convention de nommage

Le module présente la convention de nommage pour déployer la Zone d'Accueil en utilisant des variables pré-définies. Cela sera utilisé pour générer les noms de ressources, de rôles et de comptes lorsqu'ils sont appelés par d'autres modules dans la Zone d'Accueil. Chaque sous-répertoire héberge du code pour les ressources, les configurations et les variables. Des exemples incluent les fonction de cloud, de storage et de sous-réseau(x).

Il est possible de le trouver dans [`modules/naming-standard/modules/gcp`](../modules/naming-standard/modules/gcp).

### Police Organisationnelle

Les contraintes de police organisationnelle imposent la conformité au niveau de l'organisation GCP, de dossier ou de projet. Elles sont un ensemble de règles prédéfinies qui empêchent certaines actions de se dérouler.

Ces polices intégrées sont définies par Google et activées par l'organisation utilisant GCP et n'offrent pas de possibilité de personnalisation. Ces polices aident à protéger les limites de sécurité de la plateforme.

Certaines polices sont configurées par défaut et elles sont indiquées dans le code. Voici des exemples :

- Limiter les régions où les ressources peuvent être déployées.
- Définir les IPs externes autorisés pour les instances VM.
- Restreindre les APIs de Google Cloud et les services autorisés.
- Activer *Domain Restricted Sharing*.
- Activer l'accès uniforme au niveau de bucket.
- Requérir Login d'OS.
- Ignorer la création de réseau par défaut.
- Restreindre l'acheminement d'IP de VM.
- Définir les images de projets fiables.

Il est possible de le trouver dans [`modules/organization-policy`](../modules/organization-policy).

### Projet

Le module est utilisé pour créer des projets avec une convention appropriée de nommage et inclut les rôles par défaut et personnalisé ainsi que les configurations obtenues des autres modules comme le projet de Terraform.

Il est possible de le trouver dans [`modules/project`](../modules/project).

### Projet Terraform

Ce module dépend du module de Réseau et Boostrap pour instancier des nouveaux projets. Il peut aussi être employé dans un état étendu pour déployer des projets d'application dans la Zone d'Accueil. 

Il se trouve dans [`modules/project`](../modules/project)

## Gestion d'identité et d'accès (IAM)

Google Cloud Identity est le produit utilisé pour gérer les usagers, les groupes et les paramètres de sécurité basés sur le domaine pour l'espace de travail et la plateforme de Google Cloud.

Cloud Identity est lié à un domaine DNS unique qui doit être activé pour recevoir des courriels (par exemple, avoir un MX approprié configuré) pour que les usagers et les groupes configurés avec les résponsabilités dans GCP puissent recevoir des notifications générées.

Les configurations de Cloud Identity sont faites dans *Admin Console*. Les clients existants de d'espace de travail peuvent utiliser *Workspace Admin Console* pour *Cloud Identity*.

Les clients sans un compte existant de l'espace de travail peuvent créer un *Cloud Identity* dans la section "IAM" dans *GCP Cloud Console*.

Les polices IAM sont disponibles pour configuration dans *Google Cloud Console*. Les rôles IAM sont disponibles pour les usagers, pour les groupes des usagers et pour les comptes de service qui permettent un contrôle granulaire des permissions pour accéder aux ressources. La ressource d'organisation fournit une façon d'unifier tous les projets sous une seule organisation avec l'héritage de permission à travers l'organisation.

*Identity Aware Proxy*(IAP) fournit un proxy authentifié qui vérifie toutes les connexions contre une police de contrôle d'accès. Il peut être utilisé pour accéder aux ressources dans un VPC où le système de ressources qui n'a pas une route vers le système visé ou une règle de pare-feu qui bloque l'accès direct.

Une fois authentifiée, toutes les connexions via IAP doivent être authenfiées et elles seront acheminées au service de destination où elles peuvent intéragir avec le service. 

Cette interaction peut être un simple trafic TCP tel qu'un service web, une session de RDP ou SSH où une identité sera nécessaire pour accéder au système. Tous les traffics IAP sont cryptés par TLS.

L'accès est contrôlé par les rôles IAM et assigné directement aux groupes, aux usagers ou aux comptes services. Cela permet de contrôler granulairement l'accès au système et d'assurer que le principe de moindre privilège est respecté.

Par conséquent, au lieu de gérer des hôtes bastion, des clés SSH et d'autres composantes qui peuvent causer des surchages opérationnelles, la Zone d'accueil profitera des compétences d'IAP.

### Configuration IAM

Le module est utilisé pour créer et configurer les comptes services et les usagers. Il est aussi utilisé pour définir les permissions appropriées en assignant de rôles.

Même si les fonctionnalités actuelles sont limités à quelques cas d'utilisation seulement, le module est extensible dans le futur pour prendre en charge des nouveaux cas d'utilisation et une configuration automatisée plus facile.

Il se trouve dans le sous-répertoire [`modules/iam`](../modules/iam)

### Rôles personnalisés organisationnels

Ce module est utilisé pour créer des rôles personnalisés dans un niveau de l'organisation, de dossier et de projet. Il dépend de la convention de nommage et d'autres sources et est appelé par plusieurs autres modules pendant l'instantiation de la Zone d'Accueil.

Il se trouve dans le sous-répertoire [`modules/org-custom-roles`](../modules/org-custom-roles).

## Réseautage & Ressources

L'infrastructure mondiale de Google est composée de régions et dans ces régions il y a des zones. Google offre plusieurs options de connectivité pour une connectivité physique via direct peering ou *Google Carrier Interconnect* à travers de multiples régions geographiques. Un VPN peut être construit au-dessus de la couche physique et *Cloud Router* est disponible pour gérer le routage dynamique en utilisant BGP, une fois que la connexion aura été configurée.

L'utilisation de VPCs partagés vous permet de centraliser l'infrastructure réseautique dans un seul projet d'hôte et permet aux autres projets de service d'utiliser les ressources de réseau. 

### DNS

Cloud DNS prend en charge des zones publiques (résolvable par l'internet) et privées. Ce module est utilisé pour créer et gérer une zone privée dans chaque projet hôte, projet de prod, de non-prod ou de périmètre.

Il établit aussi *DNS Peering* entre deux zones privées dans chaque projet hôte et entre les projets de production et de périmètre. L'instance de Cloud DNS qui est déployée dans le VPC périmètre sera configuré en tant que zone de transfert pour toutes les autres zones privées dans cette zone d'accueil.

La zone de transfert gérera les demandes de GCP jusqu'à des domaines sur site. Les demandes sur site jusqu'à GCP seront résolues en utilisant une police entrante qui sera configuré dans Cloud DNS dans le projet périmètre.

Il se trouve dans [`modules/dns-zone`](../modules/dns-zone).

### Pare-feu

Le pare-feu de VPC de GCP permet la création d'un flux à base d'étiquette. Cela permet aux instances GCP d'être groupés ensemble avec des étiquettes de pare-feu en commun et des décisions subséquentes sur le contrôle de flux peuvent être pris basée sur ces étiquettes.

La segmentation de réseau est accomplie en utilisant ces étiquettes afin de permettre du traffic entre les ressources au besoin, tout en ne pas restreignant les traffics à la frontière du segment de réseau.

Dans le cadre de la conception de la zone d'accueil, tous traffics dans le VPC, entrant et sortant, seront interdits explicitement par défaut, le résultat de ce modèle de zero-confiance.

Ce modèle permet d'avoir un état de réseau plus sécuritaire où le traffic de l'ouest à l'est est restreint de la même façon que celui du nord au sud. 

Ce module est utilisé pour configurer le pare-feu de GCP. Basé sur les décisions mentionnées en haut, il y a quelques règles prédéfinies et le code permet une personnalisation afin de les changer.

Il se trouve dans [`modules/firewall`](../modules/firewall).

#### Pare-feu : Fortigate

Ce module optionel est disponible si un pare-feu de Fortigate est utilisé. Ce type de pare-feu de NVA fournira des fonctionnalités comme :

- Inspection profonde de paquet
- IDS
- WAF
- Filtrage de FQDN

Si utilisé, tous traffics passeront par cet appareil virtuel, avant d'arriver jusqu'à l'internet public. Le traffic qui est destiné à un appareil sur site passera NVA avant d'arriver dans l'environnement sur site.

Il se trouve dans [`modules/fortiagte-appliance`](../modules/fortigate-appliance).

### Projet d'hôte de réseau

Ce module est utilisé pour créer un projet d'hôte de réseau de GCP, de VPC et des sous-réseaux. Plusieurs instances de ce module peuvent être utilisés pour créer des projets d'hôte séparés et des réseaux pour la production et la non-production.

Il se trouve dans [`module/network-host-projet`](../modules/network-host-project).

### Réseau

Ce module ajoute un réseau quand il est temps de promouvoir un projet.

Il se trouve dans [`modules/network`](../modules/network).

### Machine virtuelle

Ce module fournit le code qui peut être utilisé pour créer une VM de Linux ou de Windows avec l'option d'ajouter des disques et des polices de snapshot.

Il se trouve dans [`modules/virtual-machine`](../modules/virtual-machine).

### Contrôles de service de VPC

Afin de protéger l'exfiltration de données, de gérer l'accès aux données et la confidentialité de données,  le contrôle de service de CPV sera implémentées dans le cadre de la zone d'accueil. 

Un seul périmètre de contrôle de service de VPC sera créé pour l'organisation de GCP. Les gammes d'IPs sur site et toutes les identités nécessaires seront permis et reconnues. 

Un contrôle de service de VPC assure que les données dans plupart de service de GCP ne sortent pas le périmètre pour arriver à un IP inconnu, même s'il possède des identifications IAM appropriées comme un compte d'usager ou de service.

Ce module fournit du code pour configurer le contrôle de service de VPC. Configurations disponibles, entre autres, sont Police d'accès organisationnelle, Niveaux d'accès, Périmètre régulier de service.

Il se trouve dans [`module/vpc-service-controls`](../modules/vpc-service-controls).

## Journalisation

Surveillance et journalisation dans GCP est fourni par deux produits différents: *Cloud Monitoring* et *Cloud Logging*. Ces services GCP, en conjonction avec *Security Command Center*, permet d'avoir une vue holistique de la santé des ressources dans tous les projets de GCP.

*Log Bunkering* est inclus dans la configuration de la zone d'accueil. *Log Bunkering* se réfère à l'environnement avec des contrôles stricts pour stocker des journaux inaltérés durant une période de retention. Ces journaux sont disponibles aux fins d'enquête légale.

Ce module est compatible avec les exigences de la zone d'accueil de GCP et est utilisé pour satisfaire les mesures de sécurités de stockage de journal de 30-jour. Ce module crée un projet d'audit avec une ou plusieurs piscines/buckets de journal organisationnelles qui peuvent être filtrés pour stocker des journaux spécifiques.

La configuration par défaut inclus *Admin Activity Logs, Data Access Logs, VPC Flow Logs, Firewall Rule Logs, Google Admin Logs*. Ces journaux sont stockés dans des projets de compartiments séparés. Les journaux seront recueillis à un niveau d'organisation et transférés directement dans un bucket verrouillé qui est configuré avec une police de retention.
Après que le bucket aura été créé, configuré et verrouillé, personne ne peut déverrouiller ou apporter de modification à un bucket ou aux journaux dans un bucket. Cela assure que tous les journaux stockés sont dans leur format original et sans altération. 

Il se trouve dans [`modules/audit-bunker`](../modules/audit-bunker).

## Automatisation

Ces modules fournissent du code pour aider à déployer et à gérer la zone d'accueil.

### Cloud Build

Terraform est utilisé pour déployer et gérer des changements dans le coe. Les demandes de pull de Terraform sont gérées par Cloud Build, et une opération "plan" de terraform sera effectués pour confirmer l'impact de changement à l'environnement.
Des changements de Terraform qui sont fusionnés dans la branche principale du repo de Bootstrap est géré par Cloud Build, et une opération *apply* de Terraform sera effectuée. 

Ce module contient du code pour créer une machine virtuelle avec cloud builder et le reste du code nécessaire pour commencer à construire un pipeline CI/CD .

Il se trouve dans [`modules/cloudbuild`](../modules/cloudbuild)

### Mesures de sécurité

Ce module fournit du code qui peut être utilisé pour créer une Google Cloud Function qui va importer les mesures de sécurité qui peuvent être utilisées pour examiner une collection préliminaire de contrôle à base dans des environnements de cloud.

Il se trouve dans [`modules/guardrails`](../modules/guardrails)

## Sécurité

### Detective Scanning

Foresti Security est souvent une approche recommandée pour effectuer "detective scanning" dans un environnement de Google Cloud Platform. En plus de Foresti, Google est en train de travailler sur une nouvelle fonctionnalité: Custom Governance. Cette fonctionnalité est actuellement en beta, mais elle sera une approche recommandée pour effectuer "detective scanning" après qu'elle aura rendu disponible au public.

Pour l'instant, les mesures de sécurités seront satisfait en utilisant une combinaison de documentation qui définissent comment l'environnement de Google Cloud Platform sera configuré, et la validation d'exportation de ressource qui va valider certains contrôles en utilisant le langage de requête REGO. Tous les rapports de violation de ressources seront stockés dans le bucket GCS.

À un niveau plus haut, l'outil de validation qui utilise REGO peut être décomposés dans les 3 flux de travails suivants:
 1. Exporter l'inventaire de ressource
 2. Effectuer la validation sur l'inventaire de ressource
 3. Mettre à jour le gabarit de police de validation

| Workflow                               | Déclenché par                     |Artifact sortant|
|----------------------------------------|-----------------------------------|----|
| **Exporter l'inventaire de ressource** | Cloud Scheduler (Quotidiennement) | Inventaire de ressource (JSON) stocké dans bucket GCS |
| **Effectuer la validation sur l'inventaire de ressource** | Changements dans le bucket de l'inventaire de ressource (Notification d'événement de bucket) | Signaler les résultats|
| **Mettre à jour le gabarit de police de validation**| Commit au repo de police de mesures de sécurité | Conteneur de validation de mesures de sécurités|

### Security Command Center

Security Command Center est une plateforme de gestion de risque pour Google Cloud. Il est utilisé pour trouver, comprendre et remédier les risques de sécurité de GCP et de données à travers de l'organisation.
Il est recommandé d'implémenter *Security Command Center* pour centraliser les évènements d'intérêts à travers de l'environnement.

Les types d'évènements qui seront recueilli sont:
- Audit Logs
- VPC flow logs
- Firewall Rule Logs

### Gestion de secret

GCP offre une solution de gestion de secret native dans le format de gestion de secret de GCP. Ce service offre un endroit central pour les applications, les équipes d'applications et les opérateurs d'applications pour accéder aux secrets comme les secrets d'application, les certificats, et les autres informations.


GCP utilise IAM pour enforcer le principe de moindre privilège où IAM peut être assigné aux 4 niveaux de l'organisation GCP.

| Portée                       |Accès|
|------------------------------|----|
| **Organisation**             | Tous les secrets dans tous les projets appartiennent à l'organisation|
| **Dossier**                  | Tous les secrets dans tous les proejts dans un dossier donné|
| **Projet**                   | Tous les secrets dans un projet|
| **Secret/Version de Secret** | Un secret ou une version de secret spécifique|

Les opérateurs de plateforme devraient avoir l'accès à un accès de niveau de projet aux secrets dans des projets gérés par l'équipe de plateforme, mais ils ne devraient pas avoir d'accès aux secrets de l'application, qui inclut la création, la mise à jour ou le déclassement de secrets dans *Secrets Manager*.
En plus, les compte de service propres à une application devrait avoir l'accès à chaque secret ou version de secret individuelle, mais ces comptes de service ne seront pas capable de lire les autres secrets auxquels ne leur appartiennent pas.

*Secrets Manager* a un cryptage au repos par défaut en utilisant les clés de *Google Managed Encription*. L'option d'utiliser *Customer Managed Encryption Keys* est aussi disponible et recommandé.










