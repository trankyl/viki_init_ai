# Contrôles de sécurité pour l'exigence 7

07 : Protéger les données en transit

Contrôles liés à l'exigence 07 :
SC-8, SC-8(1), SC-12, SC-13, SC-17

## < --- Contrôle EX7_SC-8--->

![EX6](../images/ex7_SC-8.PNG)

## Validation Contrôle EX7_SC-8

   1. Responsabilité fournisseur
   2. Commentaire
   3. Lien Document

## < --- Contrôle EX7_SC-8(1)--->

![EX6](../images/ex7_SC-8(1).PNG)

## Validation Contrôle EX7_SC-8(1)

   1. Responsabilité fournisseur : Oui
   2. Commentaire : Le service d'équilibreur de charge d'OCI peut utiliser des certificats SSL. Ces certificats, qui peuvent être émis par Oracle Certicate, peuvent utiliser une clé cryptographique stockée dans OCI Vault. Le contrôle consiste à s'assurer que les serveurs d'applications soient toujours protégés par des équilibreurs de charge pour lesquels SSL est activé.
   Fonctions de réseau--> Équilibreurs de charge --> Processus d'écoute
   3. [Lien Document](https://docs.oracle.com/fr-ca/iaas/Content/Balance/Tasks/managingloadbalancer_topic-Creating_Load_Balancers.htm#create)

## < --- Contrôle EX7_SC-12--->

![EX6](../images/ex7_SC-12.PNG)

## Validation Contrôle EX7_SC-12

   1. Responsabilité fournisseur : Oui
   2. Commentaire : Le service d'équilibreur de charge d'OCI peut utiliser des certificats SSL. Ces certificats, qui peuvent être émis par Oracle Certicate, utilisent une clé cryptographique stockée dans OCI Vault. Le contrôle consiste à s'assurer que les serveurs d'applications soient toujours protégés par des équilibreurs de charge pour lesquels SSL est activé.
   Fonctions de réseau-->Équilibreurs de charge --> Processus d'écoute
   3. [Lien Document](https://docs.oracle.com/fr-ca/iaas/Content/Balance/Tasks/managingcertificates.htm#console)
  
## < --- Contrôle EX7_SC13--->

![EX6](../images/ex7_SC-13.PNG)
  
## Validation Contrôle EX7_SC13

   1. Responsabilité fournisseur : Oui
   2. Commentaire : On peut moduler la vérification de conformité par 'cible' au niveau de Cloud Guard et Vulnerability Scanning.
   3. Lien Document

## < --- Contrôle EX7_SC17--->

![EX6](../images/ex7_SC-17.PNG)
  
## Validation Contrôle EX7_SC17

   1. Responsabilité fournisseur
   2. Commentaire : Oracle Certicate est en place et utilise les clés cryptographiques du coffre-fort pour tous les équilibreurs de charges.
   3. Lien Document

[Retour à la liste des exigences](OCI_12_exigences.md)
