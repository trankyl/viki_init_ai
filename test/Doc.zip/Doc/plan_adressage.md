#### Retour en arrière

* [Aperçu de l'abonnement Plateforme Connectivité](connectivite.md)
* [Aperçu du paramétrage du déploiement](parametrage_deploiements.md)
* [Paramétrage de la plateforme](parametrage_plateforme.md)
* [Aperçu de paramétrage des zones d'accueil](parametrage_za_charge.md)
* [Page d'accueil](../Readme.md)

# Le plan d'adressage IP

Le plan d'adressage définit les plages d'adresse pour les réseaux virtuels (VNet) et les sous-réseaux (*subnet*) provisionnés par le script v2 dans les abonnements de la plateforme et des zones d'accueil.

Les préfixes IP des VNet et des sous-réseaux sont composés de deux parties :

* Un préfixe /16 qui définit les premiers 2 chiffres de l'adresse IP. Ces préfixes sont configurables dans le fichier de paramétrage du scénario (par exemple cei-base-param.yml dans azure-pipeline/config/variables/scenario-base).
* Un suffixe qui définit les 2 derniers chiffres de l'adresse IP. Ces suffixes sont définis séparément pour les abonnements Plateforme et ceux des zones d'accueil.

Le plan d'adressage "par défaut" peut être téléchargé :

<p><a href ="./fichiers/Adressage_IP_ZoneAccueil_Azure_base.xlsx">Plan adressage en format Excel - scénario base</a></p><br>
<p><a href ="./fichiers/Adressage_IP_ZoneAccueil_Azure_complexe.xlsx">Plan adressage en format Excel - scénario complexe</a></p>

Le plan d'adressage peut être téléchargé en format Excel avec les préfixes par défaut. Ces préfixes peuvent être ajustés en fonction des plages d'adresses disponibles, mais dans tous les cas elles doivent correspondre à des adresses IP "privées" dans la plage 10.0.0.0/8.

L'assignation des suffixes réseau pour les abonnements Plateforme (et périmètre) est indépendante du scénario et est réalisée dans les fichiers suivants :

* Connectivité (*hub*), Gestion, Identité : dans le fichier cei-platform.yml dans azure-pipeline/config/variables
* Périmètre: dans le fichier cei-perimetre.yml dans azure-pipeline/config/variables

Pour les zones d'accueil, la configuration des suffixes réseau est dépendante du scénario. Pour le scénario de base, cette assignation est faite dans le fichier cei-bas-lz.yml dans azure-pipeline/config/variables/scenario-base.

## 1. Plan d'adressage dans les abonnements Plateforme et Périmètre

Les abonnements Plateforme comprennent Connectivité (*hub*), Gestion et Identité. L'abonnement Périmètre est inclus à part.

### 1.1 Paramétrage du plan d'adressage Plateforme et Périmètre

Les variables suivantes peuvent être ajustées dans le fichier de paramétrage (pour le scénario "base", il s'agit cei-base-param.yml). Cet ajustement peut être nécessaire pour éviter des conflits d'adressage (plages IP superposées) avec les environnements satellites comme sur site (*on-prem*) ou des plages IP dans d'autres nuages.


| Variable                                        | Abonnement    | Par défaut   | Commentaires                                  |
| ------------------------------------------------- | --------------- | ----------- | ----------------------------------------------- |
| var-platform-hub-virtualNetwork-ip-prefix       | Connectivité | 10.84     | Changer si besoin, éviter les conflits d'adresse |
| var-platform-perimetre-virtualNetwork-ip-prefix | Périmètre   | 10.84     | Changer si besoin, éviter les conflits d'adresse |
| var-platform-gestion-virtualNetwork-ip-prefix   | Gestion       | 10.73     | Changer si besoin, éviter les conflits d'adresse |
| var-platform-identite-virtualNetwork-ip-prefix  | Identité     | 10.73     | Changer si besoin, éviter les conflits d'adresse |
| var-platform-gestion-virtualNetwork-ip-suffix   | Gestion       | .128.0/17 | À ne pas toucher - utiliser pour le routage    |
| var-platform-identite-virtualNetwork-ip-suffix  | Identité     | .0.0/17   | À ne pas toucher - utiliser pour le routage    |

### 1.2 Plan d'adressage dans l'abonnement Connectivité (connu aussi en tant que *hub*)

L'abonnement "Connectivité" héberge les services et les ressources réseau qui servent à la connectivité par le biais des canaux privés entre les environnements Azure et les applications qui restent soit sur site, soit déménagent dans d'autres environnements en nuage :


| Suffixe par défaut | Nom sous-réseau    | Type         | Commentaire                                               |
| ----------------- | --------------------- | -------------- | ----------------------------------------------------------- |
| .0.0/17         | S/O                 | Plage IP     | Plage IP réservée pour l'ensemble VNet et sous-réseaux |
| .0.0/20         | S/O                 | Plage IP     | Plage IP de la VNET pour l'ensemble des sous-réseaux        |
| .0.0/24         | Gateway             | Sous-réseau | Placer ici la passerelle VPN                              |
| .2.0/24         | AzureFirewall       | Sous-réseau | Non utilisé dans la version courante                     |
| .4.0/24         | NVA                 | Sous-réseau | Sous-divisé en 4 sous-réseaux /26 pour FortiGate<br />   |
| .0/26           | Subnet externe      | Sous-réseau | Port 1 Fortigate A et B                                   |
| .64/26          | Subnet interne      | Sous-réseau | Port 2 Fortigate A et B, *front-end* LB interne              |
| .128/26         | Subnet HA-Sync      | Sous-réseau | Port 3 Fortigate A et B                                   |
| .192/26         | Subnet Gestion      | Sous-réseau | Port 4 Fortigate A et B                                   |
| .6.0/23         | Desserte            | Sous-réseau | À ne pas utiliser                                        |
| .8.0/22         | Application Gateway | Sous-réseau | Non utilisée dans la version courante                     |
| .12.0/22        | Azure Bastion       | Sous-réseau | Le sous-réseau utilisé par le service Azure Bastion     |
| .16.0/20        | Évolution 1        | Sous-réseau | Pour utilisation selon les besoins des OP et des établissements                 |
| .32.0/20        | Évolution 2        | Sous-réseau | Pour utilisation selon les besoins des OP et des établissements                |
| .48.0/20        | Évolution 3        | Sous-réseau | Pour utilisation selon les besoins des OP et des établissements                |

### 1.3 Plan d'adressage dans abonnement Périmètre

L'abonnement Périmètre regroupe les services et les ressources réseau qui servent à la connectivité par le biais des canaux publics entre les environnements Azure et Internet. Des applications qui roulent dans des zones d'accueil et qui permettent l'accès d'Internet sont exposées par le C/F du périmètre.


| Suffixe par défaut | Nom sous-réseau    | Type         | Commentaire                                                               |
| ----------------- | --------------------- | -------------- | --------------------------------------------------------------------------- |
| .128.0/17       | S/O                 | Plage IP     | Plage IP réservée pour l'ensemble VNet et sous-réseaux                  |
| .128.0/20       | S/O                 | Plage IP     | Plage IP de la VNet pour l'ensemble des sous-réseaux                        |
| .128.0/24       | AzureFirewall       | Sous-réseau | Placer ici le C/F Azure                                                   |
| .130.0/24       | NVA                 | Sous-réseau | Placer ici les applications virtuelles, par exemple un C/F non-Azure                  |
| .132.0/22       | Application Gateway | Sous-réseau | Placer ici le balanceur de charge applicative Azure (Application Gateway) |
| .144.0/20       | Évolution 1        | Sous-réseau | Pour utilisation selon les besoins des OP et des établissements                                 |
| .160.0/20       | Évolution 2        | Sous-réseau | Pour utilisation selon les besoins des OP et des établissements                                 |
| .176.0/20       | Évolution 3        | Sous-réseau | Pour utilisation selon les besoins des OP et des établissements                                 |

### 1.4 Adresses IP prédéfinies

Certaines adresses IP sont utilisées dans les scripts, veuillez vérifier les assignations.


| Suffixe IP | Abonnement          | Sous-réseau  | Variable                                  | Fichier                                     | Commentaires                                                                                                    |
| ------------ | --------------------- | --------------- | ------------------------------------------- | --------------------------------------------- | ----------------------------------------------------------------------------------------------------------------- |
| .4.4       | Connectivité (*hub*) | NVA           | var-platform-hub-egressVirtualApplianceIp | cei-platform.yml                         | Utilisé comme "next-hop" pour le routage UDR à travers une application virtuelle, si définie                   |
| .128.4     | Périmètre          | AzureFirewall | var-platform-perimetre-egressFirewallIp   | cei-perimetre.yml                        | Utilisé comme "next-hop" pour le routage par défaut vers Internet                                                 |
| .0.6       | Connectivité       | Gateway       | S/O                                       | cei-base-routage.yml, cei-tpl-lzvars.yml | Utilisé comme "next-hop" pour le routage interpériphérique (*inter-spoke*), c'est-à-dire entre Gestion, Identité et les zones d'accueil |

Il est important de noter que le préfixe .0.6 correspond à l'adresse de l'interface de la passerelle VPN et pour que le routage interpériphérique fonctionne, il est nécessaire de déployer cette passerelle dans l'abonnement Connectivité.

### 1.5 Plan d'adressage dans abonnement Identité

L'abonnement Identité regroupe les services et les ressources qui servent à la gestion des identités et des accès (GIA). C'est aux OP et aux établissements de décider quels sont les ressources et services à y déployer, par exemple des serveurs Azure Active Directory. Le préfixe réseau par défaut dans Identité est 10.73.


| Suffixe par défaut | Nom sous-réseau | Type         | Commentaire                                                                                                                            |
| ----------------- | ------------------ | -------------- | ---------------------------------------------------------------------------------------------------------------------------------------- |
| .0.0/17         | S/O              | Plage IP     | Plage IP réservée pour l'ensemble VNet et sous-réseaux                                                                               |
| .0.0/21         | S/O              | Plage IP     | Plage IP de la VNet pour l'ensemble des sous-réseaux                                                                                     |
| .0.0/24         | DC               | Sous-réseau | Placer ici un ou plusieurs serveurs AD *Domain Controller*, possiblement pour étendre la grappe AD sur site dans le nuage.              |
| .2.0/24         | Jumpbox          | Sous-réseau | Placer ici la machine virtuelle *jumpbox* qui permet la connectivité sécuritaire aux ressources déployées dans l'abonnement Identité.              |
| .4.0/24         | Private Endpoint | Sous-réseau | Placer ici les points de terminaison virtuels (*virtual endpoints*) qui permettent la connectivité sécuritaire, par des liens privés, aux services publics Azure. |
| .8.0/21         | Évolution 1     | Sous-réseau | Pour utilisation selon les besoins des OP et des établissements                                                                                              |
| .16.0/21        | Évolution 2     | Sous-réseau | Pour utilisation selon les besoins des OP et des établissements                                                                                              |
| .24.0/21        | Évolution 3     | Sous-réseau | Pour utilisation selon les besoins des OP et des établissements                                                                                              |

### 1.6 Plan d'adressage dans l'abonnement Gestion

L'abonnement Gestion regroupe les services et les ressources qui servent à la gestion des ressources dans les autres abonnements, soit Plateforme ou Zones d'accueil. Le déploiement de certains services est optionnel, selon le [paramétrage du déploiement](parametrage_deploiements.md). Le préfixe réseau par défaut dans Gestion est 10.73. Exemple de services :


| Service                      | Déploiement | Commentaires                                                                                                                                                                  |
| ------------------------------ | ------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Azure Bastion                | Optionnel   | Permet l'accès sécuritaire au *jump-box* et d'ici vers les autres abonnements pour gérer les ressources déployées de façon sécuritaire, avec une authentification forte. |
| Azure Recovery Service vault | Optionnel   | Utilisé pour les sauvegardes des machines virtuelles déployées                                                                                                                              |
| Azure Log Analytics          | Par défaut     | Permet la surveillance des ressources déployées                                                                                                                             |

Le plan d'adressage par défaut est le suivant :


| Suffixe par défaut | Nom sous-réseau | Type         | Commentaire                                                                                                                                 |
| ----------------- | ------------------ | -------------- | --------------------------------------------------------------------------------------------------------------------------------------------- |
| .128.0/17       | S/O              | Plage IP     | Plage IP réservée pour l'ensemble VNet et sous-réseaux                                                                                   |
| .128.0/20       | S/O              | Plage IP     | Plage IP de la VNet pour l'ensemble des sous-réseaux                                                                                          |
| .128.0/23       | Infra Gestion    | Sous-réseau | Placer ici les ressources dédiées à la gestion et la surveillance, comme des machines virtuelles, avec des applications spécifiques comme Cacti, Nagios, SCCM |
| .132.0/24       | Jumpbox          | Sous-réseau | Placer ici la machine virtuelle *jumpbox* qui permet la connectivité sécuritaire aux ressources déployées dans Gestion et dans les autres abonnements  |
| .134.0/24       | Private Endpoint | Sous-réseau | Placer ici les points de terminaison virtuels (*virtual endpoints*) qui permettent la connectivité sécuritaire, par des liens privés, aux services publics Azure      |
| .136.0/24       | Azure Bastion    | Sous-réseau | Le sous-réseau utilisé par le service Azure Bastion                                                                                       |

---

## 2. Plan d'adressage dans les abonnements Zones d'accueil - scénario de base

Toutes les zones d'accueil ont un plan d'adressage similaire, mais ce n'est pas obligatoire. L'exemple fourni de scénario personnalisé ("complexe") utilise des plans d'adressage différents dans différents abonnements de type zone d'accueil, mais autrement la fonctionnalité est similaire.

Le préfixe par défaut pour l'adressage des zones d'accueil est 10.77 et pour le scénario "base", chaque zone d'accueil prédéfinie a un suffixe réseau spécifique paramétré dans cei-base-param.yml :


| Variable                             | Abonnement                | Par défaut   | Commentaires                                                                                                                              |
| :------------------------------------- | --------------------------- | ----------- | ------------------------------------------------------------------------------------------------------------------------------------------- |
| var-charges-virtualNetwork-ip-prefix | Tous dans les zones d'accueil | 10.77     | Toutes les passerelles VNet et tous sous-réseaux dans les abonnements des zones d'accueil sont par défaut provisionnés dans la plage 10.77.0.0/16.      |
| var-charges-nonsens-assigne-suffix   | Données non sensibles    | .64.0/18  | La plage complète IP qui couvre la VNet et les sous-réseaux de la zone d'accueil Données non sensibles. Utilisée à des fins de routage. |
| var-charges-sens-assigne-suffix      | Données sensibles        | .0.0/18   | La plage complète IP qui couvre la VNet et les sous-réseaux de la zone d'accueil Données sensibles. Utilisée à des fins de routage.     |
| var-charges-nonprod-assigne-suffix   | Non-Prod                  | .128.0/17 | La plage complète IP qui couvre la VNet et les sous-réseaux de la zone d'accueil Non-Prod. Utilisée à des fins de routage.               |

La VNet d'une zone d'accueil est partagée en sous-réseaux de manière similaire, pour le scénario "base" :

### 2.1 Zone d'accueil "Données sensibles"

Placer ici les ressources et les services qui traitent des données sensibles.


| Suffixe  | Type         | Nom sous-réseau | Commentaire                                                                                                                                        |
| ---------- | -------------- | ------------------ | ---------------------------------------------------------------------------------------------------------------------------------------------------- |
| .0.0/18  | Plage IP     | S/O              | La plage complète IP qui couvre la VNet et les sous-réseaux de la zone d'accueil Données sensibles. Utilisée à des fins de routage.         |
| .0.0/20  | Plage IP     | S/O              | Plage IP de la VNet pour l'ensemble des sous-réseaux dans "données sensibles"                                                                       |
| .0.0/23  | sous-réseau | Private Endpoint | Placer ici les points de terminaison virtuels (*virtual endpoints*) qui permettent la connectivité sécuritaire, par des liens privés, aux services Azure publics.             |
| .2.0/23  | sous-réseau | Jumpbox          | Placer ici la machine virtuelle *jumpbox* qui permet la connectivité sécuritaire aux ressources déployées dans la zone d'accueil par le service Azure Bastion |
| .4.0/23  | sous-réseau | Web              | Placer ici les ressources dédiées aux applications de type "Services en ligne"                                                                   |
| .6.0/23  | sous-réseau | Application      | Placer ici les ressources dédiées aux applications type *back-end* sans exposition directe aux accès par les interfaces Web                         |
| .8.0/23  | sous-réseau | Data             | Placer ici des ressources de type base de données ou dépôt de fichiers                                                                          |
| .10.0/23 | sous-réseau | Evolution 1      | Pour utilisation selon les besoins des OP et les établissements                                                                                                          |
| .12.0/23 | sous-réseau | Evolution 2      | Pour utilisation selon les besoins des OP et les établissements                                                                                                          |
| .14.0/23 | sous-réseau | Evolution 3      | Pour utilisation selon les besoins des OP et les établissements                                                                                                          |

### 2.2 Zone d'accueil "Données non sensibles"

Placer ici les ressources et les services qui traitent des données non sensibles.


| Suffixe  | Type         | Nom sous-réseau | Commentaire                                                                                                                                       |
| ---------- | -------------- | ------------------ | --------------------------------------------------------------------------------------------------------------------------------------------------- |
| .64.0/18 | Plage IP     | S/O              | La plage complète IP qui couvre la VNet et les sous-réseaux de la zone d'accueil Données sensibles. Utilisée à des fins de routage.        |
| .64.0/20 | Plage IP     | S/O              | Plage IP de la VNet pour l'ensemble des sous-réseaux dans "données sensibles"                                                                      |
| .64.0/23 | sous-réseau | Private Endpoint | Placer ici les points de terminaison virtuels (*virtual endpoints*) qui permettent la connectivité sécuritaire, par des liens privés, aux services Azure publics            |
| .66.0/23 | sous-réseau | Jumpbox          | Placer ici la machine virtuelle *jumpbox* qui permet la connectivité sécuritaire aux ressources déployées dans la zone d'accueil par le service Azure Bastion |
| .68.0/23 | sous-réseau | Web              | Placer ici les ressources dédiées aux applications de type "Services en ligne"                                                                   |
| .70.0/23 | sous-réseau | Application      | Placer ici les ressources dédiées aux applications type *back-end* sans exposition directe aux accès par les interfaces Web                         |
| .72.0/23 | sous-réseau | Data             | Placer ici des ressources de type base de données ou dépôt de fichiers                                                                         |
| .74.0/23 | sous-réseau | Evolution 1      | Pour utilisation selon les besoins des OP et les établissements                                                                                                         |
| .76.0/23 | sous-réseau | Evolution 2      | Pour utilisation selon les besoins des OP et les établissements                                                                                                         |
| .78.0/23 | sous-réseau | Evolution 3      | Pour utilisation selon les besoins des OP et les établissements                                                                                                         |

### 2.3 Zone d'accueil "Non-Prod"

Placer ici les ressources et les services qui traitent des données non-prod.


| Suffixe   | Type         | Nom sous-réseau | Commentaire                                                                                                                                       |
| ----------- | -------------- | ------------------ | --------------------------------------------------------------------------------------------------------------------------------------------------- |
| .128.0/18 | Plage IP     | S/O              | La plage complète IP qui couvre la VNet et les sous-réseaux des zones d'accueil Non-prod. Utilisée à des fins de routage.                        |
| .128.0/19 | Plage IP     | S/O              | La plage complète IP qui couvre la VNet et les sous-réseaux des zones d'accueil Non-prod "Acceptation".                                           |
| .128.0/21 | Plage IP     | S/O              | Plage IP de la VNet pour l'ensemble des sous-réseaux dans "données sensibles"                                                                      |
| .128.0/24 | sous-réseau | Private Endpoint | Placer ici les points de terminaison virtuels (*virtual endpoints*) qui permettent la connectivité sécuritaire, par des liens privés, aux services Azure publics.            |
| .129.0/24 | sous-réseau | Jumpbox          | Placer ici la machine virtuelle *jumpbox* qui permet la connectivité sécuritaire aux ressources déployées dans la zone d'accueil par le service Azure Bastion |
| .130.0/24 | sous-réseau | Web              | Placer ici les ressources dédiées aux applications de type "Services en ligne"                                                                  |
| .131.0/24 | sous-réseau | Application      | Placer ici les ressources dédiées aux applications type *back-end* sans exposition directe aux accès par les interfaces Web                        |
| .132.0/24 | sous-réseau | Data             | Placer ici des ressources de type base de données ou dépôt de fichiers                                                                         |
| .133.0/24 | sous-réseau | Evolution 1      | Pour utilisation selon les besoins des OP et des établissements                                                                                                         |
| .134.0/24 | sous-réseau | Evolution 2      | Pour utilisation selon les besoins des OP et des établissements                                                                                                        |
| .135.0/24 | sous-réseau | Evolution 3      | Pour utilisation selon les besoins des OP et des établissements                                                                                                        |
| .136.0/21 | Plage IP     | Non-Prod Dev     | Pour utilisation selon les besoins des OP et des établissements                                                                                                        |
| .144.0/21 | Plage IP     | Non-Prod Test    | Pour utilisation selon les besoins des OP et des établissements                                                                                                        |
| .152.0/21 | Plage IP     | Non-Prod Autre   | Pour utilisation selon les besoins des OP et des établissements                                                                                                        |
