#### Retour en arrière

* [Architecture des scénarios prédéfinis](archit_scenario_predefini.md)
* [Mise en contexte](mise_en_contexte.md)
* [Aperçu de l'étiquetage](tags.md)
* [Page d'accueil](../Readme.md)

# Architecture des Zones d’accueil Azure

Les zones d'accueil pour les organismes publics (OP) et les établissements du REES et du RSSS permettent de déployer dans le nuage, de façon sécuritaire, des charges de travail anciennement déployées sur des infrastructures dédiées et coûteuses.

## 1. Présentation de la zone d’accueil Azure proposée par le CEI

La zone d’accueil provisionnée par le script s’appuie sur le cadre d'adoption infonuagique ([Cloud Adoption Framework - CAF](https://docs.microsoft.com/en-us/azure/cloud-adoption-framework/)) et sur [ses principes d’architecture](https://docs.microsoft.com/fr-ca/azure/cloud-adoption-framework/ready/enterprise-scale/design-principles), et met en place certaines décisions d'architecture propres aux besoins des organismes visés.

---

## 2. Structure des groupes d’administration et des abonnements

L’arborescence ressemble dans ses principes fondamentaux à celle mise en place chez Microsoft, soit :

- Une séparation des groupes d’administration des opérations des groupes d’administration des zones de charges.
- Des groupes d’administration propres à l’environnement d’expérimentation ainsi qu'à l'environnement de fin d'utilisation (décommissionnement).
- Des architectures de groupes d'administration de paliers et zones d'accueils prédéfinies regroupés par des "scénarios".

À ce jour, le scénario "base" est pris en charge et représente un déploiement simplifié, répondant aux besoins de la plupart des OP y compris les établissements du REES et du RSSS.
Un scénario "complexe" est fourni pour faciliter des déploiements plus élaborés similaires comme la hiérarchie des groupes d'administration aux déploiements faits avec le script v1.1 et v2.

### 2.1 Séparation entre les services communs de type "Plateforme" et les zones de charge qui accueillent des charges de travail

- La grande séparation **Plateforme** versus **Zone de charges** est un principe clé d’architecture du cadre d'adoption infonuagique. Les stratégies, les rôles RBAC, et généralement les budgets assignés, sont en effet de nature différente.
- **Plateforme** regroupe des abonnements de type infrastructure de base et d’opérations communes et transversales servant à administrer les autres ressources.
- **Zone de charges**, pour sa part, va regrouper des abonnements de type applicatif de charges de travail.
- **Décommissionnés** est un groupe d’administration qui permet de séparer les zones de charges inactives des charges actives (qui sont dans **Zones de charges**) et de les garder ainsi sous le coup de stratégies qui leur seront spécifiques (exemple : un abonnement qui se retrouverait dans ce groupe d’administration pourrait être chapeauté par des stratégies qui empêchent que des ressources soient déployées).

### 2.2 Séparation des zones d'accueil pour les charges de travail en fonction de la nature des applications et/ou nature des données

Cette séparation est réalisée en fonction du scénario déployé:

### 2.3 Scénario base

- La séparation entre **charges données sensibles** et **charges données non sensibles** dans l'environnement de production est basée sur les besoins de conformité réglementaire en fonction de la nature différente des données.
- La séparation en paliers **Production** et **Non-production**  permet d’accorder une souplesse supplémentaire entre les différents paliers et de faire en sorte que des stratégies puissent par exemple s’appliquer en mode audit, d’abord du côté de l’environnement non-production avant de les appliquer en mode forcé et contraignant, par exemple dans l'environnement de production.
- La séparation au niveau de la réseautique entre les environnements:
  - Entre l'environnement de production et celui de non-production
  - Entre les zones de charge **données sensibles** et celles **données non sensibles**


![Diagramme architecture scénario "base"](images/hub-spoke-network-topology-architecture_800px.png)

## 2.4 Liens rapides

Pour plus d'information, suivre les liens ci-dessous :

* [Architecture zones d'accueil pour les scénarios prédéfinis](archit_scenario_predefini.md)
* [Architecture plateforme - connectivité](connectivite.md)
* [Architecture plateforme - étiquettes (*tags*)](tags.md)
* [Architecture plateforme - contrôle d'accès (RBAC)](rbac.md)
