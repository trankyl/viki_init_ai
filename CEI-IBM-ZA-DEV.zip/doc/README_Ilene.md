# Secure Landing Zone with Extensions

This package contains the following terraform scripts

* [00-landing-zone](terraform/00-landing-zone/README.md)

  Landing Zone based on IBM Cloud [VSI Pattern](https://cloud.ibm.com/docs/framework-financial-services?topic=framework-financial-services-vpc-architecture-detailed-vsi) for Financial Services

* [10-observability](terraform/10-observability)

  * [IBM Activity Tracker](https://cloud.ibm.com/docs/activity-tracker?topic=activity-tracker-getting-started) for audit events
  * [IBM Log Analysis](https://cloud.ibm.com/docs/log-analysis?topic=log-analysis-getting-started) for application and platform logging
  * [IBM Cloud Monitoring](https://cloud.ibm.com/docs/monitoring?topic=monitoring-getting-started) for platform and service monitoring

* [20-fortigate-ha](terraform/20-fortigate-ha) or [21-fortigate-ha-multi](terraform/21-fortigate-ha-multi)

  *Choose either 20-fortigate-ha or 21-fortigate-ha-multi*

  **20-fortigate-ha**
  Edge VPC with a [Fortigate HA Pair](https://docs.fortinet.com/document/fortigate-public-cloud/7.2.0/ibm-cloud-administration-guide/944419/deploying-fortigate-vm-a-p-ha-on-ibm-vpc-cloud-byol) provisioned in Zone 1 of selected region.

  **21-fortigate-ha-multi**
  Edge VPC with a [Fortigate HA Pair](https://docs.fortinet.com/document/fortigate-public-cloud/7.2.0/ibm-cloud-administration-guide/944419/deploying-fortigate-vm-a-p-ha-on-ibm-vpc-cloud-byol) provisioned in any combination of Zones 1, 2 and 3 of the selected region.  You can provision one pair in one zone, or a pair in multiple zones.

* [30-cloudinternetsvcs](terraform/30-cloudinternetsvcs)

  [Cloud Internet Services](https://cloud.ibm.com/docs/cis?topic=cis-about-ibm-cloud-internet-services-cis), powered by CloudFlare offers security, reliability and performance features for internet facing applications.

With all extensions, this is the complete deployment

![Deployment](docs-temp/images/vsi-with-extensions.png)

## Prerequisites

To ensure that Secure Landing Zone can be deployed, follow these steps

### Setup an IBM Cloud Account

An IBM Cloud account is required. An Enterprise account is recommended but Pay as you Go account suffices to deploy secure landing zone cloud resources.

If you do not already have an account, follow instructions [to create the account](https://cloud.ibm.com/docs/account?topic=account-account-getting-started#account-gs-createlite) and [upgrade to Pay-as-you-Go](https://cloud.ibm.com/docs/account?topic=account-account-getting-started#account-gs-upgrade)

- Have access to an [IBM Cloud account](https://cloud.ibm.com/docs/account?topic=account-account-getting-started). An Enterprise account is recommended but a Pay as you Go account should also work with this automation.

### Setup IBM Cloud Account for Secure Landing Zone

1. Log into IBM Cloud [console](https://cloud.ibm.com) using the IBMid you used to setup the account. This IBMid user is the account __owner__ and has all the IAM accesses.

2. [Complete the company profile and contacts information](https://cloud.ibm.com/docs/account?topic=account-contact-info) for the account. (Recommended)

4. Enable VRF and Service Endpoints. This requires creating a support case. Follow [instructions](https://cloud.ibm.com/docs/account?topic=account-vrf-service-endpoint#vrf) carefully.  (Recommended if using any Classic Infrastructure, so you have private connectivity to IBM Cloud services)

## Execution

You must run the `00-landing-zone` terraform scripts first.  The rest of the scripts are optional and can be run in any order or even in parallel, but are listed in the recommended order.

All scripts require the following environment variable: `TF_VAR_ibmcloud_api_key` set to your IBM Cloud API Key that has authority to provision the resources in the script.

1. Navigate to [00-landing-zone](terraform/00-landing-zone/README.md) for details on what is provisioned, available customizations and how to run the script.

1. Navigate to [10-observability](terraform/10-observability)

   *IMPORTANT:* This script requires the following environment variable setting: `export IBMCLOUD_ATRACKER_API_ENDPOINT="https://us-east.atracker.cloud.ibm.com"`

   The script does not require any other parameters, as long as the overall folder structure is maintained and has access to the landing zone tfstate files.

1. Navigate to [20-fortigate-ha](terraform/20-fortigate-ha) or [21-fortigate-ha-multi](terraform/21-fortigate-ha-multi)

   Both require the parameter `fortigate_allowed_cidrs`.  If you do not set it, the script will still work, but you won't be able to access the Fortinet servers unless you manually update the Network Access Control list and Security Group to permit tcp 443 (https) traffic and optionally tcp 22 (ssh), and ICMP Type 8 (ping).

   Additionally, [21-fortigate-ha-multi](terraform/21-fortigate-ha-multi) has an optional field for you to specify the zones you want to provision the pairs into.  By default, the script will provision HA Pairs in Zones 1 and 3 of your selected region.  For more information, review the [README](terraform/21-fortigate-ha-multi/README.md).  

   All other parameters are accessed from the tfstate files of the landing zone.

1. Navigate to [30-cloudinternetsvcs](terraform/30-cloudinternetsvcs)

   No parameters are required as long as it has access to the landing zone tfstate files.
