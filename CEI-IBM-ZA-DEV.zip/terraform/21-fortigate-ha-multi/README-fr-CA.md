# Paire active-passive haute disponibilité FortiGate avec infrastructure

## Aperçu

La paire active-passive haute disponibilité FortiGate est une offre dans le [catalogue IBM Cloud](https://cloud.ibm.com/catalog/content/ibm-fortigate-AP-HA-terraform-deploy-5dd3e4ba-c94b-43ab-b416-c1c313479cec-global)

Cet environnement Terraform fournit l'ensemble de l'infrastructure prérequise qui est nécessaire pour le déploiement de l'offre dans le catalogue et la fourniture d'une, deux ou trois paires haute disponibilité.  Vous indiquez pour quelles zones dans la région multizone vous voulez une paire.  Vous pouvez fournir jusqu'à trois paires (une par zone).

1. Un nuage privé virtuel en périphérie dans la région multizone sélectionnée.
1. Pour chaque zone sélectionnée, quatre sous-réseaux (public, interne, haute disponibilité et de gestion)
1. Pour chaque zone, il y a une liste de contrôle d'accès afin de permettre le trafic à partir d'un ensemble d'adresses IP autorisées, ainsi que le trafic sortant et de réponse dans le but de permettre le fonctionnement des outils FortiGate.
1. Groupe de sécurité afin de permettre le trafic à l'interne et à partir d'adresses IP autorisées
1. Mises à jour dans le tableau des routes par défaut et un tableau des routes secondaires pour le flux du trafic
1. Porte-clés et clés servant à chiffrer les volumes de démarrage et de données des serveurs FortiGate.
1. Journaux des flux de réseau pour le nuage privé virtuel (facultatif)
1. Connexion à la passerelle de transit (facultatif)


Le module de paires-actives haute disponibilité FortiGate repose sur l'environnement Terraform [ici](https://github.com/fortinet/ibm-fortigate-AP-HA-terraform-deploy) (qui appuie l'offre dans le catalogue) avec les modifications suivantes :

* Les volumes des journaux et de démarrage sont chiffrés au moyen de la clé fournie.
* La variable Groupe de ressources a été ajoutée et elle est utilisée avec toutes les ressources afin que celles-ci ne soient pas placées dans le groupe de ressources par défaut.
* On crée un ID de service et une clé d'interface API afin d'autoriser le connecteur SDN IBM au lieu d'utiliser la clé d'interface API IBM servant à exécuter Terraform.
* L'usurpation d'adresse IP est activée pour l'interface interne.

Ce graphique montre l'ajout de cette extension dans la zone d'atterrissage.  Vous pouvez fournir une, deux ou trois paires.  Le graphique montre une paire dans chaque zone.

![Paires haute disponibilité FortiGate](../../docs/images/vsi-fortinet-fr-CA.png)

Vous pouvez voir un graphique détaillé du déploiement de produits FortiGate dans le fichier README du référentiel Git ci-dessus, ou [dans le module local](./modules/fortigate-ha/README.md).


## Prérequis

Ces prérequis seront extraits de la sortie de [00-landing-zone](../00-landing-zone/patterns/vsi)

1. Une [ressource consistant en une clé Secure Shell](https://cloud.ibm.com/docs/ssh-keys?topic=ssh-keys-adding-an-ssh-key) dans IBM Cloud dans la région dans laquelle vous effectuerez le déploiement.  Vous aurez besoin du nom de cette ressource.

1. Une instance Key Protect ou IBM Cloud Hyper Protect Crypto Services.  Vous aurez besoin du nom de la ressource infonuagique et de l'identificateur global unique.  Un porte-clés et des clés seront créés afin de chiffrer les volumes FortiGate.  Si des journaux de flux sont sélectionnés, une autre clé pour les journaux de flux sera alors créée.

1. Cloud Object Storage (facultatif).  Si vous choisissez d'avoir des journaux de flux, vous aurez besoin d'une instance Cloud Object Storage.  Un compartiment sera créé dans cette instance.  Vous avez besoin du nom de la ressource infonuagique et de l'identificateur global unique de cette instance.

1. Passerelle de transit (facultatif).  Vous pouvez ajouter de manière facultative une connexion pour le nuage privé virtuel à une passerelle de transit existante.  Vous aurez besoin de l'identificateur global unique de la passerelle de transit.



## Variables d'entrée

Ces variables d'entrée seront consultées dans la sortie de [00-landing-zone](../00-landing-zone/patterns/vsi). Ou vous pouvez les remplacer et les transmettre.

| Nom | Description | Type |Par défaut/Exemple | Obligatoire |
| ---- | ----------- | ---- | ------- | -------- |
| ibmcloud_api_key | Clé d'interface API utilisée pour fournir les ressources.  Votre clé doit être autorisée à effectuer les actions dans ce script. **IMPORTANT : Assurez-vous que la clé d'interface API est autorisée à configurer l'usurpation d'adresse IP dans l'infrastructure de nuage privé virtuel** | chaîne  | sans objet  | oui |
| region | Région multizone pour fournir les paires actives-passives haute disponibilité FortiGate. Répertoriez toutes les régions disponibles avec : "ibmcloud regions".  | chaîne | Par défaut : "ca-tor" | oui |
| prefix | Courte chaîne qui sera utilisée pour préfixer tous les noms de ressources  | chaîne | sans objet | oui |
| vpc_cidrs |Un tableau des préfixes d'adresses pour les plages d'adresses IP disponibles dans chaque zone du nuage privé virtuel.  Vous pouvez utiliser les valeurs par défaut, mais soyez conscient des conflits avec d'autres nuages privés virtuels ou réseaux auxquels vous vous connectez. | list(chaîne) | ["10.70.0.0/18","10.80.0.0/18", "10.90.0.0/18"] | Utilisez celle par défaut ou fournissez la vôtre  |
| ssh_key_name | Nom de la ressource consistant en une clé Secure Shell à utiliser avec tous les serveurs  | chaîne | sans objet | oui | 
| kms_crn | Nom de la ressource infonuagique de l'instance de service de gestion des clés (Key Protect ou Hyper Protect Crypto Services).  On l'utilisera pour le porte-clés et les clés afin de chiffrer les volumes des serveurs et les journaux de flux (s'ils sont sélectionnés).  | chaîne | sans objet | oui | 
| kms_guid | Identificateur global unique de l'instance de service de gestion des clés (Key Protect ou Hyper Protect Crypto Services).  On l'utilisera pour le porte-clés et les clés afin de chiffrer les volumes des serveurs et les journaux de flux (s'ils sont sélectionnés). | chaîne | sans objet |oui |
| cos_crn | Nom de la ressource infonuagique de l'instance Cloud Object Storage dans laquelle il faut ajouter un compartiment pour les journaux de flux de réseau. | chaîne | null | Non - Si vous laissez la valeur null par défaut, les journaux de flux de réseau ne seront pas alimentés |
| cos_guid |  Si vous voulez des journaux de flux de réseau, fournissez l'identificateur global unique Cloud Object Storage ainsi que le nom de la ressource infonuagique | chaîne | null | Non - Si vous laissez la valeur null par défaut, les journaux de flux de réseau ne seront pas alimentés |
| connect_to_transitgateway | Configurez la valeur comme fausse si vous ne voulez pas connecter le nuage privé virtuel à une passerelle de transit | bool | vrai | non |
| transit_gateway_id | Si la valeur `connect_to_transitgateway` est vraie, vous devez fournir un identificateur global unique de la passerelle de transit | chaîne | sans objet | non |


Il est possible de transmettre ces variables d'entrée ou d'utiliser les variables par défaut.

| Nom  | Description | Type | Par défaut/Exemple | Obligatoire |
| ---- | ----------- | ---- | ------- | -------- |
| fortigate_zone_subnet_cidrs | Une carte de zone pour les routages inter-domaine sans classe des sous-réseaux pour les sous-réseaux FortiGate.  Les valeurs par défaut seront fournies dans les zones 1 et 3.  |carte | Voyez les valeurs par défaut ci-dessous | Utilisez les valeurs par défaut ou fournissez les vôtres |
| fortigate_allowed_cidrs | | Tableaux des routages inter-domaine sans classe qui seront autorisés à accéder au réseau FortiGate. Si aucun routage inter-domaine sans classe n'est fourni, vous ne pourrez pas accéder aux serveurs afin de configurer ou de charger des licences.  | list(string) | Par défaut, il s'agit d'une tableau vide `[]`. Un exemple avec une adresse IP autorisée `["99.99.99.99/32"]` | non - Le module Terraform fonctionnera en l'état, mais vous devrez ajouter des adresses IP dans la liste de contrôle d'accès et le groupe de sécurité plus tard. |

### Default fortigate_zone_subnet_cidrs

Vous pouvez voir les variables par défaut dans `variables.tf`.  Les variables par défaut fourniront une paire dans les zones 1 et 3 comme le montre le côté gauche de la carte.  Les quatre routages inter-domaine sans classe sont respectivement destinés aux sous-réseaux public, interne, haute disponibilité et de gestion.

```
{
    1 = ["10.70.10.0/24","10.70.20.0/24","10.70.30.0/24","10.70.40.0/24"]
    3 = ["10.90.10.0/24","10.90.20.0/24","10.90.30.0/24","10.90.40.0/24"]
}
```

## Variables de sortie

La sortie est dans le format JavaScript Object Notation et affiche tous les détails de chaque paire que vous avez fournie.  Le nombre à gauche est la zone et vous aurez donc jusqu'à trois entrées pour les zones 1, 2 et 3, en fonction du nombre de paires que vous avez fournies.

Voici un exemple de sortie :

```
FortiGate_Public_IP = {
  "1" = {
    "Custom_Image_Name" = "fortigate-terraform-fortigate-custom-image-oslq"
    "FGT1_Default_Admin_Password" = "<password>"
    "FGT1_Public_HA_Mangment_IP" = "xx.xx.xx.xx"
    "FGT2_Default_Admin_Password" = "<password>"
    "FGT2_Public_HA_Mangment_IP" = "xx.xx.xx.xx"
    "FortiGate_Public_IP" = "xx.xx.xx.xx"
    "Username" = "admin"
  }
  "3" = {
    "FGT1_Default_Admin_Password" = "<password>"
    "FGT1_Public_HA_Mangment_IP" = "xx.xx.xx.xx"
    "FGT2_Default_Admin_Password" = "<password>"
    "FGT2_Public_HA_Mangment_IP" = "xx.xx.xx.xx"
    "FortiGate_Public_IP" = "xx.xx.xx.xx"
    "Username" = "admin"
  }
}
```

## Exécuter

1. Copiez terraform.tfvars.template dans terraform.tfvars et entrez les valeurs des variables
1. Exécutez `terraform init`
1. Exécutez `terraform plan` et/ou `terraform apply`


## Après l'exécution

Votre sortie doit ressembler à l'exemple de sortie ci-dessus.

Si vous naviguez vers `Virtual Private Cloud -> Virtual Server Instances` dans la console IBM Cloud, vous devriez voir chacune de vos paires d'instances.  Chaque paire aura le même suffixe généré de manière aléatoire.

![Paire de serveurs virtuels](images/Fortigate_Pair_VSIs.png)

Veuillez noter que le premier serveur a deux adresses IP flottantes et que le second n'en a qu'une.  Chaque serveur a une adresse IP flottante dans son interface publique et, lors du basculement, l'adresse IP flottante est automatiquement déplacée par le connecteur SDN IBM FortiGate vers l'autre machine.

Si vous cliquez sur le serveur principal et faites défiler l'écran jusqu'aux interfaces réseau, vous devriez voir quatre interfaces dans chacun des quatre sous-réseaux.  L'usurpation d'adresse IP est activée dans le sous-réseau interne.  Les interfaces publiques et de gestion ont des adresses IP flottantes qui correspondent aux adresses IP dans la sortie Terraform.


![Fortigate Primary VSI](images/Fortigate_Primary_VSI.png)

Procédez comme suit :

1. Naviguez vers `https://<FGT1_Public_HA_Mangment_IP>` pour voir une de vos paires.  Connectez-vous en utilisant le mot de passe par défaut correspondant.  Changez le mot de passe à l'invite, puis téléchargez votre licence.
1. Naviguez vers `https://<FGT2_Public_HA_Mangment_IP>` pour voir la même paire.  Vous pouvez généralement vous connecter maintenant avec le nouveau mot de passe obtenu lors de l'étape précédente.  Téléchargez votre licence.

Vous pourriez devoir rafraîchir le navigateur afin de revenir à une invite d'ouverture de session.  La validation de la licence peut prendre plusieurs minutes.


*Dépannage*

1. Si vous ne pouvez pas accéder à la console, assurez-vous que la liste de contrôle d'accès et le groupe de sécurité sur le serveur autorisent le trafic à partir de votre adresse IP.  Si vous n'avez pas transmis votre adresse IP dans la variable `fortigate_allowed_cidrs`, alors vous n'aurez pas d'accès.  Vous devrez mettre à jour manuellement la liste de contrôle d'accès pour autoriser le trafic entrant à destination du port 443 à partir de votre adresse IP.  Vous devrez mettre à jour le groupe de sécurité de la même manière.  Vous pouvez également ajouter des règles pour Secure Shell (tcp 22) et la commande ping (protocole Internet Control Message Protocol (ICMP) de type 8) pour votre adresse IP.
1. Si la licence n'est jamais validée, assurez-vous que le trafic sortant à destination du port 80 et le trafic de réponse à partir du port 80 sont autorisés dans la liste de contrôle d'accès pour les sous-réseaux FortiGate.

Une fois que vous avez téléchargé vos licences et qu'elles ont été validées, vous pouvez vérifier l'état de santé du connecteur IBM Cloud et vous assurer que la paire a été synchronisée.

Pour vérifier l'état de santé du connecteur IBM Cloud, naviguez vers `Security Fabric->External Connectors`.  Vous devriez voir ce connecteur IBM Cloud s'afficher avec un état sain.


![Connecteur IBM Cloud](images/Fortigate_IBMCloudConnector.png)

Si l'état n'est pas sain, cela est souvent dû à la clé d'interface API qu'il utilise.  Un ID de service et une clé API ont été générés par le script Terraform.  Dans votre console IBM Cloud, si vous naviguez vers `Manage->Access (IAM)` dans le menu en haut de l'écran, puis vers `Service IDs` à gauche, vous devriez voir une liste d'ID de services.  Il y en aura un pour chacune de vos paires haute disponibilité FortiGate tel qu'indiqué ici

![ID de service de connecteur FortiGate](images/Fortigate_Connector_ServiceID.png)

Si vous devez changer la clé d'interface API, vous pouvez la régénérer ici, puis la mettre à jour dans le connecteur SDN dans FortiGate.

Vous pouvez également vérifier que la paire haute disponibilité a été synchronisée.  Dans le tableau de bord de FortiGate, naviguez jusqu'à `System->HA`.  Cela peut parfois prendre un certain temps, mais l'opération est généralement achevée dans un délai de 30 minutes.


![Synchronisation des serveurs virtuels](images/Fortigate_Pair_Sync.png)


## Test de basculement

Pour tester le basculement, essayez ce qui suit...

Secure Shell dans les deux machines à partir de deux terminaux


  ```
  ssh admin@<FGT1_Public_HA_Mangment_IP>
  ```
  and
  ```
  ssh admin@<FGT2_Public_HA_Mangment_IP>
  ```

Dans le terminal de la machine passive, tapez les lignes suivantes :
  ```
  diagnose debug enable
  diagnose debug application ibmd -1
  ```

Dans le terminal de la machine active, tapez les lignes suivantes afin d'imposer un basculement :
  ```
  execute ha failover set 1
  ```

Dans le terminal de la machine passive, vous devriez voir ces lignes comme suit :

```
IBM-HA-PASSIVE # HA event
HA state: primary
ibmd sdn connector  is getting token
token size: 1571
token expiration: 1669746760
ibmd HA successfully got fip for hb peer
ibmd HA found hb host/peer info
ibmd HA successfully moved fip
ibmd HA found rtbl on hb peer ip
ibmd HA successfully moved route table
HA state: primary
ibmd sdn connector  is getting token
token size: 1571
token expiration: 1669746775
ibmd HA successfully got fip for hb peer
ibmd HA found hb host/peer info
ibmd HA could not move fip, or fip has already been moved
ibmd sdn connector ibm-ha is getting token
token size: 1571
token expiration: 1669746798
ibmd sdn connector ibm-ha updating
```

Si vous naviguez vers la console IBM Cloud et regardez vos instances de serveurs virtuels, vous verrez que maintenant, le second serveur a une adresse IP flottante dans l'interface publique alors qu'auparavant, c'était le premier serveur qui la possédait.  Elle a changé de serveur.  Les deux serveurs ont toujours une adresse IP flottante dans l'interface de gestion.

Si vous naviguez vers le tableau des routages par défaut pour le nuage privé virtuel, vous devriez voir une route pour chaque paire FortiGate.  L'adresse IP du prochain saut doit toujours être l'adresse IP de l'interface interne de la paire FortiGate active.  Lorsque vous avez effectué le basculement, l'adresse IP du prochain saut dans le tableau des routages a été mise à jour.



