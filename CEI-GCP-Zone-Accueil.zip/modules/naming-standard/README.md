# Aperçu

Obtenir le module depuis `modules/gcp/<module_name>` pour obtenir la convention de nommage pour la ressource

# Limitations

# Problèmes Connus

# Exemple
```hcl
locals {
   ca_governance = {
    department_code = var.department_code
    environment     = var.environment
    location      = var.location
  }
}

# folders
module "folder_name" {
  source        = "../naming-standard//modules/gcp/google_folder
  ca_governance = local.ca_governance
  owner         = var.owner
  project       = var.project
}

resource "google_folder" "audit" {
  display_name = module.folder_name.result
}
```

# Développement 

Pour ajouter des ressources, créer un dossier de ressource sous `modules/gcp/<resource_name>`
Le `resource_name` doit être aligné avec les cas de tests dans [gc_name_tests.go](./tests/gc_name_tests.go).
1. Ajouter un fichier `README.md`
2. Basé sur le type de ressource, vous devez choisir un gabarit "common". Dans le dossier `modules/common/module`, il y a plusieurs gabarits qui peuvent être utilisés. Pour réduire la duplication, l'utilisation de symlink est recommandé. Par exemple, depuis le dossier du module `ln -s ../../common/module/common.tf common.tf`. Pour déterminer le gabarit à utiliser, référez-vous au [README](./modules/common/module/README.md) entre les ressources.
3. Ajouter un `variables.tf` et le modifier avec les arguments requis et mettre à jour les variables locales dedans avec le _type_ correct et la dictionnaire _name_sections_, qui sont des arguments passés dans `modules/common/name_generator`
4. Ajouter le code de ressource dans `configs/resource_naming_patterns.yaml` et créer un gabarit de string de Terraform pour le motif de nommage, le code peut être obtenu de `config/resource_types.yaml`
5. Ajouter les variables de gabarit à _data_ _template_file_ dans `modules/common/name_generator/main.tf`


## Astuce de développement

Le meilleur flux de travaille pour TDD quand ajouter des nouveaux motifs de nommage de ressource. Pour faciliter le processus, ouvrir les fichiers suivants dans l'ordre:
- [configs/resource_types.yaml](./configs/resource_types.yaml)
- [configs/resource_naming_patterns.yaml](./configs/resource_naming_patterns.yaml)
- [tests/gc_name_tests.go](./tests/gc_name_tests.go)
- [modules/common/name_generator/variables.tf](./modules/common/name_generator/variables.tf)
- [modules/common/name_generator/main.tf](./modules/common/name_generator/main.tf)

1. Créar un motif de nommage dans `configs/resource_naming_patterns.yaml`. Pour chaque type de haut-niveau comme `vnet`, `compute_vm`, vous pouvez définir les gabarits de nommage de ressource pour réduire duplication. Cela est fait en créant un tableau nommé `common_prefixes`. Les motifs dans ce tableau sont ensuite référencé en utilisant `common_prefix_index`. L'index commence par 0. Exemple:
```yaml
  compute_vm:
    common_prefixes:
      - '${gc_governance_prefix}${device_type}-${user_defined_string}'      # Index 0
      - '${parent_resource}'                                                # Index 1
    # <dept code><environment><CSP Region><device type>-<User Defined_String>##
    # Note: Suffix is not used on Virtual Machines
    vm:
      commmon_prefix_index: 0             # This retrieves compute_vm.common_prefixes[0] --> '${gc_governance_prefix}${device_type}-${user_defined_string}'
      # Combining the prefix and suffix template, the template now becomes: ''${gc_governance_prefix}${device_type}-${user_defined_string}'${number_suffix}'
      suffix_template: '${number_suffix}'
```
2. Ajouter le code de type de ressource à la variable de valiation `type` dans `modules/common/name_generator/variables.tf`, et le code du parent, si nécessiare
3. Vérifie de nouveau `modules/common/name_generator/main.tf` `data "template_file" "gc_name"` pour voir s'il y a des nouvelles variables qui doivent être ajoutées dans le gabarit.
4. Créer la ressource dans `modules/gcp/<resource_name>`, et modifier README.md et les variables, selon besoin
5. Créer un symlink à `common*.tf` dans `modules/common/module/*` et dans `modules/gcp/<resource_name>`
6. Mettre à jour les tests et exécuter. Voir la section prochaine.

# Tests
Ajouter un nouveau terratest dans `tests/gc_name_tests.go`

Chaque ressource a besoin de sa propre dictionnaire `resourceNameTests`. Si vous avez plusieurs cas de test pour une type de ressource, vous pouvez ajouter plusieurs `nameTest`. Voir l'exemple suivant:
```go
	"subnet": resourceNameTests{
		nameTest{
			"common_args": commonArgsMap["ScPc"],
			"args": arguments{
				"user_defined_string":            "MRZ",
				"additional_user_defined_string": "SEC",
			},
			"tests": runTests{
				"equal": "ScPcCNR-MRZ-SEC-snet",
			},
		},
		nameTest{
			"common_args": commonArgsMap["ScPc"],
			"args": arguments{
				"user_defined_string":            "MRZ",
				"additional_user_defined_string": "AzureBastionSubnet",
			},
			"tests": runTests{
				"equal": "AzureBastionSubnet",
			},
		},
		nameTest{
			"common_args": commonArgsMap["ScPc"],
			"args": arguments{
				"user_defined_string":            "MRZ",
				"additional_user_defined_string": "AzureFirewallSubnet",
			},
			"tests": runTests{
				"equal": "AzureFirewallSubnet",
			},
		},
		nameTest{
			"common_args": commonArgsMap["ScPc"],
			"args": arguments{
				"user_defined_string":            "MRZ",
				"additional_user_defined_string": "GatewaySubnet",
			},
			"tests": runTests{
				"equal": "GatewaySubnet",
			},
		},
	},
```

Pour aider à tester, plusieurs `common_args` sont disponibles à utiliser dans `tests/common_args.go`. Ces objets fournissent une couverture suffisante à travers les régions et les couches de service.

Types de ressource qui sont sous-ressources n'utilisent pas de `common_args`. À la place, ils ont un nom de ressource parent qui sera utilisé pour générer la préfixe. Exemple:
```go
	"public_ip": resourceNameTests{
		nameTest{
			"args": arguments{
				"parent_resource": "ScPcFWL-egress_fw-egress_fw",
			},
			"tests": runTests{
				"equal": "ScPcFWL-egress_fw-egress_fw-pip1",
			},
		},
  },
```
