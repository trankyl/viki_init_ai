
# Zone d'accueil Google Cloud

# Introduction 

La documentation suivante portera sur le script servant à déployer une zone d'accueil Google Respectant les conventions PBMM prescrites par le gouvernement du Canada.

# Pour débuter

1.	[Processus de déploiement](#processus-de-déploiement)
2.  [Architecture](#architecture)
3.	[Dépendances logiciels](#dépendances-logiciels)
4.	[Dernière version](#dernière-version)
5.  [Références API](#références-api)

# Processus de déploiement

Dans le document suivant, vous trouverez comment déployer une zone d'accueil Google Cloud : [deploiement.md](/docs/deploiement.md)

# Architecture

L'architecture est détaillé dans le document suivant : [Architecture](/docs/architecture.md)

# Dépendances logiciels

Il requis que les outils suivant soient installés:

 - [GCloud SDK](https://cloud.google.com/sdk/docs/install?hl=fr)
 - [JQ (pour enquêtes JSON)](https://stedolan.github.io/jq/download/)
 - [Terraform >= 1.0](https://learn.hashicorp.com/tutorials/terraform/install-cli)

# Modules Terraform

Dans le fichier suivant, il est possible de trouver une liste des modules terraform utilisés dans l'architecture de Google : [Modules Terraform](/modules/README.md)

# Dernière version

Il est possible de suivre les mises à jour sur ce site internet : [Google Cloud PBMM](https://cloud.google.com/blog/topics/inside-google-cloud/whats-new-google-cloud)

# Références API

La CLI Google Cloud est un ensemble d'outils qui vous permet de gérer les ressources et les applications hébergées sur Google Cloud. Ces outils incluent les outils de ligne de commande gcloud, gsutil et bq. En savoir plus ou essayer l'aide-mémoire

Il est possible d'accèder au tout à l'adresse suivante : [Google Cloud CLI](https://cloud.google.com/sdk/docs?hl=fr)

# Construire et tester

L'intégrité des commandes afin de construire et tester la zone d'atterrissage est ici : 
[Commandes Terraform](https://www.terraform.io/cli/commands)