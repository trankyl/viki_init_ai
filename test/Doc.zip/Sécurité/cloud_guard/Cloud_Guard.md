# Cloud Guard

## Sommaire

* [Description et but du Cloud Guard](#description-et-but-du-cloud-guard)
* [Cloud Guard et le script de déploiement](#cloud-guard-et-le-script-de-déploiement)
* [Prérequis pour le déploiement du Cloud Guard et Politiques](#prérequis-pour-le-déploiement-du-cloud-guard-et-politiques)
* [Configuration du Cloud Guard et définition des cibles générales dans la zone d’accueil](#configuration-du-cloud-guard-et-définition-des-cibles-générales-dans-la-zone-accueil)
* [Collecter et analyser la posture de sécurité](#collecter-et-analyser-la-posture-de-sécurité)
* [Type de problème par catégorie et masquage de faux problème](#type-de-problème-par-catégorie-et-masquage-de-faux-problème)   

## Description et but du Cloud Guard

Oracle Cloud Guard détecte les ressources mal configurées, les activités non sécurisées et les activités de menaces malveillantes et offre aux administrateurs de sécurité la visibilité nécessaire pour trier et résoudre les problèmes de sécurité du cloud.

Une vue d’ensemble :

![Schema Overview](../images/Overview.png)

![Schema Overview](../images/Overview2.png)

Les fonctionnalités d'Oracle Cloud Guard :

![Schema Fonctionnalité 1 ](../images/Fonct1.png)

![Schema Fonctionnalité 2 ](../images/Fonct2.png)

![Schema Fonctionnalité 3 ](../images/Fonct3.png)

![Schema Fonctionnalité 4 ](../images/Fonct4.png)

![Schema Fonctionnalité 5 ](../images/Fonct5.png)

## Cloud Guard et le script de déploiement

Cloud Guard permet d’évaluer la posture de sécurité. Il doit être activé lors du déploiement du script.

![Schema script ](../images/activation_cloud_guard_au_deploiement_za_oci.jpg)

## Prérequis pour le déploiement du Cloud Guard et Politiques

S’assurer que la politique de sécurité pour le service de Cloud Guard est existante à la racine.

![Schema politiques ](../images/Politique_cloud_guard_active.jpg)

Liste des règles déployées par le script de zone d'accueil :

• Allow service cloudguard to read keys in tenancy

• Allow service cloudguard to read compartments in tenancy

• Allow service cloudguard to read tenancies in tenancy

• Allow service cloudguard to read audit-events in tenancy

• Allow service cloudguard to read compute-management-family in tenancy

• Allow service cloudguard to read instance-family in tenancy

• Allow service cloudguard to read virtual-network-family in tenancy

• Allow service cloudguard to read volume-family in tenancy

• Allow service cloudguard to read database-family in tenancy

• Allow service cloudguard to read object-family in tenancy

• Allow service cloudguard to read load-balancers in tenancy

• Allow service cloudguard to read users in tenancy

• Allow service cloudguard to read groups in tenancy

• Allow service cloudguard to read policies in tenancy

• Allow service cloudguard to read dynamic-groups in tenancy

• Allow service cloudguard to read authentication-policies in tenancy

• Allow service cloudguard to use network-security-groups in tenancy

• Allow service vulnerability-scanning-service to manage instances in tenancy

• Allow service vulnerability-scanning-service to read compartments in tenancy

• Allow service vulnerability-scanning-service to read vnics in tenancy

• Allow service vulnerability-scanning-service to read vnic-attachments in tenancy

• Allow service osms to read instances in tenancy

• allow service cloudguard to read data-safe-family in tenancy

• allow service cloudguard to read autonomous-database-family in tenancy

Les deux dernières règles doivent être ajoutées lors du déploiement de Cloud Guard pour permettre une accessibilité plus large à Cloud Guard aux différents rôles autre que le rôle administrateur.

## Configuration du Cloud Guard et définition des cibles générales dans la zone accueil

Les étapes pour la configuration de Cloud Guard :

1. S’assurer que l’option de Cloud Guard a été sélectionnée lors de l’exécution du script de zone d'accueil.

    ![Schema script ](../images/activation_cloud_guard_au_deploiement_za_oci.jpg)

2. Définir des cibles (*target*) pour chaque compartiment généré par le script.
Vous devez définir une cible pour chaque compartiment.
À des fins de simplification, le nom de la cible peut représenter un groupe de gestion ou un environnement. Par exemple : Production pour les compartiments de production, Dev pour les compartiments de développement, etc.

![Schema cibles ](../images/Cibles.png)

Exemple de compartiments :

* cmp-casae-001
* cmp-conne-001
* cmp-nocla-001
* cmp-non-prod-001
* cmp-prod-001
* cmp-sejou-001
* racine

Pour obtenir la liste des compartiments de la zone d’accueil :

![Schema compartiments ](../images/Compartiments.png)

Pour consulter la liste des cibles ainsi créées :

![Schema compartiments ](../images/Ciblestotal.png)

## Collecter et analyser la posture de sécurité

Les cibles ayant été définies, Cloud Guard sera en mesure de collecter les informations.

![Schema présentation ](../images/Présentation.png)

**Notation de l'indice de sécurité** : un outil de mesure de la posture de sécurité actuelle

![Schema score sécurité ](../images/Sécurité.png)

L'indice de sécurité numérique indique le pourcentage de ressources examinées par Cloud Guard qui n'ont pas été signalées comme des problèmes potentiels.
Plus l'indice de sécurité est élevé, plus la sécurité est bonne. Un indice de sécurité de 100 signifie qu'aucun problème n'a été détecté pour aucune ressource.

**L'indice de risque** : un outil d'estimation du niveau de risque actuel pour l’environnement

L'indice de risque numérique est mis à jour toutes les 15 minutes. Il reflète le nombre total de problèmes détectés par Cloud Guard, le niveau de risque de chaque problème et les types de ressources impliquées.

Différentes catégories de ressources sont plus sensibles aux menaces de sécurité, et cette sensibilité est pondérée dans la notation. Par exemple, les utilisateurs (IAM) et les compartiments (*buckets*) sont considérés comme plus sensibles selon des facteurs tels que la facilité d'accès et la façon dont ils peuvent devenir des cibles d'attaque.

L'indice de risque brut calculé est normalisé pour entrer dans la plage comprise entre 0 et 9 999. Un indice de risque de « 0 » signifie qu'aucun problème n'a été détecté pour aucune ressource.

Un indice de risque élevé signifie généralement qu'il existe un grand nombre de problèmes présentant des niveaux de risque élevé (HIGH ou CRITICAL). Si les problèmes et les ressources en cause sont moins sensibles, un grand nombre de problèmes n'aboutit pas à un indice de risque élevé.

**Recommandations de sécurité** :
Il s'agit d'un ensemble de suggestions qui auront le plus grand impact sur l'amélioration de l'indice de sécurité et de risque.

![Schema recommandations ](../images/Recommandations.png)

Seules les dix premières recommandations sont présentées, il s’agit des plus critiques. Une fois qu'elles auront été prises en compte, elles auront un grand impact dans l’amélioration de la posture de sécurité.

![Schema recommandations ](../images/Recommandations2.png)

Pour chacune des recommandations, un menu permet de prendre connaissance du problème.

![Schema problèmes ](../images/Problèmes.png)

Les problèmes, classés selon une échelle, peuvent être regroupés par compartiments, par région ou par type de ressource.

![Schema problèmes ](../images/Problèmes2.png)

## Type de problème par catégorie et masquage de faux problème

Les problèmes sont définis par niveau de risque, type de détecteur, ressource, cible, région, libellés et date de première détection.

![Schema problèmes ](../images/Problèmes3.png)

Les listes de sécurité (*Security lists*) doivent être ouvertes pour permettre le routage lorsqu’un pare-feu de nouvelle génération (NGF) est utilisé. On peut ‘Marquer comme résolu’ ces problèmes si le NGF est bien configuré.  

![Schema problèmes ](../images/Masquage.png)   


[Retour à la Page d'accueil](../../README.md)   

