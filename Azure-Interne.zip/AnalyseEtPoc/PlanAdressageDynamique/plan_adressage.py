#
# Il est essentiel de vérifier les chevauchements lorsque vous planifiez un schéma d’adresse IP.
# Si les adresses IP se chevauchent, vous ne pourrez pas intégrer votre réseau local à votre réseau Azure.
#

import traceback
import ipaddress

class PlanAdressage():

    def generer(
            pliste_sous_reseau
            , palgorithme
            , pparametre_algorithme
            , pliste_portee_adresse_depart
            , ptype_adresse_ip = 'IPv4'
            
            ) :
        
        lretval = {}

        if (pliste_sous_reseau is None) :
            return lretval
        elif (len(pliste_sous_reseau) == 0 ) :
            return lretval
        elif (pliste_portee_adresse_depart is None) :
            return lretval
        elif (len(pliste_portee_adresse_depart) == 0 ) :
            return lretval
        else :
            
            if ( (palgorithme) == 'incrementation_prefixe_reseau') :
                
                lpas_prefixe_reseau_cidr = pparametre_algorithme['pas']

                lretval = PlanAdressage.incrementation_prefixe_reseau( pliste_sous_reseau , pliste_portee_adresse_depart , lpas_prefixe_reseau_cidr)                    
            elif ( (palgorithme) == 'nombre_hote') :
                lretval = PlanAdressage.a_partir_du_nombre_de_hotes( pliste_sous_reseau , pliste_portee_adresse_depart)                    
                
        return lretval


    #implementation des 2 stratégies
    #incrementation_prefixe_reseau
    # ET decrementation_prefixe_reseau
    # un ppas_prefixe_reseau_cidr négatif vaut une décrémentation
    def incrementation_prefixe_reseau(pliste_sous_reseau
                                        , pliste_portee_adresse_ip_depart 
                                        , ppas_prefixe_reseau_cidr):
            lretval = {}
            lprefixe_reseau = ''

            ladresse_ip_depart = ''
            if (pliste_portee_adresse_ip_depart is None) :
                return lretval
            elif (len(pliste_portee_adresse_ip_depart) == 0) :
                return lretval

            lliste_configuration_par_sous_reseau = {}
                
            lprefixe_reseau = ''

            if (len(pliste_portee_adresse_ip_depart) == 1):
                ladresse_ip_depart = pliste_portee_adresse_ip_depart[0]['adresseip']
                lportee_adresse_ip_depart = pliste_portee_adresse_ip_depart[0]['portee']
                lprefixe_reseau = pliste_portee_adresse_ip_depart[0]['prefixe_reseau']         

                #affecter la meme adresse de depart a tous les sous-reseaux
                for unSousReseau in pliste_sous_reseau :
                    uneConfig = {}
                    uneConfig['adresseip'] = ladresse_ip_depart
                    uneConfig['prefixe_reseau'] = lprefixe_reseau
                    lliste_configuration_par_sous_reseau[unSousReseau] =  uneConfig
                    #avant de traiter le sous reseau suivant incrementer ou decrementer le prefixe reseau suivant l algo
                    lprefixe_reseau = lprefixe_reseau + ppas_prefixe_reseau_cidr

            else :
                i = 0
                configParDefaut = {}
                lliste_sous_reseau_non_traite = []
                #copy  array
                for ss in pliste_sous_reseau :
                    lliste_sous_reseau_non_traite.append(ss)
                
                #prefixe par defaut de depart pour les souss reseau non traité
                lprefixe_reseau_depart_pour_autre_sous_reseau = ''

                for unePortee in pliste_portee_adresse_ip_depart :
            
                    ladresse_ip_depart = unePortee['adresseip']
                    lliste_sous_reseau_portee = unePortee['portee']
                    lprefixe_reseau = unePortee['prefixe_reseau']
                    
                    if (i == 0) :
                        configParDefaut['adresseip'] = ladresse_ip_depart
                        configParDefaut['prefixe_reseau'] = lprefixe_reseau  #a modifier avec le dernier prefixe apres avoir traité tous les sous reseau de la condif par defaut       
                        
                    for unSousReseau in lliste_sous_reseau_portee :
                        uneConfig = {}
                        uneConfig['adresseip'] = ladresse_ip_depart
                        uneConfig['prefixe_reseau'] = lprefixe_reseau         
                        lliste_configuration_par_sous_reseau[unSousReseau] =  uneConfig

                        #retirer de la liste des sous reseau non traité
                        lliste_sous_reseau_non_traite.remove(unSousReseau)
                        #avant de traiter le sous reseau suivant incrementer ou decrementer le prefixe reseau suivant l algo
                        lprefixe_reseau = lprefixe_reseau + ppas_prefixe_reseau_cidr

                    #si je suis sur la portee 0 , memoriser ce prefixe reseau , car il servira comme prefixe de depart pour les autres sous reseau non traité
                    if (i == 0) :
                        configParDefaut['prefixe_reseau'] = lprefixe_reseau
                    
                    i = i + 1
                
                #mettre la configuration apr defaut dans les sous reseau non traité   
                lprefixe_reseau  =  configParDefaut['prefixe_reseau']
                for unSousReseau in lliste_sous_reseau_non_traite :
                    
                    ladresse_ip  =  configParDefaut['adresseip']
                    lliste_configuration_par_sous_reseau[unSousReseau] =  {}
                    lliste_configuration_par_sous_reseau[unSousReseau]['adresseip'] = ladresse_ip
                    lliste_configuration_par_sous_reseau[unSousReseau]['prefixe_reseau'] = lprefixe_reseau
                    
                    lprefixe_reseau = lprefixe_reseau + ppas_prefixe_reseau_cidr
                
            
            #générer adressage pour chaque sous réseau
            for unSousReseau in pliste_sous_reseau :
                try:

                    #initialiser la structure
                    lretval[unSousReseau] = {}

                    uneConfig = lliste_configuration_par_sous_reseau[unSousReseau]
                    
                    ladresse_ip_depart = uneConfig['adresseip']
                    lprefixe_reseau_cidr = uneConfig['prefixe_reseau']


                    ladresse_sous_reseau = ladresse_ip_depart + '/' + str(lprefixe_reseau_cidr)

                    lretval[unSousReseau]['adressage'] = ladresse_sous_reseau
                    lretval[unSousReseau]['prefixe_reseau'] = str(lprefixe_reseau_cidr)
                    lretval[unSousReseau]['nombre_ip'] = ''

                    # valider la notation
                    # si pas valide , l'istruction ci-desuss va gnérer une exception que nous allon récuperer dans bloc except
                    lsous_reseau = ipaddress.ip_network(ladresse_sous_reseau)

                    # si interpreteur arrive ici , alors c est que l,asdressage est valide
                    # notifier dans la structure ue il y a pas erreur
                    lretval[unSousReseau]['erreur'] = False
                    
                    
                    
                    lretval[unSousReseau]['nombre_ip'] = lsous_reseau.num_addresses

                except Exception as e:
                    lretval[unSousReseau]['erreur'] = True
                    lretval[unSousReseau]['message_erreur'] = str(e)
                    #traceback.print_exc()
                #finally :
                    #continuer la génération sur le sous reseau suivant
                    #lprefixe_reseau_cidr = lprefixe_reseau_cidr + ppas_prefixe_reseau_cidr
            
            return lretval

    #calculer un prefixe réseau a aprtir d'une adresse IP de départ et un nombre de hotes
    def calculer_prefixe_reseau_from(padresse_ip_depart , pnombre_hote) :
        lprefixe_reseau = ''
        return lprefixe_reseau
    
    # générer plan adressage réseau avec nombre de hotes attendus
    def a_partir_du_nombre_de_hotes(pliste_sous_reseau
                                      , pliste_portee_adresse_ip_depart ):
        lretval = {}
        lprefixe_reseau = ''

        ladresse_ip_depart = ''
        if (pliste_portee_adresse_ip_depart is None) :
            return lretval
        elif (len(pliste_portee_adresse_ip_depart) == 0) :
            return lretval

        lliste_configuration_par_sous_reseau = {}
            
        lnombre_hote = 2

        if (len(pliste_portee_adresse_ip_depart) == 1):
            ladresse_ip_depart = pliste_portee_adresse_ip_depart[0]['adresseip']
            lportee_adresse_ip_depart = pliste_portee_adresse_ip_depart[0]['portee']
            lnombre_hote = pliste_portee_adresse_ip_depart[0]['nombre_hote']         

            #affecter la meme adresse de depart a tous les sous-reseaux
            for unSousReseau in pliste_sous_reseau :
                uneConfig = {}
                uneConfig['adresseip'] = ladresse_ip_depart
                uneConfig['nombre_hote'] = lnombre_hote
                lliste_configuration_par_sous_reseau[unSousReseau] =  uneConfig
                
        else :
            i = 0
            configParDefaut = {}
            lliste_sous_reseau_non_traite = []
            #copy  array
            for ss in pliste_sous_reseau :
                lliste_sous_reseau_non_traite.append(ss)
            
            for unePortee in pliste_portee_adresse_ip_depart :
        
                ladresse_ip_depart = unePortee['adresseip']
                lliste_sous_reseau_portee = unePortee['portee']
                lnombre_hote = unePortee['nombre_hote']
                
                if (i == 0) :
                    configParDefaut['adresseip'] = ladresse_ip_depart
                    configParDefaut['nombre_hote'] = lnombre_hote  

                for unSousReseau in lliste_sous_reseau_portee :
                    uneConfig = {}
                    uneConfig['adresseip'] = ladresse_ip_depart
                    uneConfig['nombre_hote'] = lnombre_hote
                    uneConfig['prefixe_reseau'] = calculer_prefixe_reseau_from( ladresse_ip_depart , lnombre_hote )         
                    lliste_configuration_par_sous_reseau[unSousReseau] =  uneConfig

                    #retirer de la liste des sous reseau non traité
                    lliste_sous_reseau_non_traite.remove(unSousReseau)
                    
                #si je suis sur la portee 0 , memoriser ce prefixe reseau , car il servira comme prefixe de depart pour les autres sous reseau non traité
                if (i == 0) :
                    configParDefaut['prefixe_reseau'] = calculer_prefixe_reseau_from( ladresse_ip_depart , lnombre_hote )         
                    
                
                i = i + 1
            
            #mettre la configuration apr defaut dans les sous reseau non traité   
            lprefixe_reseau  =  configParDefaut['prefixe_reseau']
            for unSousReseau in lliste_sous_reseau_non_traite :
                
                ladresse_ip  =  configParDefaut['adresseip']
                lliste_configuration_par_sous_reseau[unSousReseau] =  {}
                lliste_configuration_par_sous_reseau[unSousReseau]['adresseip'] = ladresse_ip
                lliste_configuration_par_sous_reseau[unSousReseau]['prefixe_reseau'] = lprefixe_reseau
                
        
        #générer adressage pour chaque sous réseau
        for unSousReseau in pliste_sous_reseau :
            try:

                #initialiser la structure
                lretval[unSousReseau] = {}

                uneConfig = lliste_configuration_par_sous_reseau[unSousReseau]
                
                ladresse_ip_depart = uneConfig['adresseip']
                lprefixe_reseau_cidr = uneConfig['prefixe_reseau']


                ladresse_sous_reseau = ladresse_ip_depart + '/' + str(lprefixe_reseau_cidr)

                lretval[unSousReseau]['adressage'] = ladresse_sous_reseau
                lretval[unSousReseau]['prefixe_reseau'] = str(lprefixe_reseau_cidr)
                lretval[unSousReseau]['nombre_ip'] = ''

                # valider la notation
                # si pas valide , l'istruction ci-desuss va gnérer une exception que nous allon récuperer dans bloc except
                lsous_reseau = ipaddress.ip_network(ladresse_sous_reseau)

                # si interpreteur arrive ici , alors c est que l,asdressage est valide
                # notifier dans la structure ue il y a pas erreur
                lretval[unSousReseau]['erreur'] = False
                
                
                
                lretval[unSousReseau]['nombre_ip'] = lsous_reseau.num_addresses

            except Exception as e:
                lretval[unSousReseau]['erreur'] = True
                lretval[unSousReseau]['message_erreur'] = str(e)
            
        return lretval
