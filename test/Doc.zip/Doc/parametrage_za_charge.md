#### Retour en arrière

* [Aperçu de l'abonnement Plateforme Connectivité](connectivite.md)
* [Étapes du déploiement](etapes_deploiement.md)
* [Aperçu des NSG (Groupes de sécurité réseau)](nsg.md)
* [Procédures de paramétrage](parametrage.md)
* [Page d'accueil](../Readme.md)

# Aperçu des zones d'accueil

Les zones d'accueil représentent des abonnements dédiés à l'hébergement des charges de travail applicatives.

Dans la hiérarchie des groupes d'administration, ces abonnements se trouvent en dessous du chemin Root/Organisation/Charges. Le découpage de la hiérarchie des groupes d'administration et abonnements afférents varie en fonction du scénario de déploiement. Pour le scénario "base", qui est pris en charge, la hiérarchie se présente comme ci-dessous.

## 1. Rôle des abonnements Zones d'accueil

L’architecture des zones d’accueil se base sur le cadre d'adoption infonuagique de Microsoft pour sa conception avec une approche de réseau en étoile [*hub and spoke*](https://docs.microsoft.com/fr-ca/azure/architecture/reference-architectures/hybrid-networking/hub-spoke?tabs=cli).

Dans cette topologie en étoile, les abonnements des zones d'accueil (**Données sensibles**, **Données non sensibles** et **Non-Prod** pour le scénario "base"), sont organisés en tant que périphériques (*spoke*) et sont tous liés par des appairages réseau (*VNet peering*) à l’abonnement du concentrateur du réseau Connectivité (*hub*) ainsi qu'à l'abonnement "Périmètre". Les flux de communication entre les périphériques (*spokes*) passent toujours à travers le concentrateur réseau (*hub*), étant restreints par des tables de routage et des contrôles d'accès niveau réseau ("NSG" en langage Azure).

![Architecture globale des zones d'accueil pour scénario "base"](images/hub-spoke-network-topology-architecture.png)

## 2. Les ressources spécifiques aux abonnements Zones d'accueil

Les abonnements de type Zone d'accueil sont dédiés au traitement des charges de travail et il n'y a pas de ressources et/ou services spécifiques déployés par défaut. Par contre, il y a des VNet, avec des sous-réseaux spécifiques pour les différents types de charges de travail, ainsi que les tables de routage et groupes de sécurité réseau afférents.

![Architecture zones d'accueil pour scénario "base"](images/hub-spoke-network-topology-architecture_charge_travail.png)

Pour une sécurité accrue, chaque abonnement dans les zones de charge peut être provisionné avec une machine virtuelle "Jump-box". Cela permet l'accès (pour gestion, dépannage, maintenance et soutien) aux ressources dans ces abonnements par le biais du service Azure Bastion sans avoir besoin d'exposer des adresses IP publiques (ce qui, en passant, est interdit selon les stratégies par défaut déployées par le script).

## 3. Les abonnements Zone d'accueil pour le scénario "base"

Les abonnements pour les zones d'accueil doivent être préalablement créés par un usager avec le rôle "administrateur tarification" (*Billing Admin* en langage Azure). Les ID de ces abonnements (en format GUID, par exemple abcd1234-5678-9abc-def0-123456789abc) doivent être assignés à des variables spécifiques dans le fichier de paramétrage, soit cei-base-param.yml (dans dossier azure-pipeline/config/variables/scenario-base) pour le scénario "base". Pour ne pas déployer une zone d'accueil, laisser simplement la valeur de l'abonnement vide (c'est-à-dire '').

### 3.1 Paramétrage "vanille" des abonnements Zone d'accueil pour le scénario "base"

Pour le scénario "base" (pris en charge), les abonnements sont les suivants :


| Abonnement             | En dessous des groupes d'administration:      | Variable                                | Commentaire                                                              |
| ------------------------ | ----------------------------------------------- | ----------------------------------------- | -------------------------------------------------------------------------- |
| Données sensibles      | Organisation/Charges/Production/Sensibles     | var-charges-sensibles-subscriptionId    | Des charges de travail qui traitent des données confidentielles et plus. |
| Données non sensibles | Organisation/Charges/Production/Non sensibles | var-charges-nonsensibles-subscriptionId | Des charges de travail qui traitent des données non confidentielles.     |
| Non-Prod               | Organisation/Charges/Non-Production           | var-charges-nonprod-subscriptionId      | Des charges de travail qui traitent des données de test.                |
| Carrés de sable       | Organisation/Experimentation                  | var-carresdesable-subscriptionId        | Des charges de travail qui traitent des données de test.                |

### 3.2 Notes importantes

* Il n'y a pas de valeur par "défaut" pour ces abonnements, il faut donc toujours les modifier.
* L'assignation par défaut des abonnements dans la hiérarchie des groupes d'administration dans le tableau ci-dessus peut être personnalisée en modifiant les fichiers suivants dans le même répertoire que cei-base-param.yml :
  * [cei-base-hierarchie.yml](../azure-pipeline/config/variables/scenario-base/cei-base-hierarchie.yml)
  * [cei-base-subscriptions.yml](../azure-pipeline/config/variables/scenario-base/cei-base-subscriptions.yml)
* Pour un exemple d'assignation différente, voir le scénario "complexe" dans le répertoire [scenario-complexe](../azure-pipeline/config/variables/scenario-complexe). Ce scénario est fourni pour permettre des déploiements plus élaborés.

![Architecture Zones d'Accueil pour scénario complexe](images/ArchitectureGlobale_RessourcesÀDeployer_ScenarioDefaut_V0.16.png)

### 3.3 Paramétrage avancé des abonnements Zone d'accueil pour scénario "base"

À part les modifications des variables des ID des abonnements dans le fichier de paramétrage (cei-base-param.yml pour scénario de base), il n'y a pas d'autre paramétrage obligatoire. Pour les usagers avec une maîtrise avancée du script V2, et qui désirent personnaliser "à fond" les déploiements, voici les fichiers à valider et à modifier si cela est absolument nécessaire :


| Fichier                                                                                             | Chemin relatif | Paramétrage                                                                                                                                                                                                                                                                                                                                            |
| ----------------------------------------------------------------------------------------------------- | ---------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| [cei-base-lz.yml](../azure-pipeline/config/variables/scenario-base/cei-base-lz.yml)                 | /scenario-base | Ajuster ici les plages IP assignées aux VNet et sous-réseaux, ainsi que les "noms courts" utilisés pour la nomenclature des ressources. Voir le [Plan d'adressage](#planadressage) plus bas pour le détail.                                                                                                                                       |
| [cei-base-routage.yml](../azure-pipeline/config/variables/scenario-base/cei-base-routage.yml) | /scenario-base | Ajuster ici les tables de routage pour les zones d'accueil (ainsi que pour les abonnements Plateforme). Dans le cas où l'on décide d'utiliser pour le routage une solution alternative à la passerelle VPN dans Connectivité, ajuster les```nextHopIpAddress```, codées en dur par défaut pour pointer vers la première interface de la passerelle VPN. |
| [cei-tpl-landingzone.yml](../azure-pipeline/config/variables/scenario-base/cei-tpl-landingzone.yml) | /              | Si on modifie cei-base-lz.yml, par exemple en rajoutant ou en modifiant les noms des sous-paramètres, il faut ajuster aussi ce pipeline qui génère des variables basées sur le paramétrage dans cei-base-lz.yml.                                                                                                                                          |

### 3.4 Notes importantes

* Les chemins dans le tableau ci-haut sont relatifs à azure-pipeline/config/variables.
* On recommande fortement de très bien maîtriser le script avant de tenter le paramétrage avancé.
* Regarder l'exemple de scénario "complexe" pour saisir les différences de paramétrage dans les fichiers mentionnés ci-haut.

## 4. Le routage et les règles d'accès réseau (NSG)

Le plan de routage introduit un premier niveau de sécurité, en interdisant la communication entre les zones d'accueil avec des niveaux de sécurité différents (par exemple entre Prod en Non-Prod ou entre "Données sensibles" et "Données non sensibles"). Le routage est basé sur des règles statiques définies usager (UDR) :


| De / À                | Gestion | Identité | Périmètre | Données sensibles | Données non sensibles | Non-Prod |
| ------------------------ | --------- | ----------- | ----------- | -------------------- | ------------------------ | ---------- |
| Gestion                | S/O     | Permis    | Permis    | Permis             | Permis                 | Permis   |
| Identité              | Permis  | S/O       | Permis    | Permis             | Permis                 | Permis   |
| Périmètre              | Permis  | Permis    | S/O       | Permis             | Permis                 | Permis   |
| Données sensibles     | Permis  | Permis    | Permis    | S/O                | Interdit               | Interdit |
| Données non sensibles | Permis  | Permis    | Permis    | Interdit           | S/O                    | Interdit |
| Non-Prod               | Permis  | Permis    | Permis    | Interdit           | Interdit               | S/O      |

Pour plus de détail sur le routage, voir le [document sur le routage](routage.md).

Pour plus de détail sur les règles de sécurité réseau, voir le [document sur les groupes de sécurité réseau ](nsg.md).

## <a id="planadressage"> 5. Le plan d'adressage des zones d'accueil

Pour le scénario "base", toutes les plages IP des zones d'accueil sont assignées par défaut en dessous du préfixe réseau 10.77.

En cas de conflit ou de superposition de cette plage avec d'autres plages d'adresse utilisées, changer dans le fichier de paramétrage (cei-base-param pour scénario "base") la variable suivante :  ```var-charges-virtualNetwork-ip-prefix```.

Si on désire changer la taille des plages d'adresse assignées aux Zones d'accueil (en concordance avec les changements dans le fichier [cei-base-lz.yml](../azure-pipeline/config/variables/scenario-base/cei-base-lz.yml), changer aussi les variables suivantes :


| Variable                           | Défaut     | Commentaire                                                                     |
| ------------------------------------ | ------------- | --------------------------------------------------------------------------------- |
| var-charges-nonsens-assigne-suffix | '.64.0/18'  | Espace total d'adressage assigné à la zone d'accueil "Données non sensibles" |
| var-charges-sens-assigne-suffix    | '.0.0/18'   | Espace total d'adressage assigné à la zone d'accueil "Données sensibles"     |
| var-charges-nonprod-assigne-suffix | '.128.0/17' | Espace total d'adressage assigné à la zone d'accueil "Non-Prod"               |

Pour plus de détail, voir le document sur le [plan d'adressage](plan_adressage.md).
