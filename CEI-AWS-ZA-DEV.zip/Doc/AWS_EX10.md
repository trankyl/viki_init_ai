# Contrôles de sécurité pour l'exigence minimale 10

10 : Mettre en place des services de cyberdéfense

Contrôles liés à l'exigence 10 : SI-2, SI-4

## < --- Contrôle EX10_SI-2--->

![EX10](image/SI2.PNG)  

## Première Validation

   1. Responsabilité du fournisseur : Oui
   2. Commentaire : Le service Systems Manager Patch Manager d’AWS automatise le processus d’application de correctifs à des instances gérées grâce à des mises à jour de sécurité et d’autres types de mises à jour.
Les opérateurs au sein de l’entreprise peuvent installer des correctifs régulièrement en planifiant l’exécution de ceux-ci comme tâche de la fenêtre de maintenance de la fonctionnalité Systems Manager.

   Par le biais de la console : AWS Systems Manager -> Patch Manager

## < --- Contrôle EX10_SI-4--->

![EX10](image/SI4.PNG)  

## Deuxième Validation

   1. Responsabilité du fournisseur : Oui
   2. Commentaire : Divers outils infonuagiques AWS natifs sont configurés pour fonctionner ensemble dans l’environnement AWS afin de détecter les utilisations non autorisées et les activités malicieuses.
   AWS Config évalue si vos configurations de ressources sont conformes aux règles pertinentes et résume les résultats dans un tableau.

   AWS Security Hub recueille les données de sécurité de tous les comptes et services AWS ainsi que des produits de tiers qui sont pris en charge. Il soutient également les équipes responsables de la sécurité à analyser les tendances au chapitre de la sécurité et à détecter les problèmes prioritaires.

   Les pare-feux FortiGate recueillent eux aussi des journaux. Ceux-ci peuvent être utilisés pour surveiller des stratégies de routage des données qui passent par les pare-feux.

   AWS GuardDuty est un service de détection des menaces qui surveille en permanence les activités malveillantes.

   AWS Firewall Manager – AWS Firewall Manager est un service de gestion de la sécurité permettant de configurer et de gérer de manière centralisée les Groupes de sécurité AWS EC2 de tous les comptes de la plateforme AWS de l’entreprise.
  
 [Retour à la Page d'accueil](/ReadMe.md)
