# Déploiement du script

## Étapes

0. [Sélection région de déploiement](#sélection-région-de-déploiement)
1. [Création de la pile](#création-de-la-pile)
2. [Chargement du script](#chargement-du-script)
3. [Information de la pile](#information-de-la-pile)
4. [Variables de la pile](#variables-de-la-pile)
5. [Création des réseaux](#création-des-réseaux)
6. [Connecter les réseaux OCI au réseau sur site](#connecter-les-réseaux-oci-au-réseau-sur-site)
7. [Variables réseaux concernant le VNC hub (DMZ VCN)](#variables-réseau-concernant-le-vnc-hub---dmz-vcn)
8. [Aucune configuration pour l'ExaData Cloud Service](#aucune-configuration-pour-exadata-cloud-service)
9. [Identifier vos plages d’intranet permises](#identifier-vos-plages-intranet-permises)
10. [Notification et posture de sécurité](#notification-et-posture-de-sécurité)
11. [Journalisation (Audit)](#journalisation---audit)
12. [Activation du balayage de vulnérabilité](#activation-du-balayage-de-vulnérabilité)
13. [Création de la pile paramétrée](#création-de-la-pile-paramétrée)
14. [Effectuer un “plan” de la pile](#effectuer-un-plan-de-la-pile)
15. [Validation du plan](#validation-du-plan)
16. [Lancement du script](#lancement-du-script)
17. [Confirmer l'état de l'exécution](#confirmer-état-exécution)

Important : Avant de commencer cette installation, assurez-vous d'avoir déjà revu la section [des Prérequis](Prerequis.md).

Pour valider votre déploiement, veuillez consulter le document [Vérification du déploiement](Deploi_Verif.md).

Ce document décrit les étapes à suivre pour le déploiement du script 'Terraform' pour la zone d'accueil d'Oracle.  
Le déploiement se fait à travers le service ["Oracle Cloud Infrastructure (OCI) Resource Manager"](https://docs.oracle.com/fr-fr/iaas/Content/ResourceManager/Concepts/resourcemanager.htm). Il s'agit d'un service géré par Oracle qui automatise le déploiement et les opérations pour toutes les ressources Oracle Cloud Infrastructure.

## Sélection région de déploiement

Commencer par définir la région dans laquelle seront déployées les ressources qui vont suivre.

![selection_region_deploiement](../images/deploiement/selection_region_deploiement.JPG)   

Dans ce document , nous avons choisi le centre de données de Montréal (ca-montreal-1)

*Nota Bene* : La région ici doit être la même que la région de déploiement des [préréquis](Prerequis.md) ( le compartiment englobant , la Passerelle de routage dynamique , etc.)


## Création de la pile

- À partir de la console  
  - Dans le menu gauche, choisir "Services de développement"  
        - Dans la section "Gestionnaire de ressources", cliquer sur "Piles"  
            - À gauche de l'écran, choisir le "Compartiment" créé préalablement et cliquer sur le bouton "Créer une pile".  

### Écran 6.0

  ![Déploiement](../images/DP_Ecran60.png)

## Chargement du script

  Dans l'écran de la création de la "Pile"  
  -Choisir zip file  
    - Cliquer sur 'Browse' pour choisir le fichier du script en format .zip  
      - Sélectionner le fichier comportant l'extension .zip  

### Écran 6.1

  ![Déploiement](../images/DP_Ecran61.png)

## Information de la pile

- Assurez-vous de donner un nom significatif à la "Pile"; nous vous suggérons d'ajouter la date au nom du fichier.  
- Vérifier le champ "Créer dans le compartiment" : il doit contenir le nom du compartiment créé dans la section [Les Prérequis](Prerequis.md).  

### Écran 7

  ![Déploiement](../images/DP_Ecran7.png)

## Variables de la pile

 Saisir les variables que la "Pile" utilisera lors de son exécution.  
 Ces variables sont :

- La région où les ressources seront créées;  
- Le préfixe des noms dans le compartiment "Root". Puisque le préfixe est par installation, il permettra de différencier et de catégoriser les objets créés par déploiement;  
- Le nom du compartiment englobant créé dans la section des prérequis;  
- L'option "CREATE" pour créer les objets dans le compartiment Racine.  

### Écran 8

  ![Déploiement](../images/DP_Ecran8.png)  

Le champ **Région** permet de sélectionner la région où les ressources seront créées.  

Le champ **Préfixe** permet de définir le préfixe pour permettre d'exécuter le script plus d'une fois dans le même tenant.   

Dans le champ **Nom du compartiment englobant** , sélectionner le même nom du compartiment que le compartiment créé dans la section des prérequis


## Création des réseaux

L'écran suivant utilisera les blocs d'adresses en entrée pour créer les réseaux suivants :
  
- 3 réseaux pour la production, appelés ici PROD  
- 3 réseaux pour la non-production, appelés ici NonProd  
- 1 réseau pour le bac à sable, appelé ici Sandbox  
- 1 réseau pour le non classé, appelé ici Unclassified  
- 1 réseau concentrateur  

 Ajuster les plages d'adresses IP (CIDR) selon vos besoins.  Vous pouvez consulter les plages utilisées lors de notre déploiement en consultant le volet [Planification réseautique](Prerequis.md#planification-réseautique) dans la section des prérequis.

### Écran 9

Saisir les noms des compartiments suivant votre objectif d'affaire ou utiliser les noms proposés par défaut par le système.   

  ![Déploiement](../images/DP_Ecran9A_nom_compartiment.PNG)   

Puis saisir le plan d'adressage de ces compartiments.   

  ![Création_réseaux](../images/DP_Ecran9.png)

### Écran 10   

Pour les noms des réseaux virtuels (VCN) , vous pouvez laisser les champs vides, et les noms par défaut du système seront utilisés.  

 ![Connecter_réseaux](../images/DP_Ecran10A.JPG)

Ou vous pouvez personnaliser les noms des réseaux virtuels (VCN) comme dans la capture suivante :    

 ![Connecter_réseaux](../images/DP_Ecran10.JPG)


## Connecter les réseaux OCI au réseau sur site

- Copier l’identifiant de la passerelle de routage dynamique (OCID) créé durant l’étape des [Prérequis](Prerequis.md#un-drg-doit-être-créé-au-préalable-pour-pouvoir-établir-une-communication-avec-votre-infrastructure-sur-site-on-premise).  

 ![DRG existante](../images/DP_Ecran10C.png)
   

## Variables réseau concernant le VNC HUB - DMZ VCN

Cette étape vous donne la possibilité de choisir si vous souhaitez déployer un pare-feu.  
Le script vous propose également de choisir d'installer le pare-feu 'FortiGate' de Fortinet. Selon le pare-feu choisi, vous devez saisir le nombre de sous-réseaux (*subnet*) et leur taille; dans notre cas, ce sera quatre sous-réseaux.

### Écran 11

![Connecter_réseaux](../images/DP_Ecran11.png)   

* Copier la clé SSH publique créée durant l'étape [ Générer une paire de clés SSH](PreRequis.md#une-paire-de-clées-ssh-doit-être-générée-au-préalable-pour-la-création-des-vms-fortinet)   dans les prérequis.    
* Coller le jeton d'accès généré à l'étape [Génération du jeton pour accéder au dépôt de configurations des pare-feux Fortigate](PreRequis.md#génération-du-jeton-pour-accéder-au-dépôt-de-configurations-des-pare-feux-fortigate) dans les prérequis

## Aucune configuration pour ExaData Cloud Service

### Écran 12

![Connecter_réseaux](../images/DP_Ecran12.jpg)

## Identifier vos plages intranet permises

### Écran 13

![Connecter_réseaux](../images/DP_Ecran13.png)

## Notification et posture de sécurité

### Écran 14

![Connecter_réseaux](../images/DP_Ecran14.png)

## Journalisation - Audit

La journalisation est activée, mais celle-ci n'est pas activée.

## Écran 15

![Connecter_réseaux](../images/DP_Ecran15.png)   

L'activation permet d'utiliser un service d'analyse d'audit de journaux , plus élaboré ( Oracle Log Analytics ) ou d'envoyer les journaux vers un outil externe.

## Activation du balayage de vulnérabilité

### Écran 16

![Connecter_réseaux](../images/DP_Ecran16.png)

## Création de la pile paramétrée

### Écran 17

![Connecter_réseaux](../images/DP_Ecran17.png)   


Cliquer sur le bouton **Créer** pour sauvegarder cette pile incluant les valeurs des paramètres , mais sans exécuter le script.   


## Effectuer un plan de la pile

Effectuer un 'plan' pour valider le script et ses paramètres.
Cliquer sur le bouton 'Plan', puis confirmer dans l'écran suivant en cliquant encore sur le bouton 'Plan'.

### Écran 18 /Écran 19

![Connecter_réseaux](../images/DP_Ecran18.png)

![Connecter_réseaux](../images/DP_Ecran19.png)

## Validation du plan

L'état (*state*) est en mode 'Accepté/Accepted', il faut attendre l'exécution, puis vérifier que l'état soit "Réussie/Succeeded".  

### Écran 20

![Connecter_réseaux](../images/DP_Ecran20.png)

### Écran 21

Si les paramètres sont conformes, l'état passe alors au ‘vert’ et comporte la mention *Réussite (Succeeded)*.

![Connecter_réseaux](../images/DP_Ecran21.png)

## Lancement du script

Pour lancer le script, cliquer sur le bouton "Apply", puis confirmer une seconde fois en appuyant sur le bouton "Apply" à l'écran suivant.

### Écran 22 / Écran 23

![Connecter_réseaux](../images/DP_Ecran22.png)

![Connecter_réseaux](../images/DP_Ecran23.png)

## Confirmer état exécution

Si le script a été exécuté sans erreur, l'état sera alors en vert et affichera *"Succès/Succeeded"*.
Vous pouvez télécharger ou consulter le journal d'exécution se trouvant au bas de l'écran.

### Écran 24

![Connecter_réseaux](../images/DP_Ecran24.JPG)

[Retour à la Page d'accueil](../../ReadMe.md)
