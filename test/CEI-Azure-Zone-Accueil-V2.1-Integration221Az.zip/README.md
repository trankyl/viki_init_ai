# Zone d’accueil Azure pour le gouvernement du Québec

version 2.2

---

Avec le [Décret 596-2020](http://www2.publicationsduquebec.gouv.qc.ca/dynamicSearch/telecharge.php?type=1&file=72729.pdf), le gouvernement du Québec exige que les organismes publics (OP) et les établissements du réseau de l’éducation et de l’enseignement supérieur (REES), ainsi que celui de la santé et des services sociaux (RSSS), transposent leurs charges de travail informatiques en environnement infonuagique. L’adoption de l’infonuagique constitue un réel défi pour ces organisations publiques dont certaines ne disposent pas des ressources et des connaissances nécessaires pour assurer la sécurité des charges de travail dans l’infonuagique. Ce défi engendre de grands enjeux considérant que la sécurité des informations dans le nuage est une responsabilité partagée entre le client et le fournisseur.

Considérant les différents enjeux encadrant la migration vers l’infonuagique et l’application des [exigences minimales de sécurité dans le nuage](https://ccti.isec.gouv.qc.ca/SitePages/Exigences-minimales-de-s%C3%A9curit%C3%A9-dans-le-nuage(1).aspx)  imposées par le Centre gouvernemental de cyberdéfense (CGCD), le Centre d’expertise en infonuagique (CEI) propose en collaboration avec Microsoft un script qui permet de déployer de manière automatisée des [zones d'accueil](https://docs.microsoft.com/fr-ca/azure/cloud-adoption-framework/ready/landing-zone/) basées sur les meilleures pratiques, la documentation et les outils du CAF [*Cloud Adoption Framework for Azure*](https://learn.microsoft.com/fr-ca/azure/cloud-adoption-framework/).

> Important : [Licence et conditions d’utilisation du script et ses composantes](Licence.md)

---

## Table de Matières

[Décisions clés d'architecture](#DecisionsClesArchitecture)

1. [Gouvernance et organisation des ressources](#GouvernanceEtOrganisationDesRessources)
2. [Topologie de réseau et services partagés](#TopologieDeReseauEtServicesPartages)
3. [Sécurité](#Securite)
4. [Identité](#Identite)
5. [Gestion et outils de supervision](#GestionEtOutilsDeSupervision)
6. [Surveillance et sécurité](#SurveillanceEtSecurite)

[Déploiement des zones d'accueil](#DeploiementDesZonesAccueil)

7. [Clonage et prise de connaissance du script](#ClonageEtPriseDeConnaissanceDuScript)
8. [Paramétrage et exécution du script](#ParametrageEtExecutionDuScript)
9. [Notes de version](#Notesdeversion)

---

## <div id="DecisionsClesArchitecture" ></div>Décisions clés d'architecture

---

Nous présentons dans ce qui suit les éléments clés qui ont encadré la conception et l’implémentation du script proposé pour le déploiement d’une zone d’accueil Azure.

- La gouvernance et la conformité
- La topologie réseau et les services partagés
- La sécurité
- L’identité
- La gestion de l’environnement

---

## <div id="GouvernanceEtOrganisationDesRessources" ></div>1. Gouvernance et organisation des ressources

### 1.1 Considérations relatives à la conformité opérationnelle

#### Implémentation des groupes d’administration

Les groupes d'administration permettent aux organismes et établissements de gérer efficacement l'accès, la gouvernance et la conformité pour tous les abonnements. Les groupes d'administration agissent comme conteneurs et fournissent des niveaux d'étendue supérieure aux abonnements. Les [politiques/stratégies d’accès (*policies*) Azure et le contrôle d'accès basé sur les rôles (RBAC)](https://docs.microsoft.com/fr-fr/azure/governance/policy/overview#azure-policy-and-azure-rbac.html) sont appliqués aux [groupes d'administration](https://docs.microsoft.com/fr-ca/azure/governance/management-groups/overview.html). Ainsi, tous les abonnements au sein d'un groupe d'administration héritent automatiquement des paramètres appliqués au groupe d'administration. Pour ce faire, tous les abonnements doivent approuver le même [locataire Azure Active Directory](https://docs.microsoft.com/fr-ca/azure/active-directory/fundamentals/active-directory-whatis.html).

Le CEI propose une structure de groupe d'administration (scénario de base) qui permettrait de combler les besoins de la grande majorité des organismes et établissements, peu importe le type ou l'envergure. Cela dit, cette structure peut être personnalisée en fonction des besoins spécifiques d'une organisation.

![architecture_zones_daccueil_base](Doc/images/Architecture-Landing-zones-Prod-Nonprod-Prof-A-Prof-B.jpg "Architecture zones d'accueil scénario base")

Au sein d'Azure, tout est divisé en abonnements distincts.

- Il existe des abonnements pour l'identité, la gestion, la connectivité et le périmètre. Tous ces abonnements se trouvent sous le groupe d'administration de la plateforme (services communs).
- Au milieu se trouvent les zones de destination plus spécifiques à l'application avec leur propre ensemble de ressources, nommées zones de charges. Dans ces zones, les charges de travail de production (données sensibles et non sensibles) ainsi que celles de la non-production (dev/tes/accep) seront accueillies.
- Se trouve ensuite la zone « décommissionnée » pour les applications retirées ou en voie de retrait.
- Pour finir, à droite, se trouve la zone pour l'exploration et les bacs à sable.

Pour le scénario complexe, l'architecture est similaire mais avec une hierarchie un peu différente

![architecture_zones_daccueil_complexe](Doc/images/Architecture-Landing-zones-complexe.jpg "Architecture zones d'accueil scénario complexe")

#### Utilisation des stratégies de Azure – Azure Policy

Les stratégies Azure évaluent les ressources Azure en comparant les propriétés de ces ressources aux règles métier (définitions) déterminées. Il est possible de déployer un grand nombre de stratégies individuelles. Cependant, une [initiative](https://docs.microsoft.com/fr-ca/azure/defender-for-cloud/security-policy-concept#what-is-a-security-initiative) simplifie la gestion en regroupant un grand nombre de définitions.

Une fois établies, les définitions de stratégie sont appliquées aux ressources à l'aide de diverses étendues, notamment des groupes d'administration, des abonnements, des groupes de ressources ou des ressources individuelles. La définition de stratégie s'applique à toutes les ressources dans la portée définie. Dans le script proposé, l'application des stratégies et des initiatives sur les groupes d'administration est à privilégier.

### 1.2 Considérations relatives à l’inventaire et à la visibilité

#### Démocratisation des abonnements

Il s'agit ici de la séparation des abonnements pour différents environnements, par exemple, production et non-production (dev/test/etc.). Les abonnements sont partagés par toutes les applications ou charges de travail et leurs équipes.

#### Étiquetage des ressources

Les étiquettes (*Tag* en anglais) sont des éléments de métadonnées qu’il faut appliquer à l’ensemble des ressources Azure. Elles se basent principalement sur la classification des données déterminées lors du processus d’analyse des préjudices (étape réalisée préalablement à l’implémentation de la zone d’accueil). Elles se présentent sous forme de paires clé-valeur qui permettent d’identifier de manière pertinente les ressources en fonction des paramètres de l'organisation.

> Dans le cadre du script proposé pour le déploiement automatisé de la zone d’accueil, le CEI utilise une nomenclature prédéfinie et configurable afin de nommer les composantes de base de l’infrastructure Azure en infonuagique. Cependant, pour l’exploitation des environnements infonuagiques, les organisations ont la liberté de nommer leurs ressources selon leurs besoins et normes.

Stratégie d’application des étiquettes dans une structure organisationnelle

![étiquettes](Doc/images/etiquettes.drawio.png "étiquettes")

---

## <a id="TopologieDeReseauEtServicesPartages"></a>2. Topologie réseau et services partagés

### 2.1 Architecture de réseau en étoile (*Hub and Spoke*)

#### La topologie de réseau et la zone de conception de connectivité sont essentielles pour l’établissement d’une base pour la conception de réseau en nuage.

Cette architecture de référence déploie une topologie de réseau en étoile (*hub and spoke*) dans Azure.
Le réseau virtuel *hub* joue le rôle de point central de la connectivité à de nombreux réseaux virtuels périphériques (*spoke*). Le concentrateur (*hub*) peut également être utilisé comme point de connectivité aux réseaux locaux de l'organisation. Les réseaux virtuels périphériques (*spokes*) sont appairés avec le concentrateur (*hub*) et peuvent ainsi être utilisés pour isoler les charges de travail.

![hub-spoke-network-topology-architecture](Doc/images/hub-spoke-network-topology-architecture.jpg "hub-spoke-network-topology-architecture")

### 2.2 Utilisation des adresses IPV4 privées

#### Basé sur RFC 1918 et RFC 6598

Trois plages d'adresses ont été utilisées pour la segmentation des réseaux virtuels, tels que :

- 10.84.0.0/16 (connectivité et périmètre)
- 10.73.0.0/16 (gestion et identité)
- 10.77.0.0/16 (zone de charge de travail)

![IP](Doc/images/IP.jpg "IPV4")

#### Note importante pour les organismes publics et les ministères

> Les plages définies plus haut ont été exclues du routage du [RITM](https://www.quebec.ca/gouvernement/faire-affaire-gouvernement/services-organisations-publiques/services-de-plateformes-technologiques/communications-informatiques-et-multimedias/reseau-integre-telecommunication-multimedia-ritm) et le seront bientôt pour le [RGT](https://infratech.gouv.qc.ca/grands-projets/reseau-gouvernemental-de-telecommunication), afin d’éviter les conflits avec les services publiés dans le RITM/RGT. Il est donc fortement recommandé d’utiliser les plages proposées.

### 2.3 Connectivité réseau privé vers sur site (*on-prem*)

#### Utilisation d'une passerelle VPN ou Express Route centralisée

Une passerelle VPN ou Express Route dans le concentrateur (*hub*) avec appairage (*peering*) des périphériques (*spokes*) est prévu. Ainsi, toutes les communications interpériphériques (*inter-spokes*) passent à travers le concentrateur (*hub*) en respectant les exigences par le biais des tables définies par utilisateur (UDR).

### 2.4 Routage

Dans le scénario de base proposé, le routage du trafic dans Azure et entre Azure sur site (*on-prem*) est assuré par la passerelle de réseau virtuel (*virtual network gateway*) déployé dans le concentrateur (*hub*).
Au déploiement de chaque périphérique (*spoke*) et/ou d'une zone d’accueil applicative par le script proposé, les [routes](https://docs.microsoft.com/fr-fr/azure/virtual-network/network-security-groups-overview) ainsi que les [groupes de sécurité réseau (NSG)](https://docs.microsoft.com/fr-fr/azure/virtual-network/network-security-groups-overview) sont créés et assignés aux réseaux et aux sous-réseaux.

### 2.5 DNS

La resolution DNS c’est un point de conception critique dans l’architecture de Zone d'accueil Azure et pendant l'exploitation de l'infrastructure infonuagique.

Le script se limite à activer et configure le service des zones DNS privées Azure pour la résolution dans les reseux virtuels des abonnements du HUB, les spokes de gestion et identité ainsi que les zones d’accueil des charges de travail.

![DNS](Doc/images/dns-za.jpg "DNS")

La zone DNS privée deployée offre les capacités suivantes :

- Inscription automatique de machines virtuelles à partir d’un réseau virtuel lié à une zone privée avec l’inscription automatique activée
- Prise en charge de la résolution DNS sur plusieurs réseaux virtuels liés à la zone privée
- Prise en charge de la recherche DNS inversée dans l’étendue du réseau virtuel

---

## <div id="Securite" ></div>3.Sécurité

Les barrières de sécurité (*Guardrails*) sont déployées par les [Azure Policy](https://docs.microsoft.com/azure/governance/policy/overview) et permettent de renforcer la conformité aux standards de sécurité des organisations. Azure permet de visualiser dans des tableaux de bord l'état de conformité des ressources, ainsi que les déraillements (*drift*) des configurations. Voir [Azure Policy for Guardrails for an explanation of the built-in and custom policy definitions](https://github.com/Azure/CanadaPubSecALZ/blob/main/docs/policy/readme.md).

![Conformite](Doc/images/conformite.png "Conformité")

La sécurité est au cœur du script proposé. En effet, de nombreux outils et contrôles sont déployés au niveau de l'implémentation pour aider les organisations à obtenir rapidement une ligne de base de sécurité.

### 3.1 Outils

L’utilisation des outils suivants est recommandée :

- Niveau standard ou gratuit de Microsoft Defender pour le nuage
- Plan de protection Azure DDoS standard (facultatif)
- Pare-feu Azure ou NVA pour la zone périmètre
- Pare-feu d’applications Web (WAF) pour la protection des applications Web
- Privileged Identity Management (PIM)
- Intégration avec SIEM (facultatif)

### 3.2 Stratégies

Les stratégies suivantes sont déployées par le script :

- Les stratégies intégrées (*built in*) du profil PBMM du gouvernement du Canada
- [Les stratégies personnalisées du cadre d'adoption infonuagique](https://github.com/Azure/Enterprise-Scale/blob/dd16f84b040a33e77982757b049367387f36a35b/docs/ESLZ-Policies.md#eslz-policy-assignments-for-built-in-policy-definitions-and-policy-set-definitions)
- Les stratégies personnalisées du NIST 800-53 R4
- Les stratégies personnalisées des standards de sécurité Azure
- Les stratégies personnalisées provenant du CEI

Lorsqu'une règle de stratégie est évaluée pour une mise en correspondance, les exemples d’actions suivantes pourraient se produire :

- Imposer un accès sécurisé, par exemple HTTPS, aux comptes de stockage
- Appliquer l’audit pour Azure SQL Database
- Appliquer le chiffrement pour Azure SQL Database
- Empêcher le transfert IP
- Empêcher le protocole RDP entrant à partir d’Internet
- S’assurer que les sous-réseaux sont associés aux [groupes de sécurité réseau]() (NSG).

L'exemple qui suit présente des groupes de sécurité réseau (NSG) qui sont déployés et assignés par le script proposé.

![NSG](Doc/images/NSG.jpg "NSG")

---

## <div id="Identite" ></div>4. Identité

### 4.1 Contrôle d'accès par rôle et gestion des identités et des accès (GIA)

#### Gestion des identités et des accès

La gestion des identités et des accès est un des piliers majeurs d’une zone d’accueil en plus d’être un contrôle important en matière de sécurité de l’information. C’est pour cette raison que les quatre premières exigences de sécurité minimales couvrent une bonne partie de la GIA. Son implémentation se fait en utilisant Azure Active Directory avec groupes de sécurité et rôles.

#### Contrôle d’accès basé sur des rôles RBAC

Dans notre cas, nous avons inclus un modèle commun de séparation des responsabilités informatiques en [rôles personnalisés](https://docs.microsoft.com/fr-ca/azure/cloud-adoption-framework/ready/considerations/roles). Celui-ci est préconisé par Microsoft et est basé sur le principe de moindre privilège et de la séparation des rôles.

![RBAC](Doc/images/rbac.jpg "RBAC")

#### Affectation des autorisations

Les droits administrateur sont considérés comme une lame à double tranchant. Dans cette optique, il est vivement recommandé d’utiliser [Azure Privilege Identity Management (PIM)](https://docs.microsoft.com/fr-ca/azure/active-directory/privileged-identity-management/pim-configure) pour assigner les droits nécessaires en appliquant le principe de Nécessité de savoir (*Need to know*) selon le scénario affiché dans le tableau suivant :

![PIM](Doc/images/pim.jpg "PIM")

### 4.2 Accès conditionnel

#### Implémentation des autorisations basées sur des stratégies et des conditions d’accès

Il s'agit ici du renfoncement des systèmes d’identification et d’autorisation, basés sur des signaux courants, que l’accès conditionnel peut prendre en compte lors d’une prise de décision en matière de stratégie tels que :

- Détection des risques en temps réel
- Appareil spécifique
- Informations d’emplacement IP

---

## <a id="GestionEtOutilsDeSupervision"></a>5. Gestion et outils de supervision

### 5.1 Surveillance des événements de sécurité et des charges de travail

#### Azure Monitoring et Azure Log Analytics ainsi que Network Watcher pour l'analyse de trafic

Afin d’assurer une bonne pratique d’audit et de sécurité, le script :

- Déploie Azure Monitoring et Network Watcher dans chaque périphérique (*spoke*);
- Active les journaux de flux NSG sur tous les réseaux virtuels et sous-réseaux critiques des abonnements.

## 5.2 Gestion des charges de travail et le flux de management

#### Utilisation des sous-réseaux de gestion et [Azure Bastion](https://docs.microsoft.com/fr-ca/azure/bastion/bastion-overview) pour l'administration des charges de travail

L’utilisation des *Jump box* primaires et locales permet de contrôler et d'unifier le trafic de gestion, ainsi que d’éviter l’exposition des machines virtuelles depuis un réseau de non-confiance en s’appuyant sur des règles de sécurité NSG restreintes et des stratégies de sécurité qui empêchent l’utilisation des adresses IP publiques.

## <div id="SurveillanceEtSecurite"></div>6. Surveillance et sécurité

Pour la surveillance et renforcement de la posture de sécurité, **Azure Defender for Cloud** sera activé avec la licence *Standard* pour certains contrôles de sécurité comme la gestion des vulnérabilités, la conformité dans l’évaluation continue des actifs, l'activation des alertes lors de la détection des menaces.

Voici la posture de sécurité attendue par abonnement : [surveillance_et_securite.md](Doc\surveillance_et_securite.md)

---

## <div id="DeploiementDesZonesAccueil"></div>Déploiement des zones d'accueil

---

## <div id="ClonageEtPriseDeConnaissanceDuScript"></div>7. Clonage et prise de connaissance du script [Voir ici](Doc/clonage_et_apercu_script.md)

## <div id="ParametrageEtExecutionDuScript"></div>8. Paramétrage et exécution du script [Voir ici](Doc/parametrage_deploiements.md)

## <div id="Notesdeversion"></div>9. Notes de version [Voir ici](Doc/notes_de_version.md)
