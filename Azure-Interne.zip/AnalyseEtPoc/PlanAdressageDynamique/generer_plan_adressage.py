#script python de generation du plan d'adressage

import traceback
import netaddr
from plan_adressage import PlanAdressage
import argparse




def init_argparse():
    parser = argparse.ArgumentParser()

    parser = argparse.ArgumentParser(description='Génération du plan d adressage')
    parser.add_argument('-a' , '--algorithme', type=str , help='Type algorithme a appliquer pour generer plan' , default='incrementation_prefixe_reseau' , required= True)
    parser.add_argument('-p', '--portee_adresse_depart' , type=str , help='Liste des sous-réseux avec leur adresses de depart' , required=True)
    #
    #separateur : &
    #pour chaque sous-reseau : pas d espace , pas de - , pas de caractere accentue
    parser.add_argument('-l' ,'--liste_sous_reseau' , type=str , help='Liste des sous-réseux dans la zone d accueil , sparé par une virgule' , required= True)
    parser.add_argument('-i', '--pas' , type=int , help='Pas pour incrementer ou decrementer prefixe reseau' , default=1)
    
    return parser

if __name__ == '__main__':

    parser = init_argparse()
    args = parser.parse_args()

    lalgorithme = args.algorithme
    lpas = args.pas

    lportee_adresse_depart =  args.portee_adresse_depart
    lstr_liste_sous_reseau =  args.liste_sous_reseau

    

    
try:

    
    
    lalgorithme = args.algorithme
    lpas = args.pas
    
    lportee_adresse_depart =  args.portee_adresse_depart
    lstr_liste_sous_reseau =  args.liste_sous_reseau

    #lportee_adresse_depart = '10.84.0.0&17&ÉVOLUTION@10.82.0.0&18&connectivite,Gateway'
    #lalgorithme = 'incrementation_prefixe_reseau'
    #lstr_liste_sous_reseau = 'connectivite,ASSIGNÉ,Gateway,Azure Firewall,ÉVOLUTION,NVA Subnet - externe,NVA Subnet - interne'
    #lpas = 1

    print('pas préfixe réseau = ' + str(lpas))
    print('algorithme = ' + lalgorithme)
    print('liste spokes et espaces réseau = ' + lstr_liste_sous_reseau)
    print('liste configuration par spokes et espaces réseau = ' + lportee_adresse_depart)
    
    
    lliste_sous_reseau = lstr_liste_sous_reseau.split('&')

    #gliste_sous_reseau = ['connectivite','ASSIGNÉ','Gateway','Azure Firewall', 'NVA Subnet - externe']
    #gliste_sous_reseau.append('NVA Subnet - interne')
    #gliste_sous_reseau.append('NVA Subnet - HASync')
    #gliste_sous_reseau.append('NVA Subnet - Gestion')
    #gliste_sous_reseau.append('Desserte Subnet')    
    #gliste_sous_reseau.append('Application Gateway')    
    #gliste_sous_reseau.append('ÉVOLUTION')
    #gliste_sous_reseau.append('VNET PÉRIMÈTRE')
    #gliste_sous_reseau.append('VNET CONNECTIVITÉ')

    
    

    lstr_liste_portee_adressage_depart = lportee_adresse_depart
    #Exemple : '10.84.0.0&17&ÉVOLUTION@10.82.0.0&18&connectivite,Gateway'
    lliste_portee_dans_parametre = lstr_liste_portee_adressage_depart.split('@')
    #resultat
    #['10.84.0.0&17&ÉVOLUTION' , '10.82.0.0&18&connectivite,Gateway']

    #liste des portées formatée pour la methode PlanAdressage.generer
    lliste_portee_adressage_depart = []

    if (lalgorithme == 'incrementation_prefixe_reseau') :
        for unePortee in lliste_portee_dans_parametre :
            #Exemple '10.84.0.0&17&ÉVOLUTION'
            larr_info_dans_portee = unePortee.split('&')
            #resultat
            #['10.84.0.0','17','ÉVOLUTION']
            l = {}
            l['adresseip'] = str(larr_info_dans_portee[0])
            l['prefixe_reseau'] = int(larr_info_dans_portee[1])
            l['portee'] = str(larr_info_dans_portee[2]).split(',')
            lliste_portee_adressage_depart.append(l)
    elif (lalgorithme == 'nombre_hote') :
        for unePortee in lliste_portee_dans_parametre :
            #Exemple '10.84.0.0&512&ÉVOLUTION'
            larr_info_dans_portee = unePortee.split('&')
            #resultat
            #['10.84.0.0','512','ÉVOLUTION']
            l = {}
            l['adresseip'] = str(larr_info_dans_portee[0])
            l['nombre_hote'] = int(larr_info_dans_portee[1])
            l['portee'] = str(larr_info_dans_portee[2]).split(',')
            lliste_portee_adressage_depart.append(l)
    

    #liste des parametres de la stratégies de génération du plan d adressage
    lparametres_algorithme = {}

    if (lalgorithme == 'incrementation_prefixe_reseau') :
        lparametres_algorithme['pas'] = lpas

    schema_adressage = PlanAdressage.generer(lliste_sous_reseau , lalgorithme 
                                            , lparametres_algorithme , lliste_portee_adressage_depart)
    
    # set variable
    # set name of the variable
    name = 'planAdressage'
    # set value of the variable
    value = str(schema_adressage)
    #output python value to azure yaml pipeline
    print(f'##vso[task.setvariable variable={name};]{value}') 

except :
    # printing stack trace
    traceback.print_exc()

