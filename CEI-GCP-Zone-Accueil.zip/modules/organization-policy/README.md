# terraform-organization-policy

Comme une partie de la zone d'accueil GCP, les contraintes de la police d'organisation GCP sera utilisées comme une mesure préventive de sécurité afin de protéger la plateforme

Les contraintes initiales des polices qui seront activées par défaut sont alignées avec la recommendation dans "Recommandation de conception de GCP COM LZ", y compris les polices suivantes.


## Contraintes de police organisationnelle de GCP par défaut

1. Restriction d'emplacement de ressource GCP - Restreindre tous emplacements aux États-Unis, en Asie, en Europe et en Amérique du Sud.
2. Les IPs publiques ne seront pas permis dans les instances de VM
3. Seulement l'ID de directoire de client de l'organisation GC sera permis comme une entité IAM dans GCP, cela bloquera toutes les autres organisations de GSuit, y compris les comptes Gmail.
4. Forcer un accès et gestion IAM uniform au niveau de bucket
5. Requérir un login OS pour n'importe quel besoin de SSH/RDP
6. Sauter l'étape de création de VPC par défaut quand un nouveau projet a été créé
7. Restreindre l'acheminement d'IP de VM.

## Entrée du Module

### Entrée requise

Ce module a des entrées requises suivantes:
```
organization_id : String
    ID de l'organisation GCP sur laquelle les contraintes de polices s'appliqueront
```
```
directory_customer_id : Liste de String
    ID de client de directoire GSuite utilisé pour la restriction de domaine IAM. Cela sera obtenu en exécutant *Gcloud organizations list* après avoir authentifié avec GCloud.
    Afin d'obtenir l'ID avec *Gcloud organizations list*, c'est le dernier champ, pas un champ numéroté.
    Format pour le secret Github [\"ID\"]
```
Tous les deux entrées sont obligatoire pour utiliser ce module.

### Entrées Optionnelles

Les entrées optionnelles peuvent aider à ajouter des contraintes additionnelles de polices d'organisation, en utilisant les variables *policy_boolean* et *policy_list*

```
module "org_policy" {
  policy_boolean = {
    "constraints/compute.disableGuestAttributesAccess" = true
    "constraints/compute.skipDefaultNetworkCreation" = true
  }
  policy_list = {
    "constraints/computetrustedImageProjects" = {
      inherit_from_parent = null
      suggested_value = null
      status = true
      values = ["projects/my-project"]
    }
  }
}
```

## Exclusion de polices

GCP fournit des capacité pour exclure certaines contraintes de police. Pour la plateforme de LZ, l'exclusion s'appliquera via le module de projet.

<!-- BEGINNING OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
## Exigences

Pas d'exigences

## Fournisseurs

| Nom    | Version |
|--------|---------|
| google | n/a |

## Entrées

| Nom                              | Description                                                                                                                                                                 | Type | Défaut | Requis |
|----------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------|------|--------|:------:|
| directory\_customer\_id          | ID de directoire de client de l'organisation GCP                                                                                                                            | `list(string)` | n/a    |  oui   |
| organization\_id                 | ID de l'organisation GCP                                                                                                                                                    | `string` | n/a    |  oui   |
| policy\_boolean                  | Dictionnaire de police d'organisation de booléan et la valeur d'exécution, pour restaurer les polices, mettre `null`                                                        | `map(bool)` | `{}`   |   non   |
| policy\_list                     | Dictionnaire de police d'organisation, `true` pour `allow` et `false` pour `deny`, `null` pour restauration. Les valeurs ne peuvent être utilisé que pour `allow` ou `deny` | <pre>map(object({<br>    inherit_from_parent = bool<br>    suggested_value     = string<br>    status              = bool<br>    values              = list(string)<br>  }))</pre> | `{}`   |   non   |
| set\_default\_policy             | `True` pour activer les polices par défaut, sinon, pas de police par défaut.                                                                                                | `bool` | `true` |   non   |
| vms\_allowed\_with\_external\_ip | List de l'URI complet de VM permis qui peut avoir un IP externe                                                       | `list(string)` | `[]`   |   non   |
| vms\_allowed\_with\_ip\_forward  | List de l'URI complet de VM permis qui peut avoir un IP d'acheminement                                                                                                      | `list(string)` | `[]`   |   non   |

## Sorties

Pas de sorties

<!-- END OF PRE-COMMIT-TERRAFORM DOCS HOOK -->