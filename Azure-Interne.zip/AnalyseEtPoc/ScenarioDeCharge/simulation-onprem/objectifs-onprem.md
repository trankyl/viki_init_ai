# Objectifs de la simulation on-prem

![test-dns-azexplorer](img/test-dns-azexplorer.png)