
# Configuration de base du service Zone de Sécurité (Security Zone) dans une zone d'accueil OCI

## Sommaire   

* [Introduction](#introduction)   
* [Concepts autour de la zone de sécurité OCI](#concepts-autour-de-la-zone-de-sécurité-oci)  
  * [Cible zone de sécurité](#cible-zone-de-sécurité)
  * [Recette Zone de sécurité](#recette-zone-de-sécurité)  
  * [Recette de sécurité maximale](#recette-de-sécurité-maximale)  
  * [Stratégies de zone de sécurité](#stratégies-de-zone-de-sécurité)  
* [Spécifications configuration de base pour la Zone de Sécurité dans une Zone d'Accueil OCI](#spécifications-configuration-de-base-pour-la-zone-de-sécurité-dans-une-zone-accueil-oci)  
  * [Activation du service Cloud Guard de OCI](#activation-du-service-cloud-guard-de-oci)   
  * [Activation du service Zone de Sécurité de OCI](#activation-du-service-zone-de-sécurité-de-oci)   
  * [Cibles de Zone de Sécurité dans une zone d'accueil OCI](#cibles-de-zone-de-sécurité-dans-une-zone-accueil-oci)   
  * [Liste des stratégies de zone de sécurité](#liste-des-stratégies-de-zone-de-sécurité)   
  * [Recette de Zone de Sécurité dans une zone d'accueil OCI](#recette-de-zone-de-sécurité-dans-une-zone-accueil-oci)   
    * [Recette Stockage par blocs](#recette-stockage-par-blocs)   
    * [Recette Stockage d'objets](#recette-stockage-dobjets)    
    * [Recette Stockage de fichiers](#recette-stockage-de-fichiers)   
    * [Recette Réseau en nuage virtuel](#recette-réseau-en-nuage-virtuel)   
    * [Recette Gestion des certificats](#recette-gestion-des-certificats)   
    * [Recette Équilibreur de charge](#recette-équilibreur-de-charge)   
    * [Recette Instance de calcul](#recette-instance-de-calcul)      
    * [Recette Base de données](#recette-base-de-données)      
  * [Stratégies de zone de sécurité pour le compartiment production](#stratc3a9gies-de-zone-de-sc3a9curitc3a9-pour-le-compartiment-production-1)   
  * [Stratégies de zone de sécurité pour le compartiment Hub](#stratégies-de-zone-de-sécurité-pour-le-hub)   
  * [Stratégies de zone de sécurité pour le compartiment journalisation et sécurité](#stratégies-de-zone-de-sécurité-pour-le-compartiment-journalisation-et-sécurité)   
* [Recommandations](#recommandations)  

  


  

## Introduction   

Les zones de sécurité vous permettent d'être sûr que vos ressources dans Oracle Cloud Infrastructure, y compris les ressources de calcul, de mise en réseau, de stockage d'objets et de base de données, sont conformes aux meilleures pratiques de sécurité d'Oracle.   


Le service Zone de Sécurité ( Security Zone ) vous permet de vous assurer que vos ressources Oracle Cloud Infrastructure, y compris les ressources Compute, Networking, Object Storage, Block Volume et Database , sont conformes aux stratégies de sécurité.   

Les zones de sécurité garantissent que vos ressources OCI sont conformes à vos stratégies de sécurité, notamment les ressources Oracle Cloud Infrastructure Compute, Oracle Cloud Infrastructure Networking, Oracle Cloud Infrastructure Object Storage, Oracle Cloud Infrastructure Block Volumes et Database.

Le document suivant vise à définir la recette de base du service Zone de sécurité de Oracle , dans une zone d'accueil livrée par le CEI.   

Que trouve-t-on dans une zone de sécurité OCI ?

## Concepts autour de la zone de sécurité OCI   

### Cible zone de sécurité

Une zone de sécurité est associée à des **compartiments** et à une **recette de zone de sécurité** . Lorsque vous créez et mettez à jour des ressources dans une zone de sécurité, Oracle Cloud Infrastructure valide ces opérations par rapport à la liste des stratégies qui sont définies dans la recette de zone de sécurité. En cas de violation d'une stratégie de zone de sécurité, l'opération est refusée. Par défaut, un compartiment et ses sous-compartiments se trouvent dans la même zone de sécurité, mais vous pouvez également créer une autre zone de sécurité pour un sous-compartiment.    

**Nota Bene** : Un compartiment ne peut pas être associé à plusieurs zones de sécurité.   

### recette Zone de Sécurité   

Qu'est-ce qu'une recette Zones de Sécurité  ?  

Une recette de zones de sécurité est un ensemble de stratégies de zones de sécurité définies en tant que modèle pouvant être appliqué à des compartiments. Cet ensemble de stratégies de sécurité limite les actions autorisées sur les ressources cloud. 


Oracle a défini une recette de sécurité maximale. Lorsque vous créez une zone de sécurité, vous créez techniquement un compartiment avec la recette de sécurité maximale d'Oracle appliquée à ce(s) compartiment(s).   


### Recette de sécurité maximale   

La recette de sécurité maximale est une recette prédéfinie gérée par Oracle. Cette recette inclut des stratégies qui optimisent la configuration pour une situation de sécurité renforcée. Bien que la recette de zone de sécurité maximale inclut un large ensemble de stratégies de sécurité, dans la pratique, les entreprises ajustent généralement la portée des stratégies appliquées pour refléter leurs besoins spécifiques.


Maintenant, qu'y a-t-il dans la recette de la sécurité maximale ? [Voici](#liste-des-stratégies-de-zone-de-sécurité) les différentes politiques de sécurité couvertes par une recette de sécurité.

### Stratégies de zone de sécurité   


La liste des stratégies de la recette zone de sécurité maximale est dans la document : https://docs.oracle.com/fr-ca/iaas/security-zone/using/security-zone-policies.htm  

Faut-il livrer cette recette par défaut dans une zone d'accueil OCI ? Quels seront les compartiments cibles par défaut ? Quels sont les recettes communes par environnement production , non-production , par spoke dans l'architecture Hub & Spoke de la zone d'accueil OCI ?

Nous allons répondre à ces questions dans la suite de ce papier.    

   
* [Retour au Sommaire](#sommaire)   
   

## Spécifications configuration de base pour la Zone de Sécurité dans une Zone Accueil OCI  

Le déploiement de la configuration de base de la Zone de Sécurité OCI sera encapsulée dans un composant , un module Terraform.   


### Activation du service Cloud Guard de OCI

Vous devez d'abord activer le service [**Oracle Cloud Guard**](https://docs.oracle.com/fr-fr/iaas/cloud-guard/home.htm) afin de créer des zones de sécurité. 

Notre composant , aura donc un paramétre booléen qui définit si l'OP veut activer le service Cloud Guard.


| Paramètre | Description | Type | Domaine de valeurs | Défault | Obligatoire |
|-----------| ----------- | ---- | ----------- | ----------- | ----------- |
| cloud_guard_configuration_status | Détermine si Cloud Guard doit être activé dans le tenant OCI. Si 'ENABLE', une cible est créée pour le compartiment *racine*. | Booléen | [ENABLE , DISABLE] | ENABLE | OUI |  

### Activation du service Zone de Sécurité de OCI   

Vous devez d'abord activer le service [**Oracle Cloud Guard**](https://docs.oracle.com/fr-fr/iaas/cloud-guard/home.htm) avant de créer des zones de sécurité. 

Notre composant , prendra aura donc un paramétre booléen qui définit l'OP veut activer le service Cloud Guard ou non


| Paramètre | Description | Type | Domaine de valeurs | Défault | Obligatoire |
|-----------| ----------- | ---- | ----------- | ----------- | ----------- |
| zone_securite_active | Détermine si des zones de sécurité OCI peuvent être créées dans une zone d'accueil OCI.  | Booléen | [OUI , NON] | OUI | OUI |  


Si paramètre zone_securite_active est **OUI** et cloud_guard_configuration_status est **ENABLE**  , des zones de sécurité seront créé suivant la configuration de base Zone Sécurité dans une zone d'accueil OCI. 


### Stratégie IAM  

Avant de créer une zone de sécurité, l'accès requis doit vous être octroyé dans une stratégie IAM. 

Il faut avoir la privilège IAM suivante :   

        allow group <group> to manage cloud-guard-family in tenancy

Si paramètre zone_securite_active est **OUI** et cloud_guard_configuration_status est **ENABLE**  , cette stratégie IAM sera déployée dans le compartiment racine du tenant.

   
* [Retour au Sommaire](#sommaire)   


### Cibles de Zone de Sécurité dans une zone accueil OCI  

Une zone d'accueil OCI est déployée sous forme d'une achitecture Hub & Spoke , comprenant un Hub ou Connectivité , qui est le compartiment cmp-conne-001 et 5 spokes satellites : 

- Production ( cmp-prod-001)   
- Non-production ( cmp-nonprod-001)   
- Carré de sable ( cmp-casae-001)   
- Non classifié ( cmp-nocla-001)   
- Sécurité et Journalisation ( cmp-sejou-001)   

![Arc_CMP_VCN_SReseaux](../../images/Arc_CMP_VCN_SReseaux.PNG)


Notre configuration de base va cibler les compartiments les plus critiques : Production , Connectivité , Sécurité et Journalisation


![Arc_deploiement_zones_de_securite](../../images/zone_securite_oci/Arc_deploiement_zones_de_securite.png)


Voici les premières propriétés d'une zone sécurité dans une zone d'accueil OCI

| Paramètre | Description | Type | Domaine de valeurs | Défault | Obligatoire |
|-----------| ----------- | ---- | ----------- | ----------- | ----------- |
| nom_zone_securite | Nom de la zone de sécurité  | Chaîne de caractères |  |  | OUI |  
| description_zone_securite | Description de la zone de sécurité  | Chaîne de caractères |  |  | NON |   
| ocid_compartiment | OCID du compartiment qui sera associé à al cible zone sécurité  | Chaîne de caractères |  |  | OUI |  
| liste_recettes | Liste des [recettes](#recettes-zone-sécurité-dans-une-zone-accueil-oci) à activer dans la zone de sécurité  | Liste d'objets |  |  | OUI |  


### Niveau CIS de chaque zone de sécurité   

Les critères [CIS](https://www.cisecurity.org/) fournissent deux niveaux de paramètres de sécurité :

- ```Le niveau 1``` recommande des exigences de base en matière de sécurité qui peuvent être configurées sur un système quelconque et qui doivent provoquer peu ou pas d’interruption de service ou de fonctionnement réduit.   

- ```Le niveau 2``` recommande des paramètres de sécurité pour les environnements nécessitant une sécurité accrue qui pourraient entraîner un fonctionnement réduit.

Chaque zone de sécurité aura un paramète sur le niveau de sécurité CIS à appliquer .   

le paramètre sur le niveau CIS, va piloter les stratégies qui sont ajoutées à la recette. 

Valeurs valides : « 1 » et « 2 ». 

Valeur par défaut : « 1 ». 

1- Exemple de stratégies zone sécurité de Niveau CIS 1  

- [ ] Deny public buckets (deny public_buckets)
- [ ]  Deny public access to database instances (deny db_instance_public_access)   

2- Exemple de stratégies zone sécurité de Niveau CIS 2  

* Toutes les stratégies zone sécurité de Niveau CIS 1  
* Deny Block Vulume without a customer managed key (deny block_volume_without_vault_key)
* Deny Book Volume without a customer managed key (deny boot_volume_without_vault_key)
* Deny buckets without a customer managed key (deny buckets_without_vault_key)
* Deny file system without a customer managed key (deny file_system_without_vault_key)

Chaque zone de sécurité aura un paramètre sur le profil de sécurité CIS à appliquer .


| Paramètre | Description | Type | Domaine de valeurs | Défault | Obligatoire |
|-----------| ----------- | ---- | ----------- | ----------- | ----------- |
| profil_cis |  Numéro du profil CIS à appliquer dans la zone de sécurité | Entier | [1,2] | 1 | OUI |  

   
* [Retour au Sommaire](#sommaire)   
   
### Liste des stratégies de zone de sécurité

La zone d'accueil sera livrée avec 3 zones de sécurité. Une par compartiment.   


Voici la liste de 57 stratégies de zone de sécurité et leur profil CIS   

Stratégie  |   Types de ressource  |   Description  |   Principe de sécurité  |   Profil CIS |  
|-----------| ----------- | ----------- | ----------- | ----------- |
deny database_without_backup  |   Base de données (systèmes de base de données sans système d'exploitation et sur machine virtuelle, systèmes de base de données Exadata)  |   Les bases de données dans la zone de sécurité doivent être configurées pour effectuer des sauvegardes automatiques.  |   Chiffrement requis  |   1 |
deny database_not_in_security_​zone_create_from_backup_​in_security_zone  |   Base de données (systèmes de base de données sans système d'exploitation et sur machine virtuelle, systèmes de base de données Exadata)  |   Vous ne pouvez pas utiliser une sauvegarde de base de données dans la zone de sécurité pour créer une base de données en dehors de cette même zone de sécurité.  |   Garantir la sécurité des données  |   1 |
deny database_in_security_​zone_create_clone_not_​in_security_zone  |   Base de données (systèmes de base de données sur machine virtuelle, base de données autonome)  |   Vous ne pouvez pas cloner une base de données dans la zone de sécurité pour créer une base de données en dehors de cette même zone de sécurité.  |   Garantir la sécurité des données  |   1 |
deny file_system_in_security_zone_​clone_to_compartment_​not_in_security_zone  |   Stockage de fichiers  |   Vous ne pouvez pas cloner un système de fichiers  dans une zone de sécurité pour créer un système de fichiers qui ne soit pas dans la même zone de sécurité.  |   Garantir la sécurité des données  |   1 |
deny public_buckets  |   Stockage d'objets  |   Les seaux  de stockage d'objets dans la zone de sécurité ne peuvent pas être publics.  |   Refuser l'accès public  |   1 |
deny db_resource_association_​not_in_security_zone  |   Base de données (systèmes de base de données Exadata)  |   Les ressources d'infrastructure Exadata dans la zone de sécurité ne peuvent pas être associées à des bases de données conteneurs ou à des grappes de machines virtuelles qui ne sont pas dans la même zone de sécurité.  |   Restreindre l'association des ressources  |   1 |
deny dataguard_association_​with_db_instances_not_in_​security_zones  |   Base de données (systèmes de base de données sans système d'exploitation et sur machine virtuelle, systèmes de base de données Exadata)  |   Une base de données dans la zone de sécurité ne peut pas avoir d'association Data Guard avec une autre base de données (principale/de secours) qui n'est pas dans la même zone de sécurité.  |   Restreindre l'association des ressources  |   1
deny db_instance_subnet_not_​in_security_zone  |   Base de données (tous types)  |   Une base de données dans la zone de sécurité ne peut pas utiliser un sous-réseau  s'il n'est pas dans la même zone de sécurité.  |   Restreindre l'association des ressources  |   1
deny block_volume_in_security_​zone_attach_to_instance_​not_in_security_zone  |   Calcul  |   Vous ne pouvez pas associer un volume  de stockage par blocs dans la zone de sécurité à une instance  de calcul qui n'est pas dans la même zone de sécurité.  |   Restreindre l'association des ressources  |   1
deny block_volume_not_in_security_​zone_attach_to_instance_​in_security_zone  |   Calcul  |   Vous ne pouvez pas attacher un volume  de stockage par blocs à une instance  de calcul dans la zone de sécurité si le volume n'est pas dans la même zone de sécurité.  |   Restreindre l'association des ressources  |   1
deny boot_volume_in_security_​zone_attach_to_instance_​not_in_security_zone  |   Calcul  |   Vous ne pouvez pas attacher un volume de démarrage dans la zone de sécurité à une instance  de calcul qui n'est pas dans la même zone de sécurité.  |   Restreindre l'association des ressources  |   1
deny boot_volume_not_in_security_​zone_attach_to_instance_​in_security_zone  |   Calcul  |   Vous ne pouvez pas attacher un volume de démarrage à une instance  de calcul dans la zone de sécurité si le volume n'est pas dans la même zone de sécurité.  |   Restreindre l'association des ressources  |   1
deny instance_in_security_zone_​in_subnet_not_in_security_​zone  |   Calcul, Gestion du calcul  |   Une instance  de calcul dans la zone de sécurité ne peut pas utiliser un sous-réseau  s'il n'est pas dans la même zone de sécurité.  |   Restreindre l'association des ressources  |   1
deny file_system_in_security_zone_​export_via_mount_target_​not_in_security_zone  |   Stockage de fichiers  |   Vous ne pouvez pas exporter un système de fichiers  dans la zone de sécurité au moyen d'une cible de montage (stockage de fichiers)  qui n'est pas dans la même zone de sécurité.  |   Restreindre l'association des ressources  |   1
deny file_system_not_in_security_zone_​export_via_mount_target_​in_security_zone  |   Stockage de fichiers  |   Vous ne pouvez pas exporter un système de fichiers  au moyen d'une cible de montage (stockage de fichiers)  si le système de fichiers n'est pas dans la même zone de sécurité.  |   Restreindre l'association des ressources  |   1
deny mount_target_in_security_zone_​created_with_subnet_​not_in_security_zone  |   Stockage de fichiers  |   Une cible de montage (stockage de fichiers)  dans la zone de sécurité ne peut pas utiliser un sous-réseau  s'il n'est pas dans la même zone de sécurité.  |   Restreindre l'association des ressources  |   1
deny mount_target_not_in_security_zone_​create_with_subnet_​in_security_zone  |   Stockage de fichiers  |   Vous ne pouvez pas créer une cible de montage (stockage de fichiers)  qui utilise un sous-réseau  dans une zone de sécurité si la cible de montage n'est pas dans la même zone de sécurité.  |   Restreindre l'association des ressources  |   1
deny attached_block_volume_not_​in_security_zone_move_to_​compartment_in_security_zone  |   Stockage par blocs  |   Vous ne pouvez pas déplacer un volume  de stockage par blocs vers la zone de sécurité s'il est attaché à une instance de calcul qui n'est pas dans la même zone de sécurité.  |   Restreindre l'association des ressources  |   1
deny attached_boot_volume_not_in_​security_zone_move_to_​compartment_in_security_zone  |   Stockage par blocs  |   Vous ne pouvez pas déplacer un volume de démarrage vers la zone de sécurité s'il est attaché à une instance de calcul qui n'est pas dans la même zone de sécurité.  |   Restreindre l'association des ressources  |   1
deny instance_in_security_zone_​move_to_compartment_​not_in_security_zone  |   Calcul  |   Vous ne pouvez pas déplacer une instance  de calcul dans la zone de sécurité vers un compartiment qui n'est pas dans la même zone de sécurité.  |   Restreindre le déplacement des ressources  |   1
deny instance_not_in_security_​zone_move_to_compartment_​in_security_zone  |   Calcul  |   Vous ne pouvez pas déplacer une instance de calcul vers la zone de sécurité à partir d'un compartiment qui n'est pas dans la même zone de sécurité.  |   Restreindre le déplacement des ressources  |   1
deny subnet_in_security_zone_​move_to_compartment_​not_in_security_zone  |   Réseau en nuage virtuel (VCN)  |   Vous ne pouvez pas déplacer un sous-réseau  dans la zone de sécurité vers un compartiment qui n'est pas dans la même zone de sécurité.  |   Restreindre le déplacement des ressources  |   1
deny file_system_in_security_​zone_move_to_compartment_​not_in_security_zone  |   Stockage de fichiers  |   Vous ne pouvez pas déplacer un système de fichiers  dans la zone de sécurité vers un compartiment qui n'est pas dans la même zone de sécurité.  |   Restreindre le déplacement des ressources  |   1
deny mount_target_in_security_​zone_move_to_compartment_​not_in_security_zone  |   Stockage de fichiers  |   Vous ne pouvez pas déplacer une cible de montage (stockage de fichiers)  dans la zone de sécurité vers un compartiment qui ne se trouve pas dans la même zone de sécurité.  |   Restreindre le déplacement des ressources  |   1
deny bucket_in_security_zone_​move_to_compartment_​not_in_security_zone  |   Stockage d'objets  |   Vous ne pouvez pas déplacer un seau  dans la zone de sécurité vers un compartiment qui n'est pas dans la même zone de sécurité.  |   Restreindre le déplacement des ressources  |   1
deny block_volume_in_security_zone_​move_to_compartment_​not_in_security_zone  |   Stockage par blocs  |   Vous ne pouvez pas déplacer un volume  de stockage par bloc dans la zone de sécurité vers un compartiment qui n'est pas dans la même zone de sécurité.  |   Restreindre le déplacement des ressources  |   1
deny boot_volume_in_security_zone_​move_to_compartment_​not_in_security_zone  |   Stockage par blocs  |   Vous ne pouvez pas déplacer un volume de démarrage dans la zone de sécurité vers un compartiment qui ne se trouve pas dans la même zone de sécurité.  |   Restreindre le déplacement des ressources  |   1
deny delete_certificate_authority  |   Gestion des certificats  |   Vous ne pouvez pas supprimer une autorité de certification dans la zone de sécurité.  |   Utiliser uniquement les configurations approuvées par Oracle  |   1
deny revoke_certificate_authority_version  |   Gestion des certificats  |   Vous ne pouvez pas révoquer un certificat intermédiaire dans un ensemble autorité de certification dans la zone de sécurité.  |   Utiliser uniquement les configurations approuvées par Oracle  |   1
deny delete_network_security_group  |   Réseau en nuage virtuel (VCN)  |   Vous ne pouvez pas supprimer un groupe de sécurité de réseau VCN dans la zone de sécurité.  |   Utiliser uniquement les configurations approuvées par Oracle  |   1
deny delete_vcn  |   Réseau en nuage virtuel (VCN)  |   Vous ne pouvez pas supprimer un VCN dans la zone de sécurité.  |   Utiliser uniquement les configurations approuvées par Oracle  |   1
deny delete_vcn_security_list  |   Réseau en nuage virtuel (VCN)  |   Vous ne pouvez pas supprimer une liste de sécurité de VCN dans la zone de sécurité.  |   Utiliser uniquement les configurations approuvées par Oracle  |   1
deny network_security_group_with_unsecure_ingress_rule  |   Réseau en nuage virtuel (VCN)  |   Vous ne pouvez pas ajouter un groupe de sécurité de réseau avec une règle qui autorise le trafic entrant vers des ports non sécurisés ou des adresses IP dans la zone de sécurité.  |   Utiliser uniquement les configurations approuvées par Oracle  |   1
deny detach_volume  |   Stockage par blocs  |   Vous ne pouvez pas détacher un volume dans la zone de sécurité.  |   Utiliser uniquement les configurations approuvées par Oracle  |   1
deny db_instance_move_to_​compartment_not_in_​security_zone  |   Base de données (tous types)  |   Vous ne pouvez pas déplacer une base de données dans la zone de sécurité vers un compartiment qui n'est pas dans la même zone de sécurité.  |     |   1
deny block_volume_without_​vault_key  |   Stockage d'objets  |   Les volumes  de stockage par blocs dans la zone de sécurité doivent utiliser une clé de chiffrement principale gérée par le client dans le service de chambre forte. Ils ne peuvent pas utiliser la clé de chiffrement par défaut gérée par Oracl  |   Chiffrement requis  |   2
deny boot_volume_without_​vault_key  |   Stockage d'objets  |   Les volumes de démarrage dans la zone de sécurité doivent utiliser une clé de chiffrement principale gérée par le client dans le service de chambre forte. Ils ne peuvent pas utiliser la clé de chiffrement par défaut gérée par Oracle.  |   Chiffrement requis  |   2
deny buckets_without_vault_key  |   Stockage d'objets  |   Les seaux  de stockage d'objets  dans la zone de sécurité doivent utiliser une clé principale de chiffrement gérée par le client dans le service de chambre forte. Ils ne peuvent pas utiliser la clé de chiffrement par défaut gérée par Oracle.  |   Chiffrement requis  |   2
deny file_system_without_vault_​key  |   Stockage d'objets  |   Les systèmes de fichiers  dans la zone de sécurité doivent utiliser une clé de chiffrement principale gérée par le client dans le service de chambre forte. Ils ne peuvent pas utiliser la clé de chiffrement par défaut gérée par Oracle.  |   Chiffrement requis  |   2
deny db_instance_public_​access  |   Base de données (tous types)  |   Les bases de données dans la zone de sécurité ne peuvent pas être affectées à des sous-réseaux publics. Elles doivent utiliser des sous-réseaux privés.  |   Refuser l'accès public  |   2
deny public_load_balancer  |   Équilibreur de charge  |   Les équilibreurs de charge d'une zone de sécurité ne peuvent pas être publics. Tous les équilibreurs de charge doivent être privés.  |   Refuser l'accès public  |   2
deny internet_gateway  |   Réseau en nuage virtuel (VCN)  |   Vous ne pouvez pas ajouter une passerelle Internet  à un VCN (réseau en nuage virtuel)  dans la zone de sécurité.  |   Refuser l'accès public  |   2
deny public_subnets  |   Réseau en nuage virtuel (VCN)  |   Les sous-réseaux dans la zone de sécurité ne peuvent pas être publics. Ils doivent être privés.  |   Refuser l'accès public  |   2
deny instance_in_security_zone_​launch_from_boot_volume_​not_in_security_zone  |   Calcul, Gestion du calcul  |   Vous ne pouvez pas lancer une instance  de calcul dans la zone de sécurité si son volume de démarrage n'est pas dans la même zone de sécurité.  |   Restreindre l'association des ressources  |   2
deny instance_not_in_security_​zone_launch_from_boot_​volume_in_security_zone  |   Calcul, Gestion du calcul  |   Vous ne pouvez pas lancer une instance  de calcul à l'aide d'un volume de démarrage dans la zone de sécurité si l'instance n'est pas dans la même zone de sécurité.  |   Restreindre l'association des ressources  |   2
deny free_database_creation  |   Base de données (tous types)  |   Vous ne pouvez pas créer une instance de base de données de type Toujours gratuit dans une zone de sécurité.  |   Utiliser uniquement les configurations approuvées par Oracle  |   2
deny instance_without_​sanctioned_image  |   Calcul, Gestion du calcul  |   Vous devez créer une instance  de calcul dans la zone de sécurité à l'aide d'une image de plate-forme.  |   Utiliser uniquement les configurations approuvées par Oracle  |   2
deny load_balancer_with_weak_SSL_communication  |   Équilibreur de charge  |   La politique SSL d'un module d'écoute d'équilibreur de charge dans la zone de sécurité doit utiliser TLS 1.2 ou une version ultérieure.  |   Utiliser uniquement les configurations approuvées par Oracle  |   2
deny security_list_to_allow_traffic_to_restricted_port  |   Réseau en nuage virtuel (VCN)  |   Vous ne pouvez pas créer ou modifier une liste de sécurité pour autoriser le trafic vers des ports restreints dans la zone de sécurité.  |   Utiliser uniquement les configurations approuvées par Oracle  |   2
deny update_DHCP_options  |   Réseau en nuage virtuel (VCN)  |   Vous ne pouvez pas mettre à jour les options DHCP dans la zone de sécurité.  |   Utiliser uniquement les configurations approuvées par Oracle  |   2
deny update_local_peering_gateway  |   Réseau en nuage virtuel (VCN)  |   Vous ne pouvez pas mettre à jour une passerelle d'appairage local dans la zone de sécurité.  |   Utiliser uniquement les configurations approuvées par Oracle  |   2
deny update_network_security_group_egress_rule  |   Réseau en nuage virtuel (VCN)  |   Vous ne pouvez pas modifier les règles de trafic sortant d'un groupe de sécurité de réseau dans la zone de sécurité.  |   Utiliser uniquement les configurations approuvées par Oracle  |   2
deny update_network_security_group_ingress_rule  |   Réseau en nuage virtuel (VCN)  |   Vous ne pouvez pas modifier les règles de trafic entrant d'un groupe de sécurité de réseau dans la zone de sécurité.  |   Utiliser uniquement les configurations approuvées par Oracle  |   2
deny update_route_table  |   Réseau en nuage virtuel (VCN)  |   Vous ne pouvez pas mettre à jour une table de routage de VCN dans la zone de sécurité.  |   Utiliser uniquement les configurations approuvées par Oracle  |   2
deny update_vcn_security_list_egress_rules  |   Réseau en nuage virtuel (VCN)  |   Vous ne pouvez pas modifier les règles de sécurité de trafic entrant de la liste de sécurité du VCN dans la zone de sécurité.  |   Utiliser uniquement les configurations approuvées par Oracle  |   2
deny update_vcn_security_list_ingress_rules  |   Réseau en nuage virtuel (VCN)  |   Vous ne pouvez pas modifier les règles de sécurité de trafic entrant de la liste de sécurité du VCN dans la zone de sécurité.  |   Utiliser uniquement les configurations approuvées par Oracle  |   2
deny database_with_dataguard_​association_move_to_​compartment_in_security_zone  |   Base de données (systèmes de base de données sans système d'exploitation et sur machine virtuelle, systèmes de base de données Exadata)  |   Vous ne pouvez pas déplacer une base de données vers la zone de sécurité si son association Data Guard ne se trouve pas dans la même zone de sécurité.  |     |   2


   
* [Retour au Sommaire](#sommaire)   
   

Quelle est la recette pour chacune de ces 3 zones ?


### Recette de Zone de Sécurité dans une zone accueil OCI  

Étant donné que les ressources OCI ne sont pas les mêmes suivant les compartiments Production , Connectivité , Sécurité et Journalisation

Etant donné que les enjeux dans chacun de ces 3 compartiments sont différents ,   

La recette zone de sécurité n'est pas la même pour tous les 3 compartiments.  

Sur la page https://docs.oracle.com/fr-ca/iaas/security-zone/using/security-zone-policies.htm , les stratégies de la recette Maximum Security Zone sont regoupées par principe de sécurité : 

- Garantir la sécurité des données
- Chiffrement requis
- Refuser l'accès public
- Restreindre l'association des ressources
- Utiliser uniquement les configurations approuvées par Oracle

Les types de ressources impliquées dans cette recette sont les suivants :  

- Base de données (systèmes de base de données sans système d'exploitation et sur machine virtuelle, systèmes de base de données Exadata)
- Base de données (systèmes de base de données Exadata)
- Base de données (systèmes de base de données sans système d'exploitation et sur machine virtuelle, systèmes de base de données Exadata)
- Base de données (systèmes de base de données sur machine virtuelle, base de données autonome)
- Base de données (tous types)
- Calcul
- Calcul, Gestion du calcul
- Équilibreur de charge
- Gestion des certificats
- Réseau en nuage virtuel (VCN)
- Stockage de fichiers
- Stockage d'objets
- Stockage par blocs

Nous allons considérer le regroupement par type de ressources comme liste de recettes à déployer ou non dans chacune des 3 zones de sécurité. 

Ainsi , suivant le type de ressources déployées dans un compartiment , un OP pourra décider quelles stratégies zone sécurité à activer

* [Retour au Sommaire](#sommaire)   

#### Recette Stockage par blocs

| Stratégie zone de sécurité | Description | Principe de sécurité |
|-----------| ----------- | ------- |
deny attached_block_volume_not_​in_security_zone_move_to_​compartment_in_security_zone | Vous ne pouvez pas déplacer un volume  de stockage par blocs vers la zone de sécurité s'il est attaché à une instance de calcul qui n'est pas dans la même zone de sécurité. |Restreindre l'association des ressources |
deny attached_boot_volume_not_in_​security_zone_move_to_​compartment_in_security_zone | Vous ne pouvez pas déplacer un volume de démarrage vers la zone de sécurité s'il est attaché à une instance de calcul qui n'est pas dans la même zone de sécurité. | Restreindre l'association des ressources |  
deny block_volume_in_security_zone_​move_to_compartment_​not_in_security_zone| Vous ne pouvez pas déplacer un volume  de stockage par bloc dans la zone de sécurité vers un compartiment qui n'est pas dans la même zone de sécurité. | Restreindre le déplacement des ressources |  
deny boot_volume_in_security_zone_​move_to_compartment_​not_in_security_zone| Vous ne pouvez pas déplacer un volume de démarrage dans la zone de sécurité vers un compartiment qui ne se trouve pas dans la même zone de sécurité. | Restreindre le déplacement des ressources |  
deny detach_volume | Vous ne pouvez pas détacher un volume dans la zone de sécurité.|Utiliser uniquement les configurations approuvées par Oracle |  

* [Retour au Sommaire](#sommaire)   

#### Recette Stockage d'objets

| Stratégie zone de sécurité | Description | Principe de sécurité |
|-----------| ----------- | ------- |
deny block_volume_without_​vault_key | Les volumes  de stockage par blocs dans la zone de sécurité doivent utiliser une clé de chiffrement principale gérée par le client dans le service de chambre forte. Ils ne peuvent pas utiliser la clé de chiffrement par défaut gérée par Oracl | Chiffrement requis |
deny boot_volume_without_​vault_key | Les volumes de démarrage dans la zone de sécurité doivent utiliser une clé de chiffrement principale gérée par le client dans le service de chambre forte. Ils ne peuvent pas utiliser la clé de chiffrement par défaut gérée par Oracle. | Chiffrement requis |
deny buckets_without_vault_key | Les seaux  de stockage d'objets  dans la zone de sécurité doivent utiliser une clé principale de chiffrement gérée par le client dans le service de chambre forte. Ils ne peuvent pas utiliser la clé de chiffrement par défaut gérée par Oracle. | Chiffrement requis |
deny file_system_without_vault_​key | Les systèmes de fichiers  dans la zone de sécurité doivent utiliser une clé de chiffrement principale gérée par le client dans le service de chambre forte. Ils ne peuvent pas utiliser la clé de chiffrement par défaut gérée par Oracle. | Chiffrement requis |
deny public_buckets | Les seaux  de stockage d'objets dans la zone de sécurité ne peuvent pas être publics. | Refuser l'accès public
deny bucket_in_security_zone_​move_to_compartment_​not_in_security_zone | Vous ne pouvez pas déplacer un seau  dans la zone de sécurité vers un compartiment qui n'est pas dans la même zone de sécurité. | Restreindre le déplacement des ressources |

* [Retour au Sommaire](#sommaire)   

#### Recette Stockage de fichiers   

| Stratégie zone de sécurité | Description | Principe de sécurité |
|-----------| ----------- | ------- |
deny file_system_in_security_zone_​clone_to_compartment_​not_in_security_zone  |   Vous ne pouvez pas cloner un système de fichiers  dans une zone de sécurité pour créer un système de fichiers qui ne soit pas dans la même zone de sécurité.  |   Garantir la sécurité des données |  
deny file_system_in_security_zone_​export_via_mount_target_​not_in_security_zone  |   Vous ne pouvez pas exporter un système de fichiers  dans la zone de sécurité au moyen d'une cible de montage (stockage de fichiers)  qui n'est pas dans la même zone de sécurité.  |   Restreindre l'association des ressources |  
deny file_system_not_in_security_zone_​export_via_mount_target_​in_security_zone  |   Vous ne pouvez pas exporter un système de fichiers  au moyen d'une cible de montage (stockage de fichiers)  si le système de fichiers n'est pas dans la même zone de sécurité.  |   Restreindre l'association des ressources  |  
deny mount_target_in_security_zone_​created_with_subnet_​not_in_security_zone  |   Une cible de montage (stockage de fichiers)  dans la zone de sécurité ne peut pas utiliser un sous-réseau  s'il n'est pas dans la même zone de sécurité.  |   Restreindre l'association des ressources |  
deny mount_target_not_in_security_zone_​create_with_subnet_​in_security_zone  |   Vous ne pouvez pas créer une cible de montage (stockage de fichiers)  qui utilise un sous-réseau  dans une zone de sécurité si la cible de montage n'est pas dans la même zone de sécurité.  |   Restreindre l'association des ressources  |  
deny file_system_in_security_​zone_move_to_compartment_​not_in_security_zone  |   Vous ne pouvez pas déplacer un système de fichiers  dans la zone de sécurité vers un compartiment qui n'est pas dans la même zone de sécurité.  |   Restreindre le déplacement des ressources |  
deny mount_target_in_security_​zone_move_to_compartment_​not_in_security_zone  |   Vous ne pouvez pas déplacer une cible de montage (stockage de fichiers)  dans la zone de sécurité vers un compartiment qui ne se trouve pas dans la même zone de sécurité.  |   Restreindre le déplacement des ressources |  

* [Retour au Sommaire](#sommaire)   

#### Recette Réseau en nuage virtuel   

| Stratégie zone de sécurité | Profil CIS | Description | Principe de sécurité |
|-----------| ----------- | ------- | ------- |
deny subnet_in_security_zone_​move_to_compartment_​not_in_security_zone  |   1  |   Vous ne pouvez pas déplacer un sous-réseau  dans la zone de sécurité vers un compartiment qui n'est pas dans la même zone de sécurité.  |   Restreindre le déplacement des ressources |   
deny delete_network_security_group  |   1  |   Vous ne pouvez pas supprimer un groupe de sécurité de réseau VCN dans la zone de sécurité.  |   Utiliser uniquement les configurations approuvées par Oracle |   
deny delete_vcn  |   1  |   Vous ne pouvez pas supprimer un VCN dans la zone de sécurité.  |   Utiliser uniquement les configurations approuvées par Oracle |   
deny delete_vcn_security_list  |   1  |   Vous ne pouvez pas supprimer une liste de sécurité de VCN dans la zone de sécurité.  |   Utiliser uniquement les configurations approuvées par Oracle |   
deny network_security_group_with_unsecure_ingress_rule  |   1  |   Vous ne pouvez pas ajouter un groupe de sécurité de réseau avec une règle qui autorise le trafic entrant vers des ports non sécurisés ou des adresses IP dans la zone de sécurité.  |   Utiliser uniquement les configurations approuvées par Oracle |   
deny internet_gateway  |   2  |   Vous ne pouvez pas ajouter une passerelle Internet  à un VCN (réseau en nuage virtuel)  dans la zone de sécurité.  |   Refuser l'accès public |   
deny public_subnets  |   2  |   Les sous-réseaux dans la zone de sécurité ne peuvent pas être publics. Ils doivent être privés.  |   Refuser l'accès public |   
deny security_list_to_allow_traffic_to_restricted_port  |   2  |   Vous ne pouvez pas créer ou modifier une liste de sécurité pour autoriser le trafic vers des ports restreints dans la zone de sécurité.  |   Utiliser uniquement les configurations approuvées par Oracle |   
deny update_DHCP_options  |   2  |   Vous ne pouvez pas mettre à jour les options DHCP dans la zone de sécurité.  |   Utiliser uniquement les configurations approuvées par Oracle |   
deny update_local_peering_gateway  |   2  |   Vous ne pouvez pas mettre à jour une passerelle d'appairage local dans la zone de sécurité.  |   Utiliser uniquement les configurations approuvées par Oracle |   
deny update_network_security_group_egress_rule  |   2  |   Vous ne pouvez pas modifier les règles de trafic sortant d'un groupe de sécurité de réseau dans la zone de sécurité.  |   Utiliser uniquement les configurations approuvées par Oracle  |   
deny update_network_security_group_ingress_rule  |   2  |   Vous ne pouvez pas modifier les règles de trafic entrant d'un groupe de sécurité de réseau dans la zone de sécurité.  |   Utiliser uniquement les configurations approuvées par Oracle |   
deny update_route_table  |   2  |   Vous ne pouvez pas mettre à jour une table de routage de VCN dans la zone de sécurité.  |   Utiliser uniquement les configurations approuvées par Oracle |   
deny update_vcn_security_list_egress_rules  |   2  |   Vous ne pouvez pas modifier les règles de sécurité de trafic entrant de la liste de sécurité du VCN dans la zone de sécurité.  |   Utiliser uniquement les configurations approuvées par Oracle |   
deny update_vcn_security_list_ingress_rules  |   2  |   Vous ne pouvez pas modifier les règles de sécurité de trafic entrant de la liste de sécurité du VCN dans la zone de sécurité.  |   Utiliser uniquement les configurations approuvées par Oracle |   

* [Retour au Sommaire](#sommaire)   

#### Recette Gestion des certificats  


| Stratégie zone de sécurité | Profil CIS | Description | Principe de sécurité |
|-----------| ----------- | ------- | ------- |
deny delete_certificate_authority  |   1  |   Vous ne pouvez pas supprimer une autorité de certification dans la zone de sécurité.  |   Utiliser uniquement les configurations approuvées par Oracle |
deny revoke_certificate_authority_version  |   1  |   Vous ne pouvez pas révoquer un certificat intermédiaire dans un ensemble autorité de certification dans la zone de sécurité.  |   Utiliser uniquement les configurations approuvées par Oracle |
   
   
   
#### Recette Équilibreur de charge   


| Stratégie zone de sécurité | Profil CIS | Description | Principe de sécurité |
|-----------| ----------- | ------- | ------- |
deny public_load_balancer  |   2  |   Les équilibreurs de charge d'une zone de sécurité ne peuvent pas être publics. Tous les équilibreurs de charge doivent être privés.  |   Refuser l'accès public |   
deny load_balancer_with_weak_SSL_communication  |   2  |   La politique SSL d'un module d'écoute d'équilibreur de charge dans la zone de sécurité doit utiliser TLS 1.2 ou une version ultérieure.  |   Utiliser uniquement les configurations approuvées par Oracle   |


#### Recette Instance de calcul
    

| Stratégie zone de sécurité | Profil CIS | Description | Principe de sécurité |
|-----------| ----------- | ------- | ------- |
deny block_volume_in_security_​zone_attach_to_instance_​not_in_security_zone  |   1  |   Vous ne pouvez pas associer un volume  de stockage par blocs dans la zone de sécurité à une instance  de calcul qui n'est pas dans la même zone de sécurité.  |   Restreindre l'association des ressources |   
deny block_volume_not_in_security_​zone_attach_to_instance_​in_security_zone  |   1  |   Vous ne pouvez pas attacher un volume  de stockage par blocs à une instance  de calcul dans la zone de sécurité si le volume n'est pas dans la même zone de sécurité.  |   Restreindre l'association des ressources |   
deny boot_volume_in_security_​zone_attach_to_instance_​not_in_security_zone  |   1  |   Vous ne pouvez pas attacher un volume de démarrage dans la zone de sécurité à une instance  de calcul qui n'est pas dans la même zone de sécurité.  |   Restreindre l'association des ressources |   
deny boot_volume_not_in_security_​zone_attach_to_instance_​in_security_zone  |   1  |   Vous ne pouvez pas attacher un volume de démarrage à une instance  de calcul dans la zone de sécurité si le volume n'est pas dans la même zone de sécurité.  |   Restreindre l'association des ressources |   
deny instance_in_security_zone_​move_to_compartment_​not_in_security_zone  |   1  |   Vous ne pouvez pas déplacer une instance  de calcul dans la zone de sécurité vers un compartiment qui n'est pas dans la même zone de sécurité.  |   Restreindre le déplacement des ressources |   
deny instance_not_in_security_​zone_move_to_compartment_​in_security_zone  |   1  |   Vous ne pouvez pas déplacer une instance de calcul vers la zone de sécurité à partir d'un compartiment qui n'est pas dans la même zone de sécurité.  |   Restreindre le déplacement des ressources |   
deny instance_in_security_zone_​in_subnet_not_in_security_​zone  |   1  |   Une instance  de calcul dans la zone de sécurité ne peut pas utiliser un sous-réseau  s'il n'est pas dans la même zone de sécurité.  |   Restreindre l'association des ressources
deny instance_in_security_zone_​launch_from_boot_volume_​not_in_security_zone  |   2  |   Vous ne pouvez pas lancer une instance  de calcul dans la zone de sécurité si son volume de démarrage n'est pas dans la même zone de sécurité.  |   Restreindre l'association des ressources |   
deny instance_not_in_security_​zone_launch_from_boot_​volume_in_security_zone  |   2  |   Vous ne pouvez pas lancer une instance  de calcul à l'aide d'un volume de démarrage dans la zone de sécurité si l'instance n'est pas dans la même zone de sécurité.  |   Restreindre l'association des ressources |   
deny instance_without_​sanctioned_image  |   2  |   Vous devez créer une instance  de calcul dans la zone de sécurité à l'aide d'une image de plate-forme.  |   Utiliser uniquement les configurations approuvées par Oracle |   
   

* [Retour au Sommaire](#sommaire)   
   

#### Recette Base de données
    

| Stratégie zone de sécurité | Profil CIS | Description | Principe de sécurité |
|-----------| ----------- | ------- | ------- |
deny database_with_dataguard_​association_move_to_​compartment_in_security_zone  |   2  |   Vous ne pouvez pas déplacer une base de données vers la zone de sécurité si son association Data Guard ne se trouve pas dans la même zone de sécurité.  |   
deny db_resource_association_​not_in_security_zone  |   1  |   Les ressources d'infrastructure Exadata dans la zone de sécurité ne peuvent pas être associées à des bases de données conteneurs ou à des grappes de machines virtuelles qui ne sont pas dans la même zone de sécurité.  |   Restreindre l'association des ressources
deny database_without_backup  |   1  |   Les bases de données dans la zone de sécurité doivent être configurées pour effectuer des sauvegardes automatiques.  |   Chiffrement requis
deny database_not_in_security_​zone_create_from_backup_​in_security_zone  |   1  |   Vous ne pouvez pas utiliser une sauvegarde de base de données dans la zone de sécurité pour créer une base de données en dehors de cette même zone de sécurité.  |   Garantir la sécurité des données
deny dataguard_association_​with_db_instances_not_in_​security_zones  |   1  |   Une base de données dans la zone de sécurité ne peut pas avoir d'association Data Guard avec une autre base de données (principale/de secours) qui n'est pas dans la même zone de sécurité.  |   Restreindre l'association des ressources
deny database_in_security_​zone_create_clone_not_​in_security_zone  |   1  |   Vous ne pouvez pas cloner une base de données dans la zone de sécurité pour créer une base de données en dehors de cette même zone de sécurité.  |   Garantir la sécurité des données
deny db_instance_subnet_not_​in_security_zone  |   1  |   Une base de données dans la zone de sécurité ne peut pas utiliser un sous-réseau  s'il n'est pas dans la même zone de sécurité.  |   Restreindre l'association des ressources
deny db_instance_move_to_​compartment_not_in_​security_zone  |   1  |   Vous ne pouvez pas déplacer une base de données dans la zone de sécurité vers un compartiment qui n'est pas dans la même zone de sécurité.  |   
deny db_instance_public_​access  |   2  |   Les bases de données dans la zone de sécurité ne peuvent pas être affectées à des sous-réseaux publics. Elles doivent utiliser des sous-réseaux privés.  |   Refuser l'accès public
deny free_database_creation  |   2  |   Vous ne pouvez pas créer une instance de base de données de type Toujours gratuit dans une zone de sécurité.  |   Utiliser uniquement les configurations approuvées par Oracle
   
* [Retour au Sommaire](#sommaire)   
   

Sur la base des 8 recettes ci-dessus , les 8 paramètres booléean suivants sont ajoutés dans la configuration de chaque zone de sécurité   



| Paramètre | Description | Type | Domaine de valeurs | Défault | Obligatoire |
|-----------| ----------- | ---- | ----------- | ----------- | ----------- |
| recette_base_de_donnees |  Détermine si on ajoute les stratégies de la recette Base de données dans la recette de la zone de sécurité | Booléen | [OUI,NON] | NON | OUI |  
| recette_instance_de_calcul |  Détermine si on ajoute les stratégies de la recette Instance de calcul dans la recette de la zone de sécurité | Booléen | [OUI,NON] | NON | OUI |
| recette_equilibreur_de_charge |  Détermine si on ajoute les stratégies de la recette Équilibreur de charge dans la recette de la zone de sécurité | Booléen | [OUI,NON] | NON | OUI |
| recette_gestion_des_certificats |  Détermine si on ajoute les stratégies de la recette Gestion des certificats dans la recette de la zone de sécurité | Booléen | [OUI,NON] | NON | OUI |
| recette_reseau_en_nuage_virtuel |  Détermine si on ajoute les stratégies de la recette Réseau en nuage virtuel dans la recette de la zone de sécurité | Booléen | [OUI,NON] | NON | OUI |
| recette_stockage_de_fichiers |  Détermine si on ajoute les stratégies de la recette Stockage de fichiers dans la recette de la zone de sécurité | Booléen | [OUI,NON] | NON | OUI |
| recette_stockage_objets |  Détermine si on ajoute les stratégies de la recette Stockage d'objets dans la recette de la zone de sécurité | Booléen | [OUI,NON] | NON | OUI |
| recette_stockage_par_blocs |  Détermine si on ajoute les stratégies de la recette Stockage par blocs dans la recette de la zone de sécurité | Booléen | [OUI,NON] | NON | OUI |

En définitive , la spécification d'une zone de sécurité dans une zone d'accueil OCI   

| Paramètre | Description | Type | Domaine de valeurs | Défault | Obligatoire |
|-----------| ----------- | ---- | ----------- | ----------- | ----------- |
| nom_zone_securite | Nom de la zone de sécurité  | Chaîne de caractères |  |  | OUI |  
| description_zone_securite | Description de la zone de sécurité  | Chaîne de caractères |  |  | NON |   
| ocid_compartiment | OCID du compartiment qui sera associé à al cible zone sécurité  | Chaîne de caractères |  |  | OUI |  
| profil_cis |  Numéro du profil CIS à appliquer dans la zone de sécurité | Entier | [1,2] | 1 | OUI |  
| recette_base_de_donnees |  Détermine si on ajoute les stratégies de la recette Base de données dans la recette de la zone de sécurité | Booléen | [OUI,NON] | NON | OUI |  
| recette_instance_de_calcul |  Détermine si on ajoute les stratégies de la recette Instance de calcul dans la recette de la zone de sécurité | Booléen | [OUI,NON] | NON | OUI |
| recette_equilibreur_de_charge |  Détermine si on ajoute les stratégies de la recette Équilibreur de charge dans la recette de la zone de sécurité | Booléen | [OUI,NON] | NON | OUI |
| recette_gestion_des_certificats |  Détermine si on ajoute les stratégies de la recette Gestion des certificats dans la recette de la zone de sécurité | Booléen | [OUI,NON] | NON | OUI |
| recette_reseau_en_nuage_virtuel |  Détermine si on ajoute les stratégies de la recette Réseau en nuage virtuel dans la recette de la zone de sécurité | Booléen | [OUI,NON] | NON | OUI |
| recette_stockage_de_fichiers |  Détermine si on ajoute les stratégies de la recette Stockage de fichiers dans la recette de la zone de sécurité | Booléen | [OUI,NON] | NON | OUI |
| recette_stockage_objets |  Détermine si on ajoute les stratégies de la recette Stockage d'objets dans la recette de la zone de sécurité | Booléen | [OUI,NON] | NON | OUI |
| recette_stockage_par_blocs |  Détermine si on ajoute les stratégies de la recette Stockage par blocs dans la recette de la zone de sécurité | Booléen | [OUI,NON] | NON | OUI |

* [Retour au Sommaire](#sommaire)   

### Stratégies de zone de sécurité pour le compartiment production   


Pour assurer l'intégrité des données dans l'environnement de production , les ressources en production ne peuvent pas être déplacées vers un autre compartiment. Vous ne pouvez pas non plus déplacer une ressource existante vers un compartiment dans une zone de sécurité, sauf si toutes les politiques de la zone de sécurité sont respectées.

Nous allons donc mettre le compartiment cmp-prod-001 dans une zone sécurité ZS001 , avec un profil CIS de niveau 2.  

Toutes les ressources dans la zone de sécurité ZS001 ne peuvent pas être déplacées vers un compartiment  qui est en dehors de la zone de sécurité ZS1.

Voici la configuration de ZS001

| Paramètre | Description | Type | Domaine de valeurs | Défault | Obligatoire |
|-----------| ----------- | ---- | ----------- | ----------- | ----------- |
| nom_zone_securite | Nom de la zone de sécurité  | Chaîne de caractères |  | zs-cmp-prod-001  | OUI |  
| description_zone_securite | Description de la zone de sécurité  | Chaîne de caractères |  | zone de sécurité sur le compartiment Production | NON |   
| ocid_compartiment | OCID du compartiment qui sera associé à al cible zone sécurité  | Chaîne de caractères |  |  | OUI |  
| profil_cis |  Numéro du profil CIS à appliquer dans la zone de sécurité | Entier | [1,2] | 1 | OUI |  
| recette_base_de_donnees |  Détermine si on ajoute les stratégies de la recette Base de données dans la recette de la zone de sécurité | Booléen | [OUI,NON] | OUI | OUI |  
| recette_instance_de_calcul |  Détermine si on ajoute les stratégies de la recette Instance de calcul dans la recette de la zone de sécurité | Booléen | [OUI,NON] | OUI | OUI |
| recette_equilibreur_de_charge |  Détermine si on ajoute les stratégies de la recette Équilibreur de charge dans la recette de la zone de sécurité | Booléen | [OUI,NON] | NON | OUI |
| recette_gestion_des_certificats |  Détermine si on ajoute les stratégies de la recette Gestion des certificats dans la recette de la zone de sécurité | Booléen | [OUI,NON] | NON | OUI |
| recette_reseau_en_nuage_virtuel |  Détermine si on ajoute les stratégies de la recette Réseau en nuage virtuel dans la recette de la zone de sécurité | Booléen | [OUI,NON] | NON | OUI |
| recette_stockage_de_fichiers |  Détermine si on ajoute les stratégies de la recette Stockage de fichiers dans la recette de la zone de sécurité | Booléen | [OUI,NON] | NON | OUI |
| recette_stockage_objets |  Détermine si on ajoute les stratégies de la recette Stockage d'objets dans la recette de la zone de sécurité | Booléen | [OUI,NON] | NON | OUI |
| recette_stockage_par_blocs |  Détermine si on ajoute les stratégies de la recette Stockage par blocs dans la recette de la zone de sécurité | Booléen | [OUI,NON] | NON | OUI |

* [Retour au Sommaire](#sommaire)   

### Stratégies de zone de sécurité pour le Hub  

 Dans l'architecture en étoile de la zone d'accueil, le compartiment hub / Cnnectivité centralise la communication entre les réseaux inter VCN ainsi que la communication entre les VCN et le site sur place (on-premises). Elle comprend une passerelle de routage dynamique (DRG) qui offre la possibilité de diriger et d'inspecter le trafic des VCN à l'aide de pare-feux. La sécurité de ce trafic est gérée essentiellement à travers le Hub qui dispose de pare-feux en redondance. 

 
Voici la configuration de sa zone de sécurité

| Paramètre | Description | Type | Domaine de valeurs | Défault | Obligatoire |
|-----------| ----------- | ---- | ----------- | ----------- | ----------- |
| nom_zone_securite | Nom de la zone de sécurité  | Chaîne de caractères |  | zs-cmp-conne-001  | OUI |  
| description_zone_securite | Description de la zone de sécurité  | Chaîne de caractères |  | zone de sécurité sur le compartiment Connectivite | NON |   
| ocid_compartiment | OCID du compartiment qui sera associé à al cible zone sécurité  | Chaîne de caractères |  |  | OUI |  
| profil_cis |  Numéro du profil CIS à appliquer dans la zone de sécurité | Entier | [1,2] | 1 | OUI |  
| recette_base_de_donnees |  Détermine si on ajoute les stratégies de la recette Base de données dans la recette de la zone de sécurité | Booléen | [OUI,NON] | NON | OUI |  
| recette_instance_de_calcul |  Détermine si on ajoute les stratégies de la recette Instance de calcul dans la recette de la zone de sécurité | Booléen | [OUI,NON] | NON | OUI |
| recette_equilibreur_de_charge |  Détermine si on ajoute les stratégies de la recette Équilibreur de charge dans la recette de la zone de sécurité | Booléen | [OUI,NON] | OUI | OUI |
| recette_gestion_des_certificats |  Détermine si on ajoute les stratégies de la recette Gestion des certificats dans la recette de la zone de sécurité | Booléen | [OUI,NON] | NON | OUI |
| recette_reseau_en_nuage_virtuel |  Détermine si on ajoute les stratégies de la recette Réseau en nuage virtuel dans la recette de la zone de sécurité | Booléen | [OUI,NON] | NON | OUI |
| recette_stockage_de_fichiers |  Détermine si on ajoute les stratégies de la recette Stockage de fichiers dans la recette de la zone de sécurité | Booléen | [OUI,NON] | NON | OUI |
| recette_stockage_objets |  Détermine si on ajoute les stratégies de la recette Stockage d'objets dans la recette de la zone de sécurité | Booléen | [OUI,NON] | NON | OUI |
| recette_stockage_par_blocs |  Détermine si on ajoute les stratégies de la recette Stockage par blocs dans la recette de la zone de sécurité | Booléen | [OUI,NON] | NON | OUI |

* [Retour au Sommaire](#sommaire)   

### Stratégies de zone de sécurité pour le compartiment journalisation et sécurité  

C'est le compartiment de toutes les ressouces liées à la sécurité : coffres à secret, notifications, journaux d'activité, scanning,etc.


Voici la configuration de sa zone de sécurité

| Paramètre | Description | Type | Domaine de valeurs | Défault | Obligatoire |
|-----------| ----------- | ---- | ----------- | ----------- | ----------- |
| nom_zone_securite | Nom de la zone de sécurité  | Chaîne de caractères |  | zs-cmp-sejou-001  | OUI |  
| description_zone_securite | Description de la zone de sécurité  | Chaîne de caractères |  | zone de sécurité sur le compartiment Sécurité et journalisation | NON |   
| ocid_compartiment | OCID du compartiment qui sera associé à al cible zone sécurité  | Chaîne de caractères |  |  | OUI |  
| profil_cis |  Numéro du profil CIS à appliquer dans la zone de sécurité | Entier | [1,2] | 1 | OUI |  
| recette_base_de_donnees |  Détermine si on ajoute les stratégies de la recette Base de données dans la recette de la zone de sécurité | Booléen | [OUI,NON] | NON | OUI |  
| recette_instance_de_calcul |  Détermine si on ajoute les stratégies de la recette Instance de calcul dans la recette de la zone de sécurité | Booléen | [OUI,NON] | NON | OUI |
| recette_equilibreur_de_charge |  Détermine si on ajoute les stratégies de la recette Équilibreur de charge dans la recette de la zone de sécurité | Booléen | [OUI,NON] | OUI | OUI |
| recette_gestion_des_certificats |  Détermine si on ajoute les stratégies de la recette Gestion des certificats dans la recette de la zone de sécurité | Booléen | [OUI,NON] | OUI | OUI |
| recette_reseau_en_nuage_virtuel |  Détermine si on ajoute les stratégies de la recette Réseau en nuage virtuel dans la recette de la zone de sécurité | Booléen | [OUI,NON] | NON | OUI |
| recette_stockage_de_fichiers |  Détermine si on ajoute les stratégies de la recette Stockage de fichiers dans la recette de la zone de sécurité | Booléen | [OUI,NON] | OUI | OUI |
| recette_stockage_objets |  Détermine si on ajoute les stratégies de la recette Stockage d'objets dans la recette de la zone de sécurité | Booléen | [OUI,NON] | OUI | OUI |
| recette_stockage_par_blocs |  Détermine si on ajoute les stratégies de la recette Stockage par blocs dans la recette de la zone de sécurité | Booléen | [OUI,NON] | OUI | OUI |

En résumé une zone de sécurité aura 1 à 8 recettes de zone de sécurité. 
Et chaque recette de zone de sécurité aura 1 ou plusieurs stratégies de zone de sécurité


![Arc_zone_de_securite](../../images/zone_securite_oci/Arc_zone_de_securite.png)


* [Retour au Sommaire](#sommaire)   


## Recommandations   

### Éviter zone de sécurité au compartiment racine  

Pour une flexibilité maximale, évitez d'affecter une zone de sécurité au compartiment racine de la location. Les zones de sécurité appliquées au compartiment racine peuvent restreindre les actions possibles sur l'ensemble d'une location. Bien que cette configuration soit préférable pour des cas d'utilisation spécifiques, elle est trop restrictive pour la plupart des utilisateurs.

Définissez des zones de sécurité personnalisées pour répondre à vos exigences spécifiques en matière de sécurité et de conformité réglementaire. Sélectionnez les instructions de stratégie pertinentes pour vos besoins et le compartiment cible.

### principes de sécurité   

Les principes de sécurité suivant doivent être respectées 
 
 
- Garantir la sécurité des données
- Chiffrement requis
- Refuser l'accès public
- Restreindre l'association des ressources
- Utiliser uniquement les configurations approuvées par Oracle

### Politiques GIA pour les zones de sécurité  

Créez des politiques GIA pour contrôler qui a accès aux zones de sécurité, ainsi que le type d'accès pour chaque groupe d'utilisateurs.
https://docs.oracle.com/fr-ca/iaas/security-zone/using/security-zone-policies.htm#encryption-policies 
Les types de ressource individuels pour les zones de sécurité sont inclus dans le type d'agrégation cloud-guard-family. Une politique qui accorde des autorisations à cloud-guard-family accorde également les mêmes autorisations aux zones de sécurité.   

### Puis-je créer mes propres stratégies   

Les clients ne peuvent pas créer leurs propres politiques. Les clients ont accès à une liste complète de stratégies fournies par Oracle. De nouvelles stratégies seront ajoutées au fil du temps.

* [Retour au Sommaire](#sommaire)   
* [Retour à la page d'accueil](../../../README.md)


