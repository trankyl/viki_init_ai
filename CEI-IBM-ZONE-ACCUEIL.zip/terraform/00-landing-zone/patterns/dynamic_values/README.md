# Pattern Dynamic Values

This module is used to test static outputs for unit testing. Outputs for each resource are added in the appropriate `.tf` file for ease of use.