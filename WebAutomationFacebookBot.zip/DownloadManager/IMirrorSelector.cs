﻿using System.Reflection;
namespace WebBrowserBot.DownloadManager
{
    public interface IMirrorSelector
    {
        void Init(Downloader downloader);

        ResourceLocation GetNextResourceLocation();
    }
}
