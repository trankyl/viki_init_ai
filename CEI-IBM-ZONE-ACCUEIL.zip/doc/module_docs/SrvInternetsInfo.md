# 30-cloudinternetsvcs

## Overview

This extension deploys [Cloud Internet Services](https://cloud.ibm.com/docs/cis?topic=cis-getting-started) into your landing zone.

Cloud Internet Services can be used for edge protection for internet facing applications.

![Cloud Internet Services](../images/module_doc_imgs/vsi-cloudinternetsvcs.png)

## Input Variables

These input variables will be looked up in the output of [00-landing-zone](../../terraform/00-landing-zone/patterns/vsi) or you can override and pass them in.  This component is designed to be run after `00-landing-zone`.

| Name | Description | Type | Default/Example | Required |
| ---- | ----------- | ---- | ------- | -------- |
| ibmcloud_api_key | API Key used to provision resources.  Your key must be authorized to perform the actions in this script. | string | N/A | yes |
| region | MZR to provision the Fortigate AP HA pairs. List all available regions with: "ibmcloud regions". | string | Default: "ca-tor" | yes |
| prefix | Short string that will be used to prefix all resource names | list(string) | N/A | yes |
| resource_group_id | The id of the resource group in which to provision the observability components. | string | `<prefix>-slz-service-rg`| Use default or provide your own |
