# Contrôles de sécurité pour l'exigence 8

08 : Segmenter et séparer les données selon leur sensibilité

Trois contrôles sont liés à l'exigence 08 :
 AC-4, SC-7, SC-7(5)

## < --- Contrôle EX8_AC-4--->

![EX8](image/AC4.PNG)

## Première Validation

   1. Responsabilité du fournisseur : Oui
   2. Commentaire : Pour le compte de périmètre, on retrouve les instances de pare-feu et la passerelle Internet.
   La gestion de la réseautique et des tables de routage ainsi que la passerelle de service sont centralisées dans le compte réseautique. Ce dispositif permet d’assurer la segmentation réseautique entre les différents comptes de charge de travail. Il faudra donner l’accès à ce compte à l’équipe réseau afin qu’elle puisse faire la gestion des VPC, de l’adressage IP et des tables de routage de l’environnement. Ce qui permettra de gérer la communication entre les charges de travail.
   3. [Lien Document](https://docs.aws.amazon.com/fr_fr/console/ec2/security-groups#security-group-rules)
      [Lien Document](https://docs.aws.amazon.com/fr_fr/console/vpc/network-acls)

## < --- Contrôle EX8_SC-7--->

![EX8](image/SC7.PNG)

## Deuxième Validation

   1. Responsabilité du fournisseur : Oui
   2. Commentaire : Le système d’information surveille et contrôle les communications à sa frontière externe et à ses principales frontières internes. Le nuage privé virtuel (VPC) du compte périmètre héberge les services de sécurité de périmètre de l'organisation. Le VPC de périmètre est utilisé pour contrôler le flux de trafic entre les comptes AWS.

## < --- Contrôle EX8_SC-7(5)--->

![EX8](image/SC7-5.PNG)  

## Troisième Validation

   1. Responsabilité du fournisseur : Oui
   2. Commentaire : Par défaut, il n'y a pas de connectivité externe. Tout trafic externe est interdit. Il faut configurer un VPN et une passerelle publique pour communiquer à l'externe.

   Par le biais de la console : VPC -> Security Group

   [Retour à la Page d'accueil](/ReadMe.md)
