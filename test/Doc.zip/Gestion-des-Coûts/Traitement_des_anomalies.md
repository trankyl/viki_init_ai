# OCI-Traitement des anomalies

## Table des matières


La gestion des anomalies de coûts est un élément essentiel de FinOps dans Oracle Cloud Infrastructure (OCI). Une anomalie peut être un pic inattendu de l'utilisation, une augmentation soudaine des coûts ou un changement de comportement d'une ressource cloud. Voici les 10 commandements :

1. [Outils de détection des anomalies](#outils-de-détection-des-anomalies)
2. [Définition des anomalies](#définition-des-anomalies)
3. [Configuration des alertes](#configuration-des-alertes)
4. [Procédures d'intervention en cas d'alerte](#procédures-des-interventions-en-cas-d-alertes)
5. [Rôles et responsabilités](#rôles-et-responsabilités)
6. [Plan de communication](#plan-de-communication)
7. [Résolution des anomalies](#résolution-des-anomalies)
8. [Examen post-incident](#examen-post-incident)
9. [Rapports réguliers des anomalies](#rapports-réguliers-des-anomalies)
10. [Amélioration continue](#amélioration-continue)
11. [Cas d'utilisation](#cas-utilisation)


L'objectif de la gestion des anomalies n'est pas seulement de résoudre le problème immédiat, mais d'en tirer des leçons et d'améliorer vos opérations cloud et votre gestion des coûts.

## Outils de détection des anomalies

Dans le contexte du FinOps et de la gestion des coûts dans Oracle Cloud Infrastructure (OCI), les outils de détection d'anomalies sont essentiels. Ces outils aident à surveiller et à analyser vos données d'utilisation et de dépenses du cloud pour identifier des modèles ou des tendances inhabituels qui pourraient indiquer un problème ou une opportunité d'optimisation des coûts.

OCI est livré avec des capacités intégrées de surveillance et d'alerte qui peuvent être utilisées pour la détection des anomalies. Voici comment vous pouvez documenter le processus d'utilisation de ces outils :

1. **Surveillance du OCI** : La première ligne de défense est la surveillance du OCI (*OCI Monitoring), qui fournit une surveillance en temps réel basée sur des mesures pour toutes les ressources du OCI. Vous devez surveiller quelles mesures sont suivies et comment configurer la surveillance OCI pour collecter ces mesures.

2. **Alarmes OCI** : À l'aide des mesures collectées par la surveillance OCI, vous pouvez configurer des alarmes OCI pour envoyer des alertes lorsqu'une mesure franchit un seuil que vous définissez. Documentez le processus de configuration des alarmes, y compris la façon de définir des seuils qui reflètent avec précision ce qui constitue une « anomalie » dans votre environnement cloud.

3. **Notifications OCI** : Les alarmes OCI peuvent être configurées pour envoyer des notifications par courriel ou à un service de messagerie lorsqu'une alarme est déclenchée. Documentez le processus de configuration des notifications et définissez qui doit recevoir ces notifications.

4. **Événements et fonctions OCI** : Pour une détection et une réponse d'anomalies plus avancées, vous pouvez utiliser les événements et les fonctions OCI pour automatiser les réponses à des événements spécifiques. Par exemple, si une alarme est déclenchée par une augmentation soudaine des coûts, une fonction pourrait être déclenchée pour arrêter ou réduire automatiquement la ressource incriminée.

5. **Outils tiers** : En plus des capacités intégrées de l'OCI, il existe de nombreux outils tiers disponibles qui offrent des fonctionnalités de détection d'anomalies plus avancées. Cela peut inclure des algorithmes d'apprentissage automatique qui peuvent prédire les anomalies en fonction des données historiques, ou des outils de surveillance spécialisés qui peuvent suivre des aspects plus spécifiques de votre utilisation du cloud. Documentez quels outils tiers sont utilisés, comment ils sont intégrés à OCI et comment les configurer et les utiliser pour la détection des anomalies.

6. **Stratégies de détection d'anomalies** : Enfin, documentez les stratégies de votre organisation concernant la détection des anomalies. Cela devrait inclure le processus d'examen et de mise à jour de votre configuration de surveillance et d'alerte, les rôles et responsabilités pour répondre aux anomalies, et les procédures d'enquête et de résolution des anomalies.

N'oubliez pas que l'objectif de l'utilisation d'outils de détection d'anomalies n'est pas seulement de détecter les problèmes après qu'ils se sont produits, mais de surveiller de manière proactive votre environnement infonuagique et de répondre rapidement lorsque des anomalies sont détectées. Cela peut aider à garder vos coûts cloud sous contrôle et à vous assurer que vos ressources cloud sont utilisées efficacement.

## Définition des anomalies

La définition des anomalies est cruciale pour les pratiques FinOps, car elle permet de définir des paramètres spécifiques qui, en cas de violation, indiquent un comportement inhabituel ou des valeurs aberrantes dans l'utilisation du cloud. Il s’agit d’une étape essentielle pour mettre en place des alertes significatives et pour ajuster efficacement vos outils de détection d’anomalies. Voici comment vous pouvez documenter ce processus :

1. **Comprendre le comportement normal**: Pour définir à quoi ressemble une anomalie, vous devez d’abord comprendre ce qu’est un comportement normal. Cela implique d’analyser vos données historiques d’utilisation et de dépenses pour identifier les modèles et les tendances typiques. Ces tendances peuvent varier selon l’heure de la journée, le jour de la semaine ou la période de l’année, en fonction de votre entreprise.

2. **Identifier les anomalies potentielles**: Une fois que vous avez une compréhension claire du comportement normal, vous pouvez commencer à identifier les anomalies potentielles. Il peut s’agir de hausses soudaines des coûts, d’une utilisation inhabituellement élevée ou faible de certaines ressources ou de changements dans le modèle d’utilisation ou de dépenses.

3. **Définir des seuils**: Sur la base de votre analyse du comportement normal et des anomalies potentielles, vous pouvez définir des seuils qui définissent ce qui constitue une anomalie. Par exemple, vous pouvez définir un seuil pour un certain pourcentage d’augmentation des coûts par rapport au jour, à la semaine ou au mois précédent. Vous pouvez également définir un seuil pour le nombre d’instances en cours d’exécution à un moment donné.

4. **Tester et affiner les seuils** : Il est important de tester et d’affiner régulièrement vos seuils pour vous assurer qu’ils détectent avec précision les anomalies. Si vos seuils sont trop sensibles, vous risquez d’obtenir trop de fausses alarmes. S’ils ne sont pas assez sensibles, vous risquez de manquer des anomalies importantes.

5. **Définir les types d’anomalies** : Toutes les anomalies ne sont pas égales. Certains pourraient indiquer un problème grave qui nécessite une attention immédiate, tandis que d’autres pourraient être moins urgents. Définissez différents types d’anomalies et hiérarchisez-les en fonction de leur impact potentiel sur votre environnement cloud et de leurs coûts.

6. **Documentez les définitions des anomalies** : Enfin, documentez vos définitions et seuils d’anomalie. Cela permettra de s’assurer que tous les membres de votre équipe comprennent ce qui constitue une anomalie et quelles mesures doivent être prises lorsqu’une anomalie est détectée.

N’oubliez pas que l’objectif de la définition des anomalies est de vous aider à détecter et à répondre aux comportements inhabituels dans votre environnement cloud le plus rapidement possible. En définissant clairement ce qui constitue une anomalie, vous pouvez vous assurer que vos outils de détection d’anomalies sont configurés pour détecter ces événements et que votre équipe sait comment réagir lorsqu’ils se produisent.


## Configuration des alertes

La mise en place d’alertes est une étape cruciale dans la gestion de l’environnement cloud, en particulier dans la détection des anomalies. Ces alertes avertissent votre équipe lorsqu’une anomalie se produit, ce qui permet une action rapide pour atténuer les problèmes potentiels.
Dans Oracle Cloud Infrastructure (OCI), vous pouvez créer des alarmes basées sur les données de métriques collectées via OCI Monitoring. Voici un guide étape par étape pour configurer les alertes :

1. **Identifiez les mesures critiques** : Commencez par identifier les mesures les plus pertinentes pour vos opérations et la gestion des coûts. Ceux-ci pourraient inclure l’utilisation du processeur, l’utilisation du stockage, les coûts de transfert de données, etc.

2. **Définir les seuils d’alarme** : Une fois que vous avez sélectionné vos métriques, définissez les seuils auxquels une alarme doit être déclenchée. Les seuils doivent correspondre aux définitions des anomalies que vous avez établies.

3. **Créer des alarmes dans OCI** : À l’aide de la surveillance OCI, créez une alarme pour chacune des mesures critiques. Vous pouvez spécifier le seuil et la période sur laquelle le seuil doit être évalué.

4. **Définir les états d’alarme** : Vous pouvez spécifier les états dans lesquels une alarme sera déclenchée. En règle générale, il existe trois états : « OK » lorsque la métrique se situe dans le seuil défini, « ALARM » lorsque le seuil a été dépassé et « INSUFFICIENT_DATA » lorsqu’il n’y a pas assez de données pour déterminer l’état.

5. **Définir les actions** : Définissez les actions à entreprendre lorsqu’une alarme est déclenchée. Des actions peuvent être définies pour notifier une liste de destinataires par e-mail ou par d’autres canaux de communication. Dans OCI, vous pouvez utiliser le service de notification pour remettre ces messages.

6. **Testez vos alarmes** : Une fois vos alarmes configurées, il est recommandé de les tester pour vous assurer qu’elles fonctionnent comme prévu. Vous pouvez le faire en définissant temporairement un seuil bas facile à déclencher.

7. **Affiner les paramètres d’alarme**: En fonction des résultats de vos tests et au fil du temps, affinez les paramètres de vos alarmes. Si vous obtenez trop de faux positifs, vous devrez peut-être ajuster vos seuils ou vos périodes d’évaluation.

8. **Documentez le processus** : Documentez l’ensemble du processus de configuration des alarmes. Cela doit inclure les mesures que vous suivez, les seuils que vous avez définis, comment créer et modifier les alarmes et quelles actions doivent être entreprises lorsqu’une alarme est déclenchée.

En mettant en place des alertes, votre équipe peut rester proactive et réagir rapidement aux anomalies, en assurant une gestion efficace des coûts et en maintenant les performances et la disponibilité de vos ressources cloud.



## Procédures des interventions en cas d'alertes

Les procédures de réponse aux alertes décrivent les étapes que votre équipe doit suivre une fois qu’une alerte d’anomalie est déclenchée. Ces procédures sont cruciales pour assurer une réponse rapide et efficace, contribuant à atténuer l’impact potentiel de l’anomalie. Voici comment documenter ces procédures :

1. **Accuser réception de l’alerte** : La première étape pour répondre à une alerte consiste à en accuser réception. Cela permet à votre équipe de savoir que quelqu’un a vu l’alerte et agit.

2. **Enquêter sur l’alerte** : La personne qui répond à l’alerte doit enquêter pour comprendre ce qui l’a causée. Cela peut impliquer de vérifier l’état de vos ressources cloud, d’examiner les modifications récentes ou d’analyser les données d’utilisation et de coût.

3. **Classer l’anomalie** : En fonction de l’enquête, classer l’anomalie en fonction de sa gravité et de son impact. Il peut s’agir d’un problème mineur qui ne nécessite pas d’action immédiate, ou d’un problème majeur susceptible d’affecter considérablement vos opérations ou vos coûts d'utilisation cloud.

4. **Prendre des mesures correctives** : Selon la classification de l’anomalie, prendre les mesures correctives appropriées. Cela peut impliquer l’arrêt ou la réduction d’une ressource, l’ajustement d’une configuration ou la prise de contact avec un fournisseur pour obtenir de l’aide.

5. **Communiquer le statut** : Tenez votre équipe informée de l’état de l’anomalie et des mesures prises. Cela peut impliquer la mise à jour d’une page d’état, l’envoi de mises à jour par e-mail ou la tenue d’une réunion.

6. **Examiner et apprendre** : Une fois l’anomalie résolue, examinez l’incident pour en tirer des leçons. Cela peut impliquer la mise à jour de vos définitions d’anomalies ou de vos seuils d’alerte, l’amélioration de votre configuration de surveillance et d’alerte, ou la fourniture d’une formation supplémentaire à votre équipe.

7. **Documentez l’incident** : Enfin, documentez l’incident et l’intervention. Cela devrait inclure une description de l’anomalie, les mesures prises pour la résoudre, l’impact sur vos opérations ou vos coûts et toute leçon apprise. Cette documentation peut être utilisée pour référence future et pour améliorer vos procédures de réponse aux alertes au fil du temps.

N’oubliez pas que l’objectif de vos procédures de réponse aux alertes n’est pas seulement de résoudre rapidement les anomalies, mais aussi d’en tirer des leçons et d’améliorer vos opérations cloud et votre gestion des coûts. En documentant ces procédures, vous pouvez vous assurer que votre équipe sait quoi faire lorsqu’une alerte est déclenchée et peut réagir efficacement.

## Rôles et responsabilités

L’attribution de rôles et de responsabilités clairs est essentielle à la détection et à la résolution efficaces des anomalies. Il garantit que chacun connaît son rôle dans le processus, améliore la coordination et la communication et s’assure que rien ne passe entre les mailles du filet. Voici comment vous pouvez documenter ces rôles et responsabilités :

1. **Équipe des opérations cloud** : Ce sont les personnes qui sont principalement responsables de la gestion quotidienne de vos ressources cloud. Leurs responsabilités peuvent inclure la configuration et la maintenance de vos systèmes de surveillance et d’alerte, la réponse aux alertes, l’enquête sur les anomalies et la prise de mesures correctives.

2. **Équipe des finances** : L’équipe des finances joue un rôle clé dans la gestion des coûts. Ils peuvent être chargés d’analyser les données de coûts, de définir des repères de coûts et des budgets, et de travailler avec l’équipe des opérations pour comprendre et contrôler les coûts du cloud.

3. **Équipe de développement** : Les développeurs ont un rôle essentiel à jouer pour s’assurer que vos applications et services cloud sont conçus et codés pour être efficaces et rentables. Ils peuvent également jouer un rôle dans la réponse à certains types d’anomalies, en particulier celles liées aux performances ou aux fonctionnalités des applications.

4. **Gestion** : La direction doit assurer la supervision et l’orientation stratégique des opérations cloud et de la gestion des coûts. Ils peuvent également avoir besoin d’approuver certaines actions, telles que la mise à l’échelle des ressources ou l’apport de modifications importantes à votre environnement cloud.

5. **Équipe de sécurité** : Ils jouent un rôle essentiel pour assurer la conformité et la protection des données dans le cloud. Ils seraient impliqués lorsqu’une anomalie est détectée qui pourrait indiquer un problème de sécurité, comme un pic soudain de trafic réseau ou un accès non autorisé.

6. **Propriétaire du service cloud** : Il s’agit généralement d’une personne ou d’une équipe responsable d’un service ou d’une application cloud spécifique. Ils devraient participer à l’enquête et à la résolution des anomalies liées à leur service.

7. **Responsable des communications** : Il peut s’agir d’une personne désignée responsable des communications internes lorsqu’une anomalie se produit. Ils veilleront à ce que les parties prenantes concernées soient informées de l’état de l’anomalie et des mesures prises pour y remédier.

N’oubliez pas que ces rôles et responsabilités peuvent varier en fonction de la taille et de la structure de votre organisation, ainsi que de la complexité de votre environnement cloud. Il est également important d’envisager des plans de sauvegarde et de rotation au cas où des personnes clés ne seraient pas disponibles. La documentation de ces rôles et responsabilités peut aider à s’assurer que tout le monde sait ce qu’il est censé faire lorsqu’une anomalie se produit.

## Plan de communication

Un plan de communication est une partie essentielle de votre procédure de réponse aux anomalies. Il dicte qui doit être informé lorsqu’une anomalie est détectée, comment la communication doit avoir lieu et quelles informations doivent être transmises. Voici comment vous pourriez documenter votre plan de communication :

1. **Canaux de communication** : Identifiez les principaux canaux de communication en cas d’anomalie. Il peut s’agir d’un courrier électronique, d’une plate-forme de chat comme Slack, d’un outil de gestion de projet ou d’une combinaison de ceux-ci. Précisez quel canal doit être utilisé pour quel type de communication (p. ex., alerte initiale, mises à jour continues, analyse post mortem).

2. **Rôles de communication** : Spécifiez qui est responsable de la communication lors d’une anomalie. Il peut y avoir une personne qui assume le rôle de responsable de la communication, ou la responsabilité peut être partagée au sein de l’équipe.

3. **Intervenants** : Identifier les intervenants qui doivent être informés en cas d’anomalie. Cela peut inclure votre équipe d’exploitation, les développeurs, la direction, l’équipe financière, etc. Pour chaque groupe de parties prenantes, précisez les informations qu’elles doivent recevoir.

4. **Contenu de la communication** : Définissez les informations à inclure dans chaque communication. Cela dépendra généralement de la nature de l’anomalie et du groupe de parties prenantes. En règle générale, il devrait inclure une description de l’anomalie, de l’impact et des mesures prises.

5. **Fréquence des communications** : Déterminez la fréquence à laquelle les mises à jour doivent être envoyées. Cela dépendra de la gravité et de la durée de l’anomalie. Certaines parties prenantes peuvent avoir besoin de mises à jour en temps réel, tandis que d’autres peuvent n’avoir besoin d’un résumé qu’une fois le problème résolu.

6. **Chemins d’escalade** : Définissez un chemin d’escalade pour la communication. Si une anomalie n’est pas corrigée ou s’aggrave, qui devrait en être informé et comment? Ceci est particulièrement important pour les anomalies graves qui peuvent avoir un impact significatif sur l’entreprise.

7. **Rapports post-mortem** : Une fois l’anomalie résolue, un rapport d’autopsie détaillé doit être préparé et partagé avec les parties prenantes concernées. Cela devrait inclure une chronologie des événements, une analyse des causes profondes, des mesures correctives prises, une analyse des répercussions et des leçons apprises pour éviter des anomalies similaires à l’avenir.

La documentation de ce plan de communication permet d’assurer la transparence et une communication efficace lors de la résolution des anomalies. Il permet aux équipes de mieux se coordonner, réduit la confusion et garantit que tout le monde est informé de l’état de l’anomalie, ce qui permet une résolution plus rapide et plus efficace.


## Résolution des anomalies

La résolution des anomalies fait référence aux mesures prises pour enquêter et corriger une anomalie détectée dans le système. Cela peut impliquer une série d’étapes telles que l’accusé de réception de l’alerte, la classification de la gravité de l’anomalie, l’enquête sur la cause première, la prise de mesures correctives et la confirmation que l’anomalie est résolue. Voici comment vous pouvez documenter ce processus :

1. **Accusé de réception d’alerte** : Dès qu’une anomalie est détectée et qu’une alerte est déclenchée, l’équipe ou la personne désignée doit en accuser réception. Cela confirme que l’alerte a été vue et que quelqu’un prend des mesures.

2. **Classification des anomalies** : Classez l’anomalie en fonction de sa gravité. Cela inclut généralement des catégories telles que mineur, majeur et critique, et est basé sur des facteurs tels que l’impact sur vos opérations et les implications financières potentielles. Cette classification peut aider à hiérarchiser la réponse.

3. **Investigation** : L’étape suivante consiste à rechercher la cause profonde de l’anomalie. Cela pourrait impliquer la vérification des journaux, l’examen des modifications récentes, l’analyse des données d’utilisation et de coût, ou la consultation d’experts pertinents. L’objectif est de comprendre ce qui cause l’anomalie afin qu’elle puisse être traitée efficacement.

4. **Mesures correctives** : Une fois que la cause de l’anomalie est comprise, prenez les mesures correctives appropriées. Cela peut impliquer l’ajustement de vos ressources cloud, la modification de vos configurations, l’application de correctifs ou de mises à jour, ou d’autres actions. L’action exacte dépendra de la cause de l’anomalie.

5. **Confirmation** : Une fois que les mesures correctives ont été prises, confirmez que l’anomalie a été résolue. Cela peut impliquer la surveillance de votre environnement cloud et de vos métriques pour vous assurer que tout est revenu à la normale.

6. **Documentation** : Documenter l’anomalie, l’enquête, les mesures correctives prises et la résolution. Cela peut vous aider à résoudre les problèmes futurs et peut également contribuer à vos efforts continus pour améliorer vos procédures de détection et de réponse aux anomalies.

7. **Communication** : Tenir toutes les parties prenantes concernées informées tout au long du processus. Cela comprend la notification initiale de l’anomalie, les mises à jour au cours de l’enquête et de la résolution, et un rapport final une fois l’anomalie résolue. Cette communication doit être conforme à votre plan de communication établi.

8. **Examen post-incident** : Une fois l’anomalie résolue, effectuez un examen post-incident pour tirer des leçons de l’expérience. Cela devrait impliquer une analyse détaillée de ce qui s’est passé, pourquoi cela s’est produit, comment cela a été géré et ce qui peut être fait pour éviter qu’un événement similaire ne se reproduise à l’avenir.

Un processus efficace de résolution des anomalies peut vous aider à minimiser l’impact des anomalies sur vos opérations et vos coûts et peut contribuer à l’efficience et à l’efficacité globales de votre gestion du cloud.

## Examen post-incident

Un examen post-incident (parfois aussi appelé autopsie) est un processus effectué après la résolution d’un incident ou d’une anomalie pour comprendre ce qui s’est passé, pourquoi il s’est produit, comment il a été géré et ce qui peut être fait pour éviter qu’un événement similaire ne se reproduise à l’avenir. Voici les étapes pour documenter ce processus :

1. **Résumé de l’incident** : Commencez par fournir un résumé de l’incident. Cela devrait inclure quand l’incident a commencé et s’est terminé, quels étaient les symptômes observables, ce qui a causé l’incident et ce qui a été fait pour le résoudre.

2. **Chronologie des événements** : Créez une chronologie détaillée des événements, à partir du moment où l’anomalie a été détectée jusqu’au moment où elle a été résolue. Ce calendrier devrait inclure le moment où l’anomalie a été détectée, le moment où l’alerte a été reconnue, la date à laquelle l’incident a été classifié, le moment où des mesures correctives ont été prises et le moment où l’anomalie a été résolue.

3. **Évaluation d’impact** : Évaluer l’impact de l’incident. Cela peut inclure l’impact sur vos ressources cloud, vos opérations et vos coûts. Dans la mesure du possible, quantifier l’impact (p. ex., temps d’arrêt, coûts supplémentaires, perte de productivité).

4. **Analyse des causes profondes** : Effectuez une analyse des causes profondes pour comprendre ce qui a causé l’anomalie. Cela peut impliquer l’examen des journaux, l’analyse des données d’utilisation et de coût, ou la discussion avec les membres de l’équipe. L’objectif est d’identifier le problème sous-jacent qui a conduit à l’anomalie.

5. **Examen des mesures correctives** : Examinez les mesures correctives qui ont été prises pour corriger l’anomalie. Ces mesures ont-elles été efficaces? L’anomalie aurait-elle pu être résolue plus rapidement ou plus efficacement? Qu’est-ce qui pourrait être fait différemment la prochaine fois?

6. **Mesures préventives** : En fonction de l’analyse des causes profondes et de l’examen des mesures correctives, déterminer les mesures qui pourraient prévenir une anomalie similaire à l’avenir. Cela peut impliquer des modifications de votre configuration cloud, des améliorations de votre configuration de surveillance et d’alerte, ou une formation supplémentaire pour votre équipe.

7. **Leçons apprises** : Identifier les principales leçons tirées de l’incident. Il peut s’agir d’informations sur votre environnement cloud, vos opérations, vos procédures de détection et de réponse aux anomalies, ou les compétences et les connaissances de votre équipe.

8. **Mesures de suivi** : Enfin, créez une liste de mesures de suivi en fonction de votre examen après l’incident. Il peut s’agir de tâches visant à mettre en œuvre des mesures préventives, à mettre à jour votre documentation ou à fournir une formation supplémentaire à votre équipe. Attribuez chaque élément d’action à un membre de l’équipe et définissez une date limite pour l’achèvement.

En effectuant et en documentant un examen post-incident approfondi, vous pouvez transformer chaque anomalie en une opportunité d’apprentissage. Cela peut vous aider à améliorer vos procédures de détection et de réponse aux anomalies, à optimiser vos opérations cloud et à gérer vos coûts cloud plus efficacement.


## Rapports réguliers des anomalies

Le signalement régulier des anomalies est une pratique précieuse qui implique d’examiner et de documenter régulièrement les anomalies, leurs causes, leurs impacts et leurs résolutions. Cela vous aide à repérer les tendances, à identifier les domaines d’amélioration et à suivre l’efficacité de vos procédures de détection et de réponse aux anomalies. Voici comment vous pouvez documenter ce processus :

1. **Journal des anomalies** : Conservez un journal de toutes les anomalies qui se produisent. Cela devrait inclure quand chaque anomalie s’est produite, ce qui l’a causée, quel a été son impact, comment elle a été résolue et toutes les mesures préventives qui ont été mises en place.

2. **Fréquence des rapports** : Définissez la fréquence à laquelle vous produirez des rapports d’anomalie. Il peut s’agir d’une fois par semaine, par mois ou par trimestre, selon la taille de votre environnement cloud et la fréquence des anomalies.

3. **Contenu du rapport** : Décidez quels renseignements doivent être inclus dans chaque rapport. À tout le moins, cela devrait comprendre un résumé des anomalies survenues au cours de la période visée par le rapport, de leurs causes et de leurs répercussions, ainsi que des mesures prises en réponse.

4. **Analyse des tendances** : Analysez les données pour identifier les tendances. Certains types d’anomalies se produisent-ils plus fréquemment? Y a-t-il des moments ou des conditions particulières où les anomalies sont plus susceptibles de se produire?

5. **Mesures de performance** : Définissez et suivez les mesures de performance liées à la détection des anomalies et à la réponse. Cela peut inclure le temps de détection, le temps d’accusé de réception, le temps de résolution et l’impact financier des anomalies.

6. **Examen et discussion** : Planifiez une réunion régulière pour examiner et discuter du rapport d’anomalie. Cela peut impliquer votre équipe opérationnelle, les développeurs, la direction et d’autres parties prenantes. L’objectif devrait être de comprendre ce qui se passe, pourquoi cela se produit et ce qui peut être fait pour s’améliorer.

7. **Plan d’action** : En fonction de l’examen et de la discussion, élaborer un plan d’action pour la prochaine période de rapport. Cela peut impliquer des modifications de votre configuration cloud, des améliorations de votre configuration de surveillance et d’alerte, ou une formation supplémentaire pour votre équipe.

En effectuant régulièrement des rapports d’anomalie, vous pouvez rester proactif dans la gestion de votre environnement cloud. Cela peut vous aider à optimiser vos opérations cloud, à améliorer votre réponse aux anomalies et à contrôler plus efficacement vos coûts cloud.


## Amélioration continue

L’amélioration continue est un principe clé pour une gestion efficace des opérations cloud et des coûts. Cela implique de rechercher constamment des moyens d’optimiser votre environnement cloud, d’améliorer vos procédures et d’accroître l’efficacité de votre équipe. Voici comment vous pourriez documenter votre approche de l’amélioration continue :

1. **Examens réguliers** : planifiez des examens réguliers de votre environnement cloud, de vos procédures de détection et de réponse aux anomalies et des performances de votre équipe. Ces examens doivent être basés sur vos rapports d’anomalies et d’autres données et doivent viser à identifier les domaines à améliorer.

2. **Collecte de commentaires** : Sollicitez activement les commentaires de votre équipe et des autres parties prenantes. Ils peuvent avoir des informations précieuses sur ce qui fonctionne bien et ce qui pourrait être amélioré. Cela pourrait se faire au moyen de sondages, de réunions ou de boîtes à suggestions.

3. **Mesures de performance** : Définissez et suivez les mesures de performance qui reflètent l’efficience et l’efficacité de vos opérations. Il peut s’agir notamment du temps nécessaire pour détecter et résoudre les anomalies, du coût par ressource cloud, du temps de fonctionnement, etc. Utilisez ces mesures pour identifier les domaines d’amélioration et mesurer l’impact de vos améliorations.

4. **Formation et perfectionnement** : Investissez dans la formation et le perfectionnement continus de votre équipe. Cela peut impliquer des cours, des ateliers ou des conférences sur les opérations cloud, la gestion des coûts, la détection des anomalies et d’autres sujets pertinents. Il pourrait également s’agir d’une formation sur de nouveaux outils ou procédures.

5. **Amélioration des processus** : Examinez et affinez continuellement vos processus. Y a-t-il des étapes qui pourraient être éliminées ou automatisées? Existe-t-il de meilleurs moyens de détecter les anomalies ou d’y répondre? Pouvez-vous tirer parti de nouveaux outils ou de nouvelles technologies pour améliorer l’efficience ou l’efficacité?

6. **Innovation** : Encourager l’innovation et l’expérimentation. Parfois, les meilleures améliorations viennent de l’essai de nouvelles approches ou de la pensée en dehors de la boîte. Encouragez votre équipe à proposer et à tester de nouvelles idées et à créer une culture où il est sécuritaire d’échouer et d’apprendre.

7. **Documenter et partager les améliorations** : Chaque fois qu’une amélioration est mise en œuvre, documentez-la et partagez-la avec votre équipe et vos parties prenantes. Cela aide tout le monde à comprendre les changements et garantit qu’ils sont appliqués de manière cohérente.

L’amélioration continue n’est pas un effort ponctuel, mais un processus continu. En intégrant l’amélioration continue dans vos opérations, vous pouvez vous assurer que votre environnement cloud, vos procédures de détection et de réponse aux anomalies et votre équipe s’adaptent et s’améliorent constamment. Cela peut vous aider à optimiser vos opérations, à contrôler vos coûts et à garder une longueur d’avance en matière de gestion du cloud.

## Cas utilisation

Cas d’utilisation :
Je vais élaborer un cas d’utilisation détaillé concernant le traitement des anomalies dans l’environnement Oracle Cloud Infrastructure (OCI).

### **Cas d’utilisation : Détection et réponse aux anomalies dans les systèmes de base de données OCI**

#### **Contexte** :
**Nom de l’organisation** : *FinSecure Global*  (Nom fictif)
*FinSecure Global* est une société de technologie financière (fintech) de premier plan qui offre une variété de solutions bancaires numériques et de services financiers. Fondée en 2008, la société opère aujourd’hui dans plus de 20 pays, au service de millions de clients particuliers et professionnels.

**Vue d’ensemble du système** :
Le cœur de la pile technologique de *FinSecure Global* est son principal système de base de données, appelé en interne *CoreDB*. Ce système héberge une pléthore d’informations sensibles allant des profils d’utilisateurs, des historiques de transactions aux données de crédit. En raison de son importance et de la nature sensible des données, *CoreDB* est primordial pour les opérations et la réputation de l’entreprise.

**Transition vers le cloud** :
En 2020, en raison des demandes croissantes d’évolutivité et de la nécessité de mesures de sécurité plus robustes, *FinSecure Global* a pris la décision stratégique de migrer *CoreDB* vers Oracle Cloud Infrastructure (OCI). Cette décision a été motivée par la promesse d’OCI en matière de hautes performances, de fonctionnalités de sécurité améliorées et d’options d’évolutivité flexibles.

**Exigences opérationnelles** :
Après la migration, alors que *FinSecure Global* bénéficiait des avantages du OCI, il est devenu encore plus essentiel de surveiller et de maintenir l’intégrité du système en permanence. Compte tenu de l’importance de l’entreprise dans le domaine de la technologie financière, elle était une cible de choix pour les cyberattaques, les violations internes et les activités frauduleuses. En outre, le paysage réglementaire exigeait le strict respect de diverses normes de protection des données.

**Préoccupations récentes en matière de sécurité** :
Au cours des derniers mois, il y a eu une augmentation notable des cyberattaques ciblant les entreprises de technologie financière. Plusieurs concurrents ont été confrontés à des violations de données, entraînant des pertes financières et des atteintes à la réputation. À la lumière de ces événements, l’équipe de direction de *FinSecure Global* a souligné la nécessité de renforcer les mesures de sécurité et les mécanismes de réponse rapide pour détecter et contrer toute anomalie.

**Point de vue des intervenants** :
Les parties prenantes, qui comprennent les membres du conseil d’administration, les investisseurs et la haute direction, ont communiqué l’importance d’une surveillance proactive du système. Ils souhaitent s’assurer que *FinSecure Global* reste un nom de confiance dans l’industrie et que les données des clients sont protégées à tout prix. Par conséquent, il existe un consensus sur l’investissement dans des systèmes de détection et de réponse aux anomalies de pointe.

#### **Objectif**:
Mettre en œuvre un système de détection des anomalies au sein d’OCI pour surveiller le système de base de données pour détecter toute irrégularité, potentiellement causée par des attaques externes, des violations internes ou des dysfonctionnements du système, puis réagir en temps réel pour atténuer les risques.

**Objectif principal** : *Détection robuste des anomalies et réponse rapide*
Pour *FinSecure Global*, la protection de l’intégrité, de la disponibilité et de la confidentialité des données hébergées dans *CoreDB* sur OCI n’est pas seulement une exigence technique, c’est un impératif commercial. Compte tenu de la position de l’entreprise dans l’industrie fintech et de la nature sensible de ses données, un système de détection d’anomalies en temps réel associé à un mécanisme de réponse rapide est essentiel.

**Objectifs détaillés** :

1. **Précision dans la détection**:
   - **Description**: Mettre en œuvre un système qui identifie avec précision les anomalies, en minimisant les faux positifs qui peuvent gaspiller des ressources et les faux négatifs qui peuvent permettre aux véritables menaces de passer inaperçues.
   - **Justification** : Un système de détection efficace réduit le risque de négliger les menaces réelles et garantit une utilisation efficace des ressources de l’entreprise.

2. **Surveillance en temps réel** :
   - **Description**: Surveillez *CoreDB* et les systèmes associés 24 heures sur 24, 7 jours sur 7, en veillant à ce que les anomalies soient détectées en temps réel ou aussi près que possible de leur apparition.
   - **Justification** : La détection immédiate permet une réponse plus rapide, ce qui peut empêcher les violations ou les problèmes avant qu’ils ne causent des dommages importants.

3. **Réponse initiale automatisée**:
   - **Description** : Développer des systèmes automatisés capables de déclencher des mesures de protection préliminaires immédiatement après la détection d’anomalies, telles que le blocage temporaire d’adresses IP ou de transactions suspectes.
   - **Justification** : Les premières minutes après la détection d’une anomalie sont cruciales. Une réponse initiale automatisée peut faire gagner du temps à l’équipe d’intervention humaine.

4. **Conservation des données** :
   - **Description** : S’assurer qu’en cas d’anomalie, les registres de données et les preuves essentiels sont conservés pour l’analyse judiciaire et les rapports de conformité.
   - **Justification** : La préservation des données relatives à l’événement aide à comprendre la cause et peut être critique pour des raisons réglementaires et juridiques.

5. **Communication avec les intervenants** :
   - **Description** : Établir des protocoles pour tenir les intervenants internes et externes informés de l’état de toute anomalie importante, des mesures d’intervention prises et des répercussions potentielles.
   - **Justification** : Une communication claire permet de s’assurer que toutes les parties sont au courant de la situation et peuvent prendre les mesures appropriées, au besoin.

6. **Conformité réglementaire** :
   - **Description** : S’assurer que le système de détection et de réponse aux anomalies est conforme aux réglementations locales et internationales en matière de protection des données et du secteur financier.
   - **Justification** : La conformité n’est pas seulement une exigence légale, mais aussi essentielle pour maintenir la confiance des clients et des parties prenantes.

7. **Amélioration continue** :
   - **Description** : Le système devrait intégrer des boucles de rétroaction, permettant une amélioration continue. Les leçons tirées des incidents passés devraient être intégrées afin de peaufiner les algorithmes de détection et les protocoles d’intervention.
   - **Justification** : Les paysages et les technologies des menaces évoluent. Le système doit s’adapter et s’améliorer pour rester efficace.


#### **Acteurs**:
- Administrateurs du OCI
- Administrateurs de bases de données
- Équipe d’intervention de sécurité

#### **Conditions préalables**:
- Le système de base de données de l’organisation est hébergé au sein du OCI.
- Les outils de surveillance et de journalisation nécessaires sont activés sur la base de données.

#### **Étapes**:

1. **Détection d’anomalies de configuration** :
   - Utiliser les outils de surveillance natifs d’OCI, intégrer des solutions tierces si nécessaire.
   - Définissez ce qui constitue une « anomalie » – par exemple, plusieurs tentatives de connexion infructueuses, des transferts de données volumineux inattendus ou des modèles d’accès irréguliers.
   - Mettre en place des mécanismes d’alerte pour avertir les équipes concernées lorsqu’une anomalie est détectée.

2. **Surveillance continue** :
   - Les administrateurs du OCI et les administrateurs de bases de données examinent régulièrement les tableaux de bord de surveillance.
   - Les outils automatisés recherchent des signatures d’anomalies prédéfinies.

3. **Détection d’anomalie**:
- À 2h30 du matin, le système détecte plusieurs  tentatives de connexion à partir d’une adresse IP inconnue, déclenchant les critères d’anomalie pour un accès non autorisé potentiel.

4. **Réponse d’alerte** :
   - Des alertes automatiques immédiates sont envoyées aux administrateurs OCI, aux administrateurs de base de données et à l’équipe d’intervention de sécurité.
   - L’alerte contient les détails de l’anomalie : horodatage, nature de l’anomalie, impact potentiel et actions immédiates recommandées.

5. **Réponse initiale** :
   - Les administrateurs de base de données arrêtent immédiatement l’accès à partir de l’adresse IP suspecte.
   - Les administrateurs de l’OCI recoupent d’autres systèmes pour voir si l’anomalie est isolée ou fait partie d’un problème plus large.

6. **Enquête** :
   - L’équipe d’intervention de sécurité entame une enquête plus approfondie : y a-t-il des violations de données ? Des données ont-elles été modifiées ou supprimées ?
   - Les journaux sont examinés à la recherche de toute activité suspecte connexe.

7. **Résolution et rapports** :
   - L’équipe d’intervention de sécurité identifie que les tentatives faisaient partie d’une attaque coordonnée sur plusieurs bases de données. Ils veillent à ce que toutes les atteintes soient fermées.
   - Un rapport détaillé de l’incident, y compris l’anomalie, la réponse, les conclusions de l’enquête et toute mesure corrective, est préparé.

8. **Examen post-incident** :
   - Une fois la menace immédiate atténuée, une réunion est convoquée avec toutes les parties prenantes.
   - L’incident est analysé : Qu’est-ce qui s’est bien passé ? Qu’est-ce qui peut être amélioré? Y avait-il des lacunes dans le mécanisme actuel de détection des anomalies et d’intervention?

9. **Amélioration continue** :
   - Sur la base de l’examen post-incident, des modifications sont apportées au système de détection des anomalies afin de prévenir des incidents similaires à l’avenir.
   - De nouvelles sessions de formation pourraient être organisées pour que l’équipe réponde mieux à de telles anomalies.

#### **Conditions postérieures** :
- L’anomalie a été corrigée et le système est revenu à ses activités normales.
- Les leçons tirées de l’incident sont documentées et des mesures préventives sont mises en place.

#### **Exceptions** :
- Si l’anomalie indique un dysfonctionnement du système plutôt qu’une violation de la sécurité, la procédure impliquerait l’équipe d’ingénierie système pour identifier et corriger le dysfonctionnement.

Ce cas d’utilisation fournit un flux détaillé de la façon dont les anomalies peuvent être détectées et gérées dans un environnement OCI, garantissant que les systèmes restent sécurisés et fonctionnels. Les principes peuvent être adaptés à divers scénarios ou environnements particuliers au sein du OCI.



[Début de la page](#table-des-matières)
