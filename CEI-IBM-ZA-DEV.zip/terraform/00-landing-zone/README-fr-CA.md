# Zone d'atterrissage sécurisée (00-landing-zone)

Ce modèle repose sur IBM Cloud Framework for Financial Services [architecture de référence pour le nuage privé virtuel avec des serveurs virtuels](https://cloud.ibm.com/docs/framework-financial-services?topic=framework-financial-services-vpc-architecture-detailed-vsi).

Le script Terraform est dérivé des scripts dans la chaîne d'outils *Déployer l'infrastructure en tant que code pour IBM Cloud for Financial Services* que vous pouvez trouver [ici](https://cloud.ibm.com/devops/setup/deploy?repository=https%3A%2F%2Fca-tor.git.cloud.ibm.com%2Fopen-toolchain%2Flanding-zone&env_id=ibm:yp:ca-tor) ou en naviguant dans votre compte IBM Cloud vers `DevOps->Toolchains->Create a Toolchain` et en cherchant le mot clé *Financial*.  Il est personnalisé à l'intention du gouvernement du Québec.

## Table des matières

1. [Aperçu](#aperçu)
2. [Prérequis](#prérequis)
    - [Générer une clé Secure Shell sous Windows / Mac / Linux](#générer-une-clé-secure-shell-sous-windows--mac--linux)
2. [Exécuter les scripts](#exécuter-les-scripts)
3. [Variables fournies dans terraform.tfvars](#variables-fournies-dans-terraformtfvars)
4. [Configuration avec override.json](#configuration-avec-overridejson)
    - [Groupes de ressources](#groupes-de-ressources)
    - [Services infonuagiques IBM](#services-infonuagiques-ibm)
      - [Gestion des clés](#gestion-des-clés)
      - [Cloud Object Storage](#cloud-object-storage)
    - [Infrastructure de nuage privé virtuel](#infrastructure-de-nuage-privé-virtuel)
      - [Listes de contrôle d'accès au réseau](#listes-de-contrôle-daccès-au-réseau)
      - [Sous-réseaux](#sous-réseaux)
      - [Groupe de sécurité de nuage privé virtuel par défaut](#groupe-de-sécurité-de-nuage-privé-virtuel-par-défaut)
    - [Journaux de flux](#journaux-de-flux)
    - [Points d'extrémité privés virtuels](#points-dextrémité-privés-virtuels)
    - [Déploiements de serveurs virtuels](#déploiements-de-serveurs-virtuels)
      - [Chiffrement de volume de démarrage](#chiffrement-de-volume-de-démarrage)
      - [Image de serveur virtuel](#image-de-serveur-virtuel)
      - [Profil de serveur virtuel](#profil-de-serveur-virtuel)
      - [Composants supplémentaires](#composants-supplémentaires)

---
## Aperçu

On peut utiliser `00-landing-zone` pour créer un environnement de nuage privé virtuel entièrement personnalisable. Les variables par défaut sont configurées pour le gouvernement du Québec, mais elles peuvent être configurées de manière plus poussée en fonction des exigences relatives aux charges de travail.  Ce document décrit les variables par défaut et indique comment les remplacer.

Ce modèle crée :

- Un groupe de ressources pour les services infonuagiques et pour chaque nuage privé virtuel.
- Les instances Object Storage pour [Journaux de flux de réseau](https://cloud.ibm.com/docs/vpc?topic=vpc-flow-logs).
- Une instance Key Protect avec des porte-clés et des clés de chiffrement servant à chiffrer les journaux de flux stockés dans des compartiments Object Storage et d'une procédure de démarrage d'instance de serveurs virtuels et des volumes de données.
- Nuages privés virtuels de gestion et des charges de travail connectés par une [passerelle de transit] (https://cloud.ibm.com/docs/transit-gateway?topic=transit-gateway-about).  Il existe des nuages privés virtuels de charges de travail pour différents environnements : développement, bac à sable et production.  Veuillez noter que le nuage privé virtuel de gestion n'a qu'un seul serveur virtuel dans la zone 1.  Il doit généralement être utilisé comme un serveur Bastion ou un serveur Jump pour les activités d'exploitation.
- Un collecteur de [journaux de flux](https://cloud.ibm.com/docs/vpc?topic=vpc-flow-logs) pour chaque nuage privé virtuel.
- Toutes les règles de réseautique nécessaires pour permettre la communication.
- Des passerelles de points d'extrémité privés virtuels (https://cloud.ibm.com/docs/vpc?topic=vpc-about-vpe) pour Cloud Object Storage dans chaque nuage privé virtuel.
- Une passerelle de nuage privé virtuel dans le nuage privé virtuel de gestion.
- Des instances de serveurs virtuels dans les nuages privés virtuels des charges de travail.


 ![Instance de serveurs virtuels](../../docs/images/vsi-fr-CA.png) 

## Prérequis

Prérequis pour tous les scripts Terraform dans cet ensemble. Veuillez consulter [ce fichier README](../README.md).

De plus, vous avez besoin d'une paire de clés publique/privée Secure Shell pour accéder à vos instances de serveurs virtuels IBM Cloud.

### Générer une clé Secure Shell sous Windows / Mac / Linux

1. Sous Windows, ouvrez une invite de commande.  Pour Mac et Linux, ouvrez un terminal.
1. Tapez la commande :
   ``` 
   ssh-keygen -b 4096 -t rsa
   ```
1. Entrez le nom du fichier dans lequel vous souhaitez sauvegarder les clés.
1. Lorsque vous êtes invité à entrer la phrase de passe, appuyez simplement sur la touche 'Entrée'.
1. Vous devriez maintenant avoir un fichier contenant les clés publique et privée à l'emplacement que vous avez entré avec le nom de fichier à l'étape 3 ci-dessus.  La clé publique aura l'extension `.pub`.  Vous aurez besoin du contenu de ce fichier pour la configuration de la zone d'atterrissage sécurisée.
1. Pour copier la clé publique dans le presse-papier à des fins de référence ultérieure, tapez la commande :
   ```
   pbcopy < <name of SSH key>.pub
   ```

   Une fois la fourniture effectuée, pour installer une clé Secure Shell dans une instance de serveurs virtuels, vous pouvez utiliser la commande suivante :
   ```
   ssh root@<ip of instance> -i <private key filename>
   ```

## Exécuter les scripts

Pour exécuter les scripts localement, veuillez suivre ces étapes :

1. Naviguez vers le répertoire [instance de serveurs virtuels](patterns/vsi).
1. Fournissez votre [fichier terraform.tfvars](patterns/vsi/terraform.tfvars) avec les variables requises telles que le préfixe, la région, etc. Veuillez vous référer au reste de ce document pour connaître les détails au sujet de la méthode de configuration.
1. Consultez [override.json](patterns/vsi/override.json) afin de vous assurer qu'il est configuré comme vous le souhaitez.
1. Fournissez votre clé d'interface API IBM Cloud au moyen d'une variable d'environnement (ex: export TF_VAR_ibmcloud_api_key="`<YOUR IBM Cloud API Key>)`"
1. Exécutez `terraform init` pour initialiser la configuration et le répertoire de travail.
1. Exécutez `terraform plan` pour prévisualiser les modifications que Terraform prévoit d'apporter à votre infrastructure.
1. Exécutez `terraform apply` pour exécuter le plan de création ou de modification de votre infrastructure.
1. Lorsque vous n'avez plus besoin de l'infrastructure, vous pouvez exécuter `terraform destroy` afin de supprimer les ressources.


## Variables fournies dans terraform.tfvars

Nom                                | Type         | Description                                                                                                                                                                                                                                                                                                                                                     | Sensible  | Par défaut
----------------------------------- | ------------ | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | --------- | --------------------------------------------------------
ibmcloud_api_key                    | chaîne       | La clé d'interface API de la plateforme IBM Cloud nécessaire pour déployer des ressources pour la gestion des identités et des accès. | vrai | 
TF_VERSION                          | chaîne       | La version du moteur Terraform utilisée dans l'espace de travail workspace. |           | 1.3 ou 1.4
prefix                              | chaîne       | Un identificateur unique pour les ressources. Il doit commencer par une lettre en minuscule et se terminer par une lettre en minuscule ou par un chiffre. Ce préfixe sera ajouté au début de toutes les ressources fournies par ce modèle. Les préfixes doivent avoir 16 caractères ou moins.  |           | 
ssh_public_key                      | chaîne       | Une [clé publique Secure Shell](https://cloud.ibm.com/docs/vpc?topic=vpc-ssh-keys) | | 
region                              | chaîne       | Région dans laquelle le nuage privé virtuel sera créé. Pour trouver votre région dans laquelle le nuage privé virtuel sera créé, utilisez la commande `ibmcloud is regions` afin de trouver les régions disponibles. | |       
override                            | booléen          | Remplacez les variables par défaut par un modèle JSON personnalisé. Le fichier `override.json` est utilisé afin de permettre aux utilisateurs de créer un environnement entièrement personnalisé. |           | vrai

---

## Configuration avec override.json

Le reste de la personnalisation du modèle est géré dans [override.json](../00-landing-zone/patterns/vsi/override.json).  On peut trouver l'ensemble complet des attributs disponibles pour chaque type de ressource en examinant les [variables.tf dans 00-landing-zone/landing-zone](../00-landing-zone/landing-zone/variables.tf).

Des exemples suivront dans chaque section.


Des exemples suivront dans chaque section.

---

### Groupes de ressources

Les groupes de ressources sont définis dans [override.json](../00-landing-zone/patterns/vsi/override.json#L70).  Il s'agit de l'ensemble des groupes de ressources définis par défaut pour la zone d'atterrissage au Québec.

Nom            | Description
----------------|------------------------------------------------
`<prefix>-slz-management-rg`     | Composants d'infrastructure virtuelle de gestion
`<prefix>-slz-workload-rg`       | Composants d'infrastructure virtuelle de l'environnement de production des charges de travail
`<prefix>-slz-workload-dev-rg`   | Composants de serveurs virtuels de l'environnement de développement des charges de travail
`<prefix>-slz-workload-sable-rg` | Composants de serveurs virtuels de l'environnement de bac à sable des charges de travail
`<prefix>-slz-service-rg`        | Instances de services infonuagiques

Chacun de ces groupes de ressources aura la variable `prefix` et un trait d'union devant le nom (ex. : `demo-slz-management-rg` si le préfixe est `demo`).

Si vous naviguez vers [override.json](../00-landing-zone/patterns/vsi/override.json#L70), vous verrez comment cela est défini :

```
    "resource_groups": [
        {
            "create": false,
            "name": "slz-service-rg",
            "use_prefix": true
        },
        {
            "create": true,
            "name": "slz-management-rg",
            "use_prefix": true
        },
        {
            "create": true,
            "name": "slz-workload-rg",
            "use_prefix": true            
        },
        {
            "create": true,
            "name": "slz-workload-sable-rg",
            "use_prefix": true            
        },
        {
            "create": true,
            "name": "slz-workload-dev-rg",
            "use_prefix": true
        }       
    ],
```

Notez les attributs pour chaque groupe de ressources.  Vous pouvez trouver les attributs pris en charge dans [variables.tf ](../00-landing-zone/landing-zone/variables.tf#L33).

```
variable "resource_groups" {
  description = "Object describing resource groups to create or reference"
  type = list(
    object({
      name       = string
      create     = optional(bool)
      use_prefix = optional(bool)
    })
  )

  validation {
    error_message = "Each group must have a unique name."
    condition     = length(distinct(var.resource_groups.*.name)) == length(var.resource_groups.*.name)
  }
}
```

Le paramètre create indique s'il faut créer le groupe de ressources ou s'il s'agit simplement de fournir une référence.  Dans le cas de `slz-service-rg`, ce groupe de ressources est créé dans [main.tf](../00-landing-zone/patterns/vsi/main.tf) et le paramètre `create` est faux.  Le paramètre `use_prefix` indique s'il faut ajouter le préfixe au nom du groupe de ressources.

---

### Services infonuagiques IBM

Ce graphique montre les services infonuagiques dans la solution :

* [Gestion des clés](https://cloud.ibm.com/docs/key-protect?topic=key-protect-about)
* [Cloud Object Storage](https://cloud.ibm.com/docs/cloud-object-storage?topic=cloud-object-storage-about-cloud-object-storage).


![services](../../docs/images/resources-fr-CA.png)

#### Gestion des clés

Par défaut, une instance Key Protect est créée à moins que la variable `hs_crypto_instance_name` ne soit fournie. Les instances Key Protect par défaut seront fournies dans le groupe de ressources `<prefix>-service-rg`.

Les paramètres de gestion des clés disponibles se trouvent dans [variables.tf](../00-landing-zone/landing-zone/kms/variables.tf).

Dans [override.json](../00-landing-zone/patterns/vsi/override.json#L43), cherchez la configuration `key_management`.  Veuillez noter qu'il n'y a pas de paramètre `use_prefix`. Donc, dans ce cas, le préfixe doit être codé en dur si vous le voulez dans les configurations key_management et key_ring et les noms des ressources clés.


---

##### Clés de chiffrement et porte-clés

Nom de clé | Nom de porte-clés                   | Description
--------------------------|--------------------------|-------------------------------------------
`<prefix>-slz-flowlogs-prod-key`    | `<prefix>-slz-prod-ring`    | Clé de chiffrement de zone d'atterrissage pour les journaux de flux dans l'environnement de production |
`<prefix>-slz-flowlogs-nonprod-key` | `<prefix>-slz-nonprod-ring` | Clé de chiffrement de zone d'atterrissage pour les journaux de flux dans un environnement qui n'est pas l'environnement de production |
`<prefix>-vsi-prod-volume-key`      | `<prefix>-slz-prod-ring`    | Clé de chiffrement de zone d'atterrissage pour les volumes d'instances de serveurs virtuels dans l'environnement de production | 
`<prefix>-slz-nonprod-volume-key`   | `<prefix>-slz-nonprod-ring` | Clé de chiffrement de zone d'atterrissage pour les volumes d'instances de serveurs virtuels dans un environnement qui n'est pas l'environnement de production |


---

#### Cloud Object Storage

Une instance Cloud Object Storage est créée dans le groupe de ressources `<prefix>-service-rg`.  Ceci est utilisé pour les compartiments qui contiennent les journaux de flux de réseau provenant de chaque nuage privé virtuel.

Dans [override.json](../00-landing-zone/patterns/vsi/override.json#L2), cherchez la configuration `cos`. Veuillez noter qu'il n'y a pas de paramètre `use_prefix`. Mais le préfixe est toujours ajouté au début des noms des compartiments et de l'instance de stockage Cloud Object Storage.  De plus, il existe un paramètre `random_suffix` dans l'instance `cos` qui lui fait générer un suffixe aléatoire ajouté à la fin des noms des compartiments et de l'instance de stockage Cloud Object Storage.  Ceci est utile car les noms des compartiments Cloud Objet Storage doivent être globalement uniques et le nettoyage peut parfois prendre un certain temps.

Cherchez `cos` dans [variables.tf](../00-landing-zone/landing-zone/variables.tf#487) afin de trouver d'autres attributs facultatifs.  Il y en a plusieurs qui pourraient être utiles selon vos besoins, notamment l'option d'archivage.

 

Nom            | Description
----------------|------------------------------------------------
`<prefix>-cos-<random-suffix>`           | Object storage

---

##### Compartiments Object Storage

Ces compartiments sont destinés aux journaux de flux de réseau provenant de chaque nuage privé virtuel.  **REMARQUE** Vous pourriez vouloir établir une politique d'expiration pour les compartiments car ils collectent rapidement de nombreuses données.  Autrement, vous pouvez établir une politique d'archivage afin de déplacer les données vers le niveau «stockage à froid».


Nom                                             | Instance                       | Clé de chiffrement                     | Description
-------------------------------------------------|--------------------------------|------------------------------------|---------------------------------------------
`<prefix>-management-bucket-<random-suffix>`     | `<prefix>-cos-<random-suffix>` | `<prefix>-slz-flowlogs-prod-key`   | Compartiment pour les journaux de flux provenant d'un nuage privé virtuel de gestion.
`<prefix>-workload-bucket-<random-suffix>`       | `<prefix>-cos-<random-suffix>` | `<prefix>-slz-flowlogs-prod-key`   | Compartiment pour les journaux de flux provenant d'un nuage privé virtuel des charges de travail.
`<prefix>-workload-dev-bucket-<random-suffix>`   | `<prefix>-cos-<random-suffix>` | `<prefix>-slz-flowlogs-nonprod-key` | Compartiment pour les journaux de flux provenant du nuage privé virtuel dans l'environnement de développement des charges de travail.
`<prefix>-workload-sable-bucket-<random-suffix>` | `<prefix>-cos-<random-suffix>` | `<prefix>-slz-flowlogs-nonprod-key` | Compartiment pour les journaux de flux provenant du nuage privé virtuel dans l'environnement de bac à sable des charges de travail.

---


### Infrastructure de nuage privé virtuel

Par défaut, quatre nuages privés virtuels sont créés `<prefix>-management-vpc`, `<prefix>-workload-vpc`, `<prefix>-workload-dev-vpc` et `<prefix>-workload-sable-vpc`. Tous les composants de chaque nuage privé virtuel sont dans un groupe de ressources dédié.


![network](../../docs/images/network-fr-CA.png)


Les passerelles publiques autorisent la sortie et sont associées à un sous-réseau.  Par défaut, aucune passerelle publique n'est fournie, mais on peut en ajouter une en mettant à jour le paramètre `use_public_gateways` pour des zones spécifiques dans la configuration `vpc`, puis en ajoutant `public_gateway: true` pour les sous-réseaux dans une zone dans laquelle vous avez besoin de la passerelle.

Pour voir tous les paramètres disponibles pour la configuration de nuage privé virtuel, voyez [variables.tf](./landing-zone/variables.tf#L159).

Pour ajouter, supprimer, renommer ou modifier des nuages privés virtuels dans la solution, mettez à jour la configuration `vpc` dans [override.json](../00-landing-zone/patterns/vsi/override.json#L2).

Cette entrée provenant de `override.json` est destinée au nuage privé virtuel de gestion.  Si vous n'avez pas besoin de ce nuage privé virtuel, vous pouvez simplement supprimer ce bloc.  Vous pouvez voir qu'il inclut la configuration pour :

* Les règles en matière de groupes de sécurité par défaut
* Le nom des compartiments des journaux de flux pour le nuage privé virtuel.  Ce nom fait l'objet d'une référence croisée dans la configuration `cos`.
* Règles en matière de listes de contrôle d'accès au réseau pour une liste de contrôle d'accès appelée `management-acl`.
* Noms pour le nuage privé virtuel et le tableau des routes par défaut, le groupe de sécurité et la liste de contrôle d'accès au réseau
* Configurations de sous-réseaux
* Passerelles publiques


```
"vpcs": [
        {
            "default_security_group_rules": [
  
            ],
            "flow_logs_bucket_name": "management-bucket",
            "network_acls": [
                {
                    "name": "management-acl",
                    "rules": [
                        {
                            "action": "allow",
                            "destination": "10.0.0.0/8",
                            "direction": "inbound",
                            "name": "allow-ibm-inbound",
                            "source": "161.26.0.0/16"
                        },
                        {
                            "action": "allow",
                            "destination": "10.0.0.0/8",
                            "direction": "inbound",
                            "name": "allow-all-network-inbound",
                            "source": "10.0.0.0/8"
                        },
                        {
                            "action": "allow",
                            "destination": "0.0.0.0/0",
                            "direction": "outbound",
                            "name": "allow-all-outbound",
                            "source": "0.0.0.0/0"
                        }
                    ]
                }
            ],
            "prefix": "management",
            "default_network_acl_name":"demo-management-default-acl",
            "default_security_group_name":"demo-management-default-sg",
            "default_routing_table_name":"demo-management-default-rt",             
            "resource_group": "demo-slz-management-rg",
            "subnets": {
                "zone-1": [
                    {
                        "acl_name": "management-acl",
                        "cidr": "10.10.10.0/24",
                        "name": "vsi-zone-1",
                        "public_gateway": false
                    },
                    {
                        "acl_name": "management-acl",
                        "cidr": "10.10.20.0/24",
                        "name": "vpe-zone-1",
                        "public_gateway": false
                    },
                    {
                        "acl_name": "management-acl",
                        "cidr": "10.10.30.0/24",
                        "name": "vpn-zone-1",
                        "public_gateway": false
                    }
                ],
                "zone-2": [
                    {
                        "acl_name": "management-acl",
                        "cidr": "10.15.10.0/24",
                        "name": "vsi-zone-2",
                        "public_gateway": false
                    },
                    {
                        "acl_name": "management-acl",
                        "cidr": "10.15.20.0/24",
                        "name": "vpe-zone-2",
                        "public_gateway": false
                    }
                ],
                "zone-3": [
                    {
                        "acl_name": "management-acl",
                        "cidr": "10.20.10.0/24",
                        "name": "vsi-zone-3",
                        "public_gateway": false
                    },
                    {
                        "acl_name": "management-acl",
                        "cidr": "10.20.20.0/24",
                        "name": "vpe-zone-3",
                        "public_gateway": false
                    }
                ]
            },
            "use_public_gateways": {
                "zone-1": false,
                "zone-2": false,
                "zone-3": false
            }
        },
```
---

#### Listes de contrôle d'accès au réseau

Une [liste de contrôle d'accès au réseau](https://cloud.ibm.com/docs/vpc?topic=vpc-using-acls) est créée pour chaque nuage privé virtuel afin d'autoriser les communications entrantes dans le réseau et les communications entrantes en provenance des services IBM et tout le trafic sortant.


Règle                                            | Action | Direction | Source        | Destination 
----------------------------|--------|-----------|---------------|----------------
`allow-ibm-inbound`         | Autoriser   | Entrant      | 161.26.0.0/16 | 10.0.0.0/8
`allow-all-network-inbound` | Autoriser   | Entrant      | 10.0.0.0/8    | 10.0.0.0/8
`allow-all-outbound`        | Autoriser   | Sortant    | 0.0.0.0/0     | 0.0.0.0/0

**IMPORTANT : ** Étant donné que les nuages privés virtuels des charges de travail dans un environnement qui n'est pas l'environnement de production sont connectés au moyen de la passerelle de transit au nuage privé virtuel des charges de travail dans l'environnement de production, la liste de contrôle d'accès aux nuages privés virtuels des charges de travail comporte en outre ces règles de refus afin que le trafic en provenance d'autres environnements que l'environnement de production ne puisse pas entrer dans le nuage privé virtuel dans l'environnement de production.

Règle                        | Action | Direction | Source        | Destination 
----------------------------|--------|-----------|---------------|----------------
`deny-sable-inbound-1`      | Refus   | Entrant     | 10.40.0.0/16   | 10.0.0.0/8
`deny-sable-inbound-2`      | Refus   | Entrant    | 10.45.0.0/16   | 10.0.0.0/8
`deny-sable-inbound-3`      | Refus   | Entrant    | 10.50.0.0/16   | 10.0.0.0/8
`deny-dev-inbound-1`        | Refus   | Entrant    | 10.55.0.0/16   | 10.0.0.0/8
`deny-dev-inbound-2`        | Refus   | Entrant    | 10.60.0.0/16   | 10.0.0.0/8
`deny-dev-inbound-3`        | Refus   | Entrant    | 10.65.0.0/16   | 10.0.0.0/8


---

#### Sous-réseaux

Chaque nuage privé virtuel crée deux niveaux de sous-réseaux, chacun étant attaché à la liste de contrôle d'accès au réseau créée pour ce nuage privé virtuel. Le réseau privé virtuel de gestion possède également un sous-réseau créé en vue de la création de la passerelle de nuage privé virtuel.

##### Sous-réseaux de nuage privé virtuel de gestion

Niveau de sous-réseau | Nom de sous-réseau dans la zone 1 | Routage inter-domaine sans classe dans la zone 1  | Nom de sous-réseau dans la zone 2 | Routage inter-domaine sans classe dans la zone 2   | Nom de sous-réseau dans la zone 2 | Routage inter-domaine sans classe dans la zone 3  |
------------|--------------------|---------------|--------------------|---------------|--------------------|---------------|
`vsi`       | `vsi-zone-1`       | 10.10.10.0/24 | `vsi-zone-2`       | 10.15.10.0/24 | `vsi-zone-3`       | 10.20.10.0/24 |
`vpe`       | `vpe-zone-1`       | 10.10.20.0/24 | `vpe-zone-2`       | 10.15.20.0/24 | `vsi-zone-3`       | 10.20.20.0/24 |
`vpn`       | `vpn-zone-1`       | 10.10.30.0/24 |


##### Sous-réseaux de nuage privé virtuel des charges de travail

Niveau de sous-réseau | Nom de sous-réseau dans la zone 1 | Routage inter-domaine sans classe dans la zone 1  | Nom de sous-réseau dans la zone 2 | Routage inter-domaine sans classe dans la zone 2   | Nom de sous-réseau dans la zone 2 | Routage inter-domaine sans classe dans la zone 3  |
------------|--------------------|---------------|--------------------|---------------|--------------------|---------------|
`vsi`       | `vsi-zone-1`       | 10.25.10.0/24 | `vsi-zone-2`       | 10.30.10.0/24 | `vsi-zone-3`       | 10.35.10.0/24 |
`vpe`       | `vpe-zone-1`       | 10.25.20.0/24 | `vpe-zone-2`       | 10.30.20.0/24 | `vsi-zone-3`       | 10.35.20.0/24 |

##### Sous-réseaux de nuage privé virtuel de développement des charges de travail

Niveau de sous-réseau | Nom de sous-réseau dans la zone 1 | Routage inter-domaine sans classe dans la zone 1  | Nom de sous-réseau dans la zone 2 | Routage inter-domaine sans classe dans la zone 2   | Nom de sous-réseau dans la zone 2 | Routage inter-domaine sans classe dans la zone 3  |
------------|--------------------|---------------|--------------------|---------------|--------------------|---------------|
`vsi`       | `vsi-zone-1`       | 10.55.10.0/24 | `vsi-zone-2`       | 10.60.10.0/24 | `vsi-zone-3`       | 10.65.10.0/24 |
`vpe`       | `vpe-zone-1`       | 10.55.20.0/24 | `vpe-zone-2`       | 10.60.20.0/24 | `vsi-zone-3`       | 10.65.20.0/24 |

##### Sous-réseaux de nuage privé virtuel dans l'environnement de bac à sable des charges de travail

Niveau de sous-réseau | Nom de sous-réseau dans la zone 1 | Routage inter-domaine sans classe dans la zone 1  | Nom de sous-réseau dans la zone 2 | Routage inter-domaine sans classe dans la zone 2   | Nom de sous-réseau dans la zone 2 | Routage inter-domaine sans classe dans la zone 3  |
------------|--------------------|---------------|--------------------|---------------|--------------------|---------------|
`vsi`       | `vsi-zone-1`       | 10.40.10.0/24 | `vsi-zone-2`       | 10.45.10.0/24 | `vsi-zone-3`       | 10.50.10.0/24 |
`vpe`       | `vpe-zone-1`       | 10.40.20.0/24 | `vpe-zone-2`       | 10.45.20.0/24 | `vsi-zone-3`       | 10.50.20.0/24 |

---

#### Groupe de sécurité de nuage privé virtuel par défaut

Le nuage privé virtuel par défaut [groupe de sécurité](https://cloud.ibm.com/docs/security-groups?topic=security-groups-about-ibm-security-groups) ) autorise tout le trafic sortant et entrant à l'intérieur du groupe de sécurité.

Les règles en matière de groupes de sécurité par défaut sont définies dans l'attribut `default_security_group_rules` de la configuration `vpcs` dans `override.json`.

Des groupes de sécurité peuvent également être définis pour les interfaces dans une instance de serveurs virtuels spécifique et ils seront utilisés à la place des groupes par défaut.


### Journaux de flux

À l'aide du compartiment Cloud Object Storage fourni pour chaque réseau de nuage privé virtuel, un [collecteur des journaux de flux](https://cloud.ibm.com/docs/vpc?topic=vpc-flow-logs) est créé.

![journaux de flux](../../docs/images/flowlogs-fr-CA.png)

----

### Points d'extrémité privés virtuels

Chaque réseau privé virtuel possède de manière dynamique une adresse [point d'extrémité privé virtuel](https://cloud.ibm.com/docs/vpc?topic=vpc-about-vpe) pour l'instance `cos` créée dans chaque zone du point d'extrémité virtuel du niveau de sous-réseau de ce nuage privé virtuel.

![point d'extrémité privé virtuel](../../docs/images/vpe-fr-CA.png)

---

### Virtual Sever Deployments


### Déploiements de serveurs virtuels

Des déploiements de serveurs virtuels identiques sont créés dans chaque zone du niveau d'instance de serveurs virtuels de chaque nuage privé virtuel. Le nombre de ces serveurs virtuels peut être modifié à l'aide du paramètre `vsi_per_subnet` de la configuration `vsi` dans `override.json`.  L'ensemble complet des variables pour les serveurs virtuels qu'on peut spécifier dans `override.json` peut être trouvé dans [ici dans variables.tf](./landing-zone/variables.tf#L258).

Par défaut, il y a un seul serveur dans le sous-réseau d'instance de serveurs virtuels dans chaque zone pour les nuages privés virtuels des charges de travail.  Le nuage privé virtuel de gestion n'a qu'un seul serveur virtuel dans la zone 1.


#### Boot Volume Encryption

#### Chiffrement du volume de démarrage

Les volumes de démarrage pour chaque serveur virtuel sont chiffrés à l'aide de `<demo>-vsi-prod-volume-key` pour les serveurs virtuels dans le nuage privé virtuel des charges de travail et de `<demo>-vsi-nonprod-volume-key` pour les serveurs virtuels dans les nuages privés virtuels dans les environnements de développement des charges de travail et de bac à sable des charges de travail.  Cela vous permet de gérer séparément le cycle de vie des clés dans l'environnement de production et les autres environnements et d'autoriser séparément l'accès à ces clés.  La clé est spécifiée dans le paramètre `boot_volume_encryption_key_name` de la configuration `vsi`.


#### Image de serveur virtuel

Pour chercher les serveurs virtuels disponibles dans votre région, utilisez la ligne de commande IBM Cloud :


```shell
ibmcloud is images
```

Vous pouvez ensuite spécifier cela dans le paramètre `image_name`.  Par défaut, l'image utilisée pour tous les serveurs virtuels est `ibm-ubuntu-18-04-6-minimal-amd64-2`.


#### Profil de serveur virtuel

Pour chercher les configurations matérielles disponibles dans votre région, utilisez la ligne de commande IBM Cloud :

```shell
ibmcloud is instance-profiles
```

Vous pouvez ensuite spécifier cela dans le paramètre `machine_type`.  Par défaut, le profil utilisé pour tous les serveurs virtuels est `cx2-4x8`.


#### Composants supplémentaires

Les composants des serveurs virtuels tels que le stockage par blocs supplémentaires et les équilibreurs de charges peuvent être configurés à l'aide de `override.json` et ces définitions des variables peuvent être trouvées [ici dans variables.tf](./landing-zone/variables.tf#304).

