# Module Terraform IBM VPC  

Ce module crée les composants sous-jacents du réseau VPC :

- VPC
- Passerelles publiques
- Sous-réseau
- Liste de contrôle d’accès (ACLs) réseau
- Passerelles VPN 
- Connexions des passerelles VPN

![module-vpc](../images/module_doc_imgs/vpc-module.png)

## Table des matières

1. [VPC](#vpc)
2. [Passerelles publiques](#passerelles-publics)
3. [ACLs Réseau](#acls-réseau)
4. [Sous-réseaux](#sous-réseaux)
5. [Passerelles VPN](#passerelles-vpn)
5. [Variables du Module](#variables-du-module)
6. [Sorties du Module](#sorties-du-module)
7. [En tant que module dans une architecture plus large](#module-dans-une-architecture-plus-large)

## VPC

Ce module crée un nuage privé virtuel (VPC) dans un groupe de ressources comportant un accès classique facultatif. Le VPC et les composantes sont créés dans le fichier [main.tf](../../terraform/00-landing-zone/landing-zone/vpc/main.tf)

---

## Passerelles publiques

This module allows a user to optionally create public gateways in the VPC in each of the three zones of the VPC's region.

---

## ACLs Réseau

Ce module crée un nombre quelconque de listes de contrôle d'accès au réseau avec un nombre assorti de règles. *(Remarque : par défaut, les listes de droits d’accès réseau VPC ont un maximum de 25 règles.)*

---

## Sous-réseaux

Le fichier [subnet.tf](../../terraform/00-landing-zone/landing-zone/vpc/subnet.tf) permet aux utilisateurs de créer des sous-réseaux dans 1, 2, ou 3 zones. Des passerelles publiques peuvent être attachées de manière optionnelle à chaque sous-réseau. Chaque sous-réseau peut également recevoir comme paramètre toute liste de contrôle d’accès créée dans ce module.

### Address Prefixes

Un bloc CIDR est créé dans le VPC pour chaque sous-réseau qui sera approvisionné.

### Subnets

Le type de la variable `subnets`  est le suivant:

```terraform
object({
    zone-1 = list(object({
      name           = string
      cidr           = string
      acl_name       = string
      public_gateway = optional(bool)
    }))
    zone-2 = list(object({
      name           = string
      cidr           = string
      acl_name       = string
      public_gateway = optional(bool)
    }))
    zone-3 = list(object({
      name           = string
      cidr           = string
      acl_name       = string
      public_gateway = optional(bool)
    }))
  })
```

Bien que `zone-1`, `zone-2`, et `zone-3` soient toutes des listes, celles-ci sont converties en un objet avant que les ressources ne soient provisionnées. Cela garantit que l'ajout ou la suppression de sous-réseaux n'affectera que les sous-réseaux ajoutés ou supprimés. Exemple:

```terraform
module.subnets.ibm_is_subnet.subnet["gcat-multizone-subnet-a"]
module.subnets.ibm_is_subnet.subnet["gcat-multizone-subnet-b"]
module.subnets.ibm_is_subnet.subnet["gcat-multizone-subnet-c"]
module.subnets.ibm_is_vpc_address_prefix.subnet_prefix["gcat-multizone-subnet-a"]
module.subnets.ibm_is_vpc_address_prefix.subnet_prefix["gcat-multizone-subnet-b"]
module.subnets.ibm_is_vpc_address_prefix.subnet_prefix["gcat-multizone-subnet-c"]
```

---

## Passerelles VPN

Ce module peut créer un nombre quelconque de passerelles VPN sur un nombre quelconque de sous-réseaux en utilisant la variable `vpn_gateways`. Pour en savoir plus sur les passerelles VPN sur VPC, [lisez la documentation ici](https://cloud.ibm.com/docs/vpc?topic=vpc-using-vpn)

---

## Variables du Module

Nom                        | Type                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       | Description                                                                                                                                                                                                                                                                                                                                                                          | Sensible | Valeur par Default
--------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ | --------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
resource_group_id           | chaîne de caractères                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     | ID du groupe de ressources où le VPC doit être créé                                                                                                                                                                                                                                                                                                                                    |           | 
region                      | chaîne de caractères                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     | La région dans laquelle le VPC doit être déployé                                                                                                                                                                                                                                                                                                                                               |           | 
prefix                      | chaîne de caractères                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     | Le préfixe que vous souhaitez ajouter à vos ressources.                                                                                                                                                                                                                                                                                                                          |           | 
tags                        | list(chaîne de caractères)                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               | Liste des étiquettes pour la ressource créée                                                                                                                                                                                                                                                                                                                                              |           | null
vpc_name                    | chaîne de caractères                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     | ID du groupe de ressources où le VPC doit être créé. S'il est laissé sans valeur, il sera généré en utilisant le préfixe de ce module.                                                                                                                                                                                                                                                             |           | null
classic_access              | booléen                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       | OPTIONNEL - Accès classique au VPC                                                                                                                                                                                                                                                                                                                                                |           | false
use_manual_address_prefixes | chaîne de caractères                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     | OPTIONNEL - Utiliser les préfixes d'adresses manuels pour VPC                                                                                                                                                                                                                                                                                                                                      |           | false
default_network_acl_name    | chaîne de caractères                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     | OPTIONNEL - Nom de l'ACL par défaut. S'il est nul, un nom sera automatiquement généré.                                                                                                                                                                                                                                                                                                 |           | null
default_security_group_name | chaîne de caractères                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     | OPTIONNEL - Nom du groupe de sécurité par défaut. S'il est nul, un nom sera automatiquement généré.                                                                                                                                                                                                                                                                                      |           | null
default_routing_table_name  | chaîne de caractères                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     | OPTIONNEL - Nom de la table de routage par défaut. S'il est sans valeur, un nom sera automatiquement généré.                                                                                                                                                                                                                                                                                      |           | null
address_prefixes            | object({ zone-1 = optional(list(string)) zone-2 = optional(list(string)) zone-3 = optional(list(string)) })                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                | FACULTATIF - Plage d'adresses IP qui sera définie pour le VPC pour un certain emplacement. À utiliser uniquement avec des préfixes d'adresse manuels                                                                                                                                                                                                                                                                   |           | { zone-1 = null zone-2 = null zone-3 = null }
network_acls                | list( object({ name = string network_connections = optional(list(string)) add_cluster_rules = optional(bool) rules = list( object({ name = string action = string destination = string direction = string source = string tcp = optional( object({ port_max = optional(number) port_min = optional(number) source_port_max = optional(number) source_port_min = optional(number) }) ) udp = optional( object({ port_max = optional(number) port_min = optional(number) source_port_max = optional(number) source_port_min = optional(number) }) ) icmp = optional( object({ type = optional(number) code = optional(number) }) ) }) ) }) ) | Liste des ACL à créer. Les règles peuvent être créées automatiquement pour autoriser le trafic entrant et sortant d'un niveau VPC en ajoutant le nom de ce niveau à la liste  `network_connections`. Les règles générées automatiquement par ces connexions réseau seront ajoutées au début d'une liste, et seront appliquées au trafic en premier. Au moins une règle doit être fournie pour chaque ACL. |           | [ { name = "vpc-acl" add_cluster_rules = true rules = [ { name = "allow-all-inbound" action = "allow" direction = "inbound" destination = "0.0.0.0/0" source = "0.0.0.0/0" }, { name = "allow-all-outbound" action = "allow" direction = "outbound" destination = "0.0.0.0/0" source = "0.0.0.0/0" } ] } ]
use_public_gateways         | object({ zone-1 = optional(bool) zone-2 = optional(bool) zone-3 = optional(bool) })                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        | Crée une passerelle publique dans l'une des trois zones avec `true`.                                                                                                                                                                                                                                                                                                                       |           | { zone-1 = true zone-2 = false zone-3 = false }
subnets                     | object({ zone-1 = list(object({ name = string cidr = string public_gateway = optional(bool) acl_name = string })) zone-2 = list(object({ name = string cidr = string public_gateway = optional(bool) acl_name = string })) zone-3 = list(object({ name = string cidr = string public_gateway = optional(bool) acl_name = string })) })                                                                                                                                                                                                                                                                                                     | Liste des sous-réseaux pour le VPC. Pour chaque élément de chaque tableau, un sous-réseau sera créé. Les éléments peuvent être des blocs CIDR ou l'ensemble d'adresses IPv4. Les passerelles publiques seront activées uniquement dans les zones où une passerelle a été créée.                                                                                                                                                         |           | { zone-1 = [ { name = "subnet-a" cidr = "10.10.10.0/24" public_gateway = true acl_name = "vpc-acl" } ], zone-2 = [ { name = "subnet-b" cidr = "10.20.10.0/24" public_gateway = true acl_name = "vpc-acl" } ], zone-3 = [ { name = "subnet-c" cidr = "10.30.10.0/24" public_gateway = true acl_name = "vpc-acl" } ] }
routes                      | list( object({ name = string zone = number destination = string next_hop = string }) )                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     | OPTIONNEL - Vous permet de spécifier le prochain saut pour les paquets en fonction de leur adresse de destination.                                                                                                                                                                                                                                                                                       |           | []
vpn_gateways                | list( object({ name = string subnet_name = string mode = optional(string) tags = optional(list(string)) connections = list( object({ peer_address = list(string) preshared_key = string local_cidrs = optional(list(string)) peer_cidrs = optional(list(string)) admin_state_up = optional(bool) }) ) }) )                                                                                                                                                                                                                                                                                                                                 |      Liste définissant les informations nécessaires à la création d'un service VPN pour connecter en toute sécurité votre VPC à un autre réseau privé.                                                                                                                                                                                                                                                            |           | []

---

## Sorties du Module

Nom                  | Description
---------------------- | -----------------------------------------------------------
vpc_id                 | ID du VPC Créé
vpn_gateway_public_ips | Liste des adresse IP publiques des passerelles VPN
subnet_ids             | ID des sous-réseaux
subnet_detail_list     | Liste de sous-réseaux contenant des noms, des blocs CIDR et des zones.
subnet_zone_list       | Liste contenant les ID de sous-réseau et les zones de sous-réseau

---

## En tant que module dans une architecture plus large

```terraform
module vpc {
  source                      = "./vpc"
  resource_group_id           = var.resource_group_id
  region                      = var.region
  prefix                      = var.prefix
  tags                        = var.tags
  vpc_name                    = var.vpc_name
  classic_access              = var.classic_access
  network_acls                = var.network_acls
  use_public_gateways         = var.use_public_gateways
  subnets                     = var.subnets
  vpn_gateways                = var.vpn_gateways
}
```
