# Déploiement du pare-feu réseau natif d'Oracle Cloud Infrastructure  

Au menu

- [Prérequis](#prérequis)
- [Création des stratégies de pare-feu réseau](#création-des-stratégies-de-pare\-feu-réseau)
- [Déploiement du pare-feu réseau](#déploiement-du-pare\-feu-réseau)
- [Acheminement du trafic vers le pare-feu](#acheminement-du-trafic-vers-le-pare\-feu)
- [Activation de la journalisation du trafic vers le pare-feu](#activation-de-la-journalisation-du-trafic-vers-le-pare-feu)

## Prérequis  

- Avant de déployer le pare-feu réseau, un réseau virtuel infonuagique (VCN) et un sous-réseau pour le pare-feu réseau doivent être créés.

## Création des stratégies de pare-feu réseau  

Avant de créer un pare-feu réseau, une ou plusieurs stratégies de pare-feu réseau doivent être mises en place, car elles seront nécessaires au moment de la création du pare-feu réseau.

- À partir de OCI Shell, naviguez vers **Identité et sécurité**, puis sur **Stratégies de pare-feu réseau**.

![1_naviguez_vers_strategie_parefeu_reseau](../images/creation_strategie/1_naviguez_vers_strategie_parefeu_reseau.png)  

Le système affiche la page Web *Stratégies de pare-feu réseau*.  

- Dans le champ **Compartiment** à gauche, sélectionnez le compartiment pour lequel vous voulez voir la liste des stratégies de pare-feu, puis cliquez sur le bouton **Créer une stratégie**.

![2_page_creer_strategie_parefeu_oci](../images/creation_strategie/2_page_creer_strategie_parefeu_oci.png)

Le système affiche la page Web *Créer une stratégie de pare-feu*.

### Informations de base

Fournissez un nom et sélectionnez le compartiment dans lequel sera déployée la stratégie de pare-feu, puis cliquez sur le bouton **Suivant**.

![3_creer_strategie_parefeu_oci_1](../images/creation_strategie/3_creer_strategie_parefeu_oci_1.png)
  
### Listes (facultatif)

Créez des listes pour vous aider à générer vos règles de stratégie de pare-feu. Les listes vous permettent d'appliquer les mêmes règles de stratégie à des groupes d'applications, d'URL ou d'adresses IP.  

![4_creer_strategie_parefeu_oci_liste](../images/creation_strategie/4_creer_strategie_parefeu_oci_liste.png)

Cliquez sur le bouton **Suivant**.  

### Clés secrètes mises en correspondance/profils de décryptage (facultatif)  

Si votre stratégie utilise des règles de décryptage qui emploient l'authentification par certificat, vous devez configurer des clés secrètes mises en correspondance et des profils de décryptage. Vous pouvez configurer jusqu'à 25 clés secrètes mises en correspondance et 25 profils de décryptage pour chaque stratégie.  

![5_creer_strategie_parefeu_oci_cle_secrete](../images/creation_strategie/5_creer_strategie_parefeu_oci_cle_secrete.png)

Cliquez sur le bouton **Suivant**.  

### Règles de cryptage et de sécurité  

- Cliquez sur le bouton **Ajouter une règle de sécurité**.  

Le système affiche une boîte de dialogue.

![6_creer_strategie_parefeu_oci_cle_regle](../images/creation_strategie/6_creer_strategie_parefeu_oci_cle_regle.png)

- Saisissez le nom de la règle.  

- Dans le champ **Adresse IP source**, définissez la ou les adresses IP source dans la condition de la règle.

- Dans le champ **Adresse IP de destination**, définissez la ou les adresses IP de destination dans la condition de la règle.  

- Dans le champ **Applications**, définissez le ou les protocoles dans la condition de la règle.  

- Dans le champ **URL**, définissez la ou les adresses URL dans la condition de la règle.  

- Dans la liste déroulante **Action**, sélectionnez l'action à appliquer lorsque la condition est remplie.

- Cliquez sur le bouton **Enregistrer les modifications**.

- Répétez les étapes 6 à 13 autant de fois que nécessaire pour ajouter de nouvelles règles.

### Vérifier et créer  

![7_creer_strategie_parefeu_oci_verifier](../images/creation_strategie/7_creer_strategie_parefeu_oci_verifier.png)

Cliquez sur le bouton **Créer une stratégie de pare-feu réseau**.

![8_detail_strategie_parefeu_oci](../images/creation_strategie/8_detail_strategie_parefeu_oci.png)  

Ces stratégies de pare-feu seront plus tard attachées au pare-feu natif d'Oracle.

## Déploiement du pare-feu réseau

- À partir d'OCI Shell, naviguez à nouveau vers **Identité et sécurité**, puis sur **Pare-feu réseau**.  

![1_naviguez_vers_parefeu_reseau](../images/deploi_pare_feu_oci/1_naviguez_vers_parefeu_reseau.png)  

Le système affiche la page Web *Pare-feu réseau*.  

- Dans le champ **Compartiment** à gauche, sélectionnez le compartiment pour lequel vous voulez voir la liste des pare-feux, puis cliquez sur le bouton **Créer un pare-feu réseau**.

![2_page_creer_pare_feu_oci](../images/deploi_pare_feu_oci/2_page_creer_pare_feu_oci.png)  

Le système affiche une page Web *Créer un pare-feu réseau*.

- Saisissez le nom du pare-feu réseau.  

![3_creer_un_parefeu_reseau](../images/deploi_pare_feu_oci/3_creer_un_parefeu_reseau.png)  

- Sélectionnez le compartiment dans lequel vous voulez déployer le pare-feu réseau.

- Sélectionnez la stratégie définie à la section [précédente](#création-des-stratégies-de-pare-feu-réseau).

- Sélectionnez un réseau virtuel infonuagique et un sous-réseau pour le routage du trafic.

Après avoir cliqué sur le bouton **Créer un pare-feu réseau**, un temps d'attente entre 20 et 30 minutes est requis pour que le pare-feu réseau soit créé.

![4_detail_parefeu_reseau](../images/deploi_pare_feu_oci/4_detail_parefeu_reseau.png)  

![detail_parefeu_reseau_oci](../images/deploi_pare_feu_oci/detail_parefeu_reseau_oci.png)  

## Acheminement du trafic vers le pare-feu  

L'acheminement du trafic vers un pare-feu réseau va dépendre de l'un des scénarios suivants :  

- Acheminement du trafic sur place au moyen d'un pare-feu réseau
- Acheminement du trafic Internet au moyen d'un pare-feu réseau
- Acheminement du trafic intra-VCN au moyen d'un pare-feu réseau

La rubrique **Tâche 3 : Acheminer le trafic vers le pare-feu** dans le lien <https://docs.oracle.com/fr-ca/iaas/Content/network-firewall/setting-up-network-firewall.htm> donne un exemple de configuration de routage pour chacun des trois scénarios ci-dessus.  

## Cas d'utilisation : Accéder à une machine virtuelle dans un réseau privé à partir d'Internet à l'aide de la passerelle Internet et du pare-feu réseau  

Nous allons configurer le routage pour un cas d'utilisation simple de trafic nord-sud.  

### Topologie réseau  

![networking_topology](../images/deploi_pare_feu_oci/networking_topology.jpg)  

Nous avons deux hôtes sur Internet :  

- l'un possédant l'adresse IP **150.136.212.20**  
- et l'autre possédant l'adresse IP **192.9.241.52**.  

Dans la zone d'accueil Oracle du cas d'utilisation, on y trouve :  

- Un réseau virtuel infonuagique (VCN1) dont le CIDR est **192.168.0.0/24**  
- Une passerelle Internet
- Un pare-feu natif Oracle
- Une machine virtuelle VM1
- L'adresse IP publique du pare-feu natif Oracle est *192.168.0.20*.  
- Le pare-feu est déployé dans le sous-réseau *192.168.0.16/28*.

Le trafic de l'hôte 150.136.212.20 vers la VM1 192.18.141.51 dans la zone d'accueil Oracle sera autorisé pour les protocoles ICMP type 8 et SSH sur le port 22 en passant par le pare-feu réseau. Ce trafic est représenté par la ligne verte.  

 D'autre part, le trafic provenant de 192.9.241.52 et les protocoles d'ICMP Type 8 et SSH sur le port 22 vers VM1 seront refusés par le pare-feu réseau (représenté par la ligne rouge); le trafic refusé sera enregistré pour une analyse plus approfondie.

### Configuration des routes

Lors de la configuration d'un pare-feu FortiGate, l'acheminement du trafic vers le pare-feu FortiGate passe par la définition de règles de routage vers ou depuis les interfaces publiques ou privées du pare-feu FortiGate.

Dans le pare-feu natif Oracle, les notions de port ou d'interface n'existent pas.  

L'acheminement du trafic vers le pare-feu natif d'Oracle passe par la définition de tables de routage entre les réseaux virtuels infonuagiques (VCN) dans la zone d'accueil Oracle.  

#### Route 1 : Table de routage pour acheminer le trafic vers le sous-réseau hébergeant VM1

![route1](../images/deploi_pare_feu_oci/route1.jpg)  

#### Route 2 : Table de routage attachée au sous-réseau hébergeant le pare-feu natif Oracle  

![route2](../images/deploi_pare_feu_oci/route2.jpg)  

 Le pare-feu réseau sera utilisé comme un tremplin, une passerelle, pour atteindre les sous-réseaux à l'intérieur du VCN1.

#### Route 3 : Table de routage pour le trafic entrant dans le VCN1

Vous devez créer une nouvelle table de routage et ajouter une route afin que tout trafic entrant dans le réseau virtuel VCN1 (*192.168.0.0/24*) soit redirigé vers le pare-feu (192.168.0.20).  

![route3](../images/deploi_pare_feu_oci/route3.jpg)  

Nous avons vu dans la [topologie](#topologie-réseau) que le trafic Internet atteindra le réseau virtuel VCN1 en passant par la passerelle Internet, puis le pare-feu réseau.

Par défaut, la passerelle Internet ne peut envoyer le trafic directement vers la VM1 en passant par le pare-feu réseau au 192.168.0.20.

Nous allons étendre la capacité de la passerelle Internet en attachant une table de routage à la passerelle Internet.

Attachons la dernière [table de routage](#route-3--table-de-routage-pour-le-trafic-entrant-dans-le-vcn1) à la passerelle Internet :

![route4](../images/deploi_pare_feu_oci/route4.jpg)  

Nous avons terminé la configuration du routage.

Assurez-vous que les [règles de sécurité](#règles-de-cryptage-et-de-sécurité) sur les protocoles ICMP, SSH ou les NSG que vous utilisez permettent la circulation du trafic.

## Activation de la journalisation du trafic vers le pare-feu  

Sur la page Web **Détails du pare-feu réseau**, dans le panneau **Ressources** à gauche de l'écran, cliquez sur **Journaux** et démarrez la journalisation du trafic vers le pare-feu.

![traffic_log](../images/deploi_pare_feu_oci/traffic_log.jpg)  

Maintenant, votre tout nouveau pare-feu réseau est prêt à être utilisé!  

[Retour à la Page d'accueil](../../README.md "Retour à la page d'accueil")
