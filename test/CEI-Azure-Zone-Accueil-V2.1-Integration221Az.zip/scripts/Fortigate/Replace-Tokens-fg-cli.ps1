# ----------------------------------------------------------------------------------
#  Ce code est la propriété du MCN. S.V.P. vous référer au fichier Licence.md  pour les clauses légales 
# ----------------------------------------------------------------------------------
<#

.SYNOPSIS
Remplace tokens dans les fichiers maquette de configuration Fortigate avec valeurs calculés à partir d'un fichier de configuration

.DESCRIPTION
Trouve tokens dans format ${nom-token} et les remplace avec valeurs calculées pour générer les fichiers de configuration (cli) de Fortigate FG-A et FG-B 

.PARAMETER InputFile
Le fichier contenant les valeurs initiales de paramétrage à partir desquelles les calculs et substitutions sont faitesà
platform-hub-virtualNetwork (default 10.84.0.0/16) : vient du paramétrage $(var-platform-hub-virtualNetwork-ip-prefix)/$( var-platform-hub-virtualNetwork-ip-suffix) 
platform-gestion-virtualNetwork (default 10.73.128.0/17) :  vient du paramétrage $(platform-gestion-virtualNetwork-ip-prefix)/$(platform-gestion-virtualNetwork-ip-suffix)
platform-identite-virtualNetwork (default 10.73.0.0/17)  :  vient du paramétrage $(platform-identite-virtualNetwork-ip-prefix)/$(platform-identite-virtualNetwork-ip-suffix)
charges-virtualNetwork (default 10.77.0.0/16)   :  vient du paramétrage $(platform-charges-virtualNetwork-ip-prefix)/$(platform-charges-virtualNetwork-ip-suffix)



.PARAMETER OutputFile
Le fichier de sortie, paramètre obligatoire

.PARAMETER NullPattern
Le "pattern" utilisé pour signifier $null pour palier au fait qu'une variable d'environnement ne peut pas être mise comme $null
À la place setter dans la configuration la valeur de remplacement tu token à cette valeur et le script va remplacer ce token avec ''


.PARAMETER NoWarning
Si utilisé le script n'avertira pas quand des tokens apparaissant dans la maquette n'apparaissent pas dans la configuration

#>
# inclure fonction de calcul des tokens
. '.\calculExtraCfg.ps1'

Function loadConfig ($fileName, $oneSection=$null) {
    $config = Get-Content ($fileName)    
    $cfg = @{}
    ForEach ($line in $config) {
       $line = $line.Trim()
       $k = $line.IndexOf('=')
       if ($line -eq '' -or $k -lt 1 -or $line[0] -in '[','#') {continue}
       $cfg.Add($line.Substring(0,$k), $line.Substring($k+1))
    }
    Return $cfg
 }
function ReplaceTokens {
	[CmdletBinding()]
	param(
		[string]$InputFile,
		[string]$OutputFile,
		[string]$ConfigFile = "config.ini",
		[string]$NullPattern = ":::NULL:::",
		[switch]$NoWarning
	)
	$StartTokenPattern = '\${'
	$EndTokenPattern = '}'

	$Tokens = loadConfig($ConfigFile)
	$extraCfg = calculExtraCfg($Tokens)
	$Tokens += $extraCfg
	function GetTokenCount($line) {
		($line | Select-String -Pattern "$($StartTokenPattern).+?$($EndTokenPattern)" -AllMatches).Matches.Count
	}

	# If the OutputFile is null, we will write to a temporary file
	if ([string]::IsNullOrWhiteSpace($OutputFile)) {
		Write-Verbose "OutputFile was omitted. Replacing InputFile."
		$OutputFile = [System.IO.Path]::GetTempFileName()
		$ReplaceInputFile = $true
	}

	# Empty OutputFile if it already exists
	if (Test-Path -Path $OutputFile) {
		Write-Verbose "Clearing file $OutputFile"
		Clear-Content -Path $OutputFile
	}

	# Go through each line of the InputFile and replace the tokens with their values
	$totalTokens = 0
	$missedTokens = 0
	$usedTokens = New-Object -TypeName "System.Collections.ArrayList"
	(Get-Content $InputFile) | ForEach-Object {
		$line = $_
		$totalTokens += GetTokenCount($line)
		foreach ($key in $Tokens.Keys) {
			$token = "$($StartTokenPattern)$($key)$($EndTokenPattern)"
			$value = $Tokens.$key
			if ($line -match $token) {
				$usedTokens.Add($key) | Out-Null
				if ($value -eq $NullPattern) {
					$value = ""
				}
				Write-Verbose "Replacing $token with $value"
				$line = $line -replace "$token", "$value"
			}
		}
		$missedTokens += GetTokenCount($line)
		$line | Out-File -Append -FilePath $OutputFile
	}

	# If no OutputFile was given, we will replace the InputFile with the temporary file
	if ($ReplaceInputFile) {
		Get-Content -Path $OutputFile | Out-File -FilePath $InputFile -Encoding UTF8
	}

	# Write warning if there were tokens given in the Token parameter which were not replaced
	if (!$NoWarning -and $usedTokens.Count -ne $Tokens.Count) {
		$unusedTokens = New-Object -TypeName "System.Collections.ArrayList"
		foreach ($token in $Tokens.Keys) {
			if (!$usedTokens.Contains($token)) {
				$unusedTokens.Add($token) | Out-Null
			}
		}
		Write-Warning "The following tokens were not used: $($unusedTokens)"
	}

	# Write status message -- warn if there were tokens in the file that were not replaced
	$message = "Processed: $($InputFile) ($($totalTokens - $missedTokens) out of $totalTokens tokens replaced)"
	if ($missedTokens -gt 0) {
		Write-Warning $message
	}
	else {
		Write-Host $message
	}
}
# exemple utilisation
# ReplaceTokens -InputFile fga_cfg.tpl  -OutputFile fga.cfg -Config config.ini
# ReplaceTokens -InputFile fgb_cfg.tpl  -OutputFile fgb.cfg -Config config.ini