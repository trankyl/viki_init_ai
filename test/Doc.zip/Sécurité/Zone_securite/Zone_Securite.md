# Zone de sécurité

## Sommaire

- [Zone de sécurité](#zone-de-sécurité)
  - [Sommaire](#sommaire)
  - [Objectifs](#objectifs)
  - [Définition](#définition)
  - [Caractéristiques](#caractéristiques)
  - [Privilèges pour créer la zone de sécurité](#privilèges-pour-créer-la-zone-de-sécurité)
  - [Recettes de zone de sécurité (Security Zone Recipes)](#recettes-de-zone-de-sécurité-aka-security-zone-recipes)
  - [Création d’une recette](#création-recette)
  - [Création d’une zone de sécurité personnelle ou gérée par Oracle](#création-zone-de-sécurité-personnelle-ou-gérée-par-oracle)
  - [Organisation des strategies des zones de scurité](#organisation-des-strategies-des-zones-de-sécurité)
    - [Limiter le déplacement de ressource](#limiter-le-déplacement-de-ressource)
    - [Limiter l'association de ressource](#limiter-association-de-ressource)
    - [Refuser l'accès public](#refuser-accès-public)
    - [Exiger le cryptage](#exiger-le-cryptage)
    - [Garantir la durabilité des données](#garantir-la-durabilité-des-données)
    - [Garantir la sécurité des données](#garantir-la-sécurité-des-données)
    - [Utiliser uniquement des configurations approuvées par Oracle](#utiliser-uniquement-des-configurations-approuvées-par-oracle)
  - [Maximum Security Zone (MSZ)](#maximum-security-zone)
  - [Actions permises et non permises](#actions-permises-et-non-permises)
  - [Reference](#reference)


## Objectifs

    Ce document décrit la zone de sécurité et son utilisation, l'objectif est de comprende son utilisation et, dans un autre travail, evaluer la possibilité d'introduire la zone de sécurité dans la zone d"accueil OCI.

## Définition 
    Les zones de sécurité renforcent la posture de sécurité sur les compartiments cloud OCI et empêchent les actions susceptibles d'affaiblir la posture de sécurité des clients. Les zones de sécurité OCI appliquent des règles de sécurité strictes et conformes aux meilleures pratiques, qui sont verrouillées et ne peuvent pas être modifiées.

## Caractéristiques
    • La zone de sécurité est associée à un seul compartiment 
    • Une recette est associée à une zone de sécurité, voir la définition de la recette

    Lorsque vous créez et mettez à jour des ressources dans une zone de sécurité, Oracle Cloud Infrastructure valide ces opérations par rapport à la liste des stratégies définies dans la recette de zone de sécurité. Si une politique de zone de sécurité est violée, l'opération est refusée.

## Privilèges pour créer la zone de sécurité 
   Allow group SecurityAdmins to manage security-zone in tenancy 

## Recettes de zone de sécurité aka Security Zone Recipes
    Vous attribuez une recette à la zone de sécurité lors de la création d'une zone de sécurité dans la console. Une recette est un ensemble de stratégies de zone de sécurité. Lorsque vous effectuez certaines opérations sur les ressources dans une zone de sécurité, telles que la création d'une instance de calcul ou d'un sous-réseau, Oracle Cloud Infrastructure valide automatiquement les stratégies de la recette affectée à la zone de sécurité.

    Votre location dispose d'une recette prédéfinie nommée 'Recette de sécurité maximale', voir sa déscription ci-dessous, qui inclut toutes les stratégies de zone de sécurité disponibles. Oracle gère cette recette et ne peut être modifiée par le client.

    

## Création recette   

    Pour voir ou créer les stratégies de la recette de la zone de sécurité, sélectionner Recettes (Recipes) du menu gauche de la zone de sécurité

 * À partir du menu gauche, selectionner 'Identité et sécurité' puis 'Zones de sécurité'
 * À partir du menu gauche encore, cliquez sur 'Recettes'
  
  ![SZ_Creer_Recette](../../images/zone_securite_oci/Securite_Zone/SZ_Creer_Recette.png)


 * Cliquez sur 'Créer une recette'
  
  ![SZ_Creer_Recette01](../../images/zone_securite_oci/Securite_Zone/SZ_Creer_Recette_01.png)

 * Dans l'écran de 'Stratégies', Selectionner les stratégie souhaitées 

![SZ_Creer_Recette02](../../images/zone_securite_oci/Securite_Zone/SZ_Creer_Recette_02.png)

 * Dans notre cas, nous avons choisi, quatre privileges   

![SZ_Creer_Recette03](../../images/zone_securite_oci/Securite_Zone/SZ_Creer_Recette_03.png)

 * Vérifier le résultat et créer la recette  

![SZ_Creer_Recette04](../../images/zone_securite_oci/Securite_Zone/SZ_Creer_Recette_04.png)

 * Le détail de la recette est affiché ainsi que la possibilité de modifer ou de supprimer la recette

![SZ_Creer_Recette05](../../images/zone_securite_oci/Securite_Zone/SZ_Creer_Recette_05.png)

 * Vous pouvez aussi afficher les zones de sécurité pour lesquelles la 'Recette' est attachée 

![SZ_Creer_Recette06](../../images/zone_securite_oci/Securite_Zone/SZ_Creer_Recette_06.png)

 * Vous avez aussi la possibilité de 'Cloner' ou de 'Supprimer' la recette en utilisant le menu affiché ci-dessous. 

![SZ_Creer_Recette07](../../images/zone_securite_oci/Securite_Zone/SZ_Creer_Recette_07.png)


Pour modifier une recette, lister et cliquer sur la recette, puis cliquer sur le bouton modifier 
 Il est possible de modifier 
  * Le nom 
  * La description 
  * Dans quel compartiment est crée la recette 
  * ainsi que les stratégies affectées

![SZ_Modif_Recette_01](../../images/zone_securite_oci/Securite_Zone/SZ_Modif_Recette_01.png)

 * Revoir les modifications et confirmer 

![SZ_Modif_Recette_02](../../images/zone_securite_oci/Securite_Zone/SZ_Modif_Recette_02.png)

## Création zone de sécurité personnelle ou gérée par Oracle 

 * A partir du menu gauche, sélectionner 'Identité et sécurité' puis 'Zones de sécurité'
 * Puis cliquez sur le  bouton 'Créer une zone de sécurité'

![SZ_Creer_SZ_01](../../images/zone_securite_oci/Securite_Zone/SZ_Creer_SZ_01.png)

 * Selectionner une recette de zone.   Dans notre cas une recette gérée par le client. 

![SZ_Creer_SZ_02](../../images/zone_securite_oci/Securite_Zone/SZ_Creer_SZ_02.png)

Après création, tu auras la possibilité de modifier ou de supprimer la zone de sécurité.   A noter que les violations trouvées sont affichées dans cet écran 

![SZ_Creer_SZ_03](../../images/zone_securite_oci/Securite_Zone/SZ_Creer_SZ_03.png)

Liste des compartiments

 Nous pouvons remarquer que le compartiment CEI_SZ liste le nom de zone de sécurité qui s’applique sur lui. 

![SZ_Creer_SZ_04](../../images/zone_securite_oci/Securite_Zone/SZ_Creer_SZ_04.png)

En cliquant sur le bouton modifer 'Modifier' a partir de l'écran du détail de la zone de sécurité,  voir l'écran ci-haut,  vous pouvez modifier les données de la zone de sécurité

![SZ_Creer_SZ_05](../../images/zone_securite_oci/Securite_Zone/SZ_Creer_SZ_05.png)

 * Déplacement d'une zone de sécurité entre des compartiments
   
  Cette tâche ne peut pas être effectuée à l'aide de la console.   

Pour la suppression, il suffit de cliquer sur le bouton supprimer 

![SZ_Supp_SZ_01](../../images/zone_securite_oci/Securite_Zone/SZ_Supp_SZ_01.png)

Lorsque vous enlevez un sous-compartiment d'une zone, Cloud Guard crée une cible standard pour le sous-compartiment. 
La nouvelle cible dispose des mêmes recettes de détecteur que la cible de zone de sécurité pour le compartiment parent, mais elle ne détecte pas les violations de stratégie de zone de sécurité. Aucune modification n'est apportée aux cibles et recettes de détecteur Cloud Guard existantes.

Si vous avez enlevé un sous-compartiment d'une zone de sécurité, vous pouvez l'ajouter à nouveau. A la suite de cela, Oracle Cloud Infrastructure veille à ce que les ressources du sous-compartiment soient conformes aux stratégies de la zone de sécurité.

* Supprimez une zone de sécurité pour un compartiment.
  
  Lorsque vous supprimez une zone de sécurité, les modifications suivantes se produisent :
  Oracle Cloud Infrastructure n'applique pas de stratégie de zone de sécurité aux ressources du compartiment,
  Cloud Guard ne détecte pas les violations de stratégie sur les ressources du compartiment.
  Ces modifications ont également une incidence sur tous les sous-compartiments, sauf si l'un d'entre eux se trouve dans une autre zone de sécurité.

![SZ_Supp_SZ_02](../../images/zone_securite_oci/Securite_Zone/SZ_Supp_SZ_02.png)

[Source:Suppression d'un sous-compartiment d'une zone de sécurité](https://docs.oracle.com/fr-fr/iaas/security-zone/using/remove-compartment-from-zone.htm)

Vous ne pouvez pas enlever le compartiment parent utilisé pour créer la zone de sécurité. Vous devez 
[supprimer la zone de sécurité](https://docs.oracle.com/fr-fr/iaas/security-zone/using/delete-security-zone.htm#delete-security-zone)

![SZ_Sppression_SZ_01](../../images/zone_securite_oci/Securite_Zone/SZ_Suppression_SZ_01.png)

En supprimant le compartiment enfant de la zone de sécurité, le parent sera toujours couvert mais pas l’enfant 

![SZ_Suppression_SZ_02](../../images/zone_securite_oci/Securite_Zone/SZ_Suppression_SZ_02.png)

* Ajouter un compartiment a une zone de sécurité 
  Nous  ne pouvons ajouter ou supprimer que les compartiments enfants d’un compartiment protégé par une zone de sécurité

![SZ_Suppression_SZ_03](../../images/zone_securite_oci/Securite_Zone/SZ_Suppression_SZ_03.png)

* Un test de violation des stratégies 
  * Rappel des stratégies mises en place, test des 2 stratégies en surbrillance

![SZ_Test_SZ_01](../../images/zone_securite_oci/Securite_Zone/SZ_Test_SZ_01.png)

* Création d’un VCN dans la Zone de sécurité 
  
![SZ_Test_SZ_02](../../images/zone_securite_oci/Securite_Zone/SZ_Test_SZ_02.png)

* Test de création d’un sous-réseau public

![SZ_Test_SZ_03](../../images/zone_securite_oci/Securite_Zone/SZ_Test_SZ_03.png)

Résultat :  Action se termine en erreur a cause du fait que le sous-réseau ne peut pas être public

* Test de migration d’un sous-réseau privé dans un compartiment non sécurisé

![SZ_Test_SZ_04](../../images/zone_securite_oci/Securite_Zone/SZ_Test_SZ_04.png)

Résultat :  Action se termine en erreur a cause du fait que le compartiment n'est pas dans une zone de sécurité 


## Organisation des strategies des zones de sécurité   

  ###	Limiter le déplacement de ressource
  Les politiques de sécurité limitent le déplacement de certaines ressources d'une zone de sécurité vers un compartiment standard, par exemple un compartiment moins sécurisé. 
  Une ressource existante ne peut pas être déplacée d'un compartiment standard vers une zone de sécurité à moins que toutes les stratégies de sécurité ne soient respectées.
  ###	Limiter association de ressource
  Les composants d'une ressource doivent également être situés dans une zone de sécurité. Par exemple, le volume de démarrage d'une instance de calcul dans une zone de sécurité doit également se trouver dans une zone de sécurité.
  ###	Refuser accès public
  Toutes les ressources d’une zone de sécurité ne doivent pas être accessibles depuis l’internet public. Par exemple, vous ne pouvez pas créer de sous-réseaux publics dans une zone de sécurité, tous les sous-réseaux doivent être privés au sein d'un VCN dans une zone de sécurité, ou vous ne pouvez pas ajouter de passerelle Internet à un VCN dans une zone de sécurité.
  ###	Exiger le cryptage
  Les ressources d'une zone de sécurité doivent être chiffrées à l'aide de clés gérées par le client garantissant le chiffrement des données en transit ou au repos. 
  Par exemple, les compartiments Object Storage d'une zone de sécurité doivent utiliser une clé de chiffrement principale gérée par le client dans le service Vault. 
  Ils ne peuvent pas utiliser la clé de chiffrement par défaut gérée par Oracle.
  ###	Garantir la durabilité des données
  Des sauvegardes automatiques doivent être effectuées régulièrement pour les ressources d'une zone de sécurité. 
  Par exemple, les bases de données dans une zone de sécurité doivent être configurées pour effectuer des sauvegardes automatiques.
  ###	Garantir la sécurité des données
  Les données d'une zone de sécurité sont considérées comme privilégiées et ne doivent donc pas être copiées dans un compartiment standard. Par exemple, vous ne pouvez pas utiliser une sauvegarde de base de données dans une zone de sécurité pour créer une base de données qui ne se trouve pas dans une zone de sécurité.
  ###	Utiliser uniquement des configurations approuvées par Oracle
  Les ressources d'une zone de sécurité doivent utiliser uniquement des configurations et des modèles approuvés par Oracle. Par exemple, toutes les instances de calcul dans une zone de sécurité doivent être créées à l'aide d'un Oracle-provided image.

## Maximum Security Zone

  Oracle Maximum Security Zone garantit l'application automatique des politiques de sécurité des meilleures pratiques dès le premier jour afin que les clients puissent éviter les erreurs de configuration et déployer les charges de travail en toute sécurité. Les zones de sécurité OCI maximales seront publiées avec une politique de sécurité maximale activée.

  Les zones de sécurité maximale seront accompagnées d'un ensemble de politiques prédéfinies et obligatoires, appelées recettes (Maximum Security Recipe). Cette recette appliquera le niveau maximum de protection de sécurité. Il s’agira de la politique la plus restrictive par nature et ne pourra être modifiée.

  Les stratégies appliquées dans les zones de sécurité maximale Oracle sont :
  * Pas d'Internet public entrant ou sortant
  * Toutes les données chiffrées avec des clés HSM gérées par le client
  * Accès bastion uniquement aux hôtes
  * Pas de bases de données sans sauvegardes
  * Aucune instance sans images renforcées

## Actions permises et non permises 

![SZ_Actions](../../images/zone_securite_oci/Securite_Zone/SZ_Actions.png)


## Reference 

[Gestion des recettes dans les zones de sécurité](https://docs.oracle.com/fr-fr/iaas/security-zone/using/managing-recipes.htm)   
[Retour au Sommaire](#sommaire)   
[Retour à la page d'accueil](../../../README.md)

