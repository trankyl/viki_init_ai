# GCP Gatekeeper Naming Policies

This folder contains Gatekeeper naming policies for GCP resources.