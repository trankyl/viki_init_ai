# Contrôles de sécurité pour l'exigence 8

08 : Segmenter et séparer les données selon leur sensibilité

Trois contrôles sont liés à l'exigence 08 :
 AC-4, SC-7, SC-7(5)

## < --- Contrôle EX8_AC-4--->

![EX8](../images/ex8_AC-4.PNG)

## Validation Contrôle EX8_AC-4

   1. Responsabilité fournisseur : Oui
   2. Commentaire : Le script de zone d'accueil met en place une topologie réseau ayant plusieurs VNC et sous-réseaux qui sont protégés par des listes de sécurité, des NSG et/ou un pare-feu de prochaine génération.
      Vérification : Vérification par le script python, Cloud Guard (CIS_OCI_V1.0_NETWORK,Network), Vulnerability Scanning (Ports)
   3. [Lien Document](https://docs.oracle.com/fr-ca/iaas/Content/Network/Tasks/managingVCNs_topic-Overview_of_VCNs_and_Subnets.htm#Overview)
  
## < --- Contrôle EX8_SC-7--->

![EX8](../images/ex8_SC-7.PNG)

## Validation Contrôle EX8_SC-7

   1. Responsabilité fournisseur : Oui
   2. Commentaire : Le script de zone d'accueil met en place une topologie réseau ayant plusieurs VNC et sous-réseaux qui sont protégés par des listes de sécurité, des NSG et/ou un pare-feu de prochaine génération.
      Vérification : Vérification par le script python, Cloud Guard (CIS_OCI_V1.0_NETWORK,Network), Vulnerability Scanning (Ports)
   3. [Lien Document](https://docs.oracle.com/fr-ca/iaas/Content/Network/Tasks/managingVCNs_topic-Overview_of_VCNs_and_Subnets.htm#Overview)
  
## < --- Contrôle EX8_SC-7(5)--->

![EX8](../images/ex8_SC-7(5).PNG)
  
## Validation Contrôle EX8_SC-7(5)

   1. Responsabilité fournisseur : Oui
   2. Commentaire : Le NSG ne contient aucune règle de pare-feu par défaut. Par conséquent, on doit explicitement créer des règles de pare-feu pour permettre tout trafic.
      Vérification : Vérification par le script python, Cloud Guard (CIS_OCI_V1.0_NETWORK,Network), Vulnerability Scanning (Ports)
   3. [Lien Document](https://docs.oracle.com/fr-ca/iaas/Content/Network/Concepts/networksecuritygroups.htm)

[Retour à la liste des exigences](OCI_12_exigences.md)
