# Contrôles de sécurité pour l'exigence minimale 11

11 : Implémenter la journalisation et la surveillance

Contrôles liés à l'exigence 11 : CM-2, CM-3, CM-4, CM-5, CM-8

## < --- Contrôle EX11_CM-2--->

![EX11](image/CM2.PNG)

## Première Validation

   1. Responsabilité du fournisseur : Oui
   2. Commentaire : La zone d'accueil est l'architechture de référence. Chaque OP ou établissement a la responsabilité de tenir à jour la configuration de référence. AWS offre une configuration de base qui est identifiée et maintenue à jour périodiquement par le biais du service AWS Code Commit et AWS Systms Manager sur lesquelles les OP et les établissements peuvent se baser.

   Par le biais de la console : AWS Config -> Dashboard

## < --- Contrôle EX11_CM-3--->  

![EX11](image/CM3.PNG)

## Deuxième Validation

   1. Responsabilité du fournisseur : Oui
   2. Commentaire : La zone d'accueil déploie AWS Config qui surveille de façon continue les changements de configuration qui se produisent au sein des ressources contrôlées par la configuration (toutes les ressources AWS). Il vérifie si ces changements violent l’une ou l’autre des conditions stipulées dans les règles prédéfinies de l’entreprise. Si une ressource viole une règle, AWS Config signale la ressource et la règle comme étant non conformes.

   Par le biais de la console : AWS Config -> Dashboard

## < --- Contrôle EX11_CM-4--->

![EX11](image/CM4.PNG)

## Troisième Validation

   1. Responsabilité du fournisseur : Oui
   2. Commentaire : AWS Systems Manager aide les utilisateurs à maintenir la sécurité et la conformité en analysant les instances gérées et en signalant toute violation des politiques qu’il détecte.
   AWS Code Commit est un système de contrôle des versions distribuées qui surveille les changements apportés au code source pendant le développement de logiciels.

   Par le viais de la console : Developper Tools  -> Code Commit -> Repositories

## < --- Contrôle EX11_CM5--->  

![EX11](image/CM5.PNG)  

## Quatrième Validation

   1. Responsabilité du fournisseur : Oui
   2. Commentaire : La matrice des accès logiques doit être documentée et respectée.
   Les accès logiques sont gérés par l'utilisateur propriétaire du compte ou un utilisateur ayant un droit élevé.

   Par le biais de la console :
   IAM -> Users
   IAM -> User Groups

## < --- Contrôle EX11_CM-8--->

![EX11](image/CM8.PNG)

## Cinquième Validation

   1. Responsabilité du fournisseur : Oui
   2. Commentaire : La zone d'accueil déploie AWS Config qui fournit un aperçu détaillé des ressources associées à chaque compte AWS, y compris la façon dont celles-ci sont configurées et liées entre elles ainsi que la façon dont les configurations et les liens en question ont changé au fil du temps.

   Par le biais de la console : AWS Config -> Dashboad

 [Retour à la Page d'accueil](/ReadMe.md)
