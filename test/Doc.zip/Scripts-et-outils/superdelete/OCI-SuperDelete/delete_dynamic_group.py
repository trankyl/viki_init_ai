import json
import subprocess
import time

servicelabel = input("Rentrez le servicelabel (ex CEISDEL): ")
ocid_compartiment_racine = input("Saisir OCID du compartiment racine (ex ocid1.tenancy.xxx) : ")
logfile = input("Saisir le nom ou chemin du fichier journal (ex : log.txt) : ")

fichier_liste = "dynamicgrouptodel.json"

def log(pinformation , pfile):
    print(CurrentTimeString() + " : " + pinformation + "\n\n")
    f = open(pfile , 'a')
    if (f is None):
        return
    f.write(CurrentTimeString() + " : " + pinformation + "\n\n")
    f.close()

def CurrentTimeString():
    return time.strftime("%D %H:%M:%S", time.localtime())

# ocid1.tenancy.oc1..aaaaaaaaevng5cb7yve3myznrz3lyehvioucls4yt2mx2bku7wtextnevupq
log("Chargement des dynamic-group dans le compartiment " + ocid_compartiment_racine , logfile)

oci_command = "oci iam dynamic-group list -c " + ocid_compartiment_racine + " > " + fichier_liste
subprocess.run(oci_command, shell=True)
lbuffer = ""

f = open(fichier_liste, 'r')
if (f is None):
    log("Aucun dynamic-group à supprimer" , logfile)
    exit()
else:
    lbuffer = f.read()
    if (lbuffer != ""):
        f.close()
    else:
        log("Aucun dynamic-group à supprimer" , logfile)
        print("Aucun dynamic-group à supprimer")
        f.close()
        exit()
    
    
with open(fichier_liste, 'r') as file:
    data = json.load(file)

id_list = []

log("Filtrage dynamic-group ayant étiquette " + servicelabel + "..." , logfile)

for item in data['data']:
    if item['name'].startswith(servicelabel):
        id_list.append(item)


if (len(id_list) == 0) :
    log("Aucun dynamic-group à supprimer" , logfile)
    print("Aucun dynamic-group à supprimer")

for item in id_list:
    id_value = item['id']
    log("Suppression dynamic-group  ocid =" + item['id'] + " et nom = " + item['name'] + "..." , logfile)
    command = f"oci iam dynamic-group delete --dynamic-group-id {id_value}"

    subprocess.run(command, shell=True)
    log("dynamic-group " + id_value + " supprimé" , logfile)
    
