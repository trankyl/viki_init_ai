# Architecture

## Sommaire

- [Compartiments, VCN et sous-réseaux](#compartiments-vcns-et-sous-réseaux)
- [Réseautique](#réseautique)
- [Routage](#routage)
- [Périmètre et pare-feux](#périmètre-et-pare-feux)

## Description de l'architecture

   La solution de notre zone d'accueil est basée sur une topologie en étoile (*Hub and Spoke*). Cette architecture utilise une DRG, [Passerelle de routage dynamique](https://docs.oracle.com/fr-fr/iaas/Content/Network/Tasks/managingDRGs.htm), comme un routeur virtuel pour permettre de relier des réseaux dans le nuage, des réseaux dans différentes régions et des réseaux sur site (*on-premises*) au réseau du nuage.

### Diagramme typique d'une architecture en étoile avec une DRG (1)

   ![ARC_HP_DRG](../images/ARC_HP_DRG.png)

   (1) Source : site Web d'Oracle

### Compartiments VCNs et sous réseaux

   Le diagramme [ci-dessous](#compartiments-réseaux-et-sous-réseaux) illustre comment les différents réseaux sont connectés à la DRG pour produire une topologie en étoile. Cette architecture est représentée par trois sections logiques composées de compartiments.

- Section **Plateforme**
  - Cette section est composée de deux compartiments
    - Compartiment de connectivité
    - Compartiment de sécurité et de journalisation
- Section **Corporative**
  - Cette section est composée de deux compartiments
    - Compartiment de production
    - Compartiment de non-production
- Sections **Carrés de sable** et **Zone non classifiée**
  - Ces sections sont composées de deux compartiments
    - Compartiment de non classifié
    - Compartiment de carrés de sable

   En résumé, la zone d'accueil est composée de six compartiments et de neuf [réseaux](#routage) reliés par des attaches à une DRG qui route le trafic.

### Compartiments réseaux et sous-réseaux

   ![Arc_CMP_VCN_SReseaux](../images/Arc_CMP_VCN_SReseaux.png)

## Réseautique

   Le diagramme suivant est le résultat du déploiement de la zone d'accueil quand elle est déployée en utilisant les paramètres par défaut, voir [Déploiement du script](Deploi_Script.md).

   En plus des six compartiments présentés dans la section précédente, le script déploie neuf réseaux répertoriés par compartiment comme suit :

- Compartiment de connectivité
  - 01 VCN pour la connectivité
- Compartiment de production
  - 02 VCN Web (web)
    - 03 VCN application (app)
    - 04 VCN base de données (bd)
- Compartiment de non-production
  - 05 VCN Web (web)
  - 06 VCN application (app)
    - 07 VCN base de données (bd)
- Compartiment de non classifié
  - 08 VCN non classifié
- Compartiment de carré de sable
  - 09 VCN carré de sable

   Pour plus d'informations concernant le découpage réseau, veuillez consulter la section [Prérequis](Prerequis.md).

   **Réseautique**
   ![Arc_CMP_VCN_SReseaux](../images/Arc_Reseautique.png)

## Routage

   Dans cette architecture en étoile, la DRG centralise la communication entre les réseaux inter VCN ainsi que la communication entre les VCN et le site sur place (*on-premises*). La DRG offre la possibilité de diriger et d'inspecter le trafic des VCN à l'aide de pare-feux. La sécurité de ce trafic est gérée essentiellement à travers le *Hub* qui dispose de pare-feux en redondance. À cet effet, voir la section [suivante](#périmètre-et-pare-feux).

   Pour Oracle, la communication avec le site peut se faire de deux façons :

- [Site-to-Site VPN](https://docs.oracle.com/fr-fr/iaas/Content/Network/Tasks/overviewIPsec.htm#:~:text=Site%2Dto%2DSite%20VPN%20provides,the%20traffic%20when%20it%20arrives.)
       Fournit une connectivité VPN IPSec entre votre réseau sur site et les VCN dans Oracle Cloud Infrastructure.
- [FastConnect](https://docs.oracle.com/fr-fr/iaas/Content/Network/Concepts/fastconnect.htm)
       Connexion privée dédiée entre votre centre de données et Oracle Cloud Infrastructure. FastConnect offre des options de bande passante plus élevée et une expérience réseau plus fiable par rapport aux connexions Internet.

   ![Arc_Routage](../images/Arc_Routage.png)

## Périmètre et pare-feux

  Pour la configuration des pare-feux, Oracle prend en charge plusieurs partenaires, dont le FortiGate de Fortinet. Lors de l'installation de la zone d'accueil, le script vous donne le choix de configurer ou non un pare-feu, voir le document [Déploiement du script](Deploi_Script.md). Par conséquent, le choix du partenaire de pare-feux peut se faire ultérieurement.

  À noter que le script ne déploie que les instances de FortiGate par défaut; pour le reste des partenaires, une configuration additionnelle est nécessaire.

  Les deux instances de FortiGate sont configurées en haute disponibilité en mode actif-passif (*Active-Passive*).

  Si vous choisissez de configurer le pare-feu lors de l'installation, le script déploie deux instances *Fortiget* et crée quatre sous-réseaux dans la VCN de connectivité (DMZ).

  Chaque partenaire déploie un nombre de sous-réseaux.

  | Partenaire sécurité | Nombre de sous-réseaux |
  |---------------------|------------------------|
  | Check Point         |          2             |
  | Cisco               |          5             |
  | Fortinet            |          4             |
  | Palo Alto Networks  |          4             |

  Pour les pare-feux de FortiGate, le script déploie les quatre sous-réseaux suivants :

- Sous-réseaux de gestion (management) (port 1)
- Sous-réseaux publics (public) (port 2)
- Sous-réseaux privés (port 3)
- Sous-réseaux HA (port 4)

   ![Arc_Perimetre_PareFeux](../images/Arc_Perimetre_PareFeux.png)

[Retour à la page d'accueil](../../ReadMe.md)
