# Contrôles de sécurité pour l'exigence minimale 9

09 : Implémenter des services de sécurité réseau

Contrôles communs à l'exigence 09 : AC-3, AC-4, SC-5, SC-7, SC-7(5), SI-3, SI-3(7), SI-4

## < --- Contrôle EX9_AC-3--->

![EX9](image/AC3.PNG)  

## Première Validation

 1. Responsabilité du fournisseur : Oui
 2. Commentaire : Le système d’information applique les autorisations approuvées pour l’accès logique aux ressources du système et à l’information conformément aux politiques de contrôle d’accès applicables.

 Par le biais de la console : IAM ->Politiques
 3. [Lien Document](https://docs.aws.amazon.com/IAM/latest/UserGuide/access_policies.html?icmpid=docs_iam_help_panel)

## < --- Contrôle EX9_AC-4--->  

![EX9](image/AC4.PNG)

## Deuxième Validation

 1. Responsabilité du fournisseur : Oui
 2. Commentaire : Pour le compte de périmètre, on retrouve les instances de pare-feu et la passerelle Internet.
La gestion de la réseautique et des tables de routage ainsi que la passerelle de service sont centralisées dans le compte réseautique. Ce dispositif permet d’assurer la segmentation réseautique entre les différents comptes de charge de travail. Il faudra donner l’accès à ce compte à l’équipe réseau afin qu’elle puisse assurer la gestion des VPC, de l’adressage IP et des tables de routage de l’environnement. Ceci permettra de gérer la communication entre les charges de travail.
 3. [Lien Document](https://docs.aws.amazon.com/fr_fr/console/ec2/security-groups#security-group-rules)
      [Lien Document](https://docs.aws.amazon.com/fr_fr/console/vpc/network-acls)

## < --- Contrôle EX9_SC-5--->  

![EX9](image/SC5.PNG)

## Troisième Validation

   1. Responsabilité du fournisseur : Oui
   2. Commentaire : AWS offre le service Shield qui permet de protéger contre les attaques DDOS, le déni de service ou en limite les effets par l’emploi de mesures de protection de sécurité définies par le fournisseur ou l’organisation.
   Par le biais de la console : AWS Shield   -> Protected Ressources

## < --- Contrôle EX9_SC-7--->

![EX9](image/SC7.PNG)

## Quatrième Validation

   1. Responsabilité du fournisseur : Oui
   2. Commentaire : Le système d’information surveille et contrôle les communications à sa frontière externe et à ses principales frontières internes. Le VPC de compte de périmètre héberge les services de sécurité de périmètre de l'organisation. Le VPC de périmètre est utilisé pour contrôler le flux de trafic entre les comptes AWS.

## < --- Contrôle EX9_SC-7(5)--->  

![EX9](image/SC7-5.PNG)  

## Cinquième Validation

   1. Responsabilité du fournisseur : Oui
   2. Commentaire : Par défaut, il n'y a pas de connectivité externe. Tout trafic externe est interdit. Il faut configurer un VPN et une passerelle publique pour communiquer à l'externe.

   Par le biais de la console : VPC -> Security Group

## < --- Contrôle EX9_SI-3--->

![EX9](image/SI3.PNG)

## Sixième Validation

   1. Responsabilité du fournisseur : Oui
   2. Commentaire : L’organisation utilise des mécanismes de protection contre les codes malveillants aux points d’entrée et de sortie du système d’information afin de détecter et d’éradiquer les codes malveillants.
   AWS offre le service GuardDuty qui permet la détection des menaces en surveillant en permanence les activités malveillantes et les comportements anormaux.
   Par le biais de la console : Guarduty Finding -> Finding

## < --- Contrôle EX9_SI-3(7)--->

![EX9](image/SI3-7.PNG)

## Septième alidation

   1. Responsabilité du fournisseur : Oui
   2. Commentaire : Le système d’information met en œuvre des mécanismes non axés sur les signatures de détection de code malveillant. L’antivirus FortiGuard assure une protection contre les virus et les logiciels espions les plus récents et contre les autres menaces qui ciblent le contenu.

## < --- Contrôle EX9_SI-4--->

![EX9](image/SI4.PNG)

## Huitième Validation

   1. Responsabilité du fournisseur : Oui
   2. Commentaire : Outils de surveillance du système d’information
   Par le biais de la console : AWS Security Hub, AWS GuardDuty
  
 [Retour à la Page d'accueil](/ReadMe.md)
