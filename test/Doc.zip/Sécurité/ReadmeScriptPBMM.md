# Utilisation et exploitation de script de validation de la zone d’accueil fourni par Oracle

## Table des matières

1. [Création de bucket Object Storage où les rapports seront copiés](#création-de-bucket-object-storage-où-les-rapports-seront-copiés)
1. [Exécution du script](#exécution-du-script)
1. [Génération du rapport CSV](#génération-du-rapport-csv)

## Introduction

  Cette documentation vise à faciliter l’utilisation et l'exploitation de script de validation de la zone d’accueil fourni par Oracle.
  Ce script génère un rapport synthèse en format CSV ainsi qu'un rapport de résultats individuel, également en format CSV, pour les problèmes de configuration découverts dans un dossier (emplacement par défaut). Celui-ci comporte la date du jour, par exemple. 2022-05-25.

## Création de bucket Object Storage où les rapports seront copiés

 Création d’un compartiment (*bucket*) “demo” où les rapports synthèses seront copiés.

![Cration Bucket](../images/CreateBucket.png)
![List Bucket](../images/ListBucket.png)

## Exécution du script

 Ce script peut être exécuté à partir de Cloud Shell ou à partir d'un poste de développement local.

### Au niveau de la machine locale

1. Ouvrir votre ligne de commande ou votre terminal.
2. [Configuration et prérequis](https://docs.oracle.com/en-us/iaas/Content/API/Concepts/sdkconfig.htm)
3. Accéder au répertoire où se trouve votre script **Python cis_reports**.
4. Exécuter le script  cis_reports.py en tapant les commandes suivantes :

**pip3 install oci**
**python3 cis_reports.py --output-to-bucket 'demo' -t <Profile_Name>**

**Profile_Name** : est le nom du profil dans le fichier de configuration du client OCI (généralement situé sous $HOME/.oci). Un profil définit les paramètres de connexion à votre location, comme l'identifiant de la location, la région, l'identifiant de l'utilisateur, l'empreinte digitale et le fichier clé.

 **Output-to-bucket** **bucket-name** : les rapports seront copiés dans le compartiment stockage d'objets (*bucket Object Storage*) dans un dossier (emplacement par défaut) avec la date du jour, par exemple 2022-05-25.

 -**Au niveau d’Oracle Cloud Shell** :
1. Téléverser le script python cis_reports.

![File Download](../images/FileDownload.png)

![File Transfer](../images/FileTransfer.png)

2. Exécuter le script en tapant les commandes suivantes :

+ **python3 -m venv python**
+ **pip3 install oci**
+ **python3 cis_reports.py -dt --output-to-bucket  ‘demo’**

![Script Execution](../images/ExecutionScript.png)

## Génération du rapport CSV

  Le téléchargement de document peut se faire au niveau du compartiment défini en « demo ».

![Lister Bucket Demo](../images/ListDocBucketDemo.png)

**Extraction du fichier Excel** :

  Extraire le fichier CSV pour analyse et identification de la conformité de la location par rapport à la référence CIS.

![File Output](../images/ListeFileOutput.png)

  Chaque ligne de rapport correspond à une recommandation de l'OCI Foundations Benchmark et identifie si la location est conforme ainsi que le nombre des écarts détectés. Le rapport est composé de :

**Recommandation** : le numéro de recommandation dans le document CIS Benchmark

**Section** : les sections de la recommandation sont séparées comme suit : gestion des accès et des identités, réseau, journalisation et surveillance, stockage des objets et gestion des actifs.

**Niveau** : le niveau de recommandation, à savoir que les recommandations de niveau 1 sont moins restrictives que celles de niveau 2.

**Conforme** : si la location est conforme à la recommandation.

**Écart** : le nombre de conclusions incriminées pour la recommandation

**Titre** : la description de la recommandation

**Date d’extraction** : la date de l’extraction

 Dans l'exemple ci-dessous, nous remarquons que la location n'est pas conforme à quatorze recommandations. Parmi celles-ci se trouve l'élément 1.7 qui montre que cinq utilisateurs n'ont pas activé l'authentification multifacteur (MFA) pour accéder à la console OCI.

![Finding MFA](../images/ExcelResult.png)

 Un rapport CSV dédié pour chaque écart remonté est généré au niveau de la console. Par exemple, pour l’élément 1.7, le rapport donne plus de détails sur les cinq utilisateurs.

![Finding MFA](../images/Ecart1.7.png)

[Page d'accueil](/Doc/README_zone_d'accueil_script.md)
