# Nettoyage de la zone d'accueil OCI

## Script de suppression

Source : https://github.com/AnykeyNL/OCI-SuperDelete

![script_archi](../../images/superdelete/script_archi.PNG)

![script_archi_modules](../../images/superdelete/script_archi_modules.PNG)

## Arguments du script

Comment le lancer :

```
Syntaxe : delete.py [-h] [-cf CONFIG_FILE] [-cp CONFIG_PROFILE] [-force] [-debug] [-rg REGIONS] [-c COMPARTMENT]

arguments optionnels :
  -h, --help                Afficher ce message d'aide et arrêter le script
  -cp CONFIG_PROFILE        Config Profile dans le fichier de configuration
  -ip                       Utiliser l'instance principale pour se connecter à Oracle Cloud
  -dt                       Utiliser le jeton dans le fichier de configuration pour se connecter à Oracle Cloud
  -force                    Forcer la suppression sans attendre une confirmation humaine
  -debug                    Activer le déboguage
  -rg REGIONS               Liste de nom de régions dans lequel se fera la suppression de ressources. Utiliser ; comme séparateur entre noms de région
  -c COMPARTMENT            Identifiant OCID du compartiment de premier niveau ayant les ressources à supprimer
  -skip_delete_compartment  Ne pas supprimer le compartiment de premier niveau  à la fin du processus

python3 delete.py -c <CompartmentID>

```


## Workflow pour le suppression
Dans le cadre des tests de suppression en utilisant le module superdelete, la méthodologie est la suivante :

![workflow_superdelete](../../images/superdelete/workflow_superdelete.png)

Le premier cas concerne la suppression d'une zone d'accueil ayant les composants suivants :
![za_mcfgd](../../images/superdelete/za_mcfgd.drawio.png)
#### Étape 1:
Récupération du dossier ZIP contenant le script superdelete :
![download_script](../../images/superdelete/download_script.png)
#### Étape 2:
Téleversement du dossier ZIP au niveau de la console CloudShell :
![upload_script](../../images/superdelete/upload_script.png)
#### Étape 3:
Vérification de la présence du fichier config ­au niveau de l'environnement:
![config_file](../../images/superdelete/config_file.png)

Si votre fichier ~/.oci/config n'existe pas ou a été corrompu , bien vouloir suivre la recette suivante https://docs.oracle.com/fr-ca/iaas/Content/API/Concepts/apisigningkey.htm#two pour sa génération.

#### Étape 4:
Modification, si besoin, du fichier config pour ajouter un profil qui peut être utilisé pour spécifier des paramètres qui seront pris en compte par le script de suppression. Dans notre cas, le profil par défaut "DEFAULT" a été utilisé et aucun profil n'a été crée.

![config_file_content](../../images/superdelete/config_file_content.PNG)

#### Étape 5:
Récupération des informations nécessaires pour l'execution du script, en l'occurence l'OCID du compartiment à supprimer:

![compartiment_ocid](../../images/superdelete/compartiment_ocid.PNG)

***NOTE:*** Un fichier de log peut être spécifé afin d'enregistrer les logs d'execution qui seront accessible par la suite au niveau du CloudShell, si aucun fichier log n'est spécifié dans la commande un fichier sera quand même crée automatiquement par le script avec le nom "log.txt".

#### Étape 6:
Execution du script en utilisant la commande suivante:

`python3 delete.py -dt -rg [REGION] -c [OCID]`

La console affichera alors un récapitulatif des elements à supprimer, une vérification doit être faite ainsi qu'une confirmation pour la suppression du contenu du compartiment choisi, il faudra alors taper "yes" pour confirmer et rouler le script:

![cloudshell_commandline](../../images/superdelete/cloudshell_commandline.png)
#### Étape 7:
Suivi de l'execution au niveau de la console CloudShell, les étapes de suppressions y sont indiqués et également enregistrés dans le fichier de logs:
![cloudshell_commandline2](../../images/superdelete/cloudshell_commandline2.png)

#### Étape 8:
À la fin d'éxecution du script, un message de type "l'environnement a été supprimé" sera affiché au niveau de la console, cela ne signifie pas pour autant que l'environnement est complétement supprimé. Une vérification manuelle doit alors être effectuée afin de confirmer la suppression:

***Avant execution***
![etat_cmp_preexecution2](../../images/superdelete/etat_cmp_preexecution2.png)

***Après execution***
![etat_cmp_postexecution2](../../images/superdelete/etat_cmp_postexecution2.PNG)

**Note** :  Si le script Python est lancé depuis son poste local , à l'extérieur du cloud Oracle ( Console Cloud Shell), les appels multiples des API OCI de suppression par le script Python seront suspects par OCI et la suppression des ressources ne sera pas effective.

#### Étape 9:
Une fois que le script fini de supprimer les ressources au niveau du compartiment englobant, il reste des stratégies propres à la ZA au niveau de la racine. Le script SuperDelete n'ayant pas accès au compartiment racine, il faut alors lancer le script de suppression des stratégies. Ce script prend en paramètres l'ocid du compartiment racine, ainsi que le service label du compartiment englobant.

**Script**:

![script_supol](../../images/superdelete/script_supol.png)

**Avant suppression**

![script_supol](../../images/superdelete/policies_avsupp.png)

**Execution du scipt**

![script_supol](../../images/superdelete/process_supp.png)

**Après suppression**

![script_supol](../../images/superdelete/policies_posupp.png)

### Exception:

Lors des tests du script superdelete, une exception a été levée. Lorsque un compartiment est incomplet (le déploiement n'a pas été bien effectué, ou bien une suppression du compartiment non aboutie) on remarque que le script roule et affiche le message d'une suppression complète alors que les ressources n'ont pas été totalement effacées. Dans ce cas il faut alors vérifier la suppression de ces ressources et réexecuter le script si besoin. Les étapes à suivre sont les suivantes :

#### Les étapes de 1 jusqu'à 8 sont les mêmes que celles mentionnées prcedemment, une fois que cela est fait il faut vérifier les work requests au niveau des compartiments/ressources existantes pour faire le suivi de la suppression :

Compartiment incomplet (3 sous compartiments uniquement):

![za_modfortigate](../../images/superdelete/za_modfortigate.drawio.png)

![etat_cmp_preexecution](../../images/superdelete/etat_cmp_preexecution.png)

Après l'execution du script on observe que les workrequests ont échoués (Failed) :

![etat_cmp_postexecution](../../images/superdelete/etat_cmp_postexecution.png)

Il faut alors débugger pour voir les ressources problématiques en survolant l'icone "***i***", des ocids sont alors affichés et une recherche au niveau de l'environnement permettent alors de cibler les ressources problématiques, dans ce cas les "Topics" :

![etat_cmp_execution_suppression_topics](../../images/superdelete/etat_cmp_execution_suppression_topics.png)

Le script a bien lancé la suppression des topics "security-topic" et "network-topic", mais ceux-ci sont toujours en état "Deleting" càd en cours de suppression, il faut alors attendre que la suppression soit effective puis relancer le script de suppression:

![etat_cmp_execution2](../../images/superdelete/etat_cmp_execution2.png)

![etat_cmp_execution3](../../images/superdelete/etat_cmp_execution3.png)

Il est possible d'affirmer que la suppresion est effective une fois que la workrequest est complété avec succès :

![etat_cmp_postexecution-success](../../images/superdelete/etat_cmp_postexecution-success.png)

Et que le compartiment n'affiche plus aucune ressources :

![etat_cmp_postexecution-cmpts](../../images/superdelete/etat_cmp_postexecution-cmpts.PNG)

![etat_cmp_postexecution-vcns](../../images/superdelete/etat_cmp_postexecution-vcns.PNG)

![etat_cmp_postexecution-lbs](../../images/superdelete/etat_cmp_postexecution-lbs.PNG)

## FAQ   

### Please go to your home region XYZ to execute CREATE , UPDATE and DELETE operations

#### Contexte

Dans Cloud Shell ,je lance delete_policies.py avec ses trois parametres et j'ai erreur suivante  


![Please_go_to_your_home_region_XYZ_to_execute](../../images/superdelete/faq/Please_go_to_your_home_region_XYZ_to_execute.png)


#### Solution   

La région du Cloud Shell n'est pas la même que la région de déploiement des stratégies IAM.

Changez de région m assurez que ce sont les mŵmes régions , puis relancez le script delete_policies.py   


![solution_please_go_to_your_home_region_XYZ_to_execute](../../images/superdelete/faq/solution_please_go_to_your_home_region_XYZ_to_execute.JPG)

