#### Retour en arrière

* [Architecture des Zones d'accueil](architecture_za.md)
* [Paramétrage du déploiement](parametrage_deploiements.md)
* [Paramétrage de la Plateforme](parametrage_plateforme.md)
* [Page d'accueil](../Readme.md)

# Aperçu de l'abonnement Connectivité

L'abonnement Connectivité (*hub*) est au coeur de l'architecture des zones d'accueil en fournissant de manière sécuritaire l'accès à un nombre de services réseau communs, utilisés par les charges de travail déployées dans les zones d'accueil.

## 1. Rôle de l’abonnement Connectivité

L’architecture des ressources Plateforme et des zones d’accueil se base sur le cadre d'adoption infonuagique de Microsoft, pour sa conception, avec une approche de réseau en étoile [*hub and spoke*](https://docs.microsoft.com/fr-ca/azure/architecture/reference-architectures/hybrid-networking/hub-spoke?tabs=cli).

Dans cette topologie en étoile, l'abonnement de connectivité assume un rôle de concentrateur réseau (*hub*).

Les abonnements-plateforme **Gestion** et **Identité**, ainsi que les abonnements des zones d'accueil (**Données sensibles** et **Données non sensibles** pour le scénario "base"), sont organisés en tant que périphériques (*spoke*). Ils sont tous liés par des appairages réseau (*VNet peering*) à l’abonnement du concentrateur du réseau Connectivité (*hub*) ainsi qu'à l'abonnement "Périmètre". Les flux de communication entre les "spokes" passent toujours à travers le "hub", étant restreints par le biais des tables de routage et des contrôles d'accès niveau réseau ("NSG" en langage Azure).
Pour simplification, on présente cette architecture pour le scénario "base" :

![en voici le schéma](images/hub-spoke-network-topology-architecture.png)

Pour le scénario "complexe", c'est très similaire d'un point de vue de l'architecture, il y a juste plus de zones de charge en dessous d'une hiérarchie de groupes d'administration plus élaborée.

---

## 2. Les ressources spécifiques de l’abonnement Connectivité

Les ressources et services suivants peuvent être déployés dans l'abonnement Connectivité. Pour le scénario "base", la seule ressource nécessaire (pour le routage entre les *spokes*) est la passerelle du réseau privé virtuel (VPN).


| Ressource                         | Balise d'activation                       | Défaut | Commentaire                                                                                                                                                                                                                                                                                                                                                   |
| ----------------------------------- | ------------------------------------------- | --------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Passerelle VPN                    | var-platform-hub-deploy-VPNGW             | True    | Utilisée pour la communication entre l'environnement Azure et sur site (*on-prem*). Toutes les applications déployées dans les zones de charge communiquent sur site par le biais de cette passerelle. Aussi, le routage entre les zones de charge et les abonnements Identité et Gestion ont besoin de cette passerelle si le mode de routage est 'vpn'. |
| Passerelle ExpressRoute           | var-platform-hub-deploy-expressRouteGW    | False   | Onéreuse, elle est utilisée dans le cas où on veut une connectivité plus haute vitesse que celle fournie par un réseau privé virtuel (VPN).                                                                                                                                                                                                             |
| Zone DNS privée                  | var-platform-hub-deploy-privateDNS        | False   | Utilisée pour l'adressage des machines virtuelles déployées dans cet abonnement.                                                                                                                                                                                                                                                                           |
| Coffre-fort Azure de recouvrement | var-platform-hub-deploy-recoveryVault     | False   | Utilisé pour la sauvegarde des machines virtuelles déployées dans cet abonnement.                                                                                                                                                                                                                                                                          |
| Network Watcher                   | S/O                                       | S/O     | Le surveillant de réseau est utilisé pour le dépannage de la communication réseau.                                                                                                                                                                                                                                                                        |
| Bastion                           | var-platform-hub-deploy-bastion           | True    | Le bastion déployé dans Connectivité a accès à tous les*jump-box*.                                                                                                                                                                                                                                                                                       |
| Fortigate                         | var-platform-hub-deploy-Fortigate         | True    | Déployer FortiGate dans Connectivité.                                                                                                                                                                                                                                                                                                                       |
| Aiguilleur DNS intrant            | var-platform-hub-deploy-resolver-inbound  | False   | Permet l'accès DNS des charges de travail hors-Azure à la zone DNS interne dans la zone d'accueil Azure, par le biais d'un point d'entrée dans Azure.                                                                                                                                                                                                      |
| Aiguilleur DNS sortant            | var-platform-hub-deploy-resolver-outbound | False   | Permet l'accès DNS des charges de travail qui roulent dans la zone d'accueil Azure à des répertoires DNS externes à Azure, pour la résolution des noms DNS définis dans ces répertoires, comme des noms DNS des ressources sur site.                                                                                                                   |
| Règles d'acheminement DNS        | var-fw-domain-rules                       | False   | Définir ici les règles d'acheminement des requêtes DNS via l'aiguilleur sortant, par domaine spécifique ou pour tous les domaines non-résolus à l'interne.                                                                                                                                                                                              |

Note importante : dans le fichier de paramétrage, toujours laisser aux valeurs par défaut (false) les balises suivantes :

* var-platform-hub-deploy-appGateway : le déploiement de la passerelle applicative dans le *hub* n'est pas pris en charge.
* var-platform-hub-deploy-AzureFW : le déploiement du pare-feu Azure dans le *hub* n'est pas pris en charge.
* var-platform-hub-deploy-bastion : le déploiement du service Bastion dans le *hub* n'est pas pris en charge.

Voici une illustration détaillée de l'architecture de Connectivité. Pour les informations d'adressage, veuillez consulter le [plan d'adressage](plan_adressage.md).

Voici les groupes de ressources déployées par défaut dans l'abonnement Connectivité:


| Nom groupe de ressource      | Utilisation                                                                                                                                                                                                                   |
| ------------------------------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| NetworkWatcher_canadacentral | Le service Network Watcher est y déployé.                                                                                                                                                                                   |
| rg-agw-hub-prod-cac-001      | La passerelle applicative y est déployée.                                                                                                                                                                                   |
| rg-bastion-hub-prod-cac-001  | Le service Azure Bastion y est déployé.                                                                                                                                                                                     |
| rg-network-hub-prod-cac-001  | Le VNet vnet-hub-prod-cac-001 y est déployé avec la table de routage rt-hub-prod-cac-001, ainsi que le groupe de sécurité réseau nsg-snetshred-hub-001. Il en est de même pour les passerelles VPN et/ou Express Route. |
| rg-nva-hub-prod-cac-001      | Des applications virtuelles peuvent être déployées dans ce groupe de ressources. C'est ici que FortiGate est déployé.                                                                                                    |
| rg-prvdns-hub-prod-cac-001   | Le service "DNS privé" est y déployé, s'il est activé par la balise var-platform-hub-deploy-privateDNS.                                                                                                                   |
| rg-rsc-hub-prod-cac-001      | Le coffre-fort de recouvrement y est provisionné, s'il est activé par la balise var-platform-hub-deploy-recoveryVault.                                                                                                      |
| rg-dnsrslv-prod-cac-001      | Le groupe de ressource pour les points d'accès de aiguilleur DNS ("DNS Resolver").                                                                                                                                           |

Le VNet de l'abonnement Connectivité est apparié (*peering* en langage Azure) aux VNet dans les autres abonnements *spoke*, soit Gestion, Identité et Charges (pour le scénario "base Données sensibles, Données non sensibles et Non-prod).

![Connectivité](images/hub-spoke-network-topology-architecture_hub.png)

Les sous-réseaux déployées dans le réseau virtuel `vnet-hub-prod-cac-001`de l'abonnement Connectivité sont les suivantes:


| Nom défaut sous-réseau        | Plage d'adresse défaut | Description et commentaires                                                                                                           |
| --------------------------------- | ------------------------- | --------------------------------------------------------------------------------------------------------------------------------------- |
| GatewaySubnet                   | 10.84.0.0/24            | Réservé pour le déploiement de la passerelle VPN ou Express Route. Le nom est pré-défini et ne peut pas être changé            |
| AzureFirewallSubnet             | 10.84.2.0/24            | Réservé pour le déploiement du pare-feu Azure.                                                                                     |
| snetnva-ext-hub-prod-cac-001    | 10.84.4.0/26            | Utilisé pour les interfaces externes de Fortigate                                                                                    |
| snetnva-int-hub-prod-cac-001    | 10.84.4.64/26           | Utilisé pour les interfaces internes de Fortigate                                                                                    |
| snetnva-hasync-hub-prod-cac-001 | 10.84.4.128/26          | Utilisé pour les interfaces de synchronisation de Fortigate                                                                          |
| snetnva-mgmt-hub-prod-cac-001   | 10.84.4.192/26          | Utilisé pour les interfaces de gestion de Fortigate                                                                                  |
| snetdesserte-hub-prod-cac-001   | 10.84.6.0/23            | Réservé, non utilisée                                                                                                              |
| ApplicationGatewaySubnet        | 10.84.8.0/23            | Réservé pour le dépoliement de la passerelle VPN ou Express Route. Le nom est pré-défini et ne peut pas être changé            |
| AzureBastionSubnet              | 10.84.12.0/22           | Réservé pour le déploiement de l'équilibreur de charge applicatif Azure ("Application Gateway"). Le nom est pré-défini et fixe. |
| PrivateDnsResolverInbound       | 10.84.16.0/25           | Réservé pour le déploiement des points d'accès intrants du relais DNS.                                                            |
| PrivateDnsResolverOutbound      | 10.84.16.128/25         | Réservé pour le déploiement des points d'accès sortants du relais DNS.                                                            |

---

## 3. Le routage et les règles dans le pare-feu Azure (Azure Firewall) pour le concentrateur Connectivité (*hub*)

Par défaut, la table de routage rt-hub-prod-cac-001 dans le VNet Connectivité permet la communication avec l'environnement sur site (*on-prem*) par le biais de la passerelle du réseau virtuel privé (mais non par le biais de la passerelle Express Route), ainsi que l'accès à Internet par le biais du C/F dans l'abonnement Périmètre.

Toute la communication entre les VNet dans les abonnements *spoke* se fait par le "next-hop" fourni par la passerelle VPN déployée dans Connectivité.

Le routage est organisé de la manière illustrée dans le schéma ci-dessous, selon les principes suivants:

* Tout le routage entre les *spokes* se fait par l'interface locale de la passerelle VPN dans l'abonnement Connectivité (*hub*).
* Les routage est permis comme suit :
  * Entre le VNet dans l'abonnement Gestion et les VNet dans les *spokes* Charges de travail
  * Entre le VNet dans l'abonnement Identité et les VNet dans les *spokes* Charges de travail
  * Entre les VNET Gestion et Identité
  * Entre les VNet *spoke* (Gestion, Identité et Charges de Travail) et le réseau sur site
  * Entre le les VNet dans les abonnements "spoke" (Gestion, Identité et Charges de travail) et Internet par le biais du pare-feu dans l'abonnement Périmètre
  * Entre le VNet dans l'abonnement Connectivité ("hub") et Internet par le biais du pare-feu dans l'abonnement Périmètre

![SchémaRoutageAzureFirewall](images/hub-spoke-network-topology-architecture_hub_routage_1024px.png)

---

## 4. Le routage et les règles dans le pare-feu FortiGate pour le concentrateur Connectivité (*Hub*)

Voir la section documentaire pour [Paramétrage FortiGate](parametrage_fortigate.md).

## 5. L'acheminement des requêtes DNS intrantes et sortantes

Pour plus d'information par rapport à la fonctionnalité voir [Documentation Microsoft](https://learn.microsoft.com/en-us/azure/dns/tutorial-dns-private-resolver-failover). Le principe général est illustré dans le diagramme fournie par Microsoft:

![SchémaRoutageAzureFirewall](images/DNS_resolver_1.png)

L'acheminement intrant des requêtes sert à la résolution DNS dans Azure pas les charges de travail externes à Azure (par exemple sur site). C'est utile pour permettre à ces charges de travail d'accéder à des services Azure comme bases de données ou liens privés ("private link"). Le point d'entrée intrant est une interface virtuelle dans un sous-réseau Azure dédié.

L'acheminement sortant des requêtes sert à l'achemninement des requêtes DNS en provenance de charges de travail roulant en Azure vers des serveurs DNS hors-Azure, par exemple sur-site. Un cas typique d'usage est l'accès par nom DNS par les charges de travail roulant en Azure aux charges de travail roulant sur site ou à l'externe, via des noms DNS définis dans un répertoire DNS privé hors-Azure. Dans les cas de l'acheminement sortant il faut définir des règles d'acheminement, dans la variable de paramétrage```var-fw-domain-rules``` (exemple plus bas) et ces requêtes sortent à travers un point d'entrée sortant, qui est une interface virtuelle dans un sous-réseau dédié Azure. On peut également acheminer toutes les requêtes DNS vers l'externe en utilisant comme nom de domaine l'étoile. Il y a des règles de priorité qui sont appliquées par rapport à la résolution DNS:

* Si un nom DNS n'est pas connu dans la zone DNS privée définie dans la zone d'accueil, la requête est acheminée vers l'externe, tenant compte des règles d'acheminement.
* Dans les règles d'acheminement, un nom DNS plus spécifique prend précédence sur un nom moins spécifique (p.e. "*")

```
var-fw-domain-rules: >    [
      {
        "domainName": "cira.ca.",
        "targetDNS": [
          "172.19.121.10",
          "172.19.122.10"
        ]
      },
      {
        "domainName": "contoso.com.",
        "targetDNS": [
          "10.248.154.22",
          "10.248.154.170"
        ]
      },
      {
        "domainName": ".",
        "targetDNS": [
          "172.19.121.10",
          "172.19.121.11"
        ]
      }
    ] 
```

## 6.La passerelle ExpressRoute

La passerelle ExpressRoute permet une connexion plus performante d'un point de vue latence et vitesse du lien, cela par rapport à la passerelle de réseau virtuel. Quand même la passerelle ExpressRoute vient avec des requis supplémentaires

* On ne peut pas la déployer ensemble avec la passerelle VPN car il y a un seul sous-réseau GatewaySubnet.
* Requiert du routage eBGP entre l'environnement Azure et le réseau local sur-site ([Azure ExpressRoute: Routing requirements | Microsoft Learn](https://learn.microsoft.com/en-us/azure/expressroute/expressroute-routing))
* Tandis que la connexion VPN se fait directement entre l'environnement Azure et un pare-feu dans le réseau local sur site, dans le cas de l'ExpressRoute la connexion se fait (d'habitude) entre l'environnement Azure et l'environnement d'un fournisseur de service tiers, ce qui nécessite beaucoup plus de travail et délais, et amène une certaine manque de flexibilité.
* Le coût d'une connexion ExpressRoute est sensiblement plus élevé que celui d'une connexion VPN.

Le script provisionne juste la "coquille" de la passerelle ExpressRoute, tout autre paramétrage doit être fait en dehors du script, ensemble avec le fournisseur de service.

## 7. Liens rapides

Pour plus d'information, suivre les liens ci-dessous :

* [Pipelines de déploiement](etapes_deploiement.md)
* [Plan adressage](plan_adressage.md)
* [Routage](routage.md)
* [Paramétrage de la plateforme](parametrage_plateforme.md)
* [Paramétrage des Zones d'accueil](parametrage_za_charge.md)
* [Groupes de sécurité réseau](nsg.md)
* [Calculatrice de coûts Azure](https://azure.microsoft.com/fr-ca/pricing/calculator/)
