#### Retour en arrière

* [Aperçu de l'abonnement Plateforme Connectivité](connectivite.md)
* [Aperçu du paramétrage des zones d'accueil](parametrage_za_charge.md)
* [Page d'accueil](../Readme.md)

# Information sur le routage pour les zones d'accueil

Un mécanisme de routage est nécessaire pour permettre la communication entre les charges de travail dans les zones d'accueil et les services communs dans Plateforme, ainsi que pour en permettre l'accès vers (ou de) l'Internet. Ce mécanisme de routage est aussi en charge de fournir un niveau de sécurité par microsegmentation, en interdisant la communication entre des charges de travail à différents niveaux de sécurité.

## 1. Aperçu du routage pour les zones d'accueil

Le plan de routage introduit un premier niveau de sécurité, en interdisant la communication entre les zones d'accueil avec des niveaux de sécurité différents (par exemple entre Prod en Non-prod ou entre "Données sensibles" et "Données non sensibles"). Le routage est basé sur des règles statiques définies par usager (UDR) :


| De / À                | Gestion | Identité | Hub    | Périmètre | Données sensibles | Données non sensibles | Non-Prod |
| ------------------------ | --------- | ----------- | -------- | ----------- | -------------------- | ------------------------ | ---------- |
| Gestion                | S/O     | Permis    | Permis | Permis    | Permis             | Permis                 | Permis   |
| Identité              | Permis  | S/O       | Permis | Permis    | Permis             | Permis                 | Permis   |
| Données sensibles     | Permis  | Permis    | Permis | Permis    | S/O                | Interdit               | Interdit |
| Données non sensibles | Permis  | Permis    | Permis | Permis    | Interdit           | S/O                    | Interdit |
| Non-Prod               | Permis  | Permis    | Permis | Permis    | Interdit           | Interdit               | S/O      |

Le routage entre les "périphériques" (*spokes*), le *hub* et le "périmètre" est par défaut permis à cause des appairages (*peering*). Le routage interpériphérique (*inter-spoke*) se fait par l'entremise du "hub". Pour le scénario complexe, le routage est similaire et comporte une plus large diversité de périphériques (*spokes*).

![Plan de routage pour scénario "base"](images/Schema_architecture_reseau_ZA_Azure_v2.0.png)

---

## 2. Configuration du routage

Pour le scénario "base", les tables de routage sont définies dans le fichier [cei-base-routage.yml](../azure-pipeline/config/variables/scenario-base/cei-base-routage.yml) et pour le scénario "complexe" dans [cei-complexe-routage.yml](../azure-pipeline/config/variables/scenario-complexe/cei-complexe-routage.yml).

Ce fichier définit des règles basées sur des variables "préfixe" et "suffixe" des plages complètes d'adressage IP des abonnements Plateforme et Zones d'accueil. Dans le script, une plage d'adresse "destination" interne est identifiée par un préfixe (toujours un sous-réseau CIDR /16) et un suffixe (qui donne les derniers 2 chiffres du sous-réseau "destination" d'une route.

Il y a trois catégories de routage; pour chacune d'elles, le mode de routage et le "next-hop" sont configurables.

* Internet : toute plage d'adresse destination non hors les routes plus spécifiques (0.0.0.0/0)
* Client : routage vers l'environnement du client pour les plages dans ```var-client-local-network-prefix```
* Spoke : routage interne dans la zone d'accueil entre l'abonnement Gestion et les autres « spokes »

Pour chaque catégorie, le mode peut être :

* ```'nva'```: le routage se fait via une adresse ```'next-hop'``` d'un dispositif NVA comme FortiGate, Azure Firewall ou autre. Dans ce cas, la variable ```'next-hop'``` pour le mode en cause doit être configurée.
* ```'vpn'```: le routage se fait via la VPN Gateway. Dans ce cas, laisser la variable ```'next-hop'``` vide (```''```).

Pour que le mode de routage ```'nva'``` fonctionne, un dispositif NVA doit être provisionné, soit Azure Firewall (dans le *hub* ou le périmètre), soit FortiGate (dans le *hub*). Les valeurs ```'next-hop'``` à utiliser sont alors les suivantes, dans la variable var-platform-hub-egressVirtualApplianceIp :


| Dispositif NVA                     | Variable à mettre à 'true'          | Valeur de la variable var-platform-hub-egressVirtualApplianceIp |
| ------------------------------------ | --------------------------------------- | ----------------------------------------------------------------- |
| Pare-feu FortiGate dans le *hub*     | var-platform-hub-deploy-Fortigate     | var-platform-hub-egressFortigateIp                              |
| Azure Firewall dans le *hub*         | var-platform-hub-deploy-AzureFW       | var-platform-hub-egressAzureFirewallIp                          |
| Azure Firewall dans le périmètre | var-platform-perimetre-deploy-AzureFW | var-platform-perim-egressAzureFirewallIp                        |
| VPN Gateway comme NVA              | var-platform-hub-deploy-VPNGW         | var-platform-hub-egressVpnGatewayIp                             |

Important : La valeur de la variable var-platform-hub-egressVirtualApplianceIp doit être configurée en fonction du mode de routage, car cette variable est utilisée dans plusieurs pipelines.

Les variables qui contrôlent le mode de routage sont :

* ```var-mode-route-internet``` : 'nva' - par défaut routage Internet se fait via une NVA (p.e. Fortigate)
* ```var-mode-route-client```: 'nva' - par défaut routage Client se fait via une NVA (p.e. Fortigate) qui aussi fourni le tunnel VPN
* ```var-mode-route-spoke```: 'nva' - par défaut routage Spoke se fait via une NVA (p.e. Fortigate)

Les variables qui contrôlent le "next-hop" pour le mode de routage 'nva' sont :

* ```var-route-internet-nexthop```: par défaut ```$(var-platform-hub-egressVirtualApplianceIp)```
* ```var-route-spoke-nexthop```: par défaut ```$(var-platform-hub-egressVirtualApplianceIp)```
* ```var-route-client-nexthop```: par défaut ```$(var-platform-hub-egressVirtualApplianceIp)```

Les valeurs peuvent être définies quand même selon des besoins spécifiques.

---

## 3. Notes importantes

* Pour la plage d'adressage de l'environnement "hors-Azure" de l'OP ou de l'établissement (soit sur site, soit hébergé dans un autre nuage), le préfixe est variable et TOUJOURS à modifier par le client.
  C'est la variable ```var-client-local-network-prefix``` qui contient les préfixes réseau de l'environnement « on-site » connecté à la ZA Azure, utilisés pour générer les tables de routage. Valeur ```défaut``` à modifier au besoin :

```
 var-client-local-network-prefix: >
   [
     "100.64.0.0/10",
     "10.0.0.0/8", 
     "192.168.0.0/24", 
     "172.16.0.0/12"
   ]
```

* On déconseille de modifier les variables "préfixe" à moins d'un besoin imminent, par exemple un conflit d'adressage.
* On déconseille encore davantage de modifier les plages d'adresse assignées aux abonnements.
* Le routage par la passerelle VPN est pris en charge seulement pour des configurations qui prennent en compte les conditions suivantes :

  * Passerelle VPN déployée dans une seule zone de disponibilité (pas de haute disponibilité)
  * Un seul tunnel VPN établi ("connexion") entre Azure et l'environnement du client
* Le routage vers Internet est possible via le tunnel VPN et le pare-feu dans l'environnement du client, dans quel cas il faut configurer "[forced tunneling](https://learn.microsoft.com/en-us/azure/vpn-gateway/vpn-gateway-forced-tunneling-rm)" ainsi que la route "Internet" en mode 'vpn'.
* Dans le cas où il faut utiliser un autre dispositif de routage (par exemple une NVA), si les contraintes ci-haut ne répondent pas aux besoins de l'OP ou de l'établissement, il faut changer la configuration du routage en conséquence. Dans ce cas, il faut changer partout dans le fichier [cei-base-routage.yml](../azure-pipeline/config/variables/scenario-base/cei-base-routage.yml) le suffixe des variables nextHopIpAddress (qui pointent par défaut vers la première interface de la passerelle VPN). Par exemple :

```yaml
        {
          "name": "RouteGestToIdentite",
          "properties": {
            "addressPrefix": "$(var-platform-identite-virtualNetwork-ip-prefix)$(var-platform-identite-virtualNetwork-ip-suffix)", 
            "nextHopType": "VirtualAppliance",
            "nextHopIpAddress": "$(var-platform-hub-virtualNetwork-ip-prefix).0.6" <<== changer le "0.6"
          }
        }
```

Ces plages ne sont pas granulaires - les "destinations" des routes englobent la plage de l'ensemble des sous-réseaux et même davantage :


| Abonnement             | Variable préfixe                               | Par défaut         | Variable suffixe                                | Par défaut     | Commentaire              |
| ------------------------ | ------------------------------------------------- | ----------------- | ------------------------------------------------- | ------------- | -------------------------- |
| S/O                    | var-client-local-network-prefix                 | '100.64.0.0/10' | S/O                                             | S/O         | Via VPN vers hors-Azure  |
| Connectivité          | var-platform-hub-virtualNetwork-ip-prefix       | '10.84'         | S/O                                             | '0.0/17'    | Direct vers le "hub"     |
| Perimetre              | var-platform-perimetre-virtualNetwork-ip-prefix | '10.84'         | S/O                                             | '128.0/17'  | Direct vers le Périmètre |
| Gestion                | var-platform-gestion-virtualNetwork-ip-prefix   | '10.73'         | var-platform-gestion-virtualNetwork-ip-suffix   | '.128.0/17' | Vers Gestion             |
| Identité              | var-platform-identite-virtualNetwork-ip-prefix  | '10.73'         | var-platform-identité-virtualNetwork-ip-suffix | '.0.0/17'   | Vers Identité           |
| Données non sensibles | var-charges-virtualNetwork-ip-prefix            | '10.77'         | var-charges-nonsens-assigne-suffix              | '.64.0/18'  | Vers Non sensibles       |
| Données sensibles     | var-charges-virtualNetwork-ip-prefix            | '10.77'         | var-charges-sens-assigne-suffix                 | '.0.0/18'   | Vers sensibles           |
| Non-prod               | var-charges-virtualNetwork-ip-prefix            | '10.77'         | var-charges-nonprod-assigne-suffix              | '.128.0/17' | Vers Non-prod            |
