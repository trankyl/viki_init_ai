# Surveillance et renforcement de la posture de sécurité  

**Sommaire**

* [Paramètre de configuration par abonnement](#ParametreDeConfigurationParAbonnement)
* [Remarques importantes](#remarquesimportantes)


Pour la surveillance et le renforcement de la posture de sécurité, ```Microsoft Defender for Cloud``` sera activé avec la licence ```*Standard*``` pour certains contrôles de sécurité tels que la gestion des vulnérabilités, la conformité dans l’évaluation continue des actifs, l'activation des alertes lors de la détection des menaces. 

## <a id="ParametreDeConfigurationParAbonnement" ></a>Paramètre de configuration par abonnement

Voici les paramètres de configuration de Microsoft Defender par abonnement, dans le [scénario de base](../azure-pipeline/config/variables/scenario-base/cei-base-param.yml "scénario de base") :  


| Paramètre | Abonnement | Description |
| --------- |  --------- | ----------- |
| Serveur |  Tous les abonnements sauf Prod-Sensible  | Activation par le script de ```Microsoft Defender``` pour serveur, ```Plan 1``` : <br/> <ul><li>Microsoft Defender pour point de terminaison</li><li>Gestion des menaces et des vulnérabilités Microsoft</li><li>Intégration automatique d’agents, d’alertes et d’intégration de données</li></ul> |
| Serveur |  Prod-Sensible  | Activation par le script de ```Microsoft Defender``` pour serveur, ```Plan 2``` : <br/> <ul><li>Microsoft Defender pour point de terminaison</li><li>Gestion des menaces et des vulnérabilités Microsoft</li><li>Intégration automatique d’agents, d’alertes et d’intégration de données</li><li>Accès juste-à-temps aux machines virtuelles pour les ports de gestion</li><li>Détection des menaces de la couche réseau</li><li>Contrôles d’applications adaptatifs</li><li>Surveillance de l'intégrité du fichier</li><li>Sécurisation renforcée du réseau adaptative</li><li>Évaluation intégrée des vulnérabilités optimisée par Qualys</li><li>Ingestion gratuite de données Log Analytics 500 Mo</li></ul>  |
| Paramètre de l’environnement | Tous les abonnements | Déploiement, dans la zone d'accueil, d'un espace de travail dédié à la journalisation des événements de sécurité. <br/>Activation automatique des extensions suivantes : <ul><li>Agent Log Analytics pour les machines virtuelles Azure/Agent</li><li>Évaluation des vulnérabilités pour les machines </li></ul>  |
| Notification | Tous les abonnements | Définition d'une liste de distribution pour l’équipe de surveillance pour le type de notification élevée.  |
| DNS | Tous les abonnements | Le DNS est un service de communication et d’architecture vitale. La compromission de ce service peut avoir des impacts importants au niveau de la sécurité de la zone d’accueil. Microsoft Defender pour DNS détecte les activités suspectes et anomalies, par exemple :  <br/> <ul><li>Exfiltration de données à partir de vos ressources Azure via la tunnellisation DNS</li><li>Communication de programmes malveillants avec les serveurs de commande et de contrôle</li><li>Attaques DNS - Communication avec des programmes de résolution DNS malveillants</li><li>Communication avec des domaines utilisés pour des activités malveillantes telles que l’hameçonnage et le minage de cryptomonnaie</li></ul><br/> Pour plus d’information sur le fonctionnement du service DNS, voir le lien ci-après [Résolution de noms des ressources dans les réseaux virtuels Azure](https://learn.microsoft.com/fr-ca/azure/virtual-network/virtual-networks-name-resolution-for-vms-and-role-instances#azure-provided-name-resolution). |

   
## <a id="remarquesimportantes" ></a>Remarques importantes

* L’agent doit être installé sur tous les abonnements de la zone d’accueil.  
* Afin de nous limiter aux exigences minimales de sécurité, nous avons activé les deux fonctionnalités suivantes : 
    * Defender pour les serveurs plan 1 pour tous les abonnement et les serveurs plan 2 pour l’abonnement sensible. 
    * Microsoft Defender pour le service DNS appliqué à tous les abonnements.  
* L’activation de Microsoft Defender pour les autres types de ressources tels qu’App Service, les Bases de données, le Stockage, les Conteneurs et Azure Key Vaults est la responsabilité du client selon l’appréciation et l’appétit du risque. 
* L'activation de l'agent de vulnérabilité n'est pas encore prise en charge par les scripts Bicep et, par ricochet, ce n'est pas pris en charge dans la zone d'accueil. Par conséquent, une fois la zone d'accueil déployée, il faut ensuite appliquer manuellement cette [procédure](https://learn.microsoft.com/fr-ca/azure/defender-for-cloud/auto-deploy-vulnerability-assessment#automatically-enable-a-vulnerability-assessment-solution) pour l'**activation manuelle de l'agent de vulnérabilité** . ![activation_evaluation_vulnerabilite_vm](images/activation_evaluation_vulnerabilite_vm.png "Activation de l'agent de vulnérabilité pour les machines virtuelles actuelles et futures")