# Zone d'accueil AWS - Exigences de sécurité vs les politiques et les systèmes de surveillance

## Table des matières  

1. [L'anatomie sécuritaire du ASEA v155](#anatomie-sécuritaire-du-asea-v155)  
2. [Les services et les outils de sécurité implémentés par défaut](#les-services-et-les-outils-de-sécurité-implémentés-par-défaut-dans-asea-v155)
3. [Les services et les outils de sécurité que AWS peut fournir mais ne sont pas été implémentés par défaut](#les-services-et-les-outils-de-sécurité-que-aws-peut-fournir-mais-ne-sont-pas-été-implémentés-par-défaut-dans-asea-v155)
4. [Les stratégies incluses par défaut dans ASEA v155](#les-stratégies-incluses-par-défaut-dans-asea-v155)  
5. [Les journaux inclus par défaut dans ASEA v155](#les-journaux-inclus-par-défaut-dans-asea-v155)  
6. [Liaison de chaque exigence et ses contrôles avec leurs services et outils](#liaison-de-chaque-exigence-et-ses-contrôles-avec-leurs-services-et-outils)
7. [Risque de manque de sécurité et améliorations](#risque-de-manque-de-sécurité-et-améliorations)  

## Anatomie sécuritaire du asea v155

AWS Secure Environment Accelerator (AWS SEA) fournit des conseils et des outils pour aider les clients à mettre en œuvre les bonnes pratiques de sécurité sur leur infrastructure AWS. Bien que AWS SEA inclue pas mal de contrôles de sécurité par défaut, il fournit aussi des recommandations et des conseils sur la mise en œuvre de contrôles de sécurité basés sur les bonnes pratiques de sécurité AWS. Voici quelques-uns des contrôles de sécurité que AWS SEA mis en place et guide les clients à mettre en œuvre :  

1.Contrôles de sécurité réseau, tels que la mise en œuvre de contrôles d’accès réseau, la segmentation du réseau et l’utilisation des journaux de flux Amazon VPC.  
2.Contrôles IAM (Identity and Access Management), tels que la mise en œuvre de l’authentification multifacteur (MFA), de l’accès avec les privilèges minimum et de la rotation des clés d’accès.  
3.Contrôles de protection des données, tels que le chiffrement des données au repos et en transit, et la mise en œuvre de stratégies de compartiment Amazon S3 et de listes de contrôle d’accès.  
4.Contrôles de journalisation et de surveillance, tels que l’utilisation d’AWS CloudTrail et d’AWS Config pour surveiller les modifications des ressources AWS et la mise en œuvre d’alarmes AWS CloudWatch pour notifier les événements de sécurité potentiels.  
5.Contrôles de réponse aux incidents, tels que la création d’un plan de réponse aux incidents, le test du plan et la documentation du plan.  
6.Contrôles de gouvernance et de conformité, tels que l’utilisation d’AWS Organizations pour gérer plusieurs comptes AWS et appliquer des politiques de sécurité et la mise en œuvre de règles AWS Config pour garantir la conformité aux exigences réglementaires.  

AWS SEA fournit des modèles CloudFormation, des produits Service Catalog et des règles de configuration qui peuvent aider à automatiser la mise en œuvre de certains de ces contrôles de sécurité. Toutefois, il est important de noter que les contrôles de sécurité spécifiques mis en œuvre dépendront des exigences de chaque client et de la nature de son infrastructure AWS.

## Les services et les outils de sécurité implémentés par défaut dans asea v155

Les services et les outils de sécurité mis en œuvre par défaut dans AWS SEA 1.5.5 sont les suivants :  
  
1-AWS CloudTrail pour la journalisation et l’audit de l’activité et des événements de l’API AWS.  
2-Amazon GuardDuty pour la détection et la surveillance continuelles des menaces sur tous les comptes AWS.  
3-AWS Config pour le suivi de l’inventaire des ressources et des modifications sur tous les comptes AWS.  
4-AWS Security Hub pour l’agrégation et la hiérarchisation des alertes de sécurité et des conclusions de conformité sur tous les comptes AWS.  
5-AWS Identity and Access Management (IAM) pour la gestion de l’accès aux ressources AWS, y compris l’authentification multifacteur (MFA) et les stratégies d’autorisations.  
6-AWS Key Management Service (KMS) pour le chiffrement et la gestion des clés cryptographiques utilisées pour protéger les données au repos et en transit.  
7-Groupes de sécurité réseau et journaux de flux VPC pour surveiller et contrôler le trafic réseau entre les ressources AWS.  
8-Amazon Macie pour la découverte, la classification et la protection des données sensibles stockées dans des compartiments AWS S3.  
9-Inspecteur Amazon pour les évaluations de sécurité automatisées des instances et des applications EC2.  
10-Actions de correction automatisées, telles que les mises à jour de stratégie IAM et les terminaisons d’instance EC2, en fonction des événements et des résultats de sécurité détectés.  

Veuillez noter que les services et les outils de sécurité spécifiques mis en œuvre dans AWS SEA 1.5.5 peuvent varier aussi selon la configuration et les exigences spécifiques du OP.  

## Les services et les outils de sécurité que AWS peut fournir mais ne sont pas été implémentés par défaut dans ASEA v155  

Certains des services et des outils de sécurité qui sont disponibles dans AWS mais qui ne sont pas implémentés par défaut dans AWS SEA 1.5.5 incluent les suivants :  
  
1-AWS Shield Advanced pour la protection par déni de service distribué (DDoS) pour les applications Web s’exécutant sur AWS.  
2-AWS WAF (Web Application Firewall) pour protéger les applications Web contre les exploits Web courants.  
3-Amazon Cognito pour l’authentification et l’autorisation de l’utilisateur.  
4-Gestionnaire de certificats AWS pour la gestion des certificats SSL/TLS pour le trafic HTTPS.  
5-AWS Secrets Manager pour le stockage et la gestion des secrets tels que les informations d’identification de base de données, les clés API et les jetons OAuth.  
6-Amazon Detective pour analyser et enquêter sur les incidents de sécurité.  
7-AWS Firewall Manager pour la gestion et l’application centralisées des règles de pare-feu sur les comptes et les ressources AWS  
8-AWS Single Sign-On (SSO) pour la gestion centralisée de l’accès à plusieurs comptes et applications AWS.
9-Artefact AWS pour accéder aux rapports de conformité AWS et à d’autres artefacts d’audit.  
10-AWS CloudHSM pour le stockage de clés matérielles et les opérations cryptographiques.
  
Veuillez noter qu’il ne s’agit pas d’une liste exhaustive et que les OPs peuvent personnaliser leur déploiement ASEA pour inclure des services de sécurité supplémentaires et caractéristiques au besoin. De plus, certains de ces services peuvent être implémentés dans AWS SEA 1.5.5 en fonction de la configuration et des exigences spécifiques du OP.  

## Les stratégies incluses par défaut dans ASEA v155

Les politiques incluses dans AWS SEA 1.5.5 par défaut sont les suivants :  
1-Stratégies de gestion des identités et des accès (IAM) pour l’application de l’authentification et de l’autorisation sécurisées des utilisateurs sur les comptes et les ressources AWS.  
2-Stratégies de mot de passe pour l’application d’exigences de mot de passe fort pour les utilisateurs IAM.  
3-Politiques de chiffrement pour l’application du chiffrement des données au repos et en transit, y compris les exigences relatives aux algorithmes de chiffrement spécifiques et aux longueurs de clé.  
4-Stratégies de sécurité réseau pour contrôler le trafic réseau entrant et sortant entre les ressources AWS, y compris l’utilisation de groupes de sécurité, de listes de contrôle d’accès réseau et de journaux de flux VPC.  
5-Stratégies de journalisation pour activer la journalisation AWS CloudTrail sur tous les comptes AWS et configurer CloudTrail pour envoyer des journaux aux journaux Amazon S3 et CloudWatch pour le stockage et l’analyse.  
6-Surveillance des stratégies pour permettre la détection des menaces Amazon GuardDuty sur tous les comptes AWS et configuration de GuardDuty pour envoyer des résultats à AWS Security Hub pour l’analyse centralisée et l’établissement des priorités.  
7-Stratégies de conformité pour la configuration des règles de configuration AWS Config afin de surveiller et d’appliquer la conformité aux normes de l’industrie et aux exigences réglementaires, telles que le CIS AWS Foundations Benchmark et HIPAA.  
8-Stratégies de sauvegarde et de récupération pour la configuration des solutions de sauvegarde et de récupération AWS, telles que AWS Backup et Amazon S3 Glacier, pour protéger les données et contre la perte de données et les temps d’arrêt.  

Veuillez noter que les politiques spécifiques incluses dans AWS SEA 1.5.5 peuvent dépendre de la configuration spécifique du OP et les exigences. En outre, les OPs peuvent personnaliser leur déploiement AWS SEA pour inclure des stratégies et des configurations supplémentaires si nécessaire.  

## Les journaux inclus par défaut dans ASEA v155  

Les journaux inclus dans AWS SEA 1.5.5 par défaut sont les suivants :  
1-AWS CloudTrail enregistre pour capturer l’activité et les événements API sur tous les comptes et régions AWS.  
2-Journaux de configuration AWS pour le suivi de l’inventaire des ressources et des modifications dans tous les comptes et régions AWS.  
3-Journaux de flux VPC pour surveiller le trafic réseau entrant et sortant entre les ressources AWS.  
4-Amazon GuardDuty détecte les journaux de détection et d’alerte sur les menaces de sécurité potentielles sur tous les comptes AWS.  
5-AWS Security Hub génère des journaux de conclusions pour l’agrégation et la hiérarchisation des alertes de sécurité et des constatations de conformité sur tous les comptes AWS.  
6-AWS Backup journaux pour la surveillance des activités de sauvegarde et de récupération sur tous les comptes AWS.  
7-Amazon S3 journaux d’accès pour enregistrer toutes les demandes faites aux compartiments S3, y compris les demandes d’accès aux objets.  
En outre, les OPs peuvent personnaliser leur déploiement ASEA pour inclure des journaux et des configurations supplémentaires selon les besoins.  

## Liaison de chaque exigence et ses contrôles avec leurs services et outils  

  **Voici la liste des 12 exigences avec quelques explications :**

1. [Protéger les comptes racines](Doc/AWS_EX1234.md)
2. [Gérer les comptes ayant le privilège administrateur](Doc/AWS_EX1234.md)
3. [Limiter les accès à la console du nuage](Doc/AWS_EX1234.md)
4. [Définir les comptes de surveillance d’entreprise](Doc/AWS_EX1234.md)
5. [Déterminer la localisation des données](Doc/AWS_EX5.md)
6. [Protéger les données au repos](Doc/AWS_EX6.md)
7. [Protéger les données en transit](Doc/AWS_EX7.md)
8. [Segmenter et séparer les données selon leur sensibilité](Doc/AWS_EX8.md)
9. [Implémenter des services de sécurité réseau](Doc/AWS_EX9.md)
10. [Mettre en place des services de cyberdéfense](Doc/AWS_EX10.md)
11. [Implémenter la journalisation et la surveillance](Doc/AWS_EX11.md)
12. [Restreindre les accès aux produits de la place de marché infonuagique](Doc/AWS_EX12.md)

  **Basé sur ces exigences et leurs contrôles, nous allons faire le lien, vérifier si c'est intégré par défaut et si c'est en mode active ou non :**

1- **AC-2** Quel est le service AWS ou le nom de l’outil responsable de la gestion des comptes ?

Le service AWS responsable de la gestion des comptes est AWS Organizations. Les organisations AWS vous permettent de gérer et de contrôler de manière centralisée plusieurs comptes AWS, ce qui vous permet de créer et de gérer une structure de facturation consolidée, d’appliquer des stratégies pour un contrôle cohérent entre les comptes et de simplifier la création et la gestion des comptes. Ce service facilite la gestion de plusieurs comptes AWS au sein d’une organisation ou d’un groupe d’organisations. C'est intégré et en mode active dans notre zone d'accueil.

2- **AC-2(1)** Quel est le service AWS ou le nom de l’outil responsable des comptes de systèmes de gestion automatisés?

AWS fournit plusieurs services pour les systèmes de gestion automatisés, mais un service spécifique pour la gestion automatique des comptes est AWS Control Tower. AWS Control Tower automatise la configuration et la gestion d’un environnement AWS sécurisé et multi-comptes basé sur les meilleures pratiques. Il vous aide à automatiser l’approvisionnement des comptes, à appliquer des garde-fous pour assurer la conformité aux politiques et à simplifier la gestion continue grâce à un tableau de bord central. C'est intégré et en mode active dans notre zone d'accueil.
En outre, vous pouvez utiliser les organisations AWS pour la gestion des comptes et l’authentification unique (SSO) AWS pour centraliser la gestion des accès sur plusieurs comptes AWS et applications métier. C'est intégré et en mode active dans notre zone d'accueil.

3- **AC-3** Quel est le service AWS ou le nom de l’outil responsable de l’accès à l’application ?

AWS Single Sign-On (SSO) est le service responsable de la gestion de l’accès aux applications dans AWS. AWS SSO fournit un portail centralisé permettant aux utilisateurs d’accéder aux comptes, rôles et applications métier AWS qui leur sont attribués, rationalisant ainsi la gestion des accès dans l’ensemble de votre organisation. En utilisant AWS SSO, vous pouvez facilement gérer l’accès à plusieurs comptes et applications AWS et permettre à vos utilisateurs de se connecter avec leurs informations d’identification d’entreprise existantes pour accéder aux ressources et applications AWS qu’ils sont autorisés à utiliser. C'est intégré et en mode active dans notre zone d'accueil.

4- **AC-4** Quel est le service AWS ou le nom de l’outil responsable du contrôle de l’application de flux de données ?

AWS AppFlow est le service responsable du flux de données et du contrôle des applications. AWS AppFlow est un service d’intégration entièrement géré qui facilite le transfert sécurisé des données entre les services AWS et les applications Software as a Service (SaaS). Il vous permet de créer, d’exécuter et de gérer des flux de données sans avoir besoin d’un codage ou d’une maintenance approfondis de l’infrastructure sous-jacente. Avec AWS AppFlow, vous pouvez automatiser les flux de données, contrôler le mouvement des données et traiter les données pour prendre en charge divers cas d’utilisation, tels que l’analyse, les flux de travail pilotés par les événements et l’ingestion de lacs de données. C'est intégré et en mode active dans notre zone d'accueil.

5- **AC-5** Quel est le service AWS ou le nom de l’outil responsable de la séparation des tâches ?

AWS Step Functions est un service qui aide à la séparation et à la coordination des tâches. Il vous permet de coordonner et de gérer les composants des applications distribuées et des microservices à l’aide de flux de travail visuels. La fonction d’étapes vous permet de créer, de visualiser et d’exécuter des applications en plusieurs étapes en décomposant des processus complexes en tâches ou étapes individuelles, qui peuvent être orchestrées à l’aide d’ordinateurs d’état. À l’aide de la fonction d’étapes AWS, vous pouvez créer et coordonner des tâches, gérer la gestion des erreurs et surveiller l’exécution de vos workflows. Ce service s’intègre à divers services AWS, tels que AWS Lambda, Amazon ECS et Amazon SNS, pour vous aider à concevoir et à gérer plus efficacement les flux de travail d’applications complexes. C'est intégré et en mode active dans notre zone d'accueil.

6- **AC-6** Quel est le service AWS ou le nom de l’outil responsable des droits d’accès minimaux ?

AWS Identity and Access Management (IAM) est le service responsable de la gestion des droits d’accès, y compris l’application du principe du moindre privilège, ce qui signifie l’octroi des droits d’accès minimum nécessaires aux utilisateurs, aux rôles et aux applications. IAM vous permet de créer et de gérer des utilisateurs, des groupes et des rôles AWS, et d’utiliser des autorisations pour autoriser ou refuser leur accès aux ressources AWS. En utilisant IAM, vous pouvez appliquer le principe du moindre privilège en accordant aux utilisateurs et aux applications uniquement les autorisations dont ils ont besoin pour effectuer leurs tâches et rien de plus. Cela permet de réduire le risque d’accès et d’actions non autorisés dans votre environnement AWS. C'est intégré et en mode active dans notre zone d'accueil.

7- **AC-6(10)** Quel est le service AWS ou le nom de l’outil responsable d’empêcher les utilisateurs non privilégiés d’exécuter des fonctions privilégiées?

AWS Identity and Access Management (IAM) est le service responsable du contrôle de l’accès aux ressources et services AWS, notamment en empêchant les utilisateurs non privilégiés d’exécuter des fonctions privilégiées. IAM vous permet de créer et de gérer des utilisateurs, des groupes et des rôles avec des autorisations spécifiques qui déterminent les actions qu’ils peuvent effectuer et les ressources auxquelles ils peuvent accéder dans votre environnement AWS. En définissant et en appliquant des stratégies IAM, vous pouvez appliquer le principe du moindre privilège, en veillant à ce que les utilisateurs ne disposent que des autorisations dont ils ont besoin pour effectuer leurs tâches et rien de plus. Cela permet d’empêcher les utilisateurs non privilégiés d’exécuter des fonctions privilégiées, ce qui réduit le risque d’accès non autorisé et d’actions dans votre environnement AWS. C'est intégré et en mode active dans notre zone d'accueil.

8- **AC-7** Quel est le nom du service ou de l’outil AWS responsable du blocage automatique des comptes pour les tentatives de connexion infructueuses ?

Bien qu’il n’existe pas de service AWS unique spécialement conçu pour bloquer lescomptes en raison de l’échec des tentatives de connexion, vous pouvez créer une solution personnalisée à l’aide d’une combinaison de services AWS. Cela peut être fait en utilisant AWS CloudTrail, Amazon CloudWatch, AWS Lambda et AWS Identity and Access Management (IAM) comme suit :

- Activez AWS CloudTrail pour enregistrer les événements de connexion, y compris les tentatives de connexion infructueuses.
- Utilisez Amazon CloudWatch pour surveiller les  journaux CloudTrail et configurer un modèle d’alarme ou d’événement pour détecter plusieurs tentatives de connexion infructueuses.
- Créez une fonction AWS Lambda qui sera déclenchée par l’alarme ou l’événement CloudWatch. Cette fonctionnalité doit prendre les mesures appropriées pour bloquer ou désactiver le compte, telles que la modification des autorisations de l’utilisateur IAM ou l’activation de l’authentification multifacteur  (MFA).
- Configurez les autorisations nécessaires pour que la fonction Lambda interagisse avec IAM et effectue les actions requises.

En combinant ces services AWS, vous pouvez créer une solution personnalisée pour bloquer ou désactiver automatiquement les comptes en réponse à une série de tentatives de connexion infructueuses.

9- **AC-9** Quel est le service AWS ou le nom de l’outil responsable de fournir une notification de la dernière session ouverte ?

Il n’existe pas de service ou d’outil AWS spécifique conçu uniquement pour fournir des notifications de la dernière session ouverte. Cependant, vous pouvez créer une solution personnalisée à l’aide d’une combinaison de services AWS, tels que AWS CloudTrail, Amazon CloudWatch et Amazon Simple Notification Service (SNS) comme suit :

- Activez AWS CloudTrail pour enregistrer les événements de connexion et d’autres activités de l’utilisateur dans votre environnement AWS.
- Utilisez Amazon CloudWatch pour surveiller les journaux CloudTrail et configurez un modèle d’événement ou un filtre métrique pour détecter les événements de connexion.
- Configurez une alarme CloudWatch ou une règle d’événement pour déclencher une rubrique Amazon SNS lorsqu’un événement de connexion est détecté.
- Abonnez-vous à la rubrique SNS à l’aide de la méthode de notification souhaitée, telle que le courriel, le SMS ou un webhook.

En combinant ces services AWS, vous pouvez créer une solution personnalisée pour recevoir des notifications chaque fois qu’une nouvelle session est ouverte dans votre environnement AWS.

10- **AC-19** Quel est le service AWS ou le nom de l’outil responsable d’accès des appareils mobile?

Amazon WorkLink est un service AWS conçu pour fournir un accès mobile sécurisé aux sites Web internes et aux applications Web à partir d’appareils mobiles. Il permet aux utilisateurs d’accéder au contenu interne, tel que les sites intranet et les applications Web, sans avoir besoin de se connecter à un VPN ou d’utiliser des navigateurs personnalisés. Amazon WorkLink affiche le contenu dans le cloud et envoie une vue vectorielle entièrement interactive du contenu Web à l’appareil de l’utilisateur, garantissant ainsi que les données sensibles restent dans le réseau de votre organisation.

En utilisant Amazon WorkLink, vous pouvez fournir à vos employés un accès facile et sécurisé aux ressources internes à partir de leurs appareils mobiles tout en maintenant la sécurité et la conformité des données de votre organisation. C'est intégré et en mode active dans notre zone d'accueil.

11- **AC-20(3)** Quel est le service AWS ou le nom de l’outil responsable de la surveillance des systèmes d’information externes?

AWS ne fournit pas un service spécifique uniquement pour la surveillance des systèmes d’information externes. Toutefois, vous pouvez utiliser une combinaison de services AWS et d’outils tiers pour surveiller les systèmes externes en fonction de vos besoins.
Amazon CloudWatch, un service de surveillance et d’observabilité, peut être utilisé pour collecter, analyser et visualiser des mesures provenant de diverses sources, y compris des applications personnalisées et tierces. CloudWatch peut également s’intégrer à d’autres services AWS comme AWS Lambda, ce qui vous permet de créer des solutions personnalisées pour surveiller et répondre aux événements système externes.
En outre, vous pouvez utiliser Amazon API Gateway pour créer, publier et gérer des API pour des systèmes externes, puis surveiller l’utilisation et les performances de l’API à l’aide de CloudWatch.

Si vous avez besoin de fonctionnalités de surveillance plus avancées pour les systèmes externes, vous pouvez envisager d’utiliser des outils de surveillance tiers qui offrent des intégrations avec les services AWS. Certains outils de surveillance populaires incluent Datadog, New Relic et Splunk. Ces outils peuvent être utilisés pour surveiller et analyser les performances, la disponibilité et la sécurité des systèmes d’information externes en conjonction avec vos ressources AWS.  

12- **AU-2** Quel aws outil cloud ou service qui est responsable des événements vérifiables?
AWS EventBridge est le service responsable de la gestion des événements vérifiables dans l’écosystème AWS Cloud. AWS EventBridge est un bus d’événements sans serveur qui facilite la connexion d’applications à l’aide de données provenant de diverses sources, notamment les services AWS, les applications SaaS et les applications personnalisées. Il vous permet de créer des règles qui déclenchent des fonctions, envoient des messages ou d’autres actions en fonction des événements qui se produisent au sein de votre infrastructure.
À l’aide d’AWS EventBridge, vous pouvez créer une architecture pilotée par les événements qui répond aux événements vérifiables en temps réel, rendant vos applications plus réactives, résilientes et évolutives.

13- **AU-3** quel aws outil ou service cloud qui est responsable du contenu des enregistrements de vérification?
AWS CloudTrail est le service qui enregistre les appels d’API AWS, fournissant un historique d’activité dans votre compte AWS.

14- **AU-6** quel aws outil ou service cloud qui est responsable de l’analyse des rapports?
Amazon QuickSight est le service d’aide à la décision (BI) entièrement géré et sans serveur qui vous permet de créer et de partager des tableaux de bord interactifs, d’effectuer des analyses ad hoc et d’obtenir des informations à partir de vos données. QuickSight peut se connecter à diverses sources de données AWS comme Amazon S3, Amazon RDS, Amazon Redshift et Amazon Athena.

15- **AU-8** quel aws outil cloud ou service qui est responsable des horodatages?
Amazon CloudWatch est le service de surveillance et d’observabilité qui vous fournit des données et des informations exploitables. Les journaux et événements CloudWatch incluent des horodatages, ce qui peut vous aider à suivre le calendrier des événements et des incidents.

16- **AU-9** quel aws outil ou service cloud qui est responsable de la protection de la vérification des informations?
Pour la protection de la vérification des informations dans AWS, vous pouvez utiliser une combinaison de services et de meilleures pratiques pour garantir l’intégrité et l’authenticité de vos données. Voici quelques-uns de ces services :

- AWS Key Management Service (KMS) : service géré qui vous permet de créer et de contrôler facilement les clés de chiffrement utilisées pour chiffrer vos données. KMS garantit que vos informations sensibles sont protégées par le cryptage, qui est un aspect essentiel de la protection de la vérification des informations.

- Amazon Macie: Un service de sécurité et de confidentialité des données entièrement géré qui utilise l’apprentissage automatique pour découvrir, classer et protéger les données sensibles stockées dans Amazon S3. Macie peut vous aider à vous assurer que seuls les utilisateurs autorisés ont accès à des informations sensibles.

- Gestion des identités et des accès (IAM) AWS : service qui vous aide à contrôler en toute sécurité l’accès de vos utilisateurs aux ressources AWS. IAM vous permet de créer et de gérer des utilisateurs et des groupes AWS et d’utiliser des autorisations pour autoriser et refuser leur accès aux ressources AWS, garantissant ainsi que seuls les utilisateurs autorisés peuvent accéder à vos informations.

- AWS Certificate Manager (ACM) : Service qui vous permet de configurer, gérer et déployer facilement des certificats SSL/TLS (Secure Sockets Layer/Transport Layer Security) publics et privés. En utilisant des certificats SSL/TLS, vous pouvez garantir l’authenticité et l’intégrité des données transmises entre vos utilisateurs et vos applications.

- Amazon GuardDuty: Un service de détection des menaces qui surveille en permanence votre environnement AWS pour détecter les activités malveillantes et les comportements non autorisés.  GuardDuty peut vous aider à protéger vos informations en détectant les menaces de sécurité potentielles et en fournissant des recommandations de correction.

- AWS Shield : service de protection DDoS (Distributed Denial of Service) géré qui protège vos applications s’exécutant sur AWS. AWS Shield permet de garantir la disponibilité de vos informations en vous protégeant contre les attaques DDoS.

En utilisant ces services et en suivant les meilleures pratiques de sécurité, vous pouvez établir un système de protection de vérification des informations robuste dans votre environnement AWS.

17- **AU-9(4)** quel aws outil ou service cloud qui est responsable de l’accès par un sous-ensemble d’utilisateurs privilégiés?
AWS Identity and Access Management (IAM) est le service responsable de la gestion de l’accès par un sous-ensemble d’utilisateurs privilégiés dans l’écosystème AWS Cloud. IAM vous permet de créer et de gérer des utilisateurs et des groupes AWS, ainsi que d’appliquer des autorisations pour autoriser ou refuser leur accès aux ressources AWS.

18- **AU-12** quel aws outil ou service cloud qui est responsable de la génération d’enregistrements d’audit?
AWS CloudTrail est le service responsable de la génération d’enregistrements d’audit dans l’écosystème AWS Cloud. AWS CloudTrail est un service qui enregistre les appels d’API AWS pour votre compte et fournit des fichiers journaux à un paquet Amazon S3. Les informations enregistrées incluent l’identité de l’appelant API, l’heure de l’appel API, l’adresse IP source de l’appelant API, les paramètres de demande et les éléments de réponse retournés par le service AWS.

19 **CM-2** quel aws outil ou service cloud qui est responsable de la configuration de référence?
AWS CloudFormation est le service responsable de la gestion des configurations de référence dans l’écosystème AWS Cloud. AWS CloudFormation vous permet de modéliser et de provisionner des ressources d’infrastructure AWS à l’aide d’un fichier modèle, qui sert de configuration de référence pour la configuration de l’infrastructure souhaitée.

20- **CM-3** quel aws outil ou service cloud qui est responsable du contrôle des changements de configuration?
AWS Config est le service responsable de la gestion et du contrôle des modifications de configuration dans l’écosystème AWS Cloud. AWS Config surveille et enregistre en permanence vos configurations de ressources AWS et vous permet d’automatiser l’évaluation de ces configurations par rapport aux paramètres souhaités.

21- **CM-4** quel aws outil ou service cloud qui est responsable du contrôle des changements de configuration?
AWS Config est le service responsable de la gestion et du contrôle des modifications de configuration dans l’écosystème AWS Cloud. AWS Config surveille et enregistre en permanence vos configurations de ressources AWS et vous permet d’automatiser l’évaluation de ces configurations par rapport aux paramètres souhaités.

22- **CM-5** quel aws outil ou service cloud qui est responsable des restrictions d’accès concernant les changements?
AWS Identity and Access Management (IAM) est le service responsable de la gestion des restrictions d’accès concernant les changements dans l’écosystème AWS Cloud. IAM vous permet de créer et de gérer des utilisateurs, des groupes et des rôles AWS, et d’utiliser des autorisations pour autoriser ou refuser leur accès aux ressources et actions AWS.

23- **CM-8** quel aws outil ou service cloud qui est responsable de l’inventaire des composants du système d’information?
AWS Config est le service responsable de la maintenance d’un inventaire des composants du système d’information dans l’écosystème AWS Cloud. AWS Config surveille et enregistre en permanence les configurations de vos ressources AWS, vous fournissant une vue détaillée de votre inventaire de ressources.

24- **IA-2** quel outil ou service cloud aws qui est responsable de l’identification des organisations des utilisateurs?
AWS Identity and Access Management (IAM) est le principal service responsable de l’identification des utilisateurs et des organisations dans l’écosystème AWS Cloud. IAM vous permet de créer et de gérer des utilisateurs et des groupes AWS et d’utiliser des autorisations pour autoriser ou refuser leur accès aux ressources et actions AWS.

25- **IA-2(1)** quel aws outil ou service cloud qui est responsable de l’identification de l’accès réseau aux comptes privilégiés?
AWS ne dispose pas d’un seul service spécifiquement dédié à l’identification de l’accès réseau aux comptes privilégiés. Toutefois, vous pouvez utiliser une combinaison de services et de fonctionnalités AWS pour surveiller et contrôler l’accès réseau aux comptes privilégiés :

- Gestion des identités et des accès (IAM) AWS : IAM vous permet de créer et de gérer des utilisateurs, des groupes et des rôles AWS avec un contrôle d’accès affiné. Vous pouvez définir des comptes privilégiés avec des autorisations spécifiques et surveiller leur utilisation.
- Amazon Virtual Private Cloud (VPC) : VPC vous permet de créer une section logiquement isolée du cloud AWS où vous pouvez lancer des ressources AWS dans un réseau virtuel que vous définissez. Vous pouvez utiliser des groupes de sécurité et des listes de contrôle d’accès réseau (ACL) pour contrôler le trafic entrant et sortant vers vos ressources, y compris les comptes privilégiés.
- AWS CloudTrail: CloudTrail enregistre les appels de l’API AWS pour votre compte, fournissant un historique des activités. En analysant les journaux CloudTrail, vous pouvez identifier l’accès réseau aux comptes privilégiés, les adresses IP source et les actions effectuées.
- Amazon GuardDuty: GuardDuty est un service de détection des menaces qui surveille en permanence votre environnement AWS pour détecter toute activité malveillante et tout comportement non autorisé.  GuardDuty peut vous aider à identifier l’accès réseau non autorisé aux comptes privilégiés et vous alerter des menaces de sécurité potentielles.
- AWS Config : AWS Config vous permet de surveiller et d’enregistrer la configuration de vos ressources AWS, y compris les groupes de sécurité et les stratégies IAM associées aux comptes privilégiés. Vous pouvez utiliser des règles de configuration AWS pour définir les configurations souhaitées et détecter les ressources non conformes.

En tirant parti de ces services AWS ensemble, vous pouvez surveiller et contrôler efficacement l’accès réseau aux comptes privilégiés, garantissant que seuls les utilisateurs autorisés peuvent accéder aux ressources et aux actions critiques.

26- **IA-2(2) quel aws outil ou service cloud responsable de l’authentification multifacteur pour l’accès réseau aux comptes non privilégiés?
AWS Identity and Access Management (IAM) est le service responsable de la mise en œuvre de l’authentification multifacteur (MFA) pour l’accès réseau aux comptes privilégiés et non privilégiés dans l’écosystème AWS Cloud. Avec IAM, vous pouvez créer et gérer des utilisateurs, des groupes et des rôles AWS, et utiliser des autorisations pour autoriser ou refuser leur accès aux ressources et actions AWS.

27- **IA-2(11)** quel aws outil ou service cloud qui est responsable de l’identification et de l’authentification: Accès à distance - Périphérique séparé?
AWS Identity and Access Management (IAM) est le service responsable de la gestion de l’identification et de l’authentification pour l’accès à distance dans l’écosystème AWS Cloud, y compris l’utilisation de périphériques distincts. IAM vous permet de créer et de gérer des utilisateurs, des groupes et des rôles AWS, et d’utiliser des autorisations pour autoriser ou refuser leur accès aux ressources et actions AWS.
Pour améliorer la sécurité de l’accès à distance, vous pouvez activer l’authentification multifacteur (MFA) pour vos utilisateurs IAM. L’AMF exige que les utilisateurs présentent au moins deux formes distinctes d’identification (facteurs) dans le cadre du processus d’authentification. Dans le cas d’AWS, les utilisateurs fournissent généralement leur nom d’utilisateur et mot de passe (premier facteur) et un mot de passe unique à usage unique (OTP) généré par un matériel ou un périphérique MFA virtuel (deuxième facteur).
Le matériel ou le périphérique MFA virtuel sert de périphérique distinct dans ce contexte, offrant une couche de sécurité supplémentaire pour aider à protéger vos ressources AWS contre tout accès non autorisé. Les périphériques MFA matériels sont des périphériques physiques qui génèrent des OTPs, tandis que les périphériques MFA virtuels sont des applications logicielles, telles que Google Authenticator ou Authy, fonctionnant sur un appareil séparé comme un smartphone.

En utilisant iam avec MFA, vous pouvez implémenter l’identification et l’authentification pour l’accès à distance avec des périphériques distincts, assurant un niveau plus élevé de sécurité pour votre environnement AWS.

28- **IA-4** quel aws outil ou service cloud qui est responsable de la gestion des identifiants?
AWS Identity and Access Management (IAM) est le service responsable de la gestion des identifiants dans l’écosystème AWS Cloud. IAM vous permet de créer et de gérer des utilisateurs, des groupes et des rôles AWS, et d’utiliser des autorisations pour autoriser ou refuser leur accès aux ressources et actions AWS.
Avec IAM, vous pouvez attribuer des identifiants uniques aux utilisateurs, aux groupes et aux rôles, ce qui vous offre un moyen de suivre et de contrôler l’accès à vos ressources AWS. IAM prend en charge les types d’identificateurs suivants :

- Utilisateurs : identités uniques qui représentent une personne ou une application accédant à vos ressources AWS. Vous pouvez attribuer des clés d’accès individuelles, des mots de passe et des périphériques d’authentification multifacteur (MFA) aux utilisateurs.
- Groupes : collections d’utilisateurs IAM que vous pouvez utiliser pour gérer les autorisations collectivement. Vous pouvez affecter des stratégies à un groupe et tous les utilisateurs de ce groupe hériteront des autorisations.
- Rôles : identités IAM que vous pouvez supposer pour prendre temporairement des autorisations spécifiques. Les rôles peuvent être assumés par les utilisateurs IAM, les services AWS ou les identités externes via la fédération d’identités.
- IAM prend également en charge la fédération d’identités, vous permettant de gérer les identités et le contrôle d’accès dans des systèmes externes tels que votre annuaire d’entreprise, et de leur accorder l’accès aux ressources AWS à l’aide des fournisseurs d’identités SAML (Security Assertion Markup Language) ou OpenID Connect (OIDC).

À l’aide d’IAM, vous pouvez gérer efficacement les identificateurs des utilisateurs, des groupes et des rôles dans votre environnement AWS, en veillant à ce que les stratégies de contrôle d’accès et de gouvernance soient appliquées de manière cohérente dans l’ensemble de votre organisation.

29- **IA-5** quel aws outil ou service cloud qui est responsable de la gestion des identifiants?
AWS Identity and Access Management (IAM) est le service responsable de la gestion des identifiants dans l’écosystème AWS Cloud. IAM vous permet de créer et de gérer des utilisateurs, des groupes et des rôles AWS, et d’utiliser des autorisations pour autoriser ou refuser leur accès aux ressources et actions AWS.
Avec IAM, vous pouvez attribuer des identifiants uniques aux utilisateurs, aux groupes et aux rôles, ce qui vous offre un moyen de suivre et de contrôler l’accès à vos ressources AWS. IAM prend en charge les types d’identificateurs suivants :

- Utilisateurs : identités uniques qui représentent une personne ou une application accédant à vos ressources AWS. Vous pouvez attribuer des clés d’accès individuelles, des mots de passe et des périphériques d’authentification multifacteur (MFA) aux utilisateurs.
- Groupes : collections d’utilisateurs IAM que vous pouvez utiliser pour gérer les autorisations collectivement. Vous pouvez affecter des stratégies à un groupe et tous les utilisateurs de ce groupe hériteront des autorisations.
- Rôles : identités IAM que vous pouvez supposer pour prendre temporairement des autorisations spécifiques. Les rôles peuvent être assumés par les utilisateurs IAM, les services AWS ou les identités externes via la fédération d’identités.
- IAM prend également en charge la fédération d’identités, vous permettant de gérer les identités et le contrôle d’accès dans des systèmes externes tels que votre annuaire d’entreprise, et de leur accorder l’accès aux ressources AWS à l’aide des fournisseurs d’identités SAML (Security Assertion Markup Language) ou OpenID Connect (OIDC).

À l’aide d’IAM, vous pouvez gérer efficacement les identificateurs des utilisateurs, des groupes et des rôles dans votre environnement AWS, en veillant à ce que les stratégies de contrôle d’accès et de gouvernance soient appliquées de manière cohérente dans l’ensemble de votre organisation.

30- **IA-5(1)** quel aws outil ou service cloud responsable de l’authentification par mot de passe?
AWS Identity and Access Management (IAM) est le service responsable de la gestion de l’authentification par mot de passe dans l’écosystème AWS Cloud. IAM vous permet de créer et de gérer des utilisateurs, des groupes et des rôles AWS, et d’utiliser des autorisations pour autoriser ou refuser leur accès aux ressources et actions AWS.
Avec IAM, vous pouvez créer des comptes d’utilisateurs individuels, chacun avec son propre nom d’utilisateur et mot de passe unique. Les utilisateurs IAM peuvent s’authentifier avec leur mot de passe pour accéder à la console de gestion AWS, et vous pouvez attribuer des autorisations spécifiques pour contrôler leur accès aux ressources et actions AWS.
En outre, iam vous permet d’appliquer des stratégies de mot de passe pour vos utilisateurs. Vous pouvez définir les exigences de complexité de mot de passe, la longueur minimale du mot de passe, l’expiration du mot de passe et les modifications de mot de passe requises. Cela permet de s’assurer que votre environnement AWS respecte les stratégies de sécurité et les meilleures pratiques de votre organisation pour l’authentification par mot de passe.

En utilisant iAM pour l’authentification par mot de passe, vous pouvez gérer efficacement l’accès des utilisateurs à vos ressources AWS tout en maintenant la sécurité et la conformité avec les stratégies de votre organisation.

31- **IA-5(6)** quel aws outil ou service cloud qui est responsable de la protection des authentificateurs?
AWS Identity and Access Management (IAM) est le principal service responsable de la protection des authentificateurs dans l’écosystème AWS Cloud. IAM vous permet de créer et de gérer des utilisateurs, des groupes et des rôles AWS, et d’utiliser des autorisations pour autoriser ou refuser leur accès aux ressources et actions AWS.

L’IAM fournit divers mécanismes pour protéger les authentificateurs :

- Authentification multifacteur (MFA) : L’IAM vous permet d’activer l’AMF pour les utilisateurs, ce qui nécessite une couche de sécurité supplémentaire au-delà d’un simple nom d’utilisateur et d’un mot de passe. Les utilisateurs doivent fournir un mot de passe à usage unique (OTP) généré par un matériel ou un périphérique MFA virtuel pour s’authentifier.
- Clés d’accès : Pour l’accès par programme aux services AWS, les utilisateurs IAM reçoivent des clés d’accès composées d’un ID de clé d’accès et d’une clé d’accès secrète. IAM fournit les meilleures pratiques pour gérer en toute sécurité les clés d’accès, telles que la rotation régulière des clés et ne pas les intégrer dans le code.
- Service d’émission de jeton sécurisé (STS) : au lieu d’utiliser des clés d’accès à long terme, vous pouvez utiliser AWS STS pour générer des informations d’identification de sécurité temporaires pour les utilisateurs, offrant un accès limité aux ressources pendant une durée spécifiée. Cela réduit le risque associé aux fuites ou aux informations d’identification compromises.
- Rôles : les rôles IAM vous permettent d’accorder temporairement des autorisations aux utilisateurs ou aux services sans avoir à émettre d’informations d’identification à long terme. Cela permet de minimiser le risque d’accès non autorisé en raison d’informations d’identification compromises.
- Fédération d’identités : IAM prend en charge la fédération des identités à partir de systèmes externes, tels que votre annuaire d’entreprise, à l’aide de fournisseurs d’identités SAML (Security Assertion Markup Language) ou OpenID Connect (OIDC). Cela vous permet de gérer l’authentification et le contrôle d’accès de manière centralisée dans vos systèmes existants, réduisant ainsi le risque d’accès non autorisé.

En tirant parti de ces fonctionnalités dans IAM, vous pouvez protéger efficacement les authentificateurs dans votre environnement AWS, garantissant un accès sécurisé à vos ressources et la conformité aux stratégies de votre organisation.

32- **IA-6** quel aws outil ou service cloud qui est responsable des commentaires d’authentification?
Dans l’écosystème AWS Cloud, il n’existe pas de service spécifique uniquement dédié à la fourniture de commentaires d’authentification. Toutefois, les commentaires d’authentification peuvent être obtenus en surveillant et en analysant les journaux générés par divers services AWS qui gèrent les événements d’authentification. Deux services principaux qui peuvent fournir des commentaires d’authentification sont :

- AWS CloudTrail : CloudTrail enregistre les appels de l’API AWS pour votre compte, qui comprend des événements d’authentification pour la console de gestion AWS et l’accès à l’interface de ligne de commande AWS. En analysant les journaux CloudTrail, vous pouvez collecter des informations sur les tentatives d’authentification réussies et infructueuses, y compris l’utilisateur, l’adresse IP source et la raison de l’échec, le cas échéant. Ces données vous aident à obtenir des informations sur l’authentification des utilisateurs et à identifier les risques de sécurité potentiels.
- Analyseur d’accès AWS Identity and Access Management (IAM) : IAM Access Analyzer est un service qui vous aide à identifier les ressources de votre organisation et de vos comptes, tels que les compartiments Amazon S3 ou les rôles IAM, qui sont partagés avec une entité externe. Bien qu’il ne fournisse pas directement de commentaires d’authentification, il vous aide à analyser et à surveiller les stratégies d’accès aux ressources, ce qui vous permet d’identifier les accès involontaires et d’améliorer votre posture de sécurité.

En utilisant AWS CloudTrail et IAM Access Analyzer, vous pouvez obtenir des commentaires d’authentification qui vous aident à surveiller et à améliorer la sécurité de votre environnement AWS.

33- **IA-8** quel aws outil ou service cloud qui est responsable de l’identification et de l’authentification
 pour les utilisateurs non organisationnels?
AWS Identity and Access Management (IAM) est le service responsable de la gestion de l’identification et de l’authentification pour les utilisateurs non organisationnels dans l’écosystème AWS Cloud. Outre la gestion des utilisateurs, des groupes et des rôles AWS, IAM prend en charge la fédération d’identités, qui vous permet d’accorder l’accès aux ressources AWS pour les utilisateurs gérés en dehors d’AWS.
Pour les utilisateurs non organisationnels, vous pouvez tirer parti de l’IAM pour l’intégrer aux fournisseurs d’identités externes (IdP) à l’aide de SAML (Security Assertion Markup Language) ou d’OIDC (OpenID Connect). Ces PDI peuvent être des fournisseurs d’identité sociale, tels que Google, Facebook ou Amazon, ou des fournisseurs d’ESE tiers.
En mettant en place la fédération d’identités avec des IdP externes, vous pouvez permettre aux utilisateurs non organisationnels de s’authentifier auprès de leurs comptes existants et d’obtenir un accès temporaire à vos ressources AWS en fonction des autorisations que vous définissez.
Grâce à l’IAM et à la fédération d’identités, vous pouvez gérer efficacement l’identification et l’authentification pour les utilisateurs non organisationnels, garantissant un accès sécurisé à vos ressources AWS tout en maintenant la conformité avec les stratégies de votre organisation.

34- **SA-22** quel aws outil ou service cloud responsable des composants système non pris en charge?
AWS ne dispose pas d’un service ou d’un outil spécifique dédié à la gestion des composants système non pris en charge. Cependant, vous pouvez utiliser divers services AWS et meilleures pratiques pour vous assurer que votre infrastructure est mise à jour et sécurisée, minimisant ainsi les risques associés aux composants non pris en charge. Voici quelques-uns de ces services et pratiques :

- AWS Systems Manager : Systems Manager vous aide à gérer vos instances, à la fois sur site et dans le cloud, en fournissant une interface unifiée pour des tâches telles que la gestion des correctifs, l’automatisation et la gestion de la configuration. Vous pouvez utiliser System Manager pour mettre à jour et gérer vos instances, en les maintenant conformes aux stratégies de votre organisation et en réduisant le risque de composants non pris en charge.
- AWS Config : AWS Config vous permet de surveiller et de suivre la configuration de vos ressources AWS en continu. En mettant en place des règles pour vérifier les configurations spécifiques, vous pouvez identifier les ressources avec des composants ou des configurations non pris en charge et prendre les mesures appropriées.
- AWS Trusted Advisor : Trusted Advisor est un service qui fournit des conseils en temps réel pour vous aider à provisionner vos ressources en suivant les meilleures pratiques AWS. Il vérifie votre environnement AWS pour les problèmes potentiels liés aux performances, à la sécurité, à l’optimisation des coûts, etc. Trusted Advisor peut vous aider à identifier les instances qui exécutent des versions de logiciels obsolètes ou non prises en charge.
- AWS Security Hub : Security Hub est un service qui vous fournit une vue complète de votre état de sécurité dans AWS. En consolidant les résultats de sécurité de divers services AWS, il vous aide à identifier et à corriger les problèmes de sécurité, y compris ceux liés aux composants système non pris en charge.

En utilisant ces services AWS conjointement avec les meilleures pratiques de maintenance et de mise à jour de votre infrastructure, vous pouvez minimiser les risques associés aux composants système non pris en charge et garantir un environnement sécurisé et conforme.

35- **SC-5** quel aws outil ou service cloud qui est responsable de la protection contre le déni de service?
AWS fournit plusieurs services et fonctionnalités qui peuvent aider à protéger vos applications et votre infrastructure contre les attaques par déni de service (DoS) et par déni de service distribué (DDoS) :

- AWS Shield : AWS Shield est un service de protection DDoS géré qui protège vos applications s’exécutant sur AWS. AWS Shield est disponible en deux niveaux: Standard et Advanced. AWS Shield Standard est automatiquement activé pour tous les clients AWS et offre une protection contre les attaques DDoS courantes. AWS Shield Advanced offre des capacités de détection et d’atténuation supplémentaires, un accès 24/7 à l’équipe DDoS Response Team (DRT) AWS et une protection contre les coûts contre les pics d’utilisation liés à DDoS.
- Amazon CloudFront: CloudFront est un service de réseau de diffusion de contenu (CDN) qui permet d’accélérer la diffusion de votre contenu aux utilisateurs. En mettant en cache et en servant du contenu à des emplacements de périphérie, CloudFront peut aider à absorber et à atténuer les attaques DDoS avant qu’elles n’atteignent vos serveurs d’origine.
- AWS Web Application Firewall (WAF) : AWS WAF est un service de pare-feu d’application Web qui permet de protéger vos applications Web contre les exploits Web courants, y compris les attaques DDoS de la couche application. Vous pouvez créer des règles personnalisées pour bloquer ou autoriser le trafic en fonction de conditions spécifiques, telles que les adresses IP, les en-têtes HTTP ou la taille de la demande.
- Amazon Route 53: Route 53 est un service Web DNS (Domain Name System) évolutif qui peut aider à protéger vos applications contre les attaques DDoS de niveau DNS en distribuant des requêtes sur plusieurs emplacements de périphérie et en mettant en cache des réponses DNS.
- Amazon Virtual Private Cloud (VPC) : avec Amazon VPC, vous pouvez créer une section logiquement isolée du cloud AWS où vous pouvez lancer des ressources AWS dans un réseau virtuel que vous définissez. Vous pouvez utiliser des groupes de sécurité VPC et des listes de contrôle d’accès réseau (ACL) pour contrôler le trafic entrant et sortant vers vos ressources, ce qui permet d’atténuer les attaques DDoS potentielles.

En tirant parti de ces services AWS et en suivant les meilleures pratiques en matière d’architecture et de sécurité, vous pouvez protéger vos applications et votre infrastructure contre les attaques par déni de service dans AWS Cloud.

36- **SC-7** quel aws outil ou service cloud qui est responsable de la protection des frontières?
AWS fournit plusieurs services et fonctionnalités qui vous aident à protéger les limites de votre infrastructure cloud, souvent appelée protection des frontières. Ces services vous aident à gérer et à sécuriser l’entrée et la sortie des données entre votre environnement AWS et les réseaux externes :

- Amazon Virtual Private Cloud (VPC) : Amazon VPC vous permet de créer une section logiquement isolée du cloud AWS où vous pouvez lancer des ressources AWS dans un réseau virtuel que vous définissez. VPC vous permet de contrôler l’accès à vos ressources en configurant des groupes de sécurité et des listes de contrôle d’accès réseau (ACL), qui agissent comme des pare-feu au niveau de l’instance et des sous-réseaux, respectivement.
- AWS Web Application Firewall (WAF) : AWS WAF est un service de pare-feu d’application Web qui aide à protéger vos applications Web contre les exploits Web courants, y compris les attaques ciblant les points d’entrée de votre application. Vous pouvez créer des règles personnalisées pour bloquer ou autoriser le trafic en fonction de conditions spécifiques, telles que les adresses IP, les en-têtes HTTP ou la taille de la demande.
- Pare-feu réseau AWS : AWS Network Firewall est un service de pare-feu réseau géré qui vous permet de déployer une sécurité réseau granulaire sur vos VPCs Amazon. Avec le pare-feu réseau, vous pouvez créer des règles de pare-feu avec état ou sans état, implémenter la prévention et la détection des intrusions et filtrer le trafic en fonction des noms de domaine ou des adresses IP.
- AWS Direct Connect : AWS Direct Connect est un service qui établit une connexion réseau dédiée entre votre centre de données local et AWS, en contournant l’Internet public. Cette connexion dédiée fournit une connexion réseau plus sécurisée et fiable, aidant à protéger la frontière entre vos environnements sur site et cloud.
- Amazon Route 53: Amazon Route 53 est un service Web DNS (Domain Name System) hautement disponible et évolutif qui aide à gérer les requêtes DNS pour votre domaine, agissant comme point d’entrée de vos ressources AWS. Route 53 fournit des caractéristiques de sécurité telles que DNSSEC, qui aide à protéger l’intégrité des données DNS en signant numériquement des réponses de DN.

En utilisant ces services AWS et en suivant les meilleures pratiques en matière de sécurité et d’architecture réseau, vous pouvez implémenter efficacement la protection des frontières pour votre infrastructure cloud, garantissant ainsi un accès sécurisé à vos ressources AWS.

37- **SC-7(5)** Quel outil ou service cloud AWS responsable du refus par défaut / Autorisation par exception ?
AWS Identity and Access Management (IAM) est le service responsable de la mise en œuvre du principe de « refus par défaut / autorisation par exception » dans l’écosystème AWS Cloud. IAM vous permet de créer et de gérer des utilisateurs, des groupes et des rôles AWS, et d’utiliser des autorisations pour autoriser ou refuser leur accès aux ressources et actions AWS.
Dans IAM, les autorisations sont gérées à l’aide de stratégies, qui sont des documents JSON qui définissent des actions, des ressources et des conditions spécifiques. Par défaut, tous les utilisateurs et rôles de votre compte AWS n’ont accès à aucune ressource ou action AWS. Vous devez accorder explicitement des autorisations aux utilisateurs, aux groupes ou aux rôles en leur attachant des stratégies.
Cette approche suit le principe du moindre privilège, garantissant que les utilisateurs et les rôles n’ont accès qu’aux ressources et aux actions requises pour leurs tâches, minimisant ainsi le risque d’accès non autorisé ou d’actions involontaires.
En utilisant IAM pour gérer les autorisations, vous pouvez implémenter efficacement « Refus par défaut / Autorisation par exception » pour vos ressources AWS, garantissant ainsi un accès sécurisé et la conformité aux stratégies de votre organisation.

38- **SC-8** Quel outil ou service cloud AWS responsable de la confidentialité et de l’intégrité des transmissions?
Il existe de multiples services et fonctionnalités qui aident à assurer la confidentialité et l’intégrité des transmissions de données:

- AWS Key Management Service (KMS) : AWS KMS est un service géré qui vous permet de créer et de gérer facilement des clés cryptographiques et de contrôler leur utilisation sur un large éventail de services et d’applications AWS. KMS aide à protéger vos données en les chiffrant en transit et au repos, en garantissant la confidentialité et l’intégrité de vos données.
- AWS Certificate Manager (ACM) : ACM est un service qui simplifie le ravitaillement, la gestion, et le déploiement des certificats SSL/TLS (Secure Sockets Layer/Transport Layer Security) pour une utilisation avec des services AWS et vos ressources connectées internes. Les certificats SSL/TLS permettent une communication sécurisée entre vos utilisateurs et vos applications, assurant ainsi la confidentialité et l’intégrité des données en transit.
- Amazon Virtual Private Cloud (VPC) : Avec Amazon VPC, vous pouvez configurer un réseau privé dans AWS où vous pouvez lancer des ressources dans un réseau virtuel que vous définissez. Vous pouvez utiliser des groupes de sécurité VPC et des listes de contrôle d’accès réseau (ACL) pour contrôler le flux de données entre vos ressources, garantissant ainsi l’intégrité de vos transmissions de données.
- VPN AWS: AWS VPN fournit une connectivité sécurisée et privée entre vos réseaux locaux et vos VPCs, garantissant la confidentialité et l’intégrité de vos transmissions de données dans différents environnements. AWS VPN se compose de deux services : AWS Site-to-Site VPN et AWS Client VPN.
- Amazon CloudFront: Amazon CloudFront est un service de réseau de diffusion de contenu (CDN) qui accélère la livraison de votre contenu aux utilisateurs. CloudFront prend en charge HTTPS pour chiffrer les données entre vos utilisateurs et le CDN, garantissant ainsi la confidentialité et l’intégrité des transmissions de données.

En tirant parti de ces services AWS et en suivant les meilleures pratiques en matière de sécurité et de transmission de données, vous pouvez garantir la confidentialité et l’intégrité de vos données lorsqu’elles se déplacent dans et à travers votre environnement AWS.

39- **SC-8(1)** Quel outil ou service cloud AWS responsable de la protection cryptographique ou physique ?
AWS offre plusieurs services et fonctionnalités qui fournissent une protection cryptographique et physique pour vos données et votre infrastructure :

**Protection cryptographique :**

- Service de gestion des clés AWS (KMS) : AWS KMS est un service géré qui vous permet de créer et de gérer des clés cryptographiques et de contrôler leur utilisation sur divers services et applications AWS. KMS aide à protéger vos données en les chiffrant au repos et en transit, garantissant ainsi la confidentialité et l’intégrité de vos données.
- Gestionnaire de certificats AWS (ACM) : ACM simplifie l’approvisionnement, la gestion et le déploiement des certificats SSL/TLS (Secure Sockets Layer/Transport Layer Security) à utiliser avec les services AWS et vos ressources connectées internes. Les certificats SSL/TLS permettent une communication sécurisée entre vos utilisateurs et vos applications, assurant ainsi la confidentialité et l’intégrité des données en transit.

**Protection physique :**

- Centres de données AWS : les centres de données AWS sont conçus et gérés pour fournir un environnement hautement sécurisé pour vos données et votre infrastructure. Les mesures de sécurité physique comprennent le contrôle d’accès, la surveillance, les gardes de sécurité et plusieurs niveaux de sécurité du périmètre. Les centres de données AWS sont également conçus en gardant à l’esprit la redondance et la résilience, garantissant la disponibilité et la fiabilité de vos ressources.
- Amazon GuardDuty: Bien qu’il ne soit pas directement lié à la protection physique, Amazon GuardDuty est un service de détection des menaces qui surveille en permanence votre environnement AWS pour détecter les activités malveillantes ou non autorisées. En analysant diverses sources de données, GuardDuty peut vous aider à détecter les menaces ciblant votre infrastructure, ce qui contribue indirectement à la sécurité physique globale de vos ressources AWS.

En utilisant ces services AWS et en suivant les meilleures pratiques de sécurité, vous pouvez assurer la protection cryptographique et physique de vos données et de votre infrastructure dans le cloud AWS.

40- **SC-12** Quel outil ou service cloud AWS responsable de l’établissement et de la gestion des clés cryptographiques?
AWS Key Management Service (KMS) est le service AWS responsable de l’établissement et de la gestion des clés cryptographiques. AWS KMS est un service géré qui vous permet de créer, de contrôler et de gérer facilement des clés cryptographiques utilisées pour le chiffrement des données sur un large éventail de services et d’applications AWS.
Avec AWS KMS, vous pouvez :

- Créez, importez et gérez des clés cryptographiques (également appelées clés principales client ou CMK).
Définissez des stratégies d’utilisation des clés pour contrôler l’accès à vos clés.
- Faites pivoter les touches automatiquement ou manuellement, selon les besoins.
- Surveillez et auditez l’utilisation des clés avec AWS CloudTrail, qui enregistre les appels de l’API AWS KMS pour votre compte.
- Utilisez le chiffrement d’enveloppe pour protéger de grandes quantités de données avec une combinaison de clés de données et de CMK.
- Utilisez AWS KMS avec d’autres services AWS, tels qu’Amazon S3, Amazon RDS et Amazon Redshift, pour activer le chiffrement au repos à l’aide de vos CMK.
- Générez des clés de données pour le chiffrement côté client ou côté serveur de vos données.
En utilisant AWS KMS pour la gestion des clés cryptographiques, vous pouvez protéger vos données avec un cryptage fort et suivre les meilleures pratiques pour la gestion des clés, garantissant la sécurité et la conformité de votre environnement AWS.

## Risque de manque de sécurité et améliorations  

1- Comment activer ou désactiver AWS Shield Advanced pour le déni de service distribué (DDoS) ?
AWS Shield Advanced est un service géré qui offre une protection améliorée contre les attaques par déni de service distribué (DDoS) pour vos applications s’exécutant sur AWS.
Pour activer AWS Shield Advanced, procédez comme suit :

- Connectez-vous à la console de gestion AWS : accédez à <https://aws.amazon.com/> et connectez-vous à l’aide de vos informations d’identification.
- Accédez à AWS Shield: Dans le menu « Services », recherchez « Shield » et cliquez dessus pour ouvrir le tableau de bord AWS Shield.
- Activer AWS Shield Advanced : sur la page d’accueil d’AWS Shield, vous trouverez une option pour activer AWS Shield Advanced. Cliquez sur « Activer AWS Shield Advanced » ou « Abonnez-vous à AWS Shield Advanced. »
- Sélectionner des ressources : choisissez les ressources que vous souhaitez protéger avec AWS Shield Advanced. Vous pouvez protéger les distributions Amazon CloudFront, les équilibreurs de charge élastiques, Amazon Route 53 hébergeait des zones et des accélérateurs AWS Global Accelerator. Ajoutez chaque ressource en sélectionnant son ID de ressource AWS correspondant.
- Choisissez AWS WAF web ACLs (facultatif) : Si vous utilisez AWS WAF avec vos ressources protégées, vous pouvez associer des listes de contrôle d’accès Web AWS WAF (ACL Web) aux ressources. Cette étape est facultative et dépend de votre cas d’utilisation et de vos exigences spécifiques.
- Passez en revue et activez AWS Shield Advanced : passez en revue vos sélections et cliquez sur « Activer AWS Shield Advanced » pour terminer le processus. Une fois AWS Shield Advanced activé, vos ressources sélectionnées recevront une protection DDoS améliorée, y compris l’accès à l’équipe de réponse DDoS (DRT), la protection des coûts pour la mise à l’échelle et des diagnostics d’attaque plus détaillés.

N’oubliez pas qu’AWS Shield Advanced entraîne des coûts supplémentaires au-delà de la protection AWS Shield de base, qui est automatiquement incluse pour tous les clients AWS. Assurez-vous de consulter les détails des prix avant d’activer AWS Shield Advanced: <https://aws.amazon.com/shield/pricing/>

Pour plus d’informations, reportez-vous à la documentation officielle d’AWS Shield : <https://docs.aws.amazon.com/waf/latest/developerguide/shield-chapter.html>

2- Comment activer AWS WAF (Web Application Firewall)?
Pour activer AWS WAF (Web Application Firewall) pour votre application Web, procédez comme suit :

- Connectez-vous à la console de gestion AWS : accédez à <https://aws.amazon.com/> et connectez-vous à l’aide de vos informations d’identification.
- Accédez à AWS WAF: Dans le menu « Services », recherchez « WAF » ou « Pare-feu d’application Web » et cliquez dessus pour ouvrir le tableau de bord AWS WAF.
- Créez un ACL web : Cliquez sur « Créer l’ACL de Web » pour démarrer le processus.
- Configurez les configurations de WEB ACL :
a. Donnez un nom à votre ACL Web et choisissez la région AWS correcte.
 b. Choisissez le type de ressource que vous souhaitez protéger (une distribution Amazon     CloudFront ou un équilibreur de charge d’application).
  c. Sélectionnez la ressource que vous voulez associer à cet ACL de Web.
- Ajouter des règles et des groupes de règles : vous pouvez créer vos propres règles personnalisées ou utiliser les règles gérées AWS, qui sont des ensembles de règles prédéfinis fournis par AWS.
- Ajoutez des règles ou des groupes de règles qui répondent à vos besoins, tels que le blocage de mauvaises adresses IP connues, des attaques par injection SQL ou des attaques XSS (Cross-site Scripting).
- Configurer les actions de règle : Pour chaque règle, vous devez configurer une action à prendre lorsque les conditions de la règle sont remplies. Vous pouvez choisir d’autoriser, de bloquer, ou comptez les demandes qui correspondent aux conditions de la règle.
- Configurer l’action par défaut : définissez l’action par défaut pour les demandes qui ne correspondent à aucune condition de règle. Vous pouvez choisir d’autoriser ou de bloquer toutes ces demandes.
- Passez en revue et créez l’ACL web : Passez en revue vos configurations d’ACL de Web, et cliquez sur « Créez l’ACL de Web » pour terminer le processus d’installation.

Une fois que vous avez créé l’ACL web, AWS WAF commencera à inspecter les demandes entrantes à votre application Web basée sur les règles que vous avez configurées. Vous pouvez surveiller et analyser les métriques WAF dans Amazon CloudWatch et apporter des ajustements à vos règles si nécessaire.
Pour plus d’informations et des guides étape par étape, reportez-vous à la documentation officielle AWS WAF: <https://docs.aws.amazon.com/waf/latest/developerguide/getting-started.html>

3- Comment activer Amazon Cognito?

Amazon Cognito fournit l’authentification, l’autorisation et la gestion des utilisateurs pour vos applications Web et mobiles. Pour activer et configurer Amazon Cognito, procédez comme suit :

- Connectez-vous à la console de gestion AWS : accédez à <https://aws.amazon.com/> et connectez-vous à l’aide de vos informations d’identification.
- Accédez à Amazon Cognito: Dans le menu « Services », recherchez « Cognito » et cliquez dessus pour ouvrir le tableau de bord Amazon Cognito.
- Créer un pool d’utilisateurs Cognito (pour la gestion des utilisateurs) :
a. Cliquez sur « Gérer les pools d’utilisateurs », puis cliquez sur « Créer un pool d’utilisateurs ».
b. Entrez un nom pour votre pool d’utilisateurs et cliquez sur « Examiner les paramètres par défaut » ou configurez les paramètres en fonction de vos besoins.
c. Passez en revue les paramètres et cliquez sur « Créer un pool ».

- Créez un pool d’identités Cognito (pour l’authentification et l’autorisation) :

a. Revenez au tableau de bord Amazon Cognito et cliquez sur « Gérer les pools d’identités ».
b. Cliquez sur « Créer un nouveau pool d’identités ».
c. Entrez un nom pour votre pool d’identités.
d. Sous « Fournisseurs d’authentification », configurez les fournisseurs que vous souhaitez utiliser pour l’authentification (par exemple, Pools d’utilisateurs Cognito, Facebook, Google, etc.). Pour les pools d’utilisateurs Cognito, entrez l’ID de pool d’utilisateurs et l’ID client d’application du pool d’utilisateurs que vous avez créé à l’étape 3.
e. Cliquez sur « Créer un bassin ».

- Configurer les rôles et les autorisations : après avoir créé le pool d’identités, vous serez invité à configurer des rôles et des autorisations. AWS créera automatiquement deux rôles par défaut, un pour les utilisateurs authentifiés et un pour les utilisateurs non authentifiés. Vous pouvez personnaliser les rôles et les autorisations selon vos besoins.
- Intégrez Amazon Cognito à votre application : utilisez les extraits de code AWS SDK fournis ou les bibliothèques Amplify pour intégrer Amazon Cognito dans votre application Web ou mobile. Cela vous permettra d’authentifier les utilisateurs et de gérer leur accès aux ressources de votre application.

Pour plus d’informations détaillées et des guides étape par étape, reportez-vous à la documentation officielle Amazon Cognito:
<https://docs.aws.amazon.com/cognito/latest/developerguide/what-is-amazon-cognito.html>

4- Comment activer AWS Certificate Manager?

AWS Certificate Manager (ACM) est un service qui vous permet de configurer, gérer et déployer facilement secure sockets layer/transport public et privé, certificats de sécurité de couche (SSL/TLS) à utiliser avec les services AWS et vos ressources internes connectées.
Pour activer et utiliser AWS Certificate Manager, procédez comme suit :

- Connectez-vous à la console de gestion AWS : accédez à <https://aws.amazon.com/> et connectez-vous à l’aide de vos informations d’identification.

- Accédez au gestionnaire de certificats AWS : Dans le menu « Services », recherchez « Gestionnaire de certificats » ou « ACM » et cliquez dessus pour ouvrir le tableau de bord du Gestionnaire de certificats AWS.

- Demandez un nouveau certificat :
a. Cliquez sur « Commencer » sous « Provisionner les certificats » ou cliquez sur le bouton « Demander un certificat ».
b. Choisissez entre « Demander un certificat public » et « Demander un certificat privé » en fonction de vos besoins.
c. Entrez le(s) nom(s) de domaine que vous souhaitez sécuriser avec le certificat (par exemple, example.com, *.example.com).
d. Cliquez sur « Suivant ».

- Choisissez une méthode de validation : sélectionnez « Validation DNS » ou « Validation par courriel » pour votre certificat. La validation DNS est recommandée car elle est plus facile pour mettre en place et entretenir. Suivez les instructions à l’écran pour terminer le processus de validation.
- Examiner et demander : Passez en revue votre demande de certificat et cliquez sur « Confirmer et demander » pour soumettre la demande.
- Validez le certificat (si nécessaire) : Si vous avez choisi la validation du courriel, vérifiez l’adresse e-mail associée à l’enregistrement du domaine pour un e-mail de validation d’ACM.
- Cliquez sur le lien dans le courriel et suivez les instructions pour valider le certificat. Pour la validation DNS, suivez les instructions fournies par ACM pour ajouter le enregistrements DNS requis pour la configuration DNS de votre domaine.
- Attendez l’émission du certificat : Une fois le processus de validation terminé, ACM émettra votre certificat. Ce processus peut prendre de quelques minutes à quelques heures. Vous pouvez surveiller l’état sur le tableau de bord ACM.
- Utilisez le certificat avec les services AWS : Une fois votre certificat émis, vous pouvez l’utiliser avec les services AWS qui prennent en charge ACM, tels qu’Amazon CloudFront, Elastic Load Balancing, Amazon API Gateway, et plus encore. Quand vous configurez ces services, vous pouvez sélectionner le certificat de l’ACM.

Veuillez noter qu’il n’est pas nécessaire d'activer ACM en tant qu’étape distincte, car il est toujours disponible dans votre compte AWS. Il vous suffit de demander et de gérer les certificats selon les besoins de vos applications.

Pour plus d’informations détaillées et des guides étape par étape, reportez-vous à la documentation officielle du gestionnaire de certificats AWS :
<https://docs.aws.amazon.com/acm/latest/userguide/acm-overview.html>

5- Comment activer AWS Secrets Manager?

AWS Secrets Manager est un service qui vous aide à protéger l’accès à vos applications, services et ressources informatiques en gérant et en faisant pivoter vos secrets en toute sécurité.
tels que les informations d’identification de base de données, les jetons à la demande et les clés API. Pour utiliser AWS Secrets Manager, procédez comme suit :

Connectez-vous à la console de gestion AWS : accédez à <https://aws.amazon.com/> et connectez-vous à l’aide de vos informations d’identification.

Accédez à AWS Secrets Manager : dans le menu « Services », recherchez « Gestionnaire de secrets » et cliquez dessus pour ouvrir le tableau de bord AWS Secrets Manager.

Stockez un nouveau secret:
un. Cliquez sur « Stocker un nouveau secret ».
b. Choisissez le type de secret que vous souhaitez stocker, tel que les informations d’identification d’une base de données RDS, DocumentDB ou les paires clé-valeur.
c. Remplissez les informations requises, telles que le nom d’utilisateur et le mot de passe, ou les paires clé-valeur.
d. Cliquez sur « Suivant ».

Nommez et décrivez votre secret :
un. Fournissez un nom secret et une description facultative.
b. Cliquez sur « Suivant ».

Configurer la rotation automatique (facultatif) :
un. Vous pouvez activer la rotation automatique pour votre secret en cliquant sur la case à cocher « Activer la rotation automatique ».
b. Choisissez l’intervalle de rotation (p. ex., 30 jours, 60 jours ou personnalisé).
c. Sélectionnez ou créez une fonction AWS Lambda pour la rotation. AWS fournit des exemples de fonctions Lambda de rotation pour diverses bases de données.
d. Cliquez sur « Suivant ».

Passez en revue et stockez le secret : passez en revue vos paramètres secrets et cliquez sur « Stocker » pour enregistrer le secret dans AWS Secrets Manager.

Maintenant, vous avez stocké un secret dans AWS Secrets Manager. Vous pouvez utiliser le SDK, l’interface de ligne de commande ou l’API AWS pour récupérer et utiliser le secret dans vos applications.
Cela vous aide à éviter le codage en dur d’informations sensibles dans votre code d’application ou vos fichiers de configuration.

N’oubliez pas qu’AWS Secrets Manager engage des coûts supplémentaires en fonction du nombre de secrets que vous stockez et du nombre d’appels API que vous effectuez pour gérer et récupérer les secrets.
Assurez-vous de consulter les détails des prix avant d’utiliser Secrets Manager: <https://aws.amazon.com/secrets-manager/pricing/>

Pour plus d’informations détaillées et des guides étape par étape, reportez-vous à la documentation officielle d’AWS Secrets Manager :
<https://docs.aws.amazon.com/secretsmanager/latest/userguide/intro.html>

[Début de la page](#table-des-matières)
