# Azure Off Hours scripts V2

**But** : On aimerait, si c'est possible, être capable de fermer les ressources qui consomment le plus, donc après analyse :

- **VMs**
- Azure Firewall
- Vpn Gateway
- Azure Bastion

---
## Comment fermer les VMs en dehors des heures voulues 
[référence](https://learn.microsoft.com/en-us/azure/azure-functions/start-stop-vms/overview)
</br>

Nous pouvons utiliser une ressource disponible dans le Azure Marketplace qui s'appelle **Start/Stop VMs v2**. Il s'agit d'une nouvelle solution qui remplace la V1, et qui utilise les *Azure Functions* et les *Logic Apps*.
- Cette ressource nous permet entre-autres de fermer des VMs selon un schedule créé dans l'application
- Permet aussi de voir des statistiques dans un *Dashboard* afin de savoir le nombre de VMs fermées, le nombre d'actions par resource group, etc.
- On peut aussi décider d'envoyer des alertes par courriel pour notifier lorsque des actions sont faites sur les VMs.
- Permet aussi d'utiliser la fonction *Autostop* pour fermer des VMs ou des Azure Resource Manager selon la consommation du CPU.

Configuration
- On doit spécifier un abonnement ainsi qu'un Resource Group. Le resource group créé contiendra toutes les fonctionnalités.
- Ici la fonctionnalité qu'on veut mettre en oeuvre est sous
  - "start-stop-resource-group" > ststv2_vms_Scheduled_stop
  - On clique sur edit
  - On entrera dans le *Logic Apps Designer*, qui nous permet de modifier les paramètres de l'horaire pour fermer les VMs.
  - On peut spécifier une *VM* en particulier ou un *Resource Group* en particulier ou encore un *Subscription* en particulier pour y appliquer les actions.
  - C'est aussi dans le *Logic Apps Designer* que nous allons spécifier l'horaire pour lequel les VMs seront fermées.

---
## Comment fermer Azure Bastion en dehors des heures voulues
https://www.reddit.com/r/AZURE/comments/idqkq0/saving_money_when_using_azure_bastion_by_using/?utm_source=BD&utm_medium=Search&utm_name=Bing&utm_content=PSR1

Encore à voir, mais potentiellement nous pourrions utiliser le même *Logic App* que celui pour fermer les VMs afin de fermer Azure Bastion pendant la nuit. 

Si cela fonctionne on pourrait aussi le réouvrir le matin.

## Comment fermer le Azure Firewall en dehors des heures voulues
https://richardsoncloud.com/reduce-azure-firewall-costs/

Si nous n'avons pas besoin du Azure Firewall en dehors des heures de travail (dans l'environnement de développement par exemple), il y a un moyen de procéder ainsi.

- Nous pouvons essayer de *deallocate* le Azure Firewall le soir puis le *allocate* le lendemain.
- Pour l'automatiser de cette façon, les technologies qui peuvent être pertinentes sont 
  - Azure Logic Apps 
  - Azure Automation
  - Azure functions 
- [Lien pertinent](https://stackoverflow.com/questions/53414671/azure-logic-apps-how-to-run-powershell-script-or-azure-cli)