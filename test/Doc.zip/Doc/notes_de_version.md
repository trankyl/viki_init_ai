# Notes de version du script de déploiement de la zone d'accueil Azure

version 2.2

---

De nouvelles fonctionnalités, des améliorations de fonctionnalités existantes et des corrections ont été apportées dans la version 2.2.

---

## Parmi les plus importantes nouvelles fonctionnalités :

* Soutien pour le scénario "complexe" (type "entreprise") avec les mêmes fonctionnalités que dans le scénario "de base"
* Rajout soutien "*jumpbox*" dans les abonnements Gestion, Identité et zones de charges, pour accès sécuritaire aux ressources dans ces zones sans avoir besoin d'assigner des adresses IP publiques aux instances VM
* Rajout soutien "[Network Watcher](https://learn.microsoft.com/en-us/azure/network-watcher/network-watcher-monitoring-overview)" dans tous les abonnements pour le dépannage et l'investigation des flux réseau
* Rajout soutien "[Traffic Analytics](https://learn.microsoft.com/en-us/azure/network-watcher/traffic-analytics)" et "[NSG Flow](https://learn.microsoft.com/en-us/azure/network-watcher/network-watcher-nsg-flow-logging-overview)"
* Rajout soutien pour plusieurs préfixes réseau du réseau local pour le routage flexible vers le sur site ("*on-prem*")
* Rajout soutien pour le routage flexible en utilisant soit la passerelle VPN, soit un NVA comme FortiGate, Azure Firewall ou autre
* Rajout soutien pour Azure Defender (Servers et DNS) dans les abonnements de Gestion, Identité et zones de charges
* Rajout soutien C/F FortiGate pour le routage et le pare-feu, avec déploiement automatique et configuration simplifiée

## Parmi les améliorations et corrections

* Élimination de quelques problématiques connues et corrigées manuellement dans la version précédente du script :

  * Positionnement correct de l'abonnement "Données sensibles" en dessous du bon groupe d'administration
  * Positionnement correct du groupe d'administration Expérimentation en dessous du groupe "racine" à la place du "tenant"
  * Syntaxe correcte des ports dans les définitions NSG (les numéros de port entourés de guillemets doubles). Cela demandait des corrections manuelles, sinon cela pouvait amener un échec des déploiements.
  * Élimination du conflit de noms des déploiements et rajout de dépendances pour éviter que le script échoue à cause de "race conditions".
  * Rajout du sous-réseau Bastion dans VNet du "*hub*" permettant le déploiement d'Azure Bastion
* Paramétrage de l'ID du groupe d'administration racine basé sur l'ID de l'organisation
* Correction du domaine ("scope") d'assignation des stratégies et des initiatives, en remplaçant le *hardcodage*
* Clarification de la nomenclature pipelines et templates, en éliminant le dédoublement des noms
* Clarification de la nomenclature de configurations par scénario et communes entre les scénarios
* Réduction des situations possibles causant des erreurs à cause de conflits de noms dans le cadre des contraintes d'unicité de nom à l'échelle d'une organisation ("tenant") :

  * Les noms des déploiements actifs simultanément
  * Les noms des groupes d'administration
  * Les noms des groupes de ressources dans le même abonnement
  * Les noms des tables de routage dans le même groupe de ressources
  * Les noms des définitions de stratégies et/ou initiatives

  Aussi
  * Les noms des groupes de ressources dans le même abonnement
  * Les noms des tables de routage dans le même groupe de ressources

Pour plus de détails, voir :

* [Notes sur les changements au niveau du paramétrage v2.2 vs v2.0](notes_de_parametrage.md)
* [Notes sur la procédure et les contraintes de mise à niveau de v2.0 à v2.2](notes_de_mise_a_niveau.md)
* [Notes sur la procédure de nettoyage](notes_nettoyage.md)