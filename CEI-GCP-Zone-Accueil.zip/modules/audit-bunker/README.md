# Audit Log Bunker
Ce module est compatible avec les exigences de la zone d'accueil de GCP et est utilisé pour satisfaire les mesures de sécurités de stockage de journal de 30-jour. Ce module crée un projet d'audit avec une ou plusieurs piscines/buckets de journal organisationnelles qui peuvent être filtrés pour stocker des journaux spécifiques.
<!-- BEGINNING OF PRE-COMMIT-TERRAFORM DOCS HOOK -->

## Exigences

| Nom                                                                       | Version |
|---------------------------------------------------------------------------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | >= 0.14.4 |

## Fournisseur

Pas de fournisseur

## Modules

| Nom                                                                           | Source                             | Version |
|-------------------------------------------------------------------------------|------------------------------------|---------|
| <a name="module_audit"></a> [audit](#module\_audit)                           | [./modules/audit](./modules/audit) | n/a |
| <a name="module_audit_project"></a> [audit\_project](#module\_audit\_project) | [../project](../project)                     | 1.3.2 |

## Resources

Pas de resources.

## Entrées

| Nom                                                                                                                                | Description                                                                                      | Type | Défaut | Requis |
|------------------------------------------------------------------------------------------------------------------------------------|--------------------------------------------------------------------------------------------------|------|--------|:------:|
| <a name="input_additional_user_defined_string"></a> [additional\_user\_defined\_string](#input\_additional\_user\_defined\_string) | String aditionnel défini par l'usager                                                            | `string` | `""`   |  non   |
| <a name="input_audit_streams"></a> [audit\_streams](#input\_audit\_streams)                                                        | Dictionnaire de buckets pour stocker les journaux d'audit                                        | `map(any)` | n/a    |  oui   |
| <a name="input_billing_account"></a> [billing\_account](#input\_billing\_account)                                                  | Id de compte de facturation                                                                      | `string` | `null` |  non   |
| <a name="input_department_code"></a> [department\_code](#input\_department\_code)                                                  | Code de département utilisé pour le nommage                                                      | `string` | n/a    |  oui   |
| <a name="input_environment"></a> [environment](#input\_environment)                                                                | P = Prod, N = NonProd, S = SandBox, etc.                                                         | `string` | n/a    |  oui   |
| <a name="input_org_id"></a> [org\_id](#input\_org\_id)                                                                             | ID de l'organisation pour mettre les récepteurs                                                  | `string` | n/a    |  oui   |
| <a name="input_owner"></a> [owner](#input\_owner)                                                                                  | Propriétaire du projet                                                                           | `string` | `""`   |  non   |
| <a name="input_parent"></a> [parent](#input\_parent)                                                                               | Dossier de parent ou organisation dans format de 'folders/folder\_id' ou 'organizations/org\_id' | `string` | `null` |  non   |
| <a name="input_region"></a> [region](#input\_region)                                                                               | Région de bucket                                                                                 | `string` | n/a    |  oui   |
| <a name="input_user_defined_string"></a> [user\_defined\_string](#input\_user\_defined\_string)                                    | String défini par l'usager                                                                       | `string` | n/a    |  oui   |

## Sorties

| Nom                                                                        | Description                            |
|----------------------------------------------------------------------------|----------------------------------------|
| <a name="output_log_sinks"></a> [log\_sinks](#output\_log\_sinks)          | Récepteur de journal de l'organisation |
| <a name="output_project_id"></a> [project\_id](#output\_project\_id)       | ID de projet d'audit                   |
| <a name="output_sink_buckets"></a> [sink\_buckets](#output\_sink\_buckets) | Buckets de récepteurs      |
<!-- END OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
