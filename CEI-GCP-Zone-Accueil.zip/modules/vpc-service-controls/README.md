# Module du contrôle de service de VPC dans GCP

Ce module a été conçu pour travailler avec les exigences de la zone d'accueil de GCP

Afin de comprendre mieux comment utiliser ce module, réviser la documentation GCP pour [Access Context
Manager](https://cloud.google.com/access-context-manager/docs) and [VPC Service
Controls](https://cloud.google.com/vpc-service-controls/docs/overview)

## Ressources créées

### Police d'accès organisationnelle

Une organisation ne peut avoir qu'une police de gestion de contexte d'accès. Ce module peut en créer une ou en utiliser une existante. Si la variable `policy_id` est fournie, le module utilisera `policy_id` sans en créer une nouvelle. La variable `policy_name` sera ignorée.

Pour obtenir l'ID de la police dans l'organisation (s'il en a un)
```bash
gcloud access-context-manager policies list --organization [orgid]
```

### Niveaux d'accès

Niveau d'accès sont utilisé pour permettre d'accès aux ressources basé sur les informations contextuelles sur une requête.
En utilisant les niveaux d'accès, vous pouvez construire les niveaux de confiance.

Gestion de contexte d'accès fournit deux chemins de définir des niveaux d'accès: Basic et personnalisé

Un niveau d'accès basic est une collection de conditions qui sont utilisé pour tester les requêtes. Conditions sont un group d'attributs que vous voulez tester, par exemple, le type d'appareil, l'adresse d'IP ou l'identité d'usager. Les attributs de niveau d'accès représentent des informations contextuelles d'une requëte.

Niveau d'accès personnalisé n'est pas pris en charge par ce module

### Périmètre de service régulier

Un périmètre de service crée une frontière de sécurité autour des ressource de Google Cloud.
Vous pouvez configurer un périmètre de service pour contrôler les communications des VM jusqu'aux services de Google Cloud (API), et entre les services de Google Cloud.
Un périmètre de service permet une communication libre dans le périmètre mais, par défaut, bloque toutes les communications à travers du périmètre.

Pour définir un usage régulier, utiliser les variables:
- `live_run`
- `restricted_services`
- `resources` OR `resources_by_numbers`
- `access_levels`

`resources` te permet d'utiliser les ID de projet utilisé dans les blocs `data` de Terraform pour obtenir les numéros de projet. Cela ne fonctionne pas avec les projets non-existants ou sont créés en faisant partie du même plan que dans les tests unitaires. `resrouces` et `resources_by_numbers` sont mutuellement exclusives.

Pour définir un "dry-tun" afin de tester un périmètre sans bloquer, utiliser:
- `dry_run`
- `restricted_services_dry_run`
- `resources_dry_run` OR `resources_dry_run_by_numbers`
- `access_levels_dry_run`

`resources_dry_run` te permet d'utiliser les ID de projet utilisé dans les blocs `data` de Terraform pour obtenir les numéros de projet. Cela ne fonctionne pas avec les projets non-existants ou sont créés en faisant partie du même plan que dans les tests unitaires. `resources_dry_run` et `resurces_dry_run_by_numbers` sont mutuellement exclusives.


### Périmètre de service de pont

Un périmètre de pont permet les projets dans les périmètres de sécurité différents à se communiquer. Les ponts de périmètres sont bidirectionnels, en permettant les projets de chaque périmètre de sécurité à avoir un accès équitable dans la porté du pont.

`resources` te permet d'utiliser les ID de projet utilisé dans les blocs `data` de Terraform pour obtenir les numéros de projet. Cela ne fonctionne pas avec les projets non-existants ou sont créés en faisant partie du même plan que dans les tests unitaires. `resrouces` et `resources_by_numbers` sont mutuellement exclusives.


## Tests unitaires

Les secrets sont nécessaires pour exécuter les tests unitaires.

## Usage

Voir [examples](./examples)

### Github:
GOOGLE_APPLICATION_CREDENTIALS : JSON key of service account with permissions to
deploy to the Org/Folder SSH_KEY : Private RSA SSH key. Should belong to a
Github Service Account and not an individual UNITTEST_ACCESSLEVEL_MEMBERS : list
of Service Accounts, Groups or Users to add to the test access level.
- format [\"group:us@domain.ca\"] UNITTEST_BILLING_ACCOUNT : Billing account for
  test projects UNITTEST_ORG_ID : Organization ID for policy creation
  UNITTEST_POLICY_ID : Policy ID for existing policy (see above to gcloud
  command) UNITTEST_PROJECT_PARENT : Organization or Folder to place test
  projects into

<!-- BEGINNING OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
## Entrées:

| Nom | Description | Type | Défaut | Requis |
|--|-------------|------|---------|:--------:|
| access\_level | Dictionnaire utilisé pour configurer un niveau d'accès | <pre>map(<br>    object({<br>      name                             = string<br>      combining_function               = optional(string)<br>      description                      = optional(string)<br>      ip_subnetworks                   = optional(list(string))<br>      required_access_levels           = optional(list(string))<br>      members                          = optional(list(string))<br>      regions                          = optional(list(string))<br>      negate                           = optional(bool)<br>      require_screen_lock              = optional(bool)<br>      require_corp_owned               = optional(bool)<br>      allowed_encryption_statuses      = optional(list(string))<br>      allowed_device_management_levels = optional(list(string))<br>      minimum_version                  = optional(string)<br>      os_type                          = optional(string)<br>    })<br>  )</pre> | `{}` | non |
| bridge\_service\_perimeter | Dictionnaire utilisé pour configurer un périmètre de service de pont | <pre>map(object({<br>    description          = optional(string)<br>    perimeter_name       = string<br>    resources            = optional(list(string))<br>    resources_by_numbers = optional(list(string))<br>    })<br>  )</pre> | `{}` | non |
| department\_code | Code pour département, partie du module de nommage | `string` | n/a | oui |
| environment | S-Sandbox P-Production Q-Quality D-development | `string` | n/a | oui |
| location | Emplacement pour placement de nommage et de ressource | `string` | `"northamerica-northeast1"` | non |
| parent\_id | Le parent de cette police d'accès dans l'hiérarchie de ressource de Cloud. En ce moment, seulement les organisations sont acceptés comme parent.  | `string` | n/a | oui |
| policy\_id | ID de Police est seulement utilisé quand une police existe déjà | `string` | `null` | non |
| policy\_name | Le nom de police, utilisée seulement quand créer une nouvelle police. | `string` | `"orgname-policy"` | non |
| regular\_service\_perimeter | Dictionnaire utilisé à configurer un périmètre régulier de service | <pre>map(object({<br>    description                  = optional(string)<br>    perimeter_name               = string<br>    restricted_services          = optional(list(string))<br>    resources                    = optional(list(string))<br>    resources_by_numbers         = optional(list(string))<br>    access_levels                = optional(list(string))<br>    restricted_services_dry_run  = optional(list(string))<br>    resources_dry_run            = optional(list(string))<br>    resources_dry_run_by_numbers = optional(list(string))<br>    access_levels_dry_run        = optional(list(string))<br>    vpc_accessible_services = optional(object({<br>      enable_restriction = bool,<br>      allowed_services   = list(string),<br>    }))<br>    dry_run  = optional(bool)<br>    live_run = optional(bool)<br>    })<br>  )</pre> | `{}` | non |
| user\_defined\_string | String défini par l'usager | `string` | n/a | oui |

## Sorties
| Nom                                | Description |
|------------------------------------|-------------|
| bridge\_service\_perimeter\_names  | n/a |
| parent\_id                         | n/a |
| policy\_id                         | n/a |
| regular\_service\_perimeter\_names | n/a |

<!-- END OF PRE-COMMIT-TERRAFORM DOCS HOOK -->