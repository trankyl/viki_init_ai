# Survol de l'implementation AVD dans la ZA 2.2.1

Correspondances termes en français avec acronymes et termes anglais utilisés dans ce document


| Terme français                                                            | Terme anglais             | Acronyme |
| ---------------------------------------------------------------------------- | --------------------------- | ---------- |
| Solution bureau virtuel                                                    | Azure Virtual Desktop     | AVD      |
| Bassin d'hôtes                                                            | Host pool                 |          |
| Groupe de machines virtuelles avec ajustement dynamique de la capacité    | Virtual Machine Scale Set | VMSS     |
| Machine Virtuelle                                                          | Virtual Machine           | VM       |
| Compte de mise en mémoire                                                  | Storage account           |          |
| Hôte de session                                                           | Session Host              |          |
| Voûte de clés / Coffre-fort                                               | Keyvault                  | KV       |
| Plan d'échelonnage d'agrandissement ou réduction de capacité de traitement | Scaling plan              |          |
| Point d'accès privé                                                      | Private Endpoin           | PE       |
| Partage de fichiers Azure pour profiles usager                             | Azure File                | fslogix  |
| Abonnement central-plateforme                                              | Hub                       |          |
| Abonnement périphérique d'extrémité dans déploiement en étoile             | spoke           |          |
| Accélérateur solution bureau virtuel                                       | AVD Accelerator           |          |

## Aperçu

La solution bureau virtuel permet d'utiliser de façon dynamique, "sur demande" des postes virtuels, dédiés ou partagés. Il y a deux fonctionnalités de base:

* Virtualisation de bureau Windows
* Virtualisation d'application windows

Les deux ressources de base de la solution AVD sont:

* Le bassin d'hôtes. Ce sont des machines virtuelles Windows, déployées dans un groupe de machines virtuelles avec ajustement dynamique de la capacité dont la taille (nombre de machines virtuelles) varie en fonction de l'utilisation. Chaque machine virtuelle dans ce bassin peut supporter plusieurs sessions de type bureau virtuel et/ou virtualisation d'application.
* Le compte de mise en mémoire  de type partage-fichier qui garde les profiles des usagers. Ce compte de mise en mémoire est connu comme "fslogix" par rapport à la couche applicative de gestion des profiles-usager.

Chaque usager a son propre profile, qui définit ses permissions, configuration et applications auxquelles l'usager a accès en mode virtualisé.

La solution AVD s'intègre avec la solution Microsoft Intune pour permettre les mises à jour automatiques des systèmes d'exploitation et applications.

La solution AVD, telle que déployée dans la zone d'accueil Azure, est de type étoile (en anglais "hub and spoke") et consiste des élements suivants:

* Un abonnement commun qui contient les ressources communes:
  * La machine virtuelle de gestion des profiles-usager
  * Le compte de stockage connu en tant que fslogix qui est utilisé pour la mise en mémoire de ces profiles-usager
  * Une voûte de clés qui est utilisée pour l'entreposage des informations secrètes comme des mots de passe.
  * Les points d'accès privée pour l'accès sécuritaires aux ressources mentionnées ci-dessus
* Un ou plusieurs abonnements "instance" dont chacun contient les ressources d'une instance AVD:
  * Le bassin d'hôtes pour les hôtes de session qui regroupe les machines virtuelles qui hébergent de façon dynamique les sessions des usagers (soit de type bureau, soit de type session applicative)
  * D'autres ressources logiques comme le plan d'échelonnage d'agrandissement ou réduction de capacité de traitement.

Tous les abonnements commun ou instance se connectent à l'abonnement central-plateforme de la zone d'accueil Azure, donc le déploiement de la solution AVD doit se faire après avoir déployé au moins les abonnement plateforme - connectivité, gestion et identité.

## Survol des sous-répertoires

* Le sous-répertoire azure-pipeline contient

  * Les 2 pipelines

    avd-common.yml : déploye l'infrastructure commune pour les instances AVD
    avd-instance.yml : déploie une instance AVD. Peut être
  * en dessous de config/variables/scenario-base: on retrouve ici le paramétrage AVD

    * cei-avd-var-param.yml: paramétrage qu'on peut personnaliser
    * cei-avd-var-common.yml: paramétrage commun (valeurs calculées)
    * cei-avd-var-instance.yml: paramétrage d'instance AVD (valeurs calculées)
  * en dessous de templates/steps: on y retrouve les script de déploiement qui appellent la commande "az deployment" avec des paramètres spécifiques

    * deploy-spoke-avd-common.yml : déploie l'infrastructure commune
    * deploy-spoke-avd-instance.yml: déploie l'instance AVD
* Le sous-répertoire modules contient

  * avd/azureFilesDomainJoin.bicep : déploiement la machine virtuelle de gestion et système fichiers fsLogix
  * carml: les modules de distribution du "AVD Accelerator" de Microsoft
* Le sous-répertoire policies contient les définitions de stratégies et initiatives. ces définitions sont déployées dans l'abonnement "common" ainsi que dans chaque abonnement "instance" et sont utilisées pour assignation dans les abonnements "instance".
* Le sous-répertoire "spokes" contient les 2 script bicep de haut niveau

  * avd-common.bicep : déploie l'infrastructure commune
  * avd-instance.bicep : déploie une instance de la solution AVD

## Modalités de déploiement

Les "instances" AVD doivent être déployées dans leurs abonnements à part et séparés de l'abonnement commun.

Le paramétrage peut être défini à plusieurs niveaux:

* Un groupe de variables devops dont le suffixe est spécifié lors du lancement de la pipeline. C'est obligatoire de spécifier un groupe de variable au moins pour sécuriser les mots de passe. N'importe que
* Paramètres spécifiés lors du lancement de la pipeline (à part le nom du vargroup) indiqués
* var-avd-common-subscriptionId: l'abonnement pour common
* var-avd-instance1-subscriptionId: l'abonnement pour une instance AVD

Les règles de précédence sont les suivantes:

* La valeur du paramètre spécifiée dans le fichier cei-avd-var-param.yml prend précédence par rapport au paramétrage de la mème variable au lancement de la pipeline ou dans le groupe de variables
* La valeur du paramètre spécifiée dans le groupe de variables prend précédence par rapport au paramétrage de la mème variable au lancement de la pipeline

### Paramètres demandés au lancement des pipelines

Certains paramètres sont demandés par les pipelines et par défaut la valeur proposée est `None `. Chaque pipeline demande par défaut la branche de déploiement et le suffixe du groupe de variable. Si on laisse `None` pour ce suffixe de groupe de variables, le groupe de variable est ignoré.

Si on laisse `'None'`dans une telle boite de paramètre lors du lancement d'une pipeline, il faut s'assurer que la variable correspondante est quand même définie soit dans le groupe de variable soit dans le fichier cei-avd-var-param.yml. Dans le tableau plus bas, dans la colonne Usage le "C" et le "I" signifient respectivement "utilisé pour pipeline avd-common.yml" et "utilisé pour pipeline avd-instance.yml"


| Nom boîte paramètre pipeline (avd-common.yml, avd-instance.yml)                                                                                             | Défaut | Nom variable                     | Usage |
| --------------------------------------------------------------------------------------------------------------------------------------------------------------- | --------- | ---------------------------------- | ------- |
| Branch/tag                                                                                                                                                    | S/O     | S/O                              | C,I   |
| Le suffixe 'NomSignificatif' du groupe de variable pour override (Azure ZA Environment Parameters -`NomSignificatif`)                                         | None    | S/O                              | C,I   |
| Le nom de l'usager local sur la VM de gestion AVD                                                                                                             | None    | var-avd-vm-local-user-name       | C,I   |
| Le nom du domaine à joindre pour AVD                                                                                                                         | None    | var-adds-domain-name             | C,I   |
| Le nom de l'usager-domaine pour joindre la VM et système FxLogix au domaine AD / Le nom usager pour joindre domaine AVD                                      | None    | var-avd-domain-join-user-name    | C,I   |
| L'abonnement "common" pour déploiement AVD                                                                                                                   | None    | var-avd-common-subscriptionId    | C,I   |
| La plage IP pour le VNET AVD Common, en format CIDR                                                                                                           | None    | var-avd-common-vnet-address      | C     |
| La plage IP pour le sous-réseau dans VNET AVD Common, en format CIDR                                                                                         | None    | var-avd-common-snet-address      | C     |
| La plage IP du sous-réseau du controlleur AD, pour le routage / La plage d'adresse du subnet de AD-DC<br />                                                  | None    | var-avd-snet-adds                | C,I   |
| Adresse IP du serveur DNS du domaine auquel AVD va se joindre /<br />l'adresse du DNS server du domaine                                                       | None    | var-avd-common-dns               | C,I   |
| Le ID objet-entreprise du compte AVD dans AAD de type application enregistrée / Cela doit être celui de l'application pré-définie Windows Virtual Desktop | None    | var-avd-enterprise-objectid      | C,I   |
| L'abonnement pour déploiement instance AVD                                                                                                                   | None    | var-avd-instance1-subscriptionId | I     |
| La plage d'adresse du VNET instance                                                                                                                           | None    | var-avd-instance1-vnet-address   | I     |
| La plage d'adresse du subnet dans VNET instance                                                                                                               | None    | var-avd-instance1-snet-address   | I     |
| Le index de l'instance de 0 à 99                                                                                                                             | None    | var-avd-instance1-num            | I     |

#### Notes par rapport au paramètre var-avd-enterprise-objectid

L'application pré-définie Windows Virtual Desktop est remplacée dans certaines versions plus récentes de déploiements par "Azure Virtual Desktop". L'ID objet varie d'un locataire à l'autre, quand même la procédure pour obtenir l'ID objet resta la même:

Trouver l'application entreprise

![Trouver l'application](Doc/images/avd_ea_1.png)

Obtenir son ID d'objet

![Obtenir l'ID objet](Doc/images/avd_ea_2.png)

On peut par après le fournir comme paramètre lors de l'execution de la pipeline:

![Fournir comme paramètre](Doc/images/avd_ea_3.png)

Ou laisser "none" dans le paramètre de la pipeline et le fournir dans le fichier de paramètrage cei-avd-var-param.yml

![ou mettre dans paramétrage](Doc/images/avd_ea_4.png)

### Paramètrage détaillé des pipelines

Comme la solution Bureau Virtuel Azure est un module à part, le paramétrage est spécifique à ce module, dont le paramétrage de base se trouve dans le fichier cei-avd-var-param.yml en dessous du chemin relatif `Custom/AVD/azure-pipeline/config` .

Les variables suivantes dans les tableaux suivants sont utilisées pour le paramétrage et les acronymes plus bas indiquent:

* PO: paramètre obligatoire
* VG: paramètre peut être spécifié dans le groupe de variables
* PP: paramètre peut être spécifié lors du lancement de la pipeline
* FP: paramètre peut être spécifié dans le fichier de paramétrage cei-avd-var-param.yml

Dans les tableaux plus bas le O et N indiquent Oui et Non. Certaines variables présentes dans le fichier de paramétrage cei-avd-var-param.yml et qui n'apparaissent pas dans le tableau ci-bas peuvent être laissées avec leurs valeurs défaut.

---

#### Création de variables dans le groupe de variables

- La création de ces variables dans le groupe de variables est obligatoire étant donné leur confidentialité
- Pour avoir un rappel sur les groupes de variables, réferez vous au document de [clonage et aperçu du script](../../Doc/clonage_et_apercu_script.md)

| Nom variable                      | Description                                                                                                                                                                                                                         | PO | VG | PP | FP |
| ----------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ---- | ---- | ---- | ---- |
| var-avd-domain-join-user-name      | Nom usager admin domaine AD à joindre                                                                                                                                                                                              | O  | O  | O  | O  |
| var-avd-domain-join-user-password | MDP usager admin domaine AD à joindre                                                                                                                                                                                              | O  | O  |    |    |
| var-avd-vm-local-user-name         | Nom usager admin VM AVD gestion en common                                                                                                                                                                                           | O  | O  | O  | O  |
| var-avd-vm-local-user-password    | MDP usager admin VM AVD gestion en common                                                                                                                                                                                           | O  | O  |    |    |

---
#### **Paramétrage commun pour pipelines avd-common.yml et avd-instance.yml**


| Nom variable                      | Description                                                                                                                                                                                                                         | PO | VG | PP | FP |
| ----------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ---- | ---- | ---- | ---- |
| var-avd-common-subscriptionId     | L'ID de l'abonnement "common"                                                                                                                                                                                                       |    |    |    |    |
| var-avd-common-vnet-address       | La plage IP (CIDR) du VNET "common"                                                                                                                                                                                                 |    |    |    |    |
| var-avd-common-snet-address       | Et la plage IP du sous-réseau dans ce VNET                                                                                                                                                                                         |    |    |    |    |
| var-avd-snet-adds                 | Le sous-réseau de l'AD-DC pour le routage                                                                                                                                                                                          |    |    |    |    |
| var-avd-common-dns                | L'adresse IP de l'AD-DC avec service DNS                                                                                                                                                                                            |    |    |    |    |
| var-adds-domain-name              | Le nom du domaine à joindre                                                                                                                                                                                                        |    |    |    |    |
| var-ouPath                        | Le chemin LDAP de l'OU assigné sur l'AD-DC                                                                                                                                                                                         |    |    |    |    |
| var-avd-identityprovider          | ADDS pour AD-DC, AADDS pour Azure ADDS                                                                                                                                                                                              |    |    |    |    |
| var-avd-enterprise-objectid       | L'objet ID d'un enregistrement applicatif AVD. Il faut trouver dans Azure AD "Applications d'entreprise" l'application prédéfinie "WindowsDesktop" (ou "AzureDesktop" pour des "tenant" plus récents) et prendre son ID d'objet. |    |    |    |    |
| var-avd-short-name                | Utilisé dans les noms, par exemple avd                                                                                                                                                                                             |    |    |    |    |
| var-avd-short-env-name            | Nom très court d'environnement (exemple pr pour production)                                                                                                                                                                        |    |    |    |    |
| var-avd-iteration                 | Une itération de 2 chiffres pour éviter conflits (ex. '-01') Est utilisée dans la génération des noms de ressources                                                                                                            |    |    |    |    |
| var-avd-fslogix-name-extra        | Un suffixe de 2 chiffre pour le nom de compte de stockage fslogix, exemple '01'                                                                                                                                                     |    |    |    |    |
| var-avd-fslogix-fileshare-quota   | Nombre de partages-fichiers disponibles dans le compte de stockage fslogix                                                                                                                                                          |    |    |    |    |
| var-avd-management-vm             | Spécification (en format json) de VM de gestion AVD                                                                                                                                                                                |    |    |    |    |
| var-avd-os-image                  | Le type d'image de système d'exploitation ('win11_22h2')                                                                                                                                                                           |    |    |    |    |
| var-avd-deploy-scalingplan        | true si on déploie un plan d'augmentation/reduction automatique de capacité du bassin de hôtes de session déployés dans instances                                                                                              |    |    |    |    |
| var-avd-sessionhosts-size         | Type d'instance à utiliser pour les VM 'hôtes de session'  ('Standard_D2s_v3') - même taille pour toutes les instances                                                                                                           |    |    |    |    |
| var-avd-sessionhost-disk-type     | Type de disque virtuel pour les VM 'hôtes de session' ('Standard_LRS' en est le moins cher, utiliser 'Premium_LRS' pour SSD ou 'Premium_ZRS" pour redondance de zone de disponibilité)                                            |    |    |    |    |
| var-create-intune-enrollment      | true si on veut que les VM hôtes de session soient prises en charge pour les MAJ par le service Intune                                                                                                                             |    |    |    |    |
| var-avd-hostpool-maxsessions      | Nombre maximal de sessions par hôte de session (défaut 5)                                                                                                                                                                         |    |    |    |    |
| var-avd-scalingplan-schedule      | Une variable complexe, json, qui définit la cédule du plan d'augmentation/reduction automatique de capacité du bassin de hôtes de session                                                                                       |    |    |    |    |
| var-avd-dnsservers                | La liste de serveurs AD-DC qui fournissent le service DNS                                                                                                                                                                           |    |    |    |    |

### Paramétrage spécifique pour pipeline avd-instance.yml


| Nom variable                     | Description                                     | PO | VG | PP | FP |
| ---------------------------------- | ------------------------------------------------- | ---- | ---- | ---- | ---- |
| var-avd-instance1-subscriptionId | L'ID de l'abonnement "instance"                 | O  | O  | O  | O  |
| var-avd-instance1-vnet-address   | La plage IP (CIDR) du VNET "instance"           | O  | O  | O  | O  |
| var-avd-instance1-snet-address   | Et la plage IP du sous-réseau dans ce VNET     | O  | O  | O  | O  |
| var-avd-instance1-num            | Un suffixe numérique pour le nom de l'instance | O  | O  | O  | O  |

#### Notes de paramétrage

C'est possible d'utiliser le même abonnement "common" pour la première instance AVD

Le déploiement AVD commence avec certains prerequis

- Le déploiement de la zone d'accueil Azure v2.2.1
- L'existence ou le provisionnement d'un controlleur de domaine Active Directory dans zone Identité ou ailleurs (note: on peut aussi utiliser le contrôleur de domaine sur site, c'est du paramétrage)
- L'existence ou le provisionnement d'un domaine (si pas existant)
- La configuration du service DNS dans ce domaine
- La configuration dans le service DNS du domaine AD d'un "DNS forwarder" qui pointe vers l'adresse DNS Azure (168.63.129.16) et qui sert d'acheminer les requêtes DNS pour tout autre domaine que celui de du contrôleur (pour le domaine pointer la résolution DNS du contrôleur de domaine vers lui même)
- La configuration d'une racine OU (indiquée dans var-ouPath) en dessous du domaine. Par défaut AVD/Session et AVD/Storage seront provisionnés en dessous de cet OU racine.
- Définir un usager avec permissions admin-domaine (fourni dans var-avd-domain-join-user-name)

Aussi

* Configurer le routage reciproque entre la zone qui héberge le contrôleur de domaine et et les plages d'adresse AVD (common et chaque instance). Dans le cas ou le controlleur est dans la zone identité:
  * Configurer la route dans le sous-réseau du contrôleur de domaine vers les plages AVD (communes et des instances)
  * Configurer dans les sous-réseaux AVD (communes et des instances) les routes vers l'identité
* Permettre l'accès (NSG, C/F) entre l'AD-DC et les sous-réseaux AVD, pour DNS et les autres ports utilisés par Active Directory. Il s'agit d'un grand nombre de ports, voir exemples NSG requis dans cei-base-nsg-custom.yml en dessous du "scenario-base" dans azure-pipeline/config/variables
* S'assurer que l'accès Internet est permis dans les abonnements AVD (des extensions en provenance de github sont déployées par les scripts)

## Execution des pipelines AVD

D'abord déployer la zone d'accueil v2.2.1, au moins les abonnements plateforme, identité et gestion. Voir les notes de paramétrage plus haut pour les prérequis. C'est très important de s'assurer que la communication avec le domaine Active Directory est permise car le compte de stockage de type partage de fichiers fslogix ainsi que les machines virtuelles provisionnées doivent s'enregistrer avec le domaine.

S'assurer d'avoir configuré les abonnements "common" et pour les instances à déployer.

S'assurer d'avoir configuré le paramétrage requis soit dans les groupes de variables soit dans les fichiers de paramétrage comme décrit plus haut.

### Rouler pipeline avd-common.yml

La première pipeline à rouler est avd-common.yml. Une partie du paramétrage peut être rentré directement dans les boîtes-paramètres de la pipelines, si pas définis dans le groupe de variables ou dans les fichiers de paramétrage.

Ce pipeline va provisionner les ressources suivantes dans l'abonnement commun identifié par var-avd-common-subscriptionId:

* La VM de gestion AVD y compris la joindre au domaine spécifié dans var-adds-domain-name
* Le compte de stockage et le partage "Azure File" fslogix pour les profiles-usager
* La voûte de clés  et les clés dedans
* Le "VNET", les sous-réseaux, appariements, les tables de routage, groupes de sécurité, groupes de sécurité applicatifs et d'autre ressources.

### Rouler pipeline avd-instance.yml

Une fois la pipeline `avd-common.yml` fini sans erreur on peut commencer à déployer des instances AVD, chacune configurée avec un bassin d'hôtes ("host pool" en anglais) pour permettre aux usagers de se connecter et consommer des applications en mode session ou bureau virtuel selon leurs besoins.

Chaque instance AVD sera connectée au réseau virtuel ("VNET" en anglais) de l'abonnement connectivité via des appariements ("peering" en anglais) et les machines virtuelles ("VM" en anglais) dans chaque bassin d'hôtes ("host pool") seront jointes au domaine Active Directory ("AD").

Dans la fichier de paramétrage `cei-avd-var-param.yml` il y a une configuration `var-avd-scalingplan-schedule` qui défini des critères défauts pour l'augmentation et diminution de la capacité de traitement du bassin d'hôtes.

De plus la variable var-avd-hostpool-maxsessions contrôle le nombre maximal de sessions-usager hébergées sur une seule VM dans ce bassin.

### Autre paramétrage avancé

Pour personnaliser encore plus en profondeur le déploiement de la solution AVD on peu changer du paramétrage avancé dans les fichiers suivants, en dessous du chemin Custom/AVD/azure-pipeline/config/variables/scenario-base

* cei-avd-var-common.yml
* cei-avd-var-instance.yml

### Valider que les ressources ont été déployées

Une fois qu'on fini de rouler la pipeline avd-common.yml c'est indiqué de valider que les ressources requises ont été déployées

![Ressources typiques dans abonnement commun](Doc/images/AVD_common_res.png)

Une fois que la validation dans l'abonnement commun est faite, on peut rouler la pipeline de déploiement d'instance en vérifiant par après que les ressources ont été déployées correctement

![Ressources typiques dans abonnement instance](Doc/images/AVD_inst1_res.png)

Pour les prochaines étapes, comme la configuration des applications, profiles usagers et bureaux virtuels, voir la documentation Microsoft:

[Azure Virtual Desktop documentation | Microsoft Learn](https://learn.microsoft.com/en-us/azure/virtual-desktop/))
