
# Visualiseur Azure Government aka AzGovViz

Au menu

* [Contexte](#contexte)
* [Comment générer un rapport AzGovViz](#comment-générer-un-rapport-azgovviz)
  * [Objectif](#objectif)
  * [Préréquis](#préréquis)
    * [Création du groupe ressource azgovviz](#création-du-groupe-ressource-azgovviz)
    * [Création d'une connexion de service à cei-sel-dev](#création-connexion-de-service-à-abonnement-hébergement-site-web)
  * [Restreindre l'accès au rapport AzGovViz](#restreindre-accès-au-site-web)
  * [Implémentation du pipeline](#implémentation-du-pipeline)
    * [Génération rapport HTML AzGovViz](#génération-rapport-html-azgovviz)
      * [Paramètres pipeline génération rapport](#paramètres-pipeline-génération-rapport)
      * [Étapes pipeline génération rapport](#étapes-du-pipeline-de-publication-du-rapport)
    * [Publication rapport HTML AzGovViz](#publication-rapport-html-azgovviz)
      * [Paramètres du pipeline de publication du rapport](#paramètres-du-pipeline-de-publication-du-rapport)
      * [Étapes du pipeline de publication du rapport](#étapes-du-pipeline-de-publication-du-rapport)
  * [Variables communes](#variables-communes)
* [Rapport HTML AzGovViz](#rapport-html-azgovviz)
* [Code source](#code-source)
  * [Liste des fichiers dans code source](#liste-des-fichiers-dans-code-source)
* [FAQ](#faq)
  * [Erreur AADSTS50011](#erreur-aadsts50011)
* [Annexes](#annexes)


## Contexte

Souhaitez-vous obtenir des informations granulaires sur votre implémentation technique de la gouvernance Azure ? - le documenter en CSV, HTML, Markdown et JSON?

Azure Governance Visualizer aka AzGovViz est un script PowerShell qui itére la hiérarchie du groupe d’administration de votre locataire Azure jusqu’au niveau de l’abonnement.

 Il capture les fonctionnalités de gouvernance Azure les plus pertinentes telles que Azure Policy, RBAC et Blueprints et bien plus encore. À partir des données collectées, Azure Governance Visualizer offre une visibilité sur votre HierarchyMap, crée un TenantSummary, crée DefinitionInsights et génère des ScopeInsights granulaires sur les groupes d’administration et les abonnements.

## Comment générer un rapport AzGovViz

### Objectif

Dans notre scénario, nous allons :

- Clôner le script AzGovViz dans le repos Azure-Interne
- Donner à AzGovViz un groupe d'administration de notre locataire , pour analyse.
- S'attarder uniquement sur le rapport HTML généré.
- Publier ce rapport HTML dans un site web statique dans Microsoft Azure.

Toutes les étapes ci-dessus seront faites dans un pipeline Azure.

### Préréquis

* Être administrateur du tenant que le script AzGovViz doit analyser
* Être administrateur du tenant ayant le repos Azure-Interne
* Avoir une connexion de service Azure Resource Manager sur le tenant ayant les *groupes d'administration et abonnements* à analyser. Ce service se nomme **AzGovVizServiceConnection** dans ce guide

#### Création du groupe ressource azgovviz

Créer le groupe de ressources **rg-azgovviz** dans l'abonnement **cei-sel-dev**

![rg_azgovviz](Doc/images/rg_azgovviz.PNG)

#### Création connexion de service à abonnement hébergement site web

Il faut créer une connexion de service , que le pipeline va utiliser pour se connecter à l'abonnement cei-sel-dev et y déployer le rapport HTML AzGovViz

Pour ce faire, aller  dans le projet AzureDevOps, [Migration](https://dev.azure.com/ccticei/Migration/_settings/), où se trouve le repos Azure-Interne.

Appliquer *UNIQUEMENT* la section **Créer une connexion de service** dans le guide suivant : https://learn.microsoft.com/fr-fr/azure/devops/pipelines/library/service-endpoints?view=azure-devops&tabs=yaml#create-a-service-connection  , afin de créer cette connexion de service. Nous l'avons appelé **AzGovVizServiceConnection**

Il faudra mentionner le groupe de ressource rg-azgovviz , [créé plus haut](#création-du-groupe-ressource-azgovviz) .

![creation_connexion_service_AzGovVizServiceConnection](Doc/images/creation_connexion_service_AzGovVizServiceConnection.PNG "Création d'une connexion de service a cei-sel-dev")


### Implémentation du pipeline

Nous avons implémenté un pipeline YAML Azure [azgovviz.yaml](azgovviz.yml) , avec les 2 grandes activités suivantes :

- Génération un rapport HTML AzGovViz et le publier dans Azure Artifactory
- Récupérer le rapport HTML dans Azure Artifactory et le publier dans un site web statique

Voici les paramètres d'entrée du pipeline azgovviz.yaml

![parametres_pipeline_azgovviz](Doc/images/parametres_pipeline_azgovviz.PNG )


| Nom paramètre entrée       | Rôle   | Type de données    |
| ------------------- | ------ | ------------------ |
| identifiantTenant          | Identifiant GUID du tenant           | Chaîne de caractères                      |
| identifiantGroupeAdministration | Identifiant GUID du groupe d administration ou abonnement à analyser (Root Management Group Id equals your Tenant Id)     | Chaine de caractères      |
| identifiantAnnuaireSiteWeb | Identifiant GUID de l annuaire Microsoft Entra ID dans lequel est enregistré le site web AzGovViz     | Chaine de caractères      |

#### Génération rapport HTML AzGovViz

Le fichier pipeline YAML [generation-rapport.yml](templates/generation-rapport.yml) implémente la génération du rapport HTML

##### Paramètres pipeline génération rapport

Voici ces paramètres d'entrée

| Nom paramètre entrée       | Rôle   | Type de données    |
| ------------------- | ------ | ------------------ |
| identifiantTenant          | Identifiant GUID du tenant           | Chaîne de caractères                      |
| identifiantGroupeAdministration | Identifiant GUID du groupe d administration ou abonnement à analyser (Root Management Group Id equals your Tenant Id)     | Chaine de caractères      |
| identifiantAnnuaireSiteWeb | Identifiant GUID de l annuaire Microsoft Entra ID dans lequel est enregistré le site web AzGovViz    | Chaine de caractères      |

##### Étapes pipeline génération rapport

Voici ses étapes :

1. Installation de git
2. Clônage du [depot Azure Governance Visualizer](https://github.com/JulianHayward/Azure-MG-Sub-Governance-Reporting.git) dans le dossier Azure-MG-Sub-Governance-Reporting
3. Installation du module Az.Accounts
4. Installation du module AzAPICall
5. Création du dossier wiki qui contiendra le rapport HTML du script Powershell
6. Sur le dossier wiki, donner a l'agent d'exécution du pipeline , le droit d'ajouter des fichiers et sous-doosiers  .
7. Se connnecter au tenant ayant les groupes d'administration et abonnements à analyser. Au lieu de sonnecter en tant que humain, se connecter avec la connexion de service **AzGovVizServiceConnection**
8. Exécuter le script PowerShell de génération avec la commande

     /Azure-MG-Sub-Governance-Reporting/pwsh/AzGovVizParallel.ps1  -ManagementGroupId ID -OutputPath 'wiki' où :

ID est l'identifiant du groupe d'administration racine ou identifiant de l'abonnement à analyser

9. Compression du dossier wiki dans le fichier azgovviz.zip
10. Publication du fichier compressé dans Azure Artifactory

#### Publication rapport HTML AzGovViz

Le fichier pipeline YAML [deploy-rapport.yml](templates/deploy-rapport.yml) implémente la création d'un site web statique (Web App) dans l'abonnement cei-sel-dev et la publication du dossier compressé azgovviz.zip dans ledit site web statique

##### Paramètres du pipeline de publication du rapport

Voici ses paramètres d'entrée

| Nom paramètre entrée       | Rôle   | Type de données    |
| ------------------- | ------ | ------------------ |
| environment          | Identifiant GUID du tenant           | Chaine de caractères                      |
| identifiantGroupeAdministration | Identifiant GUID du groupe d administration ou abonnement à analyser (Root Management Group Id equals your Tenant Id)     | Chaine de caractères      |
| identifiantAnnuaireSiteWeb | Identifiant GUID du tenant ayant Azure Active Directory (aka Microsoft Entra ID) pour sécuriser l acces au site web     | Chaine de caractères      |


##### Étapes du pipeline de publication du rapport


Voici ses étapes :

1. Création WebApp dans Azure

    az --version
                  az account set --subscription 'bbcbe5ec-af3d-4d88-a86a-7de4c13c489a'
                  $rsgExists = az group exists -n rg-azgovviz
                  if ($rsgExists -eq 'false') {
                    az group create -l canadacentral -n rg-azgovviz
                  }
                  az deployment group create --resource-group rg-azgovviz --template-file $(Pipeline.Workspace)/Deploy/deploy.bicep `
                  --parameters appName='$(nomWebApp)' `
                  --parameters appInsightsName=appinsight-azgovviz `
                  --parameters hostingPlanName=plan-azgovviz `
                  --parameters skuName='F1' `
                  --parameters skuCapacity=1 `
                  --parameters aadClientId='$(idClientWebApp)' `
                  --parameters location='canadacentral' `
                  --parameters aadTenant='${{ parameters.identifiantAnnuaireSiteWeb }}'


2. Publication du rapport HTML AzGovViz dans WebApp
3. Génération Lien pour lancer site web

Exemple :

    https://webapp-azgovviz-001.azurewebsites.net/AzGovViz_35fb9e66-b21f-42a0-bfc2-8a390a026b5c.html




### Variables communes

Tandis que le fichier azgovviz.yml contient les paramètres d'entrées pour la logique d'affaire , le fichier [common.yml](config\variables\common.yml) contient les paramètres pour l'aspect technique de l'exécution du pipeline


| Nom variable       | Rôle   | Type de données    |
| ------------------- | ------ | ------------------ |
| serviceConnectionName          | Nom du connexion de service pour se connecter au tenant ayant les groupes d'administration et abonnements à analyser           | Chaine de caractères                      |
| vmImageName | Type d'image (OS , etc...) à utiliser sur les machines virtuelles lors de l'exécution du pipeline     | Chaine de caractères      |
| nomWebApp | Nom de la Web App qui sera créé dans Azure pour y publier le site web statique     | Chaine de caractères      |
| idClientWebApp | ID de l'application Web App , apres son inscription dans Azure Active Directory (aka Microsoft Entra ID) | Chaine de caractères      |

## Rapport HTML AzGovViz

Une fois le pipeline azgovviz.yml lancé, vous obtiendrez un rapport pareil :


![capture_rapport_html_azgovviz](Doc/images/capture_rapport_html_azgovviz.PNG )

Lien : https://webapp-azgovviz-001.azurewebsites.net/AzGovViz_35fb9e66-b21f-42a0-bfc2-8a390a026b5c.html


## Restreindre accès au site web

Pour intéragir avec la plateforme d'identité Microsoft, Microsoft Entra ID doit connaître le site web que vous créez. Ce tutoriel vous montre comment inscrire une application dans un locataire sur le Portail Azure.

### Inscrire le site web dans un locataire

Pour inscrire le site web dans Microsoft Azure Active Directory aka Microsoft Entra ID, appliquer le guide suivant :

- https://learn.microsoft.com/fr-ca/azure/active-directory/develop/web-app-tutorial-01-register-application

Comme URI de redirection, mettre https://webapp-azgovviz-001.azurewebsites.net/.auth/login/aad/callback


![1_inscription_site_web_azgovviz](Doc/images/1_inscription_site_web_azgovviz.PNG )

Le volet Vue d’ensemble de l’application s’affiche une fois l’inscription terminée.

![inscription_application_azgovviz](Doc/images/inscription_application_azgovviz.PNG )


### Configurer jeton authentification

Pour s'authentifier a Microsoft Entra ID , le site web aura besoin d'un jeton

A partir de la vue d'ensemble, aller dans la section **Authentification** dans le panneau à gauche et cocher la méthode de génération des jetons dans la section **Octroi implicite et flux hybrides**


![jeton_access](Doc/images/jeton_access.PNG )

### Utiliser les identificateurs uniques du site web dans le pipeline

Revenir sur le volet Vue d’ensemble de l’application

Enregistrez l’ID de l’annuaire (locataire) et l’ID d’application (client) à utiliser dans le code source de votre application.

1. Copier ID d’application (client) et coller le comme contenu de la variable **idClientWebApp** dans le fichier de variable [common.yml](config\variables\common.yml)

    idClientWebApp: '9f59d363-9a47-475d-84fb-796bb417864e' #Identifiant de la web app dans Microsoft Entra ID aka Azure Active Directory

2. Copier ID de l’annuaire (locataire) et l'utiliser comme valeur dans le paramétre d'entrée **identifiantAnnuaireSiteWeb** , au lancement du pipeline [azgovviz.yaml](azgovviz.yml)

## Code source

Voici le lien vers le dossier contenant la documentation markdown , les scripts YAML et Bicep

[Utils/azgovviz/](../../)


### Liste des fichiers dans code source

| Fichier      | Rôle   | Emplacement    |
| ------------------- | ------ | ------------------ |
| azgovviz.yml | Pipeline qui permet de générer le rapport AzGovViz et le publier dans un site web statique    |  [/Utils/azgovviz/azgovviz.yml](azgovviz.yml)    |
| common.yml | Fichier qui contient les variables YAML globales    |   [/Utils/azgovviz/config/variables/common.yml](config/variables/common.yml)    |
| generation-rapport.yml | Pipeline de génération du rapport HTML AzGovViz    |  [/Utils/azgovviz/templates/generation-rapport.yml](/Utils/azgovviz/templates/generation-rapport.yml)   |
| deploy-rapport.yml | Pipeline de publication du rapport HTML AzGovViz dans un site web   |   [/Utils/azgovviz/templates/deploy-platform.yml](templates/generation-rapport.yml)    |
| deploy.bicep | Script bicep pour déployer des ressources dans cei-sel-dev    |    [/Utils/azgovviz/bicep/deploy.bicep](bicep/deploy.bicep)   |
| appinsights.bicep | Script Bicep pour déployer une ressource Application Insights associé au WebApp    |    [/Utils/azgovviz/modules/appinsights.bicep](bicep/modules/appinsights.bicep)   |
| appservice.bicep | Script Bicep pour déployer ressources Service App et WebApp    |    [/Utils/azgovviz/modules/appservice.bicep](bicep/modules/appservice.bicep)   |
| hostingplan.bicep | Script Bicep pour déployer une ressource Plan hébergement du site web    |   [/Utils/azgovviz/modules/hostingplan.bicep](bicep/modules/hostingplan.bicep)   |


## FAQ

### Erreur AADSTS50011

#### Contexte

![erreur_AADSTS50011](Doc/images/erreur_AADSTS50011.png)

#### Résolution

https://learn.microsoft.com/fr-ca/troubleshoot/azure/active-directory/error-code-aadsts50011-redirect-uri-mismatch

Ajouter l'URI https://webapp-azgovviz-001.azurewebsites.net/.auth/login/aad/callback dans la section **Authentification** de l'application dans Microsoft Entra ID.

## Annexes

* [Repos du script Powershell qui génère le output html](https://github.com/JulianHayward/Azure-MG-Sub-Governance-Reporting#azure-governance-visualizer-setup-guide)
* [Dépot git du script AzGovViz](https://github.com/JulianHayward/Azure-MG-Sub-Governance-Reporting.git)
