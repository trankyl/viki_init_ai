# Introduction
Documentation utile à l'interne pour le projet des zones d'accueil dans Azure et outils de tests et scénarios qui sont pertinents à l'interne.

## Structure

Le projet est structuré ainsi :
- **AnalyseEtPoc**: Notes prises dans le but d'en apprendre plus sur certains projets. Peut contenir des brouillons et n'est pas nécessairement formaté
  - *Sujet 1 (dossier)*
    - *notesSujet1.md*
- **Documentation (dossier) :** Documentation officielle, qui peut être créée à partir des notes mais plus claire et formatée.
  - *Sujet 1 (dossier)*
    - *docSujet1.md*
- **Tests (dossier)**: Plan de tests pour les releases
- **Utils (dossier)** contient des outils, pipeline, scripts, scénario, tests qui sont utiles pour l'équipe du CEI.