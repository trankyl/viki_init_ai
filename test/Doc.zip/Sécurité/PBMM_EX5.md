# Contrôles de sécurité  pour l'exigence 5

05 : Déterminer la localisation des données

![EX123](../images/ex5.jpg)

[Lien document](https://www.oracle.com/cloud/cloud-regions/data-regions/#northamerica)

[Retour à la liste des exigences](OCI_12_exigences.md)
