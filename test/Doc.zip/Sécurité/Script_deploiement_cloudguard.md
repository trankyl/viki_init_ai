# Script de configuration du pare-feu CloudGuard :
Ce script configure les ressources nécessaires sur OCI pour une instance CloudGuard, y compris un groupe de sécurité avec des règles d'entrée et de sortie spécifiques, et une instance avec un volume de démarrage, une source d'image, des métadonnées et une configuration réseau.

1. Configuration du provider :

```
provider "oci" {
  tenancy_ocid       = var.tenancy_ocid
  user_ocid          = var.user_ocid
  fingerprint        = var.api_fingerprint
  private_key_path   = var.api_fingerprint
  region             = var.region
}
```

Cette section configure le provider OCI pour Terraform. On spécifie les informations d'authentification et de connectivité nécessaires, telles que l'OCID (Oracle Cloud Identifier), l'OCID de l'utilisateur, l'empreinte API, le chemin de la clé privée et la région souhaitée.

2. Configuration du groupe de sécurité CloudGuard :

```
   resource "oci_network_security_security_groups" "cloudguard" {
     compartment_id = var.compartment_ocid
     vcn_id         = var.vcn_ocid
     display_name   = var.cg_display_name

     ingress_security_rules {
       protocol = "6"  # TCP
       tcp_options {
         destination_port_range {
           min = 22
           max = 22
         }
       }
       source = "0.0.0.0/0"
     }
     egress_security_rules {
       protocol     = "all"
       destination  = "0.0.0.0/0"
     }
   }
   ```
Cette section définit une ressource de groupe de sécurité pour CloudGuard. On spécifie l'ID du compartiment, l'ID du réseau cloud virtuel (VCN) et un display name pour le groupe de sécurité. On configure également les règles d'entrée pour autoriser le trafic TCP entrant sur le port 22 (SSH) à partir de n'importe quelle adresse IP source (0.0.0.0/0), et les règles de sortie pour autoriser tout le trafic sortant vers n'importe quelle adresse IP de destination (0.0.0.0/0).

3. Configuration de l'instance CloudGuard :

```
   resource "oci_core_instance" "cloudguard" {
     compartment_id        = var.compartment_ocid
     availability_domain   = var.availability_domain
     display_name          = var.cg_instance_display_name
     shape                 = var.instance_shape
     subnet_id             = var.subnet_id

     boot_volume {
       display_name        = "CloudGuard-Boot-Volume"
       size_in_gbs         = var.boot_volume_size
     }
     source_details {
       source_type         = "image"
       source_id           = var.image_ocid
     }

     metadata = {
       "installation_type" = "CloudGuard"
       "admin_user"        = var.cg_admin_username
       "admin_password"    = var.cg_admin_password
     }

     network_interface {
       subnet_id           = var.subnet_ocid
       security_group_ids  = [oci_network_security_security_groups.cloudguard.id]
     }
   }
   ```

Cette section définit une ressource d'instance OCI pour CloudGuard. On spécifie l'ID de compartiment, le domaine de disponibilité, le display name, le type d'instance, l'ID de sous-réseau et d'autres détails de configuration pour l'instance.

On définit également un boot volume pour l'instance, en spécifiant le display name et la taille en giga-octets. Les détails de la source indiquent qu'une image sera utilisée pour créer l'instance, avec l'OCID de l'image fourni par la variable `var.image_ocid`.

La section meta data fournit une configuration supplémentaire pour l'instance CloudGuard, comme le type d'installation, le nom d'utilisateur et le mot de passe de l'administrateur.

Enfin, la section relative à l'interface réseau spécifie l'ID du sous-réseau et associe à l'instance le groupe de sécurité défini précédemment.
