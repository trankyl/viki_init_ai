# Bootstraop de la Zone d'Accueil

Ce module est conçu pour fonctionner pour [GCP ZA](https://bitbucket.org/sourcedgroup/gcp-foundations-live-infra).

Ce module forunit:
- Projet Bootstrap
- Compte service pour déployer l'infrastructure de ZA
- Attribution de rôles dans SA
- Buckets pour stocker l'état de Terraform
- Permission de bucket pour un usager de téléverser l'état de Terraform de Bootstrap


<!-- BEGINNING OF PRE-COMMIT-TERRAFORM DOCS HOOK -->
## Entrées

| Nom                               | Description                                                                                                                                                | Type | Défaut                      | Requis |
|-----------------------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------|------|-----------------------------|:------:|
| additional\_user\_defined\_string | String aditionnel défini par l'usager                                                                                                                      | `string` | `""`                        |   no   |
| billing\_account                  | ID de compte de facturation                                                                                                                                | `string` | n/a                         |  oui   |
| bootstrap\_email                  | Courriel d'usager me@domain.com ou de group:us@domain.com pour demander des permissions de téléverser l'état à bucket une fois que le projet aura été créé | `string` | n/a                         |  oui   |
| default\_region                   | n/a                                                                                                                                                        | `string` | `"northamerica-nonrtheast1"` |   non   |
| department\_code                  | Code pour département, partie du module de nommage                                                                                                         | `string` | n/a                         |  oui   |
| environment                       | S-Sandbox P-Production Q-Quality D-development                                                                                                             | `string` | n/a                         |  oui   |
| location                          | Endroit pour placement de nommage et ressource                                                                                                             | `string` | `"northamerica-northeast1"` |   non   |
| org\_id                           | ID pour l'organisation de créer le compte de déploiement                                                                                                   | `string` | n/a                         |  oui   |
| owner                             | Division ou groupe responsable pour l'engagement de sécurité et de finance                                                                                 | `string` | n/a                         |  oui   |
| parent                            | Dossier ou organisation dans lequel doit être mis le projet                                                                                                | `string` | n/a                         |  oui   |
| sa\_org\_iam\_permissions         | Liste de permissions attribuées au compte service de Terraform à travers de l'organisation GCP                                                             | `list(string)` | `[]`                        |   non   |
| services                          | Liste de services à activer dans le projet de bootstrap requis pour utiliser leurs APIs.                                                                   | `list(string)` | n/a                         |  oui   |
| set\_billing\_iam                 | Désactiver pour tests unitaires comme SA est un usager de facturation. Administrateur de facturation est obligatoire.                                      | `bool` | `true`                      |   non   |
| terraform\_deployment\_account    | Nom de compte service                                                                                                                                      | `string` | n/a                         |  oui   |
| tfstate\_buckets                  | Dictionnaire de buckets dans lesquels stockent les fichiers d'état de Terraform                                                                            | <pre>map(<br>    object({<br>      name          = string,<br>      labels        = optional(map(string)),<br>      force_destroy = optional(bool),<br>      storage_class = optional(string),<br>    })<br>  )</pre> | n/a                         |  oui   |
| user\_defined\_string             | String défini par l'usager                                                                                                                                 | `string` | n/a                         |  oui   |
| yaml\_config\_bucket              | Dictionnaire avec paramètres de configuration de bucket                                                                                                    | <pre>object({<br>    name          = string,<br>    labels        = optional(map(string)),<br>    force_destroy = optional(bool),<br>    storage_class = optional(string),<br>  })</pre> | n/a                         |  oui   |
| yaml\_config\_bucket\_writers     | Liste de groupes/SA/usagers dans la forme d'usage:me@domain.com                                                 | `list(string)` | `[]`                        |   non   |

## Sorties

| Nom                     | Description |
|-------------------------|-------------|
| project\_id             | n/a |
| service\_account\_email | n/a |
| tfstate\_bucket\_names  | n/a |
| yaml\_config\_bucket    | n/a |

<!-- END OF PRE-COMMIT-TERRAFORM DOCS HOOK -->