# Scénario de déploiement de la zone d'accueil OCI sans pare-feu et configuration manuelle d'un pare-feu CheckPoint CloudGuard

L'objectif de cette documentation est de fournir les prérequis et les étapes pour le déploiement automatique d'une zone d'accueil OCI (Oracle Cloud Infrastructure) sans pare-feu.

Puis, dans ladite zone d'accueil, nous irons ajouter manuellement un pare-feu CheckPoint CloudGuard .

Au menu :

* [Prérequis](#prérequis "Prérequis pour le déploiement du pare-feu Fortigate")
* [Déploiement de la zone d'accueil Oracle sans pare-feu](#déploiement-de-la-zone-daccueil-oracle-sans-pare-feu)
* [Options de déploiement du pare-feu CheckPoint CloudGuard](#options-de-déploiement-du-pare-feu-checkpoint-cloudguard)
* [Conditions préalables pour le déploiement du pare-feu CheckPoint CloudGuard](#conditions-préalables-pour-le-déploiement-du-pare-feu-checkpoint-cloudguard)
* [Déploiement de CheckPoint CloudGuard depuis Oracle Cloud Marketplace ](#déploiement-de-checkpoint-cloudguard-depuis-oracle-cloud-marketplace)
* [Configuration du pare-feu CloudGuard](#configuration-du-pare-feu-cloudguard)
* [Accueil](../../README.md "Retour à la page d'accueil")

---

## Prérequis

* Pour déployer automatiquement une zone d'accueil OCI *sans* pare-feu
* Pour déployer manuellement un pare-feu CheckPoint CloudGuard  dans une zone d'accueil OCI

Vous devez [remplir les mêmes conditions](PreRequis.md) pour un déploiement automatique d'une zone d'accueil OCI *avec* un pare-feu CloudGuard CheckPoint.

---

## Déploiement de la zone d'accueil Oracle sans pare-feu

Afin de déployer une zone d'accueil OCI sans pare-feu, vous devez configurer une pile (*stack*) dans Oracle Resource Manager (ORM).
Pour ce faire, suivez le guide de déploiement dans la page [Deploi_Script.md](Deploi_Script.md),

à l'exception de l'écran 11, à l'étape 7, où vous devez :

* Cochez *Utiliser le réseau virtuel infonuagique de la zone démilitarisée pour y déployer des pares-feux tiers ?* , et
* Décochez ```Déployer un pare-feu Fortigate dans la zone démilitarisée ?```.
* Déployez deux (2) sous-réseaux dans la zone démilitarisée (DMZ) et non quatre.

![Déployez deux sous réseaux ](../images/cloudguard/decocher_use_fortigate.png)

---

## Options de déploiement du pare-feu CheckPoint CloudGuard

Vous pouvez déployer une architecture de pare-feux en utilisant l'une des trois approches suivantes :

1. Importer un [script Terraform dans une pile (*stack*) Oracle Resource Manager](https://github.com/oracle-quickstart/oci-check-point/tree/172e840e8c0da7ec5c6c3dc29a4ac073d3ea47ad/cis-landing-zone#deploy-using-oracle-resource-manager).
2. Utiliser un script avec ligne de commande [Terraform CLI](https://github.com/oracle-quickstart/oci-check-point/tree/172e840e8c0da7ec5c6c3dc29a4ac073d3ea47ad/cis-landing-zone#deploy-using-the-terraform-cli).
3. Utiliser une image CheckPoint CloudGuard  depuis la place de marché (*Marketplace*) d'Oracle Cloud.

Référence : https://github.com/oracle-quickstart/oci-check-point/tree/172e840e8c0da7ec5c6c3dc29a4ac073d3ea47ad/cis-landing-zone

Dans notre scénario, nous allons déployer deux pare-feux par le biais d'Oracle Cloud Marketplace.

---

## Conditions préalables pour le déploiement du pare-feu CheckPoint CloudGuard

Pour effectuer les étapes décrites dans ce guide, vous devez remplir les conditions préalables suivantes :

- Vous disposez d’une location dans Oracle Cloud Infrastructure.
- Vous devez avoir accès à Oracle Cloud Marketplace pour télécharger le pare-feu Check Point CloudGuard. Vous pouvez éventuellement stocker l’image dans votre stockage d’objets (par exemple, dans us-ashburn-1).
- Vous connaissez les termes suivants d’Oracle Cloud Infrastructure : domaine de disponibilité, bucket, compartiment, image, instance de machine virtuelle , paire de clés, région, forme, location et réseau virtuel infonuagique ( VCN ).

Votre architecture doit avoir les composants suivants :

- Avoir 1 réseau cloud virtuel (appelons le VCN). ( par exemple 1 VCN avec le bloc CIDR 10.0.0.0/16 ).
- Avoir 1 sous-réseau public frontal dans le VCN .  (Ex. - 10.0.0.0/24)
- Avoir 1 sous-réseau privé BackEnd dans le VCN  (Ex. - 10.0.1.0/24)

*Facultatif* : Chaque sous-réseau peut être placé dans le même VCN ou chacun dans son propre VCN indépendant.

- Une adresse IP d'un sous-réseau public et une passerelle Internet sur le réseau cloud virtuel VCN sont requis pour rendre l'instance CloudGuard accessible à partir d'Internet.

## Déploiement de CheckPoint CloudGuard depuis Oracle Cloud Marketplace

Deux instances CloudGuard CheckPoint seront déployées dans la zone d'accueil OCI.

Pour le déploiement de chacune des instances, suivre les étapes suivantes :

1- Accédez au site Web d'Oracle Cloud Marketplace : <http://cloud.oracle.com/marketplace>.
2- Cliquez sur **Se connecter**, en haut de la page Oracle Cloud Marketplace.
3- Entrez le nom d'utilisateur et le mot de passe de votre compte Oracle.
4- Cliquez sur **Se connecter**.

![page-accueil-oci-marketplace](../images/fortigate/marketplace/page-accueil-oci-marketplace.png)

5- Dans la barre de recherche, tapez **check point**.

![recherche_cloudguard](../images/cloudguard/marketplace/recherche_checkpoint.png)

6- Sélectionnez l'image *payante* de ```CloudGuard Next-Gen Firewall /w Threat Prevention - 1 OCPU```.

**Note** : Le choix d'une image avec l'option Payant est propre à notre situation de test, vous devez donc revoir votre gestion de licence.

Une page Web *CloudGuard Next-Gen Firewall /w Threat Prevention - 1 OCPU* s'affiche.

![page_web_CloudGuard_NextGen_Firewall](../images/cloudguard/marketplace/page_web_CloudGuard_NextGen_Firewall.png)


7- Dans cette page Web, sélectionnez ```R81.20_rev1.0 (02/03/2023) - valeur par défaut``` dans la liste déroulante ```Version```.

**Note** : La version (R81.20_rev1.0) avec licence payante de l'image 'CloudGuard CheckPoint' choisie est juste à titre indicatif, vous devez choisir la version qui répond à vos objectifs.

8- Dans le champ compartiment, sélectionnez ```cmp-ceiza-checkpoint``` dans le compartiment englobant.

9- Cochez la case ```J'ai pris connaissance des Conditions d'utilisation d'Oracle et des Conditions générales de partenariat, et je les accepte.```.

10- Cliquez sur le bouton ```Lancer l'instance```.

![4_choix_parametre_deploiement_fortigate-Gen_Firewall](../images/cloudguard/marketplace/4_choix_parametre_deploiement_cloudguard.png)

La page Web *Créer une instance de calcul* s'affiche.

11- Dans le champ Nom, donnez un nom à votre instance CloudGuard de Check Point.
12- Dans le champ Créer dans le compartiment, sélectionnez le compartiment dans lequel sera déployé le pare-feu.

![5_selectionner_compartiment_2](../images/cloudguard/marketplace/5_selectionner_compartiment_2.png)

Par défaut, ORM choisit le meilleur domaine de panne et de disponibilité. Dans la capture d'écran, c'est AD 1 qui a été sélectionné.

Vous pouvez manuellement définir un domaine de disponibilité (AD 1) pour la première instance CloudGuard de Check Point.

Par exemple , la deuxième instance CloudGuard de Check Point sera déployée dans un domaine de disponibilité différent (AD 3).

13- Dans la section *Placement*, cliquez sur ```Afficher les options avancées``` et dans la liste déroulante ```Domaine de pannes```, sélectionnez ```FAULT-DOMAIN-1```.

![4_2_domaine_disponibilite](../images/cloudguard/marketplace/4_2_domaine_disponibilite.png)

Pour la deuxième instance CloudGuard de Check Point, sélectionnez ```FAULT-DOMAIN-3``` dans la liste déroulante.

14- Dans la section **Image et forme**, vous pouvez changer la configuration pour les instances . Pour le faire , cliquez sur le bouton **Change Shape**.

**Note** : La configuration pour les instances ci-dessous (OCPU, forme, mémoire vive) vise à répondre à des besoins de tests seulement et est juste à titre indicatif. Vous devez donc choisir une configuration des instances répondant à vos objectifs de traitement.

Dans la nouvelle boite de dialogue à droite, choisissez le nombre de OCPU ( Exemple : ```4 OCPU``` ) et taille de la de mémoire vive ( Exemple : ```64 GB```) .

![4_3_shape_vm_1_ocpu_16_gb](../images/cloudguard/marketplace/4_3_shape_vm_1_ocpu_16_gb.PNG)

Cliquez sur le bouton ```Sélectionner une forme``` pour valider vos choix.

**Note** : Assurez-vous que le nombre de OCPU sélectionné correspond aux critères de la licence payante en cours.


Allez plus bas à la section *Fonctions de réseau* de la page Web en cours.


15- Dans la section *Réseau principal*, cochez l'option ```Sélectionner un réseau cloud virtuel existant```, puis sélectionnez le réseau virtuel infonuagique qui hébergera le pare-feu.

16- Dans la section *Sous-réseau*, cochez l'option ```Sélectionner un sous-réseau existant```, puis sélectionnez le sous-réseau frontal ou Backend qui hébergera le pare-feu.

17- Dans la section *Adresse IP publique*, cochez l'option ```Affecter une adresse IPv4 publique```.

L'affectation d'une adresse IP publique rend cette instance accessible à partir d'Internet. Si vous n'êtes pas certain d'avoir besoin d'une adresse IP publique, vous pourrez en affecter une ultérieurement.

![5_adresse_ip_3](../images/cloudguard/marketplace/5_adresse_ip_3.png)

18- Dans la section *Ajouter des clés SSH*, cochez l'option ```Coller des clés publiques```, puis copier-coller votre clé SSH dans le champ ```Clés SSH```.

![5_cle_ssh_4](../images/fortigate/marketplace/5_cle_ssh_4.png)

La page des [Prérequis.md](PreRequis.md) décrit les étapes pour générer cette clé SSH.

19- Dans la section *Volume d'initialisation*, cochez l'option ```Indiquer une taille personnalisée de volume d'initialisation```, saisissez la ```Taille du volume d'initialisation``` et définissez le nombre de ```VPU```.

![5_volume_initialisation_5](../images/fortigate/marketplace/5_volume_initialisation_5.png)

Une fois le formulaire rempli, vous avez deux options :

* Cliquer sur le bouton ```Créer``` pour déployer le pare-feu.
* Cliquer sur le bouton ```Enregistrer en tant que pile``` pour enregistrer la ressource en tant que pile Terraform réutilisable visant à créer une instance à l'aide de Oracle Resource Manager (ORM).

Cliquez sur le bouton ```Créer``` et le pare-feu sera déployé.

![6_pare_feu_deploye](../images/cloudguard/marketplace/6_pare_feu_deploye.png)

**Note** : Si lors de la tentative de création , vous avez l'alerte suivante :
![alerte_requested_volume](../images/cloudguard/marketplace/alerte_requested_volume.png)

Veuillez revenir à l'étape 19 et modifier la ```Taille du volume d'initialisation```.

![modif_taille_volume_initialisation_100_gb](../images/cloudguard/marketplace/modif_taille_volume_initialisation_100_gb.png)


Répétez les étapes 1 à 19 pour déployer dans le sous-réseau (représentant votre ) Backend , la seconde instance CloudGuard **CheckPoint-CloudGuard-2** , du cluster.


## Configuration du pare-feu CloudGuard

Une fois que vous avez déployé l'infrastructure de pare-feux, vous devez vous assurer que votre configuration est correctement appliquée sur les pare-feux CloudGuard et l'ajuster en fonction de vos [besoins](../Architecture/Architecture.md).

Vous pouvez gérer un pare-feu CloudGuard  par plusieurs moyens :

- En tant que configuration autonome dans laquelle le pare-feu CloudGuard a sa propre gestion.
- Gestion centralisée, où le serveur de gestion est situé sur site en dehors du réseau virtuel infonuagique.
- Gestion centralisée, où le serveur de gestion est situé sur Internet , dans le même réseau virtuel.

Nous allons configurer chacun des 2 pare-feux CloudGuard en utilisant le portail Check Point Gaia

1. Ouvrez un client SSH.

2.  Utiliser les informations suivantes pour vous connecter à votre instance CloudGuard
    - username: admin
    - cluster-member-publicip : Adresse IP publique de chaque instance CloudGuard

    ![1_copier_adresse_ip_cloudguard](../images/cloudguard/marketplace/1_copier_adresse_ip_cloudguard.png)

    - id_rsa : le fichier ayant la clé privée correspondante à la clé publique que vous avez utilisée Lorsque vous avez créé l’instance CloudGuard

    **Note** : Assurez-vous que l’autorisation du fichier de clé privée (id_rsa) est 600. Les clés doivent être lues en écriture uniquement par vous.

    Au besoin tapez d'abord la commande suivante pour définir la permission 600

        chmod 600 clesshcloudguard

 3. Connectez-vous aux deux instances CloudGuard avec la clé privée correspondant à la clé publique que vous avez utilisée Lorsque vous avez créé l’instance CloudGuard.

    $ ssh –i id_rsa admin@cluster-member-publicip

    **Note** : Assurez-vous que l’autorisation du fichier de clé privée (id_rsa) est 600. Les clés doivent être lues en écriture uniquement par vous afin que la commande ssh -i ne génère pas une exception.

![1_ssh -i success](../images/cloudguard/configuration/1_ssh_i_success.png)

4.  Saisir les commandes suivantes pour définir le mot de passe :

    > set user admin password
    > Saisir votre mot de passe *XXXXX*
    > save config
    > exit

![set_user_admin_password](../images/cloudguard/configuration/2_set_user_admin_password.png)




5. Utilisez un navigateur Web pour vous connecter aux  instances CloudGuard avec l’adresse IP publique de l'instance CloudGuard.


    https://cluster-member-publicip
    User name : admin
    Password: XXXXX

XXXXX étant le mot de passe défini à l'étape 4.

![3_premiere_connexion](../images/cloudguard/configuration/3_premiere_connexion.png)


Après avoir cliqué sur le bouton ```LOGIN``` , la page web ```GAiA Configuration Wizard``` s'affiche :

![3_blink](../images/cloudguard/configuration/3_blink.png)

6. Configurez les règles de sécurité dans chacune des instances du cluster CloudGuard.

---

[Retour à la Page d'accueil](../../README.md "Retour à la page d'accueil")
