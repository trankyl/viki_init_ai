# Contrôles de sécurité pour l'exigence 6

06 : Protéger les données au repos

Contrôles liés à l'exigence 06:
SC-12, SC-13, SC-17,SC-28, SC-28(1)

## < --- Contrôle EX6_SC-12--->

![EX6](../images/ex6_SC-12.PNG)

## Validation Contrôle EX6_SC-12

   1. Responsabilité fournisseur : Oui
   2. Commentaire : Un coffre-fort (*vault*) appelé 'CEI02-vault' est créé à l'intérieur du compartiment 'cmp-sejou-002' par le script d'accueil. Ce coffre-fort contient une clé de chiffrement appelée 'CEI02-oss-key'.
   Trois compartiments sont créés par le script d'accueil. Ils sont tous les trois chiffrés avec cette clé. Tous les espaces de stockage devraient être créés de la même façon.
   Identité et sécurité --> Coffre
   Vérifier Cloud Guard (label = CIS_OCI_V1.1_OBJECTSTORAGE,ObjectStorage, ....).
   3. [Lien Document](https://docs.oracle.com/fr-ca/iaas/Content/KeyManagement/Concepts/keyoverview.htm)

## < --- Contrôle EX6_SC-13--->

![EX6](../images/ex6_SC-13.jpg)

## Validation Contrôle EX6_SC-13

   1. Responsabilité fournisseur : Oui
   2. Commentaire : Une vault(coffre) est créée à l'intérieur du compartiment 'cmp-sejou-002' par le script d'accueil.
      Identité et sécurité --> Coffre
      Identité et sécurité --> Certificats --> Autorités de certification
      stockage --> Stockage d'objets et stockage d'archives-->Clé de chiffrement
      stockage --> Volumes par blocs-->Chiffrement
      stockage --> Stockage de fichiers-->Chiffrement
   3. [Lien Document](https://docs.oracle.com/fr-ca/iaas/Content/KeyManagement/Concepts/keyoverview.htm)

## < --- Contrôle EX6_SC-17--->

![EX6](../images/ex6_SC-17.JPG)

## Validation Contrôle EX6_SC-17

   1. Responsabilité fournisseur : Oui
   2. Commentaire : L'information inactive est principalement déposée dans le stockage de type archives (*object storage*). Le contrôle consiste à vérifier le chiffrement des compartiments du stockage d'objets.
   3. [Lien Document](https://docs.oracle.com/fr-ca/iaas/Content/certificates/overview.htm)

## < --- Contrôle EX6_SC-28--->

![EX6](../images/ex6_SC-28.PNG)
  
## Validation Contrôle EX6_SC-28

   1. Responsabilité fournisseur : Oui
   2. Commentaire : L'information inactive est principalement déposée dans le stockage de type archives (*object storage*). Le contrôle consiste à vérifier le chiffrement des compartiments du stockage d'objets.
   3. [Lien Document](https://docs.oracle.com/fr-ca/iaas/Content/KeyManagement/Concepts/keyoverview.htm)

## < --- Contrôle EX6_SC28(1)--->

![EX6](../images/ex6_SC-28(1).PNG)

## Validation Contrôle EX6_SC28(1)

   1. Responsabilité fournisseur : Oui
   2. Commentaire : L'information inactive est principalement déposée dans le stockage de type archives (*object storage*). Le contrôle consiste à vérifier le chiffrement des compartiments du stockage d'objets.
   3. [Lien Document](https://docs.oracle.com/fr-ca/iaas/Content/KeyManagement/Concepts/keyoverview.htm)

[Retour à la liste des exigences](OCI_12_exigences.md)
