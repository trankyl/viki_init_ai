﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace Brain
{
    class Brain
    {

        public List<String> Premisses = new List<string>();
        public List<Char> llist_separateur = new List<Char> { '|' , ' ', '°' , '_', '-', '–', '!' , '[' , ']' , '.' ,'=' , '\\' , '/' , '(' , ')'
        , '{' , '}' , ':' , ';' , '?' , '\'' , '"', ',','>','<' , '\'' , '^' , '$' , '*' , '#','+','&','’','\f' , '%' , '’' ,'\r', '\t' , '\n' , '@' ,'$'};


        public List<String> gliste_association = new List<string>();
        public List<String> gliste_forme_abstraite = new List<string>();
        public List<String> gliste_reponse_cablee = new List<string>();



        public String lemplacement_reponse = "answer.mem";
        public String lemplacement_pattern = "pattern.mem";
        public String lemplacement_association = "association.mem";
        public bool EnMemoire = false;
        

        #region enumérations


        public enum eMapReduceMode
        {
            Parallele = 0
            , Serie = 1
        }


        public enum eMode
        {
            Parallele = 0,
            Serie = 1
        }


        public enum eTypeInformation
        {
            Pattern = 0
            ,
            ReponseCablee = 1
                , Association = 2
        }

        public enum eTypeCodage
        {
            Unicode = 0,
            Xml = 1
            , Html = 2
        }


        public enum eTypeAnalyse
        {
            InsertSeparateur = 0
            , Aucun = 1
        }

        public enum eTypeMondeReel
        {
            InclureNGramme = 0
            , UnGrammeUniquement = 1
        }

        public enum eTypeMemoire
        {
            MemoireACourtTerme = 0
            ,
            MemoireALongTerme = 1
                ,
            MemoireVive = 2
                , Internet = 3
        }

        public enum eMemoireDestination
        {
            MemoireVive = 0
            , MemoireCache = 1
        }

        public enum eTypeUnification
        {
            AvecMondeReel = 0
                ,
            AvecFichierXml = 1
                ,
            ApresUnificationDansFichier = 2
                , Aucun = 3
        }

        public enum eTypeDecoupage
        {
            ParCaractere = 0,
            ParMot = 1,
            ParNGramme = 2,
            ParNGrammeAvecEspaceCommeSeparateur = 3
            , ParContexte = 4
        }


        public enum eTypePerception
        {
            Temps = 0,
            Message = 1,
            Document = 2,
            Weather = 3,
            Battery = 4,
            Temperature = 5,
            Voice = 6,
            Oreille = 7,
            Screen = 8,
            Webcam = 9

        }

        #endregion


        #region XML


        public static HtmlAgilityPack.HtmlNode select_single_node(String pfile, String pxpath)
        {
            try
            {

                if (!File.Exists(pfile)) return null;

                var doc = new HtmlAgilityPack.HtmlDocument();
                doc.Load(pfile);
                var node = doc.DocumentNode.SelectSingleNode(pxpath);

                return node;
            }
            catch (Exception)
            {
                return null;
            }
        }


        #endregion





        public static String load_setting(String pnom_setting, ref Dictionary<String, String> gdict_setting, String pxpath = null)
        {
            try
            {

                String lstr_path = "";
                if (pxpath == null)
                    pxpath = "//" + pnom_setting;

                var lnode = Brain.select_single_node(Path.Combine(Directory.GetCurrentDirectory(), "setting.xml"), pxpath);
                if (lnode == null) ;
                else lstr_path = lnode.InnerText;

                if (gdict_setting.ContainsKey(pnom_setting.ToLower()))
                    gdict_setting.Remove(pnom_setting.ToLower());

                gdict_setting.Add(pnom_setting.ToLower(), lstr_path);


                return lstr_path;
            }
            catch (Exception)
            {
                return "";
            }
        }


        public void save_liste_dans_memoire_malt(eTypeInformation ptype_info = eTypeInformation.ReponseCablee)
        {
            try
            {
                if (ptype_info == eTypeInformation.ReponseCablee)
                {
                    if (gliste_reponse_cablee == null) goto resultat;

                    if (gliste_reponse_cablee.Count == 0) goto resultat;

                    if (String.IsNullOrEmpty(lemplacement_reponse))
                        lemplacement_reponse = Path.Combine(Directory.GetCurrentDirectory(), "memoire", "answer.mem");

                    gliste_reponse_cablee = Ensemble.intersect(gliste_reponse_cablee, gliste_reponse_cablee);

                    File.WriteAllLines(lemplacement_reponse, gliste_reponse_cablee.ToArray());
                }


            resultat:

                return;
            }
            catch
            {
            }
        }



        public static void serialiser(Dictionary<String, object> pmact, String pfichier_mact)
        {
            try
            {
                /*
                String lemplacemementmemoire = get_setting(Path.Combine(lsettingpath, "setting.xml"), "/setting/memoire");
                String lfichier_mact = Path.Combine(lemplacemementmemoire, String.Format(@"mact_session_{0}.bin", psession));
                 */

                BinaryFormatter lbf = new BinaryFormatter();
                FileStream lfs = File.Open(pfichier_mact, FileMode.OpenOrCreate);
                lbf.Serialize(lfs, pmact);
                lfs.Close();
                lbf = null;
            }
            catch (Exception)
            {
            }
        }


        public static void deserialiser(ref Dictionary<String, object> pmact, String pfichier_mact)
        {
            try
            {
                /*
                String lemplacemementmemoire = get_setting(Path.Combine(lsettingpath, "setting.xml"), "/setting/memoire");
                String lfichier_mact = Path.Combine(lemplacemementmemoire, String.Format(@"mact_session_{0}.bin", psession));
                 */

                BinaryFormatter lbf = new BinaryFormatter();
                FileStream lfs = File.Open(pfichier_mact, FileMode.OpenOrCreate);
                pmact = (Dictionary<String, object>)(lbf.Deserialize(lfs));

                lfs.Close();
                lbf = null;
            }
            catch (Exception)
            {
            }
        }



        public String decode(Char pconcept, eTypeCodage ptype_codage)
        {
            System.Text.StringBuilder sb = new System.Text.StringBuilder();
            int code = (int)pconcept;
            if (ptype_codage == eTypeCodage.Xml)
            {
                sb.Append("&#");
                sb.Append(code);
                sb.Append(';');
            }
            else //Unicode
            {
                sb.Append(code.ToString().PadLeft(4, '0'));
            }
            return sb.ToString();
        }


        public String decode(String pprecondition)
        {
            try
            {
                String lretval = null;

                lretval = decode(pprecondition, eTypeCodage.Xml);

                lretval = decode(lretval, eTypeCodage.Html);

                return lretval;
            }
            catch (Exception)
            {
                return null;
            }
        }

        public String decode(String pcontext, eTypeCodage ptype_codage = eTypeCodage.Xml)
        {
            pcontext = pcontext.Replace("�", "é");
            pcontext = pcontext.Replace("�", "à");

            List<Char> llist_caractere_accentue = new List<char>();

            llist_caractere_accentue.Add('œ');

            llist_caractere_accentue.Add('û');

            llist_caractere_accentue.Add('é');
            llist_caractere_accentue.Add('ç');
            llist_caractere_accentue.Add('â');
            llist_caractere_accentue.Add('à');
            llist_caractere_accentue.Add('ä');

            llist_caractere_accentue.Add('è');
            llist_caractere_accentue.Add('ê');

            llist_caractere_accentue.Add('ù');
            llist_caractere_accentue.Add('ô');
            llist_caractere_accentue.Add('ö');


            llist_caractere_accentue.Add('ü');
            llist_caractere_accentue.Add('ë');
            llist_caractere_accentue.Add('î');

            List<String> larr_separateur = new List<string>();

            foreach (Char lchar in llist_separateur)
                larr_separateur.Add(lchar.ToString());


            List<Char> lliste_caractere = new List<char>();

            for (int i12 = 0; i12 < 2000; i12++)
            {
                try
                {
                    lliste_caractere.Add((char)(i12));
                }
                catch (Exception)
                {

                }

            }
            String lretval = "";
            String lcode = "";
            int lascii_code;

            if (!llist_caractere_accentue.Contains('œ'))
                llist_caractere_accentue.Add('œ');

            if (!llist_caractere_accentue.Contains('û'))
                llist_caractere_accentue.Add('û');


            switch (ptype_codage)
            {
                case eTypeCodage.Xml:

                    foreach (String lstr in larr_separateur)
                    {
                        lascii_code = (int)lstr[0];
                        lcode = String.Concat("&#", lascii_code.ToString(), ";");
                        pcontext = pcontext.Replace(lcode, lstr);
                    }

                    foreach (Char lchar in llist_caractere_accentue)
                    {
                        lascii_code = (int)lchar;
                        lcode = String.Concat("&#", lascii_code.ToString(), ";");
                        pcontext = pcontext.Replace(lcode, lchar.ToString());
                    }

                    if (pcontext.Contains("&#"))
                    {
                        foreach (Char lchar in lliste_caractere)
                        {
                            lascii_code = (int)lchar;
                            lcode = String.Concat("&#", lascii_code.ToString(), ";");
                            pcontext = pcontext.Replace(lcode, lchar.ToString());
                        }

                        pcontext = pcontext.Replace("&#160;", " ");
                        pcontext = pcontext.Replace("&#37;", "%");

                    }
                    //code de correction
                    Char lchar2 = '\0';
                    for (int jj = 0; jj <= 9; jj++)
                    {
                        lchar2 = jj.ToString()[0];
                        lascii_code = (int)lchar2;
                        lcode = String.Concat("&#", lascii_code.ToString(), ";");
                        pcontext = pcontext.Replace(lcode, lchar2.ToString());
                    }

                    if (pcontext.Contains("&#"))
                    {

                        for (int lascii_code12 = 2000; lascii_code12 <= 9000; lascii_code12++)
                        {

                            lchar2 = (char)(lascii_code12);

                            // lchar2 = jj.ToString()[0];
                            //lascii_code = jj;
                            lcode = String.Concat("&#", lascii_code12.ToString(), ";");
                            pcontext = pcontext.Replace(lcode, lchar2.ToString());

                            if (!pcontext.Contains("&#"))
                                break;
                        }

                    }

                    break;

                case eTypeCodage.Html:

                    //pcontext = System.Net.we  System.Net.WebUtility.HtmlDecode(pcontext);
                    pcontext = pcontext.Replace("%20", " ");
                    pcontext = pcontext.Replace("%3F", "?");
                    pcontext = pcontext.Replace("%0A", " ");

                    pcontext = pcontext.Replace("&quot;", @"""");

                    pcontext = System.Net.WebUtility.HtmlDecode(pcontext);

                    pcontext = pcontext.Replace("%C3%A9", "é");
                    pcontext = pcontext.Replace("&eacute;", "é");
                    pcontext = pcontext.Replace("&egrave;", "è");
                    pcontext = pcontext.Replace("&ecirc;", "ê");
                    pcontext = pcontext.Replace("&icirc;", "î");
                    pcontext = pcontext.Replace("&ocirc;", "ô");
                    pcontext = pcontext.Replace("&ucirc;", "û");
                    pcontext = pcontext.Replace("&agrave;", "à");
                    pcontext = pcontext.Replace("&acirc;", "â");
                    pcontext = pcontext.Replace("&lt;", "<");
                    pcontext = pcontext.Replace("&gt;", ">");
                    pcontext = pcontext.Replace("&nbsp;", " ");
                    pcontext = pcontext.Replace("&deg;", "°");
                    pcontext = pcontext.Replace("&amp;", "&");
                    pcontext = pcontext.Replace("&middot;", ".");

                    //System.Net.h
                    //Str = Str.Replace("+", " ");
                    pcontext = Regex.Replace(pcontext, "%([A-Fa-f\\d]{2})", a => "" + Convert.ToChar(Convert.ToInt32(a.Groups[1].Value, 16)));


                    //foreach (Char lchar in llist_caractere_accentue)
                    //{

                    //    lascii_code = (int)lchar;
                    //    lcode = String.Concat("&#", lascii_code.ToString(), ";");
                    //    pcontext = pcontext.Replace(lcode, lchar.ToString());
                    //}

                    break;

            }

            lretval = pcontext;
            /*//extraillistere les séquences de caractères séparées par un espace
            List<String> llist_concept = this.explode(pcontext);
            foreach (String lconcept in llist_concept)
            {
                if (lconcept.IndexOf("&#") != 0)
                {
                    //séquence codée
                    lconcept = lconcept.Replace
                }
                else
                {
                    lretval += (String.IsNullOrEmpty(lretval.Trim())) ? lretval += lconcept : " " + lconcept;
                }
            }
            */
            return lretval;
        }



        public static Object restaurer_objet(String pfichier)
        {
            try
            {


                BinaryFormatter lbf = new BinaryFormatter();


                if (!File.Exists(pfichier))
                {


                    return null;
                }


                System.IO.FileStream lfs = File.OpenRead(pfichier);
                Object ldict2 = null;
                Stack<String> ltemp = null;
                try
                {

                    ldict2 = (Object)(lbf.Deserialize(lfs));



                    lfs.Close();




                }
                catch (Exception)
                {
                    lfs.Close();

                }

                return ldict2;

            }
            catch (Exception)
            {
                return null;
            }
        }


        public static Dictionary<String, Object> create_dictionary_from_string(String pprecondition, String pseparateur = "###")
        {
            try
            {

                Dictionary<String, Object> ldict_input = new Dictionary<string, object>();
                create_dictionary_from_string(pprecondition, ref ldict_input, pseparateur);

                return ldict_input;

            }
            catch (Exception)
            {
                return null;
            }
        }



        /// <summary>
        /// si j'intègre séparateur, je ne les sépares pluas par un espace
        /// </summary>
        /// <param name="penonce">énoncé à analyser</param>
        /// <param name="poption_analyse">option d'analyse. Aucun par défaut</param>
        /// <returns>Liste des concepts à l'issu de l'analyse morphologique</returns>
        public List<String> analyse_morphologique(String penonce, eTypeAnalyse poption_analyse = eTypeAnalyse.Aucun)
        {
            try
            {


                List<String> lretval = new List<string>();
                String lconcept = "";
                int i = 0;
                Char lcar = '\0';

                if (poption_analyse == eTypeAnalyse.Aucun)
                    return penonce.Split(llist_separateur.ToArray(), StringSplitOptions.RemoveEmptyEntries).ToList();
                else
                {

                    //foreach (Char lcar in penonce)
                    while (i <= penonce.Length - 1)
                    {
                        lcar = penonce[i];
                        if ((llist_separateur.Contains(lcar))
                            || (((int)lcar) == 146)
                            )
                        {
                            if (!String.IsNullOrEmpty(lconcept))
                                lretval.Add(lconcept);

                            if (!lcar.Equals(' '))
                                lretval.Add(lcar.ToString());


                            lconcept = String.Empty;
                        }
                        else
                        {
                            lconcept += lcar;
                            if (i == penonce.Length - 1)
                            {
                                if (!String.IsNullOrEmpty(lconcept))
                                    lretval.Add(lconcept);

                            }
                        }
                        i++;
                    }

                    return lretval;

                }

            }
            catch (Exception)
            {

                return null;
            }
        }



        /// <summary>
        /// 
        /// </summary>
        /// <param name="pchaine"></param>
        /// /// <remarks>
        /// quand pprecondition est très grand comme le contenu d'une page web, uniformiser prend du temps
        /// </remarks>
        /// <returns></returns>
        public String uniformiser(String pchaine)
        {
            try
            {
                String lretval = pchaine;
                // if (pchaine.Length > 50) return pchaine;

                List<String> lliste_concept = analyse_morphologique(pchaine, eTypeAnalyse.InsertSeparateur);

                lretval = String.Join(" ", lliste_concept.ToArray());


                return lretval;
            }
            catch (Exception)
            {
                return pchaine;
            }
        }




        public static void create_dictionary_from_string(String pprecondition, ref Dictionary<String, Object> ldict_input, String pseparateur = "###")
        {
            try
            {

                Brain lviki2 = new Brain();
                String lseparateur_uniformiser = lviki2.uniformiser(pseparateur);
                String[] larr_mot = null;

                if (pprecondition.Contains(lseparateur_uniformiser))
                    larr_mot = pprecondition.Split(new String[] { lseparateur_uniformiser }, StringSplitOptions.RemoveEmptyEntries);
                else
                    /*if (  lviki2.uniformiser(pprecondition).Contains(lseparateur_uniformiser))
                       // larr_mot = lviki2.uniformiser(pprecondition).Split(new String[] { lseparateur_uniformiser }, StringSplitOptions.RemoveEmptyEntries);
                        larr_mot = lviki2.uniformiser(pprecondition).Split(new String[] { pseparateur }, StringSplitOptions.RemoveEmptyEntries);
                    else*/
                    larr_mot = pprecondition.Split(new String[] { pseparateur }, StringSplitOptions.RemoveEmptyEntries);

                String lkey = "";
                String lvalue = "";
                foreach (String linput in larr_mot)
                {
                    try
                    {

                        lkey = linput.Split(new String[] { "=" }, StringSplitOptions.RemoveEmptyEntries)[0];
                        //parfois premisse= apparait 2 fois
                        lvalue = linput.Remove(0, String.Format(@"{0}=", lkey).Length);
                        //lvalue = linput.Replace(String.Format(@"{0}=" , lkey), "");

                        if (!ldict_input.ContainsKey(lkey.Trim().ToLower()))
                            ldict_input.Add(lkey.Trim().ToLower(), lvalue/*.Trim()*/ );

                    }
                    catch (Exception)
                    {

                    }
                }

            }
            catch (Exception)
            {

            }
        }


    }

    public class Neurone
    {


        public static void create_stimuli(String pnom_neurone, Object pstimuli, String pinput_memory)
        {
            try
            {

                Dictionary<String, Object> ldict_input = new Dictionary<string, object>();

                String lfichier_input = @"";

                pinput_memory = pinput_memory.Trim();

                if (!Directory.Exists(pinput_memory))
                    Directory.CreateDirectory(pinput_memory);


                lfichier_input = Path.Combine(pinput_memory, String.Format("input_{0}.inp", DateTime.Now.Ticks.ToString())); //.ToString("ddMMyyyyHms")));
                ldict_input.Clear();
                ldict_input.Add("precondition", pstimuli);
                Brain.serialiser(ldict_input, lfichier_input);

            }
            catch (Exception)
            {

            }
        }

    }

    public class Ensemble
    {


        /// <summary>
        /// !!! il faut que ce soit indéoentdant de lacasse du contenu
        /// !!! si operandes reel = poperande2 rell, poperande.clear vide le parameètre effectif entrant aal sortie
        /// </summary>
        /// <param name="poperande1"></param>
        /// <param name="poperande2"></param>
        /// <returns></returns>
        public static List<String> intersect(List<String> poperande11, List<String> poperande22)
        {
            try
            {

                List<String> poperande1 = new List<string>(poperande11.ToList());
                List<String> poperande2 = new List<string>(poperande22.ToList());



                List<String> lretval = new List<string>();
                IEnumerable<string> query2 = null;
                Brain lviki12 = new Brain();
                List<String> lliste_temp = new List<string>();

                try
                {
                    lliste_temp = poperande1.ToList();
                    poperande1.Clear();
                    foreach (String lelt in lliste_temp)
                        poperande1.Add(lelt.ToLower());


                }
                catch (Exception)
                {

                }


                try
                {
                    lliste_temp = poperande2.ToList();
                    poperande2.Clear();
                    foreach (String lelt in lliste_temp)
                        poperande2.Add(lelt.ToLower());


                }
                catch (Exception)
                {

                }
                /*
            poperande1 = poperande1.ConvertAll(elt1 => elt1.ToLower());
            poperande2 = poperande2.ConvertAll(elt1 => elt1.ToLower());
                */
                List<String> list_temp = null;
                if (poperande1.Count > poperande2.Count)
                {

                }
                else
                {
                    list_temp = poperande1.ToList();

                    //list_temp = new List<String>(Array.ConvertAll(poperande1.ToArray(), element => element.ToLower()));
                    //poperande1 = new List<String>(Array.ConvertAll(poperande2.ToArray(), element => element.ToLower()));

                    poperande1 = poperande2.ToList();
                    poperande2 = list_temp.ToList();
                    list_temp = null;
                }

                list_temp = new List<string>();

                //pour optimiser 
                if ((poperande1.Count == poperande2.Count)
                    && (String.Join("##", poperande1.ToArray()).ToLower().Equals(String.Join("##", poperande2.ToArray()).ToLower()))
                    )
                {
                    lretval = poperande1.Intersect(poperande2).ToList();
                    return lretval;
                }

                if (poperande1.Count > 1000)
                {
                    lretval = poperande1.Intersect(poperande2).ToList();
                    return lretval;
                }

                //list_forme1.Clear();
                int iii = 0;
                foreach (String lpremisse4 in poperande1)
                {
                    iii++;
                    if (iii >= 10000) break;
                    query2 = poperande2.Where(lpremisse12 =>
                             (
                                 lviki12.uniformiser(lpremisse12).ToLower().Equals(lviki12.uniformiser(lpremisse4).ToLower())
                             )
                             );
                    //lliste_forme_abstraite = query2.ToList();
                    list_temp.AddRange(query2.ToList());

                    //if (poperande2.Contains(lpremisse4))
                    //{
                    //    if (!list_temp.Contains(lpremisse4))
                    //        list_temp.Add(lpremisse4);
                    //}

                }

                list_temp = list_temp.Intersect(list_temp).ToList();

                if (list_temp.Count == 0) lretval = new List<string>();
                else lretval = list_temp.ToList();

                return lretval;

            }
            catch (Exception)
            {
                return new List<string>();
            }
        }


    }
}
