# Survol de l'implementation AVD dans la ZA 2.2.1

## Survol des repertoires

* azure-pipeline contient

  * Les 2 pipelines

    avd-common.yml : déploye l'infrastructure commune pour les instances AVD
    avd-instance1.yml : déploie une instance AVD
  * en dessous de config/variables/scenario-base: on retrouve ici le paramétrage AVD

    * cei-avd-var-common.yml: paramétrage commun
    * cei-avd-var-instance1.yml: paramétrage d'instance AVD
  * en dessous de templates/steps: on y retrouve les script de déploiement qui appellent la commande "az deployment" avec des paramètres spécifiques

    * deploy-spoke-avd-common.yml : deploie l'infrastructure commune
    * deploy-spoke-avd-instance1.yml: déploie l'instance AVD
* modules contient

  * avd/azureFilesDomainJoin.bicep : déploiement VM management et système fichiers fsLogix
  * carml: les modules de distribution de l'"AVD Accelerator" de Microsoft
* policies contient les définitions de stratégies et initiatives. ces définitions existent dans l'abonnement "common" et sont invoqués pour assignation dans les abonnements des instances.
* spokes contient les 2 script bicep de haut niveau

  * avd-common.bicep : déploie l'infrastructure commune
  * avd-instance1.bicep : déploie la solution AVD (une instance)

## Modalités de déploiement

Les "instances" AVD doivent être déployées dans leurs abonnements à part et séparés de l'abonnement "common". Mais quand on déploie une seule instance AVD on peut la déployer dans le même abonnement que common. Il s'agit des variable suivantes

* var-avd-common-subscriptionId: l'abonnement pour common
* var-avd-instance1-subscriptionId: l'abonnement pour une instance AVD

C'est possible d'utiliser le même abonnement pour la première instance AVD

Le déploiement AVD commence avec certains prerequis

- le déployement de la zone d'accueil Azure v2.2
- le déploiement d'un controlleur de domaine Active Directory dans Identité ou ailleurs
  (note: on peut aussi utiliser le AD-DC sur site, c'est du paramétrage)
- Provisionnement d'un domaine (si pas existant)
- La configuration du service DNS dans ce AD-DC y compris un DNS forwarder qui pointe vers l'adresse DNA Azure (168.63.129.16) et qui sert d'acheminer les requêtes DNS pour tout autre domaine que celui de l'AD-DC (pour le domaine pointer la résolution DNS de l'AD-DC vers lui même)
- La configuration d'une hierarchie OU (par défaut AVD/Session et AVD/Storage)
- Définir un usager avec permissions admin-domains (domadmin)
- Le paramétrage AVD (voir plus bas)

Aussi

* Configurer le routage reciproque entre la zone qui héberge le AD-DC et les plages d'adresse AVD (common et chaque instance)
* Permettre l'accès (NSG, C/F) entre l'AD-DC et les sous-réseaux AVD, pour DNS et les autres ports utilisés par Active Directory
* S'assurer que l'accès Internet est permis dans les abonnements AVD (des extensions en provenance de github sont déployées par les scripts)

La première pipeline à rouler par après est avd-common.yml suivie par avd-instance1.yml

## Paramétrage AVD

Au minimum il faut paramétrer les variables suivantes

* Les abonnements: var-avd-common-subscriptionId et var-avd-instance1-subscriptionId
* Les paramètres d'accès au niveau de la VM et du domaine

```
  var-avd-vm-local-user-name: nom usager admin VM AVD (défaut dans vargroup secret '$(AVD.VmLocalUserName)')
  var-avd-vm-local-User-password: mdp usager admin VM (défaut dans vargroup secret '$(AVD.VmLocalUserPassword)')
  var-avd-domain-join-user-name: usager admin domaine (défaut dans vargroup secret' $(AVD.DomainJoinUserName)')
  var-avd-domain-join-user-password: mdp admin domaine (dans vargroup secret '$(AVD.DomainJoinUserPassword)')

```

* var-avd-enterprise-objectid: un Object ID d'un Service Principal "Enterprise Application"
* var-avd-common-vnet-address et var-avd-common-snet-address : les plages d'adress du VNET et sous-réseau dans abonnement common (définir dans cei-avd-var-common.yml)
* var-avd-instance1-vnet-address et var-avd-instance1-snet-address : les plages d'adress du VNET et sous-réseau dans abonnement AVD instance (définir dans cei-avd-var-instance1.yml)
* var-avd-common-dnsservers (dans cei-avd-var-common.yml) et var-avd-instance1-dnsserver (dans cei-avd-var-instance1.yml) : un array, avec les adresses IP des controleurs de dommaine AD-DC de la grappe
* var-avd-vnet-adds (dans cei-avd-var-common.yml): la plage d'adresse du sous-réseau qui heberge l'AD-DC. Utilisé pour routage

Les VNRT "common" et "instance1" sont des "spoke" et sont peerés avec le hub. Le routage se fait via la VPN Gateway ou via une NVA dans le hub.

## Validation

Pour la validation on a utilisé les élements suivants

* Un déploiement ZA Azure "de base" (dans abonnements AZE_Mario_\*)
* Un abonnement à part pour le AD-DC (abonnement AZE_Mario_ADDS) avec un VNET (172.16.0.0/27) et une VM AD-DC y déployée
* Un abonnement dédié pour AVD (AZE_Mario_AVD)
* Configuré Bastion dans le hub pour pouvoir avoir accès aux VM

Le routage se fait via la VPN Gateway mais il faut le configurer manuellement pour le AD-DC, ainsi que les NSG au niveau du hub et sous-réseau AD0DC
